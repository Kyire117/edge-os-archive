# 执行报告 — c2c_connection_reliability_repair_v1 / Iteration 4

**状态：** EXECUTED_DIAGNOSIS；MCP 启动握手超时，独立复核待连接恢复  
**证据采集：** 2026-10-30 07:20:24 UTC  
**目标：** Codex with ChatGPT · EDGE OS 101  
**预期 workspace：** 47fec7b8248c / EDGE OS 101

## 结论

重开后 Codex 桌面端确实识别了 codex-with-chatgpt-edge-os-101@created-by-me-remote，并启动 edge-os-101 MCP server。失败发生在 **MCP 客户端启动握手阶段**：桌面日志多次记录“timed out handshaking with MCP server after 30s”，随后 app-tool discovery 失败。当前工具目录仍给目标集成分配 0 个工具。

因此当前证据不支持“桌面插件没安装/没启用”作为主要原因；也没有证据证明插件被项目信任策略排除或 manifest 被拒绝。codex plugin list 是 CLI marketplace 清单，目标 remote app plugin 不在其中；但桌面日志明确显示 app runtime 已尝试加载目标插件。两种清单不可混为一谈。

**精确故障阶段：** 已确认 MCP startup handshake 超时，早于可观察到的工具注册。日志没有暴露握手内层步骤，不能断定是 HTTP/TLS 建连、MCP initialize 请求还是响应超时。日志没有 notifications/initialized、tools/list 或 HTTP 状态码证据；authStatus=unknown 不是认证失败证据。

## 关键线索与限制

- 缓存包版本为 0.1.2；桌面日志未报告运行时版本，无法确认加载副本的确切版本号。
- 根 plugin.json 与 mcp.json 是有效 JSON，声明的 Agent Plugins 1.0.0 schema 标识匹配；结构检查通过。环境没有 JSON Schema 验证器，未声称完整形式验证。OpenAI 文档说明 root plugin.json/mcp.json 与 .codex-plugin 兼容布局：[插件打包文档](https://developers.openai.com/plugins/build/plugins)。
- 缓存 MCP URL 的 hostname 与已保存 workspace MCP endpoint 不同，其 scheme、port、path 和 query presence 相同。这是强线索但未证明因果；按任务限制，本轮没有更改 endpoint。
- 没有可用于该 app-managed server 的受支持直接 MCP initialize/tools/list 命令；没有自制客户端，也没有发送网络请求或认证材料。
- 之前的 C2C doctor/bridge 健康检查是历史证据，不等于本轮 MCP server 握手成功。

## 检查范围

读取/检查：

- 用户级 Codex 配置：C:\Users\Kyrie\.codex\config.toml
- 项目级 Codex 配置：C:\Users\Kyrie\Documents\EDGE OS 101\.codex\config.toml
- 全局应用状态 JSON 的顶层键名（只作注册线索检查）
- 缓存包 plugin.json、.codex-plugin/plugin.json、mcp.json、.mcp.json（不输出 URL 或 header 值）
- 保存的 workspace endpoint 元数据：C:\Users\Kyrie\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Local\codex-with-chatgpt\endpoints\47fec7b8248c.json（只比较组成部分，不记录原值）
- Codex 桌面日志：2026-10-30 的两个 codex-desktop 日志；只提取目标 plugin ID/server key 的时间、状态和脱敏错误
- Codex CLI 帮助、插件/MCP 清单、市场清单及当前 active tool catalog

没有运行 EDGE OS 产品测试，本任务仅做本机连接诊断。本轮只在此证据目录创建报告文件；未修改源代码、数据库、WAL/SHM、策略、endpoint、凭据、connector 或运行进程。

## 独立复核

复核材料已整理到此目录。由于目标 connector 当前没有可调用工具，不能通过目标连接把材料提交到原 ChatGPT 会话；未使用名称相似的集成代替。
