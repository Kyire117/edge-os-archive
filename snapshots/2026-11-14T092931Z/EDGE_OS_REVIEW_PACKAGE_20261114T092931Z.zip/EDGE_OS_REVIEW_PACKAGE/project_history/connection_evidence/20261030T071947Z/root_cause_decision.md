# 根因决策 — Iteration 4

## 观察到的事实

1. Codex 桌面日志包含目标 plugin ID codex-with-chatgpt-edge-os-101@created-by-me-remote，并记录 app-tool discovery 尝试；MCP server key edge-os-101 先 starting，随后 failed。
2. 多次失败的错误是 MCP startup handshake 超过约 30 秒；没有 server ready 记录。
3. 重开后的 active tool catalog 有 375 个定义、18 个 owner；目标 owner 仍为 0 个工具。
4. 项目 trust_level 为 trusted；项目配置没有插件排除项。目标插件不在 codex plugin CLI marketplace 清单，但桌面日志证明 app runtime 仍尝试该 remote integration。
5. 根 plugin.json 与 portable mcp.json 是有效 JSON，schema ID 与 Agent Plugins 1.0.0 一致；必需字段、类型和额外字段结构检查通过。环境没有 JSON Schema 验证器，因此这不是完整形式验证。
6. 当前已保存 endpoint 记录绑定预期 workspace ID。缓存 MCP 配置与保存记录的 scheme、port、path 和 query presence 相同，hostname 不同。
7. 日志里的 authStatus 为 unknown；没有明确认证错误、HTTP 状态、协议版本或 JSON-RPC 方法级结果。

## 根因判定

**已确认的直接故障：** MCP 客户端 startup handshake 超时，导致 app-tool discovery 失败，工具没有注册到活动目录。

**尚未确认的更深层原因：** endpoint hostname 漂移是当前最强线索，但日志不能区分 transport connect/TLS 与 MCP initialize，也没有受支持的独立协议调用来证明因果。不能把主机差异单独当成已证实根因。

## 阶段结论

| 阶段 | 判定 |
|---|---|
| 桌面插件发现 | 已观察到，日志包含目标 plugin ID |
| 显式禁用或项目策略排除 | 未见证据 |
| Manifest 加载/拒绝 | 启动已进入 MCP 阶段；未见 schema 拒绝 |
| MCP transport / initialize | 握手超时，内层子阶段不明 |
| notifications/initialized | 未证实 |
| tools/list | 未证实 |
| Codex 工具注册 | 未完成，目标 owner 为 0 工具 |

## 是否修复

没有改 endpoint、配置、connector 或 plugin。任务明确禁止只因 hostname 不同而改地址；也没有协议证据定位到 endpoint、认证或 provider。单纯提高启动超时可能掩盖故障，未实施。
