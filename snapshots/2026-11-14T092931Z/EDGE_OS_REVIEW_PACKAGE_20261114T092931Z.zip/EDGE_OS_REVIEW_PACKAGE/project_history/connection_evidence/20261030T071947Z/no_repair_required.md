# 本轮未实施修复

本轮确认存在缺陷：目标 MCP server 在桌面启动握手期间超时。未应用修复，因为：

- 当前日志没有拆分 transport 连接与 initialize 子阶段。
- 缓存配置与当前 workspace endpoint 的 hostname 不同，但没有直接证据证明它是超时原因；本轮约束禁止仅凭此差异更换地址。
- Codex CLI 没有该 app-managed server 的直接 initialize/tools/list 调用命令；没有自制客户端。
- 提高 30 秒启动超时会延后失败，不能证明修复根因。
- 未执行 GUI 操作、账号授权、connector 重建或 EDGE OS 操作。
