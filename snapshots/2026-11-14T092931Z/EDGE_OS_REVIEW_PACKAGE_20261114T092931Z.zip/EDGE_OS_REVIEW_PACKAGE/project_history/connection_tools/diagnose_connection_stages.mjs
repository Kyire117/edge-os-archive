import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

// Read-only diagnostics. No auth creation, repair, service control or raw URL logging.
const base='C:/Users/Kyrie/Documents/EDGE OS 101';
const checkout='C:/Users/Kyrie/codex-with-chatgpt';
const expected='47fec7b8248c';
const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d+Z$/,'Z');
const out=path.join(base,'execution_output','c2c_identity_handshake',stamp);
fs.mkdirSync(out,{recursive:true});
const read=p=>{try{return JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));}catch{return null;}};
const hash=s=>createHash('sha256').update(s).digest('hex');
const fileHash=p=>{try{return hash(fs.readFileSync(p));}catch{return null;}};
const endpoint=u=>{try{const x=new URL(u);return {scheme:x.protocol,host_fingerprint:hash(x.host),path_fingerprint:hash(x.pathname),url_fingerprint:hash(x.href)};}catch{return null;}};
const dirs=[path.join(process.env.LOCALAPPDATA||'','codex-with-chatgpt'),'C:/Users/Kyrie/AppData/Local/codex-with-chatgpt','C:/Users/Kyrie/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/codex-with-chatgpt'];
if(process.env.C2C_STATE_DIR)dirs.push(process.env.C2C_STATE_DIR);
const stateDirs=[...new Set(dirs.map(p=>path.resolve(p)))];
const snapshots=[];const inventory=[];const probes=[];
const save=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');
const rootPaths=[base,path.join(base,'polymarket-edge-mvp-fixed','polymarket-edge-mvp')];
const roots=rootPaths.map(p=>{const real=fs.realpathSync.native(p);return {root:real,computed_workspace_id:hash(real.toLowerCase()).slice(0,12),readme_exists:fs.existsSync(path.join(real,'README.md')),project_name:read(path.join(real,'.c2c.json'))?.name??null};});
const binding=read(path.join(base,'connection_tools','edge_os_identity_binding.json'));
if(!binding||binding.workspace_id!==expected||!roots.some(r=>r.computed_workspace_id===expected&&path.resolve(r.root)===path.resolve(binding.workspace_root)&&r.project_name===binding.workspace_name))throw new Error('WORKSPACE_IDENTITY_BINDING_MISMATCH');
for(const d of stateDirs){
 const record={state_dir:d,exists:fs.existsSync(d),records:[]};
 for(const folder of ['runtime','endpoints','sessions']){
  const p=path.join(d,folder,expected+'.json');const value=read(p);
  if(!value)continue;
  snapshots.push({path:p,sha256:fileHash(p)});
  const item={kind:folder,file:p,workspace_id:value.workspaceId??null,workspace_root:value.workspaceRoot??null,port:value.port??null,pid:value.pid??null,saved_at:value.savedAt??value.startedAt??null,endpoint:endpoint(value.mcpUrl??value.publicUrl),connector_name:value.connectorName??null};
  if(folder==='runtime') {try{process.kill(value.pid,0);item.pid_present=true;}catch(e){item.pid_present=e.code==='ESRCH'?false:null;}}
  // Only preserve a verified ChatGPT conversation URL, never arbitrary URL fields.
  const chat=value.conversation?.chatUrl??value.url;
  if(typeof chat==='string'&&/^https:\/\/chatgpt\.com\/(?:g\/[^?#]+\/)?c\/[a-z0-9-]+$/i.test(chat))item.chat_url=chat;
  record.records.push(item);
 }
 inventory.push(record);
}
const cache='C:/Users/Kyrie/.codex/plugins/cache/created-by-me-remote/codex-with-chatgpt-edge-os-101/0.1.2';
const manifests=[];const cachedUrls=[];
for(const name of ['plugin.json','.codex-plugin/plugin.json','mcp.json','.mcp.json']){
 const p=path.join(cache,name);const value=read(p);if(!value)continue;snapshots.push({path:p,sha256:fileHash(p)});
 const rawServers=value.mcpServers??value.servers??{};
 const servers=rawServers&&typeof rawServers==='object'&&!Array.isArray(rawServers)?rawServers:{};
 const serverRecords=Object.entries(servers).map(([key,v])=>{if(typeof v.url==='string')cachedUrls.push({label:'cached_'+name,url:v.url});return {key,transport:v.type??null,endpoint:endpoint(v.url),oauth_declared:!!v.oauth};});
 manifests.push({file:p,sha256:fileHash(p),name:value.name??null,version:value.version??null,mcp_config_reference:typeof rawServers==='string'?rawServers:null,servers:serverRecords});
}
const moduleBase=path.join(checkout,'node_modules/@modelcontextprotocol/sdk/dist/esm/client');
const {Client}=await import(pathToFileURL(path.join(moduleBase,'index.js')));
const {StreamableHTTPClientTransport}=await import(pathToFileURL(path.join(moduleBase,'streamableHttp.js')));
async function sdkProbe(label,url){
 const events=[];let firstError=null;let tools=null;let serverVersion=null;
 const client=new Client({name:'c2c-readonly-diagnostic',version:'1.0.0'},{capabilities:{}});
 const safeFetch=async(input,init={})=>{
  const begin=performance.now();let method=null;try{method=JSON.parse(init.body??'{}').method??null;}catch{}
  const event={at_utc:new Date().toISOString(),rpc_method:method,http_method:init.method??'GET'};
  try{
   const response=await fetch(input,{...init,redirect:'error',signal:AbortSignal.timeout(12000)});
   Object.assign(event,{status:response.status,duration_ms:Math.round(performance.now()-begin)});events.push(event);return response;
  }catch(e){Object.assign(event,{error_type:e.name,error_code:e.cause?.code??e.code??null,duration_ms:Math.round(performance.now()-begin)});events.push(event);throw e;}
 };
 const transport=new StreamableHTTPClientTransport(new URL(url),{fetch:safeFetch});
 const start=performance.now();
 try{await client.connect(transport,{timeout:15000});serverVersion=client.getServerVersion();tools=(await client.listTools({}, {timeout:15000})).tools.map(t=>({name:t.name,inputSchema:t.inputSchema}));}
 catch(e){firstError={type:e.name,code:e.code??null,classification:events.some(x=>x.status===401)?'AUTH_REQUIRED_NO_CREDENTIALS_USED':events.some(x=>x.error_type)?'TRANSPORT_FAILURE':'PROTOCOL_OR_RESPONSE_FAILURE'};}
 finally{try{await client.close();}catch{}}
 return {label,endpoint:endpoint(url),elapsed_ms:Math.round(performance.now()-start),events,first_error:firstError,server_version:serverVersion,tools,authenticated:false};
}
// Probe recorded URLs without credentials; redirects are forbidden.
const targets=[];
for(const d of stateDirs){
 const runtime=read(path.join(d,'runtime',expected+'.json'));
 if(runtime?.workspaceId===expected&&Number.isInteger(runtime.port)&&runtime.port>0&&runtime.port<65536){
  const start=performance.now();let health=null;let err=null;
  try{const response=await fetch('http://127.0.0.1:'+runtime.port+'/health',{redirect:'error',signal:AbortSignal.timeout(3000)});const data=await response.json();health={status:response.status,service:data.service,workspace_id:data.workspaceId,version:data.version};}
  catch(e){err={type:e.name,code:e.cause?.code??null};}
  probes.push({label:'local_health',state_dir:d,health,error:err,duration_ms:Math.round(performance.now()-start)});
  if(health?.workspace_id===expected&&health.service==='c2c-bridge')targets.push({label:'verified_local_mcp',url:'http://127.0.0.1:'+runtime.port+'/mcp'});
 }
 const ep=read(path.join(d,'endpoints',expected+'.json'));if(ep?.workspaceId===expected&&ep.mcpUrl)targets.push({label:'saved_endpoint',url:ep.mcpUrl});
}
targets.push(...cachedUrls);
const seen=new Set();
for(const t of targets){if(seen.has(t.url))continue;seen.add(t.url);try{const u=new URL(t.url);if(!['https:','http:'].includes(u.protocol)||u.username||u.password||u.search)continue;probes.push(await sdkProbe(t.label,t.url));}catch(e){probes.push({label:t.label,error_type:e.name});}}
const preservation=snapshots.map(s=>({...s,unchanged:fileHash(s.path)===s.sha256}));
save('identity_inventory.json',{captured_at_utc:new Date().toISOString(),expected_workspace_id:expected,roots,state_dirs:inventory,plugin_manifests:manifests,environment:{localappdata:process.env.LOCALAPPDATA??null,c2c_state_dir_override_present:!!process.env.C2C_STATE_DIR,http_proxy_present:!!process.env.HTTP_PROXY,https_proxy_present:!!process.env.HTTPS_PROXY,node_use_env_proxy:process.env.NODE_USE_ENV_PROXY==='1'},sdk_source:moduleBase});
save('handshake_stages.json',{probes,limits:'No credentials issued, copied, loaded or sent. A 401 stops authenticated protocol acceptance. No configuration or service changes.'});
save('preservation.json',{files:preservation,all_unchanged:preservation.every(s=>s.unchanged)});
console.log(JSON.stringify({evidence_directory:out,roots,probe_summary:probes.map(p=>({label:p.label,health:p.health,error:p.error,events:p.events,first_error:p.first_error})),all_configuration_files_unchanged:preservation.every(s=>s.unchanged)},null,2));
