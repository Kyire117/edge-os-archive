"""Build a bounded review-only source bundle; never opens application databases."""
from pathlib import Path
from datetime import datetime, timezone
import os, json, hashlib, shutil, subprocess, zipfile, stat

BASE=Path(r'C:\Users\Kyrie\Documents\EDGE OS 101')
REPO=BASE/'polymarket-edge-mvp-fixed'/'polymarket-edge-mvp'
STAMP=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT=BASE/'outputs'/'transfer'/STAMP
STAGE=OUT/'EDGE_OS_REVIEW_PACKAGE'
STAGE.mkdir(parents=True,exist_ok=False)
files={};skipped=[];total=0
MAX_RAW=600_000_000
DENY_SUFFIX={'.db','.sqlite','.sqlite3','.backup','.db-wal','.db-shm','.db-journal','.pyc','.pyo','.zip','.7z','.log','.jsonl','.png','.jpg','.jpeg','.webp','.mp4'}
def allowed(p):
 n=p.name.lower()
 return not any(n.endswith(s) for s in DENY_SUFFIX) and not any(s in n for s in ['.db-wal','.db-shm','.backup-'])
def walk(root):
 if not root.exists():return
 for folder,dirs,names in os.walk(root,followlinks=False):
  for d in dirs[:]:
   p=Path(folder)/d
   try: reparse=bool(p.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)
   except OSError:reparse=True
   if reparse or d in {'.git','.venv','node_modules','__pycache__','.pytest_cache','backups'} or d.startswith(('.tmp','.pytest','.tm','.repair','.sp_','.rr')) or d.startswith('test_') or any(x in d for x in ['tests_tmp','full_tmp','pytest-temp','pytest_temp','temporary_test','basetemp']):dirs.remove(d)
  for n in names:yield Path(folder)/n
def add(src,dest,limit=None):
 global total
 if not allowed(src):return
 if str(dest).replace('\\','/') in files:return
 try:
  size=src.stat().st_size
  if limit and size>limit:skipped.append({'path':str(src.relative_to(BASE)),'reason':'per_file_limit','bytes':size});return
  if total+size>MAX_RAW:skipped.append({'path':str(src.relative_to(BASE)),'reason':'package_budget','bytes':size});return
  target=STAGE/dest;target.parent.mkdir(parents=True,exist_ok=True)
  before=src.stat();shutil.copy2(src,target);after=src.stat()
  if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise RuntimeError('SOURCE_CHANGED_DURING_COPY: '+str(src))
  digest=hashlib.sha256(target.read_bytes()).hexdigest()
  if digest!=hashlib.sha256(src.read_bytes()).hexdigest():raise RuntimeError('COPY_HASH_MISMATCH')
  files[str(dest).replace('\\','/')]={'bytes':size,'sha256':digest,'source':str(src)};total+=size
 except (PermissionError,FileNotFoundError) as e:skipped.append({'path':str(src),'reason':type(e).__name__})

# Include real working-tree sources, including untracked modifications.
for name in ['app','tests','scripts','.codex']:
 for p in walk(REPO/name):add(p,Path('project')/p.relative_to(REPO))
for p in REPO.iterdir():
 if p.is_file():add(p,Path('project')/p.name)
# Reference configuration only, no database snapshots or backup files.
for p in walk(REPO/'data'):
 if p.suffix.lower() in {'.json','.yaml','.yml','.toml','.ini','.txt'}:add(p,Path('project')/p.relative_to(REPO),2_000_000)
# Preserve executable helpers at their existing locations; bounded human-readable evidence.
for p in walk(REPO/'execution_output'):
 if p.suffix.lower() in {'.py','.ps1','.mjs','.js','.cmd','.bat','.sh','.md','.txt','.json','.diff','.patch','.csv'}:
  add(p,Path('project')/p.relative_to(REPO),2_000_000)
for name in ['data_log.md','C2C_CONNECTION_DIAGNOSIS_2026-09-26.md']:
 p=BASE/name
 if p.exists():add(p,Path('project_history')/name)
for p in walk(BASE/'connection_tools'):
 if p.suffix.lower() in {'.md','.json','.py','.mjs','.ps1','.js'}:add(p,Path('project_history')/'connection_tools'/p.relative_to(BASE/'connection_tools'),2_000_000)
for p in walk(BASE/'execution_output'/'c2c_connection_reliability_repair_v1'):
 if p.suffix.lower() in {'.md','.json','.diff'}:add(p,Path('project_history')/'connection_evidence'/p.relative_to(BASE/'execution_output'/'c2c_connection_reliability_repair_v1'),2_000_000)
for p in [BASE/'execution_output'/'c2c_stability_plan_20261031.md']:
 if p.exists():add(p,Path('project_history')/p.name)

git_results={}
for name,args in [('git_status.txt',['status','--short','--untracked-files=all']),('git_diff.patch',['diff','--no-ext-diff','--no-textconv','--binary','HEAD']),('git_commit.txt',['rev-parse','HEAD']),('git_branch.txt',['branch','--show-current'])]:
 r=subprocess.run(['git','--no-optional-locks',*args],cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (STAGE/'project_history'/name).write_bytes(r.stdout)
 git_results[name]={'exit_code':r.returncode,'stderr_bytes':len(r.stderr)}

readme='''# EDGE OS 项目主体审阅包

本包供另一台电脑上的AI阅读、分析与建立后续项目，不代表可直接恢复当前实验。

## 先读顺序
1. project/README.md、PRD.md、AI_RULES.md、SHARED_CASH_POOL.md。
2. project/data/active_experiment.json：仅为打包时配置副本，不证明服务正在运行。
3. project/app/、project/tests/、project/scripts/与根目录启动器。
4. project/execution_output/paper_trial_1u_execution_blocked_20261101/report.md（若存在）：区分代码已实现、测试通过与切换完成。
5. project_history/data_log.md：按时间理解历史决策和未解决问题。

## 内容与边界
- 复制的是当前磁盘工作树，包含未提交及未跟踪源码；git状态、HEAD差异和提交标识在project_history。
- 按用户要求没有进行脱敏；配置和精选证据保留原文，请按私人资料保管。
- 未打包数据库、WAL/SHM、备份、虚拟环境、Git对象、缓存、图片、JSONL、大型运行日志和大于单文件上限的证据。
- 完整实验数据未包含，因此不能独立复算所有历史交易/PnL或验证当前数据库状态。
- execution_output中的运行辅助代码保留原路径；该目录同时包含历史报告，不意味着各报告属于同一版本。
- 源码、README、活动配置可能来自不同演进阶段；请列出差异，不把较新的源码自动认定为已经部署。
- 此电脑的路径、代理和连接配对不能照搬；若未来运行，应另行配置并使用全新隔离模拟数据库。

## 给接收端AI的任务
先只读审阅此包：说明架构、策略、风控、数据真实性、测试覆盖和工程维护的优缺点。逐项引用文件依据，区分事实与推断，列出缺失材料。不要自动运行启动器、连接市场、修改配置或宣称已恢复原实验。需要执行测试时先使用隔离临时目录。

manifest.json列出全部文件、大小与SHA256；packaging_notes.json记录选择规则和被跳过文件。
'''
(STAGE/'START_HERE.md').write_text(readme,encoding='utf-8')
(STAGE/'packaging_notes.json').write_text(json.dumps({'created_at_utc':datetime.now(timezone.utc).isoformat(),'source_root':str(REPO),'sanitized':False,'selection_raw_budget_bytes':MAX_RAW,'per_evidence_file_limit_bytes':2_000_000,'git_results':git_results,'skipped':skipped,'excluded_categories':['database and backups','WAL/SHM','runtime logs and JSONL','caches and environments','git object history','images and media']},ensure_ascii=False,indent=2),encoding='utf-8')
manifest=[]
for p in sorted(STAGE.rglob('*')):
 if p.is_file():manifest.append({'path':p.relative_to(STAGE).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(STAGE/'manifest.json').write_text(json.dumps({'files':manifest,'file_count':len(manifest),'total_bytes_excluding_manifest':sum(x['bytes'] for x in manifest)},ensure_ascii=False,indent=2),encoding='utf-8')
archive=OUT/('EDGE_OS_REVIEW_PACKAGE_'+STAMP+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(STAGE.rglob('*')):
  if p.is_file():z.write(p,arcname='EDGE_OS_REVIEW_PACKAGE/'+p.relative_to(STAGE).as_posix())
if archive.stat().st_size>=1_000_000_000:raise RuntimeError('ARCHIVE_EXCEEDS_1GB')
with zipfile.ZipFile(archive) as z:
 if z.testzip():raise RuntimeError('ZIP_CRC_FAILED')
 for entry in manifest:
  if hashlib.sha256(z.read('EDGE_OS_REVIEW_PACKAGE/'+entry['path'])).hexdigest()!=entry['sha256']:raise RuntimeError('ZIP_CONTENT_HASH_FAILED')
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
receipt={'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha,'file_count':len(manifest)+1,'uncompressed_bytes':sum(p.stat().st_size for p in STAGE.rglob('*') if p.is_file()),'zip_crc_and_manifest_hashes_verified':True,'source_files_modified':False,'skipped_count':len(skipped)}
(OUT/'package_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/(archive.name+'.sha256')).write_text(sha+'  '+archive.name+'\n',encoding='ascii')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
