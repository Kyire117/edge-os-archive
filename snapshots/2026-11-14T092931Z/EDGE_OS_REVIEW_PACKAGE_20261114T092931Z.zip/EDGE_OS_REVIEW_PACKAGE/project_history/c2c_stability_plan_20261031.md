# Codex with ChatGPT 稳定使用方案

记录日期：2026-10-31，上海时间。本轮为历史核查与规划，只新增本文档，不执行连接修复。

## 已核对的处理历史

| 阶段 | 已做措施与证据 | 结果与边界 |
|---|---|---|
| 9月基础环境 | 安装构建 C2C、Node/cloudflared、安装 Skill、设置本地写入许可 | 建立基本运行环境；不等于远端可读 |
| 9月26日 | doctor/status、网络切换、DNS与7844连通检查、一次停止/setup恢复 | 当时 bridge 本地健康，Quick Tunnel 退出，地址失效；DNS/路由异常是线索，未确定唯一原因 |
| 10月3日 | 更新checkout、pnpm安装构建、同步Skill、保留本地DNS补丁、通过代理/HTTP2恢复连接 | 本地doctor通过；版本0.1.3是C2C版本，插件0.1.2是另一包的版本，不能混用 |
| 10月3日 | 创建私有插件、检查开发者模式、重新登录、后续完成自定义连接与授权 | 私有包存在最初未带来网页工具；开发者模式开启后，网页实际身份与README读取成功并支持独立复核 |
| 10月5日日志 | 发现曾对外层目录运行doctor，而实际绑定嵌套源码目录；停止误启动的外层连接 | 先前部分失效判断检查了错误对象，并非配对已变化 |
| 10月9日及后续 | 在同一Project内恢复原有审阅流程；多次实际identity/README读取；保留原检查点 | 曾成功，不代表永久稳定；旧聊天Resource not found与新聊天可读是历史事实 |
| 10月多轮 | 经明确授权删除/重建失效网页连接、更新插件ZIP、恢复只读审查连接、人工处理Cloudflare验证 | 多次局部恢复；引入两个不同集成身份，不能互相替代作验收证据 |
| 10月30日Iteration1–2 | 对工具目录、recipient、插件身份做区分 | Unknown tool来自单独的只读审查集成；目标插件活动工具数0；不能据前者推断后者认证失败 |
| 10月30日Iteration3 | 恢复现有bridge/Quick Tunnel、检查写入许可；用户正常关闭并重开Codex | 本地bridge/tunnel恢复；重开后目标工具仍0 |
| 10月30日Iteration4 | 检查CLI清单、manifest、信任配置、桌面日志与协议诊断能力 | 桌面发现并尝试目标插件，MCP启动握手反复约30秒超时；initialize/tools-list未获成功证据；内层原因未知 |

## 当前结论

本轮活动目录仍没有目标插件的工具。只读审查集成和其他项目工具不算目标恢复。最新完整启动日志证据来自10月30日，未重跑连接/授权调用，因此不声称10月31日网络实时健康。

已确认问题分别涉及临时地址失效、目录混淆、插件身份混淆、网页验证阻塞，以及MCP启动握手超时。它们不应统一归因于聊天session断开。缓存包与工作区endpoint主机不一致已观察到，但因果未证明。重启Codex没有解决最近的握手故障。

新核查：C2C package.json 已依赖 @modelcontextprotocol/sdk，现有服务使用官方SDK的StreamableHTTPServerTransport。因此下一阶段可评估复用已安装SDK建立分阶段诊断；此前“CLI没有直接调用命令”不代表所有SDK诊断路径都不可行。尚未实现或运行此诊断。

## 实施阶段与验收门槛

1. 固定唯一身份：维护目标plugin ID、workspace ID、规范化实际源码路径、状态目录和原审查聊天的映射；同时核对桌面打包运行环境与普通终端的LOCALAPPDATA/C2C_STATE_DIR解析，避免维护两套状态。先备份连接配置，所有地址只保存指纹。
2. 定位握手：复用现有SDK，在授权范围内分别检查本地与既有公网路径，记录连接、initialize、initialized、tools/list耗时、错误和请求关联ID。不得将凭据发往尚未证实归属的endpoint。证据必须定位第一失败阶段，再决定单项修复；服务端正常但Codex无工具时提交host注册缺陷证据，不再改地址。
3. 稳定地址：在现有C2C支持的named tunnel方案上建立固定域名，保留插件和聊天身份。前提是用户有可授权Cloudflare账号及托管域名；未知时先核实，不自动购买或改DNS。固定域名只解决地址漂移，不保证网络或认证永远正常。暂不具备条件时只能提供临时连接，不能承诺跨重启免维护。
4. 后台生命周期：为连接服务建立单实例、开机/登录启动、退出恢复、睡眠/VPN恢复后的重连；采用有限退避和错误熔断，保留日志。身份异常停止恢复；网络错误不得自动删除连接、重配对或更换地址。仅管理C2C组件，不操作EDGE OS运行服务。
5. 可审计健康与工作流：区分bridge、公开通路、授权、协议、工具注册、工作区读取、网页审查完成七种状态。记录阶段耗时、错误、最近成功时间；过滤全部secret。任务ID/iteration/证据哈希/网页审阅状态持久保存，恢复后先检查是否已提交或完成，防止重复发审查。人工验证只提示一次并保留检查点，不自动绕过。
6. 验收：目标owner真实出现→workspace_info匹配47fec7b8248c/EDGE OS 101→README读取成功→20次顺序只读调用全部成功→正常会话刷新后重验→受控VPN中断/睡眠唤醒恢复测试→24小时低频观察→7天使用观察。建议恢复目标为网络恢复后120秒内重新可读，身份错误零容忍；这些是待测目标，不是已实现SLA。故障注入只在获准测试窗口进行。

优先次序：身份/握手定位优先；直接恢复验收后再落实固定地址和后台生命周期。固定地址、监管进程和调大timeout都不能代替协议证据。不得为了通过验收盲目增加timeout。

## 证据来源与限制

本轮读取：工作区C2C_CONNECTION_DIAGNOSIS_2026-09-26.md、connection_tools/UPDATE_AND_TOOL_CREATION_20261003.md、data_log.md相关条目；嵌套源码execution_output/c2c_connection_reliability_repair_v1/下四个历史证据目录的execution_report.md；外层execution_output/c2c_connection_reliability_repair_v1/20261030T071947Z/报告与mcp_handshake_diagnostics.json；已安装codex-with-chatgpt与openai-docs Skills；C2C README.zh-CN.md、package.json、src/cli/index.ts、src/mcp/http.ts、src/config/paths.ts；当前工具目录元数据。

官方资料：https://learn.chatgpt.com/docs/extend/mcp 。插件提供的MCP与普通用户MCP配置有不同的配置入口，启动超时与可选服务器目录等待也为不同设置。文档不能证明本机具体故障原因。

部分旧测试临时目录不可读；未逐条重建全部历史浏览器操作。历史对话、日志、报告中的成功均标作历史，未当作当前连接证明。未运行doctor自动修复、产品测试、连接替换或应用重启；未读取产品DB、WAL/SHM。历史VOID BLOCKED检查点不变。
