# V2 Timestamp Evidence Model — Iteration 2

Task: c2c_v2_timestamp_evidence_model / Iteration 2 / READY_FOR_REVIEW
Date: 2026-10-03, Asia/Shanghai

## Independent review and scope

The restored EDGE OS 101 connector verified workspace_info and the exact README first line. ChatGPT read outputs 59-62 and the current sources, then returned REVIEW_CHANGES_REQUIRED for two blockers. This iteration fixes only those blockers, without deployment, EDGE OS restart, production mutation, signal replay, or changes to frozen strategy/engine rules.

## Changed files

- app/polymarket.py
- app/wallet_follow_runtime.py
- app/wallet_follow_v2.py
- tests/test_v2_timestamp_model.py
- V2_TIMESTAMP_MODEL_ITERATION_2.md
- execution_output/timestamp_model_i2_preservation.py and timestamp_model_i2/* evidence

Existing unrelated working-tree edits were preserved. app/strict_ledger.py was not edited in this iteration: its existing cancel_order_in_transaction primitive is reused.

## Fix 1: HTTP response receipt evidence

PolymarketClient._get captures response_received_timestamp (aware UTC) immediately after the actual HTTP response arrives, before status/JSON validation, with the attempt number. HTTP error metadata keeps this timestamp and the received public body/status/headers. orderbook carries the same metadata on success.

The runtime stores http_response_received_timestamp and http_response_attempt. When an HTTP exception carries a real receipt timestamp, the failed book's received_timestamp is copied from that evidence, not fabricated from the later exception time. Pure transport failure without a received response retains received_timestamp=null. The quote/execution book freshness rules and all V4/V3 rule configurations are unchanged.

## Fix 2: post-submit failure boundary

record_runtime_failure now holds BEGIN IMMEDIATE while checking the episode/order/fill identity and committing the failure handling.

- No strict order: retain the existing no-fill rejection behavior.
- Strict order exists, no committed fill: cancel it with the existing ledger transaction primitive, return its reserved cash/shares, record EXECUTION_COMMIT_INCOMPLETE plus original failure/book evidence, and terminalize the episode in that same transaction. Cancellation and episode/runtime/audit writes roll back together on persistence failure.
- A strict fill already committed before a later exception: preserve the fill/order and leave the episode OBSERVED. Append EXECUTION_FAILURE_RECOVERY_REQUIRED audit evidence without creating a false rejection event. Runtime reports RECOVERY_REQUIRED / EXECUTION_COMMIT_SYNC_REQUIRED. Existing frozen-grace, zero-network stale recovery validates immutable strict evidence, restores the episode/order link, and permits exactly one subsequent formal settlement.
- Already terminal episode: failure recording is an idempotent no-op.

If the database cannot persist failure handling, propagate the exception and retain OBSERVED for the existing zero-network recovery loop. This does not claim a failed transaction was recorded. Ordinary process death still follows the previously tested stale-recovery behavior.

## New deterministic regressions (6 cases)

- HTTP 404 through the real public client and runtime in QUOTE and EXECUTION phases: exact response receipt preserved, no fill, one GET per phase, public raw evidence retained.
- Post-submit independent ledger validation failure: reservation released and terminal no-fill.
- Post-submit SQLite fill-insert failure: financial transaction rolls back; cancellation/failure transaction releases reservation.
- Failure-event persistence abort: cancellation also rolls back, episode remains OBSERVED, later local recovery cancels without another book call.
- Exception after an actual fill commit: no false rejection, one preserved fill, local recovery, idempotence, formal settlement and green reconciliation.

All fixtures use temporary databases and simulated HTTP responses. No actual strategy profits are claimed.

## Executed verification

Targeted command:
`.venv/Scripts/python.exe -m pytest tests/test_v2_timestamp_model.py tests/test_strict_paper_iteration1.py tests/test_strict_paper_iteration2.py tests/test_wallet_follow_v2.py tests/test_wallet_follow_v2_activation.py -q --basetemp=.tm2target`

Result: 133 passed, 2 warnings in 25.30s. Warnings: existing Starlette/AnyIO deprecation and pytest denied cache write. The latter is tooling-only; the full run uses a fresh workspace cache path.

Full command:
`.venv/Scripts/python.exe -m pytest tests -q --basetemp=.tm2full -o cache_dir=.tm2cache`

Result: 277 passed, 1 existing deprecation warning in 53.89s.

DATABASE_PATH pointed to dedicated workspace temporary application DBs; TEMP/TMP used .tm2temp. Test DBs use tmp_path. git diff --check exit0 (only existing CRLF normalization warnings).

## Production preservation

Read-only snapshots used mode=ro, query_only=ON and rollback; no application DB constructors. Evidence: execution_output/timestamp_model_i2/preservation_before.json and preservation_after.json.

All six comparisons are true:
- production main DB SHA256: ff025eb47b682e125ae82980f203628c4ebf429703622d144b4c28294264e0aa
- full original 85 episode contents hash
- corresponding immutable strict decision hash
- frozen V2 version/config records hash
- tracked wallet address set hash
- strict rule registry contents (production V3 retained)

No schema migration or production initialization occurred. No historical SKIP/episode/fill was rewritten or replayed. No live orders or new production V4 state were enabled.

## Remaining boundaries

The existing recovery grace remains 120 seconds: a post-commit sync failure remains OBSERVED until local recovery runs. During a persistent database outage, cleanup must wait until writes become available; the episode is not incorrectly terminalized. This version remains local and requires independent review before deployment.

## Independent review result — 2026-10-03

ChatGPT independently retrieved this workspace's source and readable execution_output63–66 in the bound EDGE OS Project conversation and returned:

[C2C]
STATE: REVIEW_PASS
TASK_ID: c2c_v2_timestamp_evidence_model
ITERATION: 2

Both Iteration 1 blockers were confirmed fixed; no new blocking issue found. Review covered real HTTP receipt evidence, atomic no-fill cancellation/reservation release and failure rollback, committed-fill zero-network recovery, V3 compatibility/V4 rules, 133 targeted tests, 277 full tests, and unchanged production85/config/rules/DB evidence. Deployment or restart is a separate future step.

Review conversation:
https://chatgpt.com/g/g-p-6aadc15c9d6c8191b02cf6f6b4d0a77c-edge-os/c/6ab77fc3-8950-83e8-8f01-09c7045b6134
