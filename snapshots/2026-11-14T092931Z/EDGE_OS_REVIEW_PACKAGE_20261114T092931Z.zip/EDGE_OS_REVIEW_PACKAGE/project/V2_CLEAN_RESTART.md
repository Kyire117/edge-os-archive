# Wallet Follow V2.0 clean forward restart · 2026-10-01

## Scope and safety

- The live production strategy remains `wallet-follow-v2.0` in `FORWARD_TEST`; its original `activated_at` and frozen config were not rewritten. `live_orders=false`.
- No strict-paper rules, ROI threshold, $25 target notional, 10% visible-depth limit or paper fills were changed.
- The maintenance operation required a verified full SQLite backup, an active V2.0 version with expected frozen config, and an empty strict ledger. It ran in one `BEGIN IMMEDIATE` transaction and recorded a new append-only `CLEAN_FORWARD_RESTART` cutoff. A second invocation is rejected.
- Only V0.x simulation tables and the pre-existing V2 sample episode/event tables were cleared. Wallets, raw trades, wallet candidates, category statistics, public profiles, leader outcome research and the V2 version/audit history were retained.

## Production evidence

Pre-clean backup: `data/edge_mvp.db.v2-clean-final-20261001T034447548614Z.backup`, SHA256 `c70f1ed9bbe61f6e92859e745e9f26cfaa6b1605042fd4a73600c1a5ac263b9a`. Its integrity check passed. The manifest is `../../execution_output/v2_clean_restart_backup_20261001T034447548614Z.json`.

Before cleanup: 35 wallets, 39,400 raw trades, 155 wallet candidates, 219 V0 experiment entries, 169 V0 paper trades, 611 V0 signals, 638 old research entries, 16 V2 episodes, zero strict fills or settlements. The clean transaction removed the retired simulation rows and reset V2 episodes/fills/settlements to zero. The V2 observation cutoff is `2026-10-01T03:46:07.104741+00:00`. The receipt `../../execution_output/v2_clean_restart_execution_20261001T034606402056Z.json` confirms SQLite integrity and matching content hashes for all protected source tables.

During the first restart, the independent AI research loop rebuilt old `research_entries` from raw trades. This was caught during smoke verification. Its V2-active refresh path now skips retired research recovery. Before clearing that replay, a second full backup was made at `data/edge_mvp.db.v2-before-replay-purge-20261001T035647419777Z.backup`, SHA256 `aa8e7ab709e0c9cdeb98913b421001f630f77846212d3f67364ad6ae8e711839`. A separate transaction removed 320 replayed old research entries while preserving four genuine post-cutoff V2 episodes; see `../../execution_output/v2_clean_restart_replay_purge_20261001T035647419777Z.json`.

After the final restart, the live scan succeeded with 20 wallets scanned, zero scan errors and `legacy_refresh_enabled=false`. A manual request through the dashboard's new V2 scan endpoint also succeeded and made no legacy refresh. The legacy experiment, legacy research entries, signals and paper-trade tables remained empty after further background cycles. The dashboard reports the V2 version, frozen config, tracked wallets, observed raw trades, direction episodes, fills, rejection reasons and pending paper settlements. It does not request or show the retired FC14 experiment.

The clean start was zero. Later genuine post-cutoff trades created nine V2 episodes (all first leader and detection timestamps after the cutoff); no strict financial fill or settlement exists yet. At the observed check they were rejected: seven `FUTURE_ORDER_BOOK_TIMESTAMP` and two `QUOTE_PREDATES_SIGNAL`. Their source evidence is retained in the V2 journal. This is an unresolved data-quality/execution-timing limitation, not simulated profit or a reason to relax frozen rules without review.

## Verification

- Targeted V2/strict paper suite: 99 passed before the final AI refresh guard; the added clean-restart tests: 6 passed.
- Full repository regression after the final changes: 239 passed, one third-party deprecation warning. Raw output: `../../execution_output/v2_clean_restart_pytest_full.txt`.
- Frontend static escaping/URL checks passed; `node --check app/static/app.js` passed. Raw output: `../../execution_output/v2_clean_restart_ui_static.txt`.
- Production read-only status: `FORWARD_TEST`, `live_orders=false`, monitor running and healthy, old experiment tables zero, database integrity `ok`.

The production database and backups under `data/` are local and excluded from Git. Never interpret the current rejected episodes as validated strategy performance.
