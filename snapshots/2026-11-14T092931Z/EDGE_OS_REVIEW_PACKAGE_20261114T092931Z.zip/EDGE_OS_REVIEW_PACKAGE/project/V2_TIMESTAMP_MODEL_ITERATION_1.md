# V2 Timestamp Evidence Model — Iteration 1

任务：`c2c_v2_timestamp_evidence_model`，Iteration 1，READY_FOR_REVIEW。
日期：2026-10-02（Asia/Shanghai）。本轮为实现和隔离验证；未部署、未重启 EDGE OS、未激活新实验、未修改生产数据库。

## 1. 实际修改文件

- `app/strict_paper.py`：可携带不可变 JSON 观察证据的 BookSnapshot；新增 LocalObservationEngineRules/V4；按本地时钟校验观察因果、新鲜度和请求独立性。
- `app/wallet_follow_runtime.py`：逐次 QUOTE/EXECUTION 采集证据；异常先带回已获得证据，原子写入 runtime event 和终态；执行前必须成功写入 EXECUTION_ATTEMPT 审计；实时新观察明确选择 V4。
- `app/wallet_follow_v2.py`：新增显式 local_timestamp_model 参数；保持默认 V3 低层 API；运行适配器选择 V4。提交订单采用决定自己的 engine_version；崩溃恢复同时识别 V3/V4 已提交证据并核对版本一致性。
- `app/strict_ledger.py`：V4 入账时独立复核相同本地时间模型，保留身份、深度、手续费、ROI、预算和 IOC；V4 沿用按美元驱动的 BUY 和保留款释放/对账逻辑。
- `app/polymarket.py`：通过当前请求暴露公开 HTTP Date/Age/Cache-Control/status；失败响应在异常对象携带可用证据；盘口畸形档位保留原始返回供适配器拒绝。
- `tests/test_v2_timestamp_model.py`：32 个确定性回归案例，只用临时数据库和模拟响应。
- 本文；`execution_output/timestamp_model_preservation.py` 及日志/核对证据。

没有改动前端、monitor 路由、产品策略定义、生产初始化或旧实验代码。没有新增依赖。

## 2. 已审查诊断与旧模型

固定生产快照85个真实 forward episodes：48 FUTURE_ORDER_BOOK_TIMESTAMP、33 QUOTE_PREDATES_SIGNAL、4 EXECUTION_BOOK_NOT_NEWER。
33个 quote 请求都在 EDGE 检测之后；原拒绝来自 source < detected。4个 execution 请求确实独立且等待500ms，但源时间相等。当前16组配对读取全部同时间/hash/档位。
这证明请求观察时间和上游盘口状态时间必须分开。它没有证明供应商内部的 timestamp 更新机制，也不能还原48个未保存的历史原始盘口。

旧 V3 模型把 upstream source 与本地检测/接收作因果、未来和3000ms年龄比较，并要求 execution.source > quote.source。V3 类和规则语义保留；新增回归验证旧 V3 仍给出原拒绝。

## 3. 新版本与冻结证据

Engine：`strict-paper-engine-v4`。
Rule：`strict-paper-rules-v4-wallet-follow-v2.0`。
Strategy：仍为 `wallet-follow-v2.0`。

```json
{
  "timestamp_model": "LOCAL_CAUSAL_OBSERVATION_V1",
  "quote_causality_basis": "LOCAL_REQUEST_AFTER_EDGE_DETECTION",
  "book_freshness_basis": "LOCAL_RESPONSE_RECEIVED_AT",
  "upstream_timestamp_role": "PROVENANCE_ONLY",
  "execution_newness_basis": "DISTINCT_REQUEST_AFTER_FROZEN_LATENCY"
}
```

以上字段进入不可变规则登记/决定证据。V4 类不能使用 V3 规则名；账本也复核时间模型字段。旧 strict_rule_versions、strict_decisions 不重写。

冻结产品配置未变：$25 gross notional（不含另外记录的费用）；ROI≥5%；可见深度10%；执行延迟500ms；本地盘口观察年龄≤3000ms；review样本阈值20；grace120秒；IOC；HOLD_TO_FORMAL_RESOLUTION；live_orders=false。

## 4. 因果与新鲜度合同

1. quote.request >= EDGE detected，否则 QUOTE_PREDATES_SIGNAL。
2. quote.request <= quote.received <= observed_at，否则 INVALID_QUOTE_LOCAL_TIMESTAMPS。
3. execution 必须有不同 snapshot_id/request_id，否则 REUSED_QUOTE_SNAPSHOT。
4. execution.request >= quote.received + 500ms，否则 EXECUTION_BEFORE_FROZEN_LATENCY。
5. execution.request <= execution.received <= observed_at，否则 INVALID_EXECUTION_LOCAL_TIMESTAMPS。
6. observed_at - execution.received <=3000ms，否则 STALE_EXECUTION_BOOK。
7. observed_at - quote.received <=3000ms，否则 STALE_QUOTE。

优先级说明：在正常因果顺序中，执行观察已旧时，报价观察也必然更旧。V4 在两者同时过期时先报告 STALE_EXECUTION_BOOK；只有执行仍新、报价过期时报告 STALE_QUOTE。两个年龄门槛均保留。

上游时间仍必须是有效、可解析的 aware UTC 来源时间。MISSING_TIMESTAMP/INVALID_TIMESTAMP 失败闭合。source > local received、source < detected、source 相等或 hash/档位不变仅进入诊断，不单独生成拒绝或成交。没有 +/- 魔法容差。
没有在执行关键路径增加 /time 请求。

## 5. 每次盘口的证据合同

`quote`/`execution` 的不可变决定证据、`EXECUTION_ATTEMPT.adapter_evidence.books`、失败的 runtime_event `books`/`book_failure` 包含：

|领域|字段|
|---|---|
|身份|condition_id/token_id/outcome，raw_book里的上游身份（如存在则必须匹配）|
|请求|phase、quote_or_execution、request_id、snapshot_id（成功构造时）、本地 request/received、monotonic elapsed_ms|
|上游|raw_source_timestamp、raw_timestamp_type、raw_timestamp_repr、normalized_source_timestamp、upstream_hash、source_timestamp_parse_status/error、完整公开 raw_book|
|盘口|排序后的 Decimal bids/asks、level counts、best bid/ask；畸形时原始返回保留|
|HTTP|http_date、http_age、http_cache_control、http_status（接口/fixture未提供时为null）|
|诊断|source_minus_request_ms、source_minus_received_ms、response_age_at_decision_ms、source_equal_previous、hash_equal_previous|
|角色|source_timestamp_role=UPSTREAM_BOOK_STATE_PROVENANCE；received_timestamp_role=EDGE_LOCAL_OBSERVATION_TIME|
|失败|validation_reason、error_type、QUOTE或EXECUTION阶段；未取得的数据保持null/NOT_AVAILABLE|

纯网络连接失败未收到响应，所以 received_timestamp/原始盘口为null；elapsed及请求身份仍记录。HTTP错误已获得的响应/status/hash/raw时间也保留。异常发生在 BookSnapshot 构造之前不再丢失整个请求证据。
全部可用执行证据在财务执行**之前**写入审计；失败写入不允许调用执行/提交订单。终态失败写入与 episode 更新使用现有同一SQLite事务。如数据库连失败事件本身都无法保存，则异常传播且未成交的 OBSERVED 由现有零网络恢复处理；不能声称无法写入时仍已持久化。

## 6. 测试与实际运行记录

最终代码验证：

- 新时间模型文件：32个案例。
- targeted：`test_v2_timestamp_model.py` + 两个 strict-paper 文件 + wallet-follow 策略/激活：**127 passed，1 warning**。
- 全量 `pytest tests`：**271 passed，1 warning**。
- warning为既有第三方 Starlette/AnyIO deprecation。
- `git diff --check` 未报告空白错误。

测试覆盖：旧source/新请求；请求早于检测；上游未来正偏差；30秒旧source；本地报价/执行过期；500ms新请求同时间同hash同档位；ID重复；本地请求接收倒序或未来；缺失/畸形时间与QUOTE/EXECUTION失败证据；真实深度/最小订单/手续费/ROI；前置审计失败零成交；V4账本对账；重复事件零重复fill；V4已提交fill的零网络重启恢复；产品live_orders=false；HTTP元数据单GET且无/time。

执行日志：`execution_output/timestamp_model_i1/targeted_verified.txt`、`full_verified.txt`。
测试进程将 DATABASE_PATH 指向专用临时目录；每个测试使用自己的 tmp_path 数据库，未运行生产服务。

失败记录也保留：初始相关回归和较长临时路径重跑出现10个 BACKUP_FAILED。SQLite对257字符备份路径的直接试验报 unable to open database file，而短路径成功；最终将 basetemp 改为工作区 `.tm1target`/`.tm1full` 后全部通过。未为绕过失败修改产品备份逻辑。首次新增测试有1个成功reason断言错误（FILLED状态的成功reason实际为EXECUTED），已修正；不隐藏这些运行。

## 7. 生产保护与无历史回放证明

`execution_output/timestamp_model_i1/preservation_before.json`、`preservation_after.json` 均从mode=ro、query_only=ON、一致性事务读取。

前后比对全部true：

- 生产DB主文件SHA256；
- 原85条完整episode内容SHA256；
- 这些episode的不可变strict decisions SHA256；
- 完整wallet_v2_versions记录SHA256（含冻结config和activation/cutoff）；
- tracked wallet地址集合SHA256；
- strict_rule_versions记录内容。

**The existing 85 episodes remain historical rejected evidence and are NOT re-evaluated.**
这85条没有被清除、重放、改判或转成fills。生产strict规则登记仍仅V3；V4只出现在临时测试数据库。

## 8. 上线与剩余限制

本轮不需要schema迁移；证据沿用现有JSON字段和append-only审计表。未来独立部署后，第一笔真正新观察会按新的V4规则登记；它不会重写V2策略配置或旧记录。
按照批准范围，本轮没有重启EDGE OS，也没有执行新的clean-forward cutoff。若需要从零采集可比较V4样本，必须在审查通过后另行批准并备份，不能用本轮实现自动触发。
本地时钟自身发生跳变仍可能触发同钟域完整性拒绝；本轮没有校时。HTTP Age/Cache-Control记录为诊断，不能把元数据存在当成供应商保证盘口可成交；执行仍为纸面模拟。
仓库开始时已有未提交修改，未reset/revert。`baseline_product.diff`保存本轮前部分tracked diff；`final_tracked.diff`为最终tracked文件diff，含既有修改，不把其中所有行归为本轮。runtime/v2文件原已untracked，审查需read_file；没有擅自git add或commit。
ChatGPT安全连接地址已变化；独立审查读取尚需恢复失效的同名连接。本地已完成代码、验证及记录，不能将它称为独立REVIEW_PASS。

## 9. 可读取的 C2C execution_output

- **59**：最终 targeted，127 passed，未截断，exit0。
- **60**：最终 full regression，271 passed，未截断，exit0。
- **61**：生产只读保护核对，所有比较true，未截断，exit0。
- **62**：本实现报告，未截断，exit0。
- 56/57/58：初始失败/长路径失败记录；56/58被记录器截断，完整日志在execution_output/timestamp_model_i1/。
