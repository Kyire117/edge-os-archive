# Polygon OrderFilled Fast Path V1（尚未部署）

此模块仅收集已上链的公开交易证据，交给现有 Wallet Follow V2 模拟执行流程。
不签名、不提交真实订单，不改变 V2、Exit V1 或严格模拟执行参数。
本轮未启动或重启生产服务，未执行生产迁移，未处理历史 VOID。

## 来源、金额与钱包归属

官方来源：<https://docs.polymarket.com/resources/contracts>；
Polymarket/ctf-exchange-v2 固定提交 `ccc0596074f4dfd62c944fbca4de252893b82b4b`。
`README.md` 验证部署地址；`ITrading.sol`/`Events.sol` 验证四个 topic、七个 data word；
`Trading.sol`/`Structs.sol` 验证 BUY=0、SELL=1、maker 为订单拥有者；
`CollateralToken.sol` 验证六位金额精度。
源码副本及 SHA256 位于 `execution_output/polygon_fast_path/provenance/manifest.json`。

当前支持：

- CTFExchangeV2：`0xE111180000d2663C0091e4f400237545B87B996B`
- NegRiskCtfExchangeV2：`0xe2222d279d744050d28e00520010520000310F59`

官方合约文档还列出 `0xe3333700cA9d93003F00f0F71f8515005F6c00Aa`。
本轮没有验证该部署的 ABI，因此不会订阅或解码；配置未知合约会失败关闭。
`POLYGON_EXCHANGE_CONTRACTS` 可以选择已验证合约的子集；新增合约需要扩展经过验证的 ABI/来源登记。
不得据此声称覆盖所有未来或当前生产 Exchange。

所有链上原始金额使用整数，金融推导使用 Decimal（100 位计算精度）：

| side | shares | gross notional | price |
| --- | --- | --- | --- |
| BUY | takerAmountFilled / 10^6 | makerAmountFilled / 10^6 | gross / shares |
| SELL | makerAmountFilled / 10^6 | takerAmountFilled / 10^6 | gross / shares |

链上 fee 单独保留原始值，不混入上述 gross 价格，也不替代 EDGE 现有执行费率。
金融值进入网关时为十进制字符串；原始金额、maker/taker、订单 hash、builder、metadata 全部留证。
只匹配 maker/order-owner；仅出现在 taker 的被跟踪地址不会获得策略事件。

## 身份解析与去重

按顺序使用：本地 raw upstream trade 的精确 token/condition/outcome 映射；
最多 2048 条、TTL 3600 秒的 Gamma 缓存；最多 5 条候选的精确 Gamma token 查询。
本地查找最多检查 20 条记录。身份冲突或获取失败保持 `PENDING_METADATA`，不占执行网关。
后续检查可重试解析，也允许轮询先获得执行所有权。

强身份：`polygon:137:<contract>:<tx_hash>:<log_index>`。
`fill_canonical` 与 raw trade 首次所有权在同一个 `BEGIN IMMEDIATE` 事务提交。
`fill_source_observations` 保留每个来源的原始 ID、证据和匹配方法。
`fill_identity_audit` 追加保存每次身份判定；缺少来源 ID 的重复观察标记 `AMBIGUOUS_UNKEYED_REPEAT`，不伪装成精确链身份。

当前生产 raw Data API 样本只有 transaction hash，未见 contract/log index。
如果将来来源直接提供完整链身份则精确匹配；不会猜测缺失的 chain/contract/index。
弱来源只能在完整 receipt 中，maker/token/side/精确 gross 经济量唯一且来源金额完全相同时，与唯一强身份关联。
若 receipt 含相同 topic 的未知合约，也不作唯一性声明。
不同 log_index 不合并；金额不一致、多个候选或不足以证明唯一性，记录 `AMBIGUOUS` 并停止该来源的执行。
这可能保守地漏掉一次执行，但不会把模糊匹配伪装成重复。人工复核可读取证据，本轮没有历史回放入口。

实时 `DATA_API_POLL` / `FAST_PATH` 缺少合法交易哈希时，保存完整观察证据及
`AMBIGUOUS_INSUFFICIENT_TRANSACTION_IDENTITY` 审计，canonical_id 为空，禁止策略执行。
无哈希观察无论先到或后到均不会获得所有权；不按价格/时间猜测重复。
非实时 DIRECT/历史导入调用仍保留旧 trade-key 行为，不回填历史记录。

## 生命周期和补漏

配置 `POLYGON_WSS_URL` 且 `POLYGON_FAST_ENABLED=true` 后，应用 lifespan 才启动独立 asyncio producer。
默认 `POLYGON_FAST_ENABLED=false`，必须显式开启并配置地址才启动。
默认地址为空，无新网络连接；未配置或禁用状态不初始化 producer 表。
配置地址不在日志、API 或 dataclass repr 中返回。HTTP/SOCKS 系统代理是否支持由所选 WSS provider/运行环境决定。

初次运行保存当时 chain head 为 forward boundary；该高度及以前不作为新 Fast Path 事件。
重启复用已保存的边界及 confirmed-block checkpoint，不重设边界。
每 5 秒读取 head，同时使用 ping（10 秒，超时 10 秒）；RPC 默认超时 8 秒。
默认等待一个后继块：事件 block <= head - 1 才可验证 canonical block 和完整成功 receipt。
这包含一个块确认等待、最多一个 heartbeat 周期及身份解析/策略执行延迟，不保证任何延迟 SLO。

重连采用指数退避，基础间隔上限 60 秒，额外随机 jitter 0–1 秒。
按 block/log_index 处理 `eth_getLogs`，单次最多补 128 个块、10000 条 logs，内存推送队列最多 2048 条。
超过补漏范围或 head 回退失败关闭，不静默跳过缺口。
checkpoint 表示 logs 已持久化的 confirmed 范围；元数据暂缺事件仍留在持久队列。
未跟踪 maker 在本地过滤，不持久化整个交易所的活动；跟踪钱包集合每次 heartbeat 刷新。
每次最多处理 100 条待确认/待元数据事件，未解决的积压可能延迟后面的事件，API 显示待元数据数量。

removed 通知保存 tombstone；在策略处理后的 removed 标记 `REORG_AFTER_ADMISSION`，不改写历史金融账本。
一个块确认不能消除深重组风险；没有收到 removed 的深重组不在 V1 内自动重做历史账目。
进程在 ROUTING 中断，重启标记 `ROUTING_INTERRUPTED / NO_EXECUTION_REPLAY`，不重新获取后来的订单簿。
现有 V2 恢复逻辑仍负责已提交的 episode/strict 账本。
首次决策返回的 `decision` 是结构化账本证据；producer 只对字符串路由标签检查暂停状态。
已完成 FIRST 的结果会持久化为 ROUTED，包括严格拒绝，不能因为返回结构类型触发重连或重放。
重连追加 `RECONNECT_DIAGNOSTIC`：序号、异常类型、执行阶段、失败 RPC 方法和 UTC 时间。
不保存异常原文、RPC 参数、provider 地址或凭据；健康状态只返回同样的安全字段。
WSS 的网络任务与轮询任务独立；SQLite 仍沿用现有同步事务，因此不承诺锁等待或 CPU 压力下的实时调度上界。

## 增量表和健康接口

未来正常启动时只新增表，不回填或改写旧数据：

- `fill_canonical` / `fill_source_observations` / `fill_identity_audit`：跨来源身份、观察证据与追加判定审计。
- `polygon_fast_events`：持久原始事件、状态与时间。
- `polygon_fast_audit`：追加审计事件。
- `polygon_fast_state`：首次边界和 confirmed checkpoint。
- `polygon_token_cache`：有界身份缓存。

新增只读 `GET /api/polygon-fast-path`，并在 `GET /api/health` 添加 `polygon_fast_path`。
返回 configured/enabled/connected、last_event_at/last_block、跟踪数量、错误类别、待元数据数量、计数、来源和延迟；不返回 provider 地址或凭据。
计数范围是当前 producer 进程；延迟来自持久化的最近最多 1000 条已处理记录。

实时 `latency` 与 `backfill_latency` 分开；每项返回秒单位 P50/P75/P90/P95/max/sample_count（nearest-rank）：

- chain_source：block_timestamp -> first observed
- normalization：first observed -> metadata/normalized ready
- strategy：normalized ready -> V2 实际开始处理
- total：block_timestamp -> V2 实际开始处理

未进入 V2 的事件不作为已进入策略的速度样本。测试夹具的分位数不是生产测量。
本轮环境没有配置 POLYGON_WSS_URL，真实验证状态为 `BLOCKED_BY_WSS_PROVIDER_CONFIGURATION`。
没有宣称 P50/P90/P95 目标达标。部署、生产启动以及真实前向观测需要单独授权。

## 验证

`tests/test_polygon_fast_path.py` 使用临时数据库和合成 chain/provider 夹具，覆盖解码、金额、maker 归属、
缓存、不同来源 ID、不同 log index、模糊匹配、确认/重组、恢复、补漏、断线、独立网络等待、停机及安全 API。
完整运行记录、只读生产前后 count/hash 对比在 `execution_output/polygon_fast_path/`。
新增显式依赖 `websockets==17.1`（原环境已有该包）。
