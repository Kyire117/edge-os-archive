# Project working instructions

When the user enters `例行报告`, follow [ROUTINE_REPORT.md](ROUTINE_REPORT.md).
Read the current active experiment and collect fresh read-only evidence using
`.venv/Scripts/python.exe scripts/routine_report.py`. Report in Chinese.
Do not create scheduled reports. Final net portfolio PnL and the return curve
are the primary strategy measures; there is no majority-winning-trades gate or
separate evidence-sufficiency scoring gate. The four final conclusions and the
100 USDC risk limits are defined in ROUTINE_REPORT.md.

Preserve existing uncommitted work. Historical paper databases and their
verified archives are evidence: never delete, reset, synthesize settlements,
change old scores, or mix them into a new experiment's performance.
All trading remains PAPER_ONLY unless the user separately authorizes real orders.
The 100 USDC experiment has the original strategy plus a separately frozen risk
overlay. Report both nominal strategy sizing and the effective fee-inclusive
5 USDC order cap accurately.
