"""Local PAPER_ONLY start UI. No database/application imports or stop/reset API."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from edge_runtime import active_database, public_run

ROOT=Path(__file__).resolve().parent
PORT=8766
URL=f'http://127.0.0.1:{PORT}'
APP_URL='http://127.0.0.1:8000'
OUT=ROOT/'execution_output/one_click_launcher'
OUT.mkdir(parents=True,exist_ok=True)
LOCK=threading.Lock()
process: subprocess.Popen | None=None
start_error: str | None=None

def request_json(url, timeout=2):
    # Local control requests must not be sent through any public proxy.
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(url,timeout=timeout) as response:return json.load(response)

def listening(port):
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=0.5):return True
    except OSError:return False

def identity():
    # Identifying the helper must never wait for the application health check.
    return {'service':'edge-os-paper-launcher','protocol_version':1,
            'workspace':str(ROOT),'mode':'PAPER_ONLY'}

def existing_launcher():
    try:
        existing=request_json(URL+'/identity')
        valid=(existing.get('service')=='edge-os-paper-launcher'
               and existing.get('protocol_version')==1 and existing.get('mode')=='PAPER_ONLY')
    except urllib.error.HTTPError as error:
        if error.code!=404:raise
        # Reuse an already running older helper. Its /status also waits for
        # backend health, so allow its bounded checks to finish before judging it.
        existing=request_json(URL+'/status',timeout=6)
        valid=existing.get('state') in ('STOPPED','STARTING','RUNNING','CONFLICT','FAILED')
    workspace=existing.get('workspace')
    if (not valid or not isinstance(workspace,str)
        or os.path.normcase(str(Path(workspace).resolve()))!=os.path.normcase(str(ROOT.resolve()))):
        raise RuntimeError('LAUNCHER_ADDRESS_CONFLICT')
    return existing

def status():
    try:
        health=request_json(APP_URL+'/api/health')
        if health.get('mode')!='PAPER_ONLY' or health.get('live_trading') is not False:
            return {'state':'CONFLICT','message':'该地址运行的服务无法确认为仅模拟 EDGE OS，启动已阻止。'}
        if (health.get('experiment') or {}).get('run_id')!=public_run().get('run_id'):
            return {'state':'CONFLICT','message':'运行服务与当前实验不一致，不会重复启动或切换已有服务。'}
        # Serving this checkout's current static file is an additional identity
        # check. Never stop, reconfigure or replace a different local service.
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(APP_URL+'/',timeout=2) as response:page=response.read()
        if hashlib.sha256(page).digest()!=hashlib.sha256((ROOT/'app/static/index.html').read_bytes()).digest():
            return {'state':'CONFLICT','message':'运行页面与当前项目不一致，启动已阻止。'}
        fast=health.get('polygon_fast_path') or {}
        return {'state':'RUNNING','message':'EDGE OS 已运行，旧记录保留，真实交易关闭。',
                'url':APP_URL,'monitor_running':health.get('monitor_running'),
                'last_scan':health.get('monitor_last_success_at'),
                'fast_enabled':fast.get('enabled'),'fast_connected':fast.get('connected'),
                'fast_error':fast.get('error_category'),'reconnect_count':fast.get('reconnect_count'),
                'fast_last_read':fast.get('last_data_success_at'),'catchup_blocks':fast.get('catchup_remaining_blocks'),
                'experiment':public_run(),'live_orders':False}
    except Exception:
        if process is not None and process.poll() is None:
            return {'state':'STARTING','message':'服务正在启动，请稍候…'}
        if listening(8000):
            return {'state':'CONFLICT','message':'本机地址已被占用或服务暂时无响应；不会重复启动。'}
        if process is not None and process.poll() is not None:
            return {'state':'FAILED','message':'服务启动后退出。请查看本机启动日志；没有清理或重置数据。'}
        return {'state':'STOPPED','message':start_error or '服务未运行，可启动持续模拟。'}

def start():
    global process,start_error
    with LOCK:
        current=status()
        if current['state'] in ('RUNNING','STARTING','CONFLICT'):return current
        if not str(public_run().get('run_id','')).startswith('FORWARD-'):
            return {'state':'FAILED','message':'新实验配置缺失，启动已阻止；不会自动恢复旧实验。'}
        python=ROOT/'.venv/Scripts/python.exe'
        if not python.is_file():
            start_error='项目运行环境缺失，请先恢复 .venv；不会自动重建数据库。'
            return {'state':'FAILED','message':start_error}
        if not listening(7897):
            start_error='已验证的本机网络代理未运行。请先启动你的网络工具，再点击启动。'
            return {'state':'FAILED','message':start_error}
        flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
        # A source-backed SQLite backup must complete before launching the app.
        try:
            with (OUT/'preflight.log').open('ab') as log:
                preparation=subprocess.run([str(python),str(ROOT/'execution_output/polygon_fast_path/prepare_continuous_start.py')],
                    cwd=ROOT,stdout=log,stderr=log,timeout=90,creationflags=flags)
            if preparation.returncode!=0:
                start_error='备份或冻结策略检查失败，已阻止启动；旧记录未被清空。'
                return {'state':'FAILED','message':start_error}
            env=dict(os.environ)
            env.update(DATABASE_PATH=str(active_database()),POLYGON_FAST_ENABLED='true',
                POLYGON_WSS_URL='wss://polygon-bor-rpc.publicnode.com',
                HTTPS_PROXY='http://127.0.0.1:7897',HTTP_PROXY='http://127.0.0.1:7897',
                NO_PROXY='127.0.0.1,localhost,::1,polygon-bor-rpc.publicnode.com')
            env.update(MONITOR_MAX_CONCURRENCY='2',REALTIME_PAGES_PER_SLICE='1',
                       REALTIME_REQUEST_TIMEOUT_SECONDS='15',POLL_INTERVAL_SECONDS='3')
            with (OUT/'runtime_stdout.log').open('ab') as stdout, (OUT/'runtime_stderr.log').open('ab') as stderr:
                process=subprocess.Popen([str(python),'-u',str(ROOT/'execution_output/polygon_fast_path/serve_continuous.py')],
                    cwd=ROOT,env=env,stdout=stdout,stderr=stderr,creationflags=flags)
            start_error=None
            (OUT/'last_launch.json').write_text(json.dumps({'pid':process.pid,'workspace':str(ROOT),
                'started_at_utc':datetime.now(timezone.utc).isoformat(),'mode':'PAPER_ONLY',
                'old_records_preserved':True}),encoding='utf-8')
            return {'state':'STARTING','message':'备份已完成，正在启动 EDGE OS…'}
        except Exception:
            start_error='启动失败；详情已保存在本机日志中，旧数据未清空。'
            return {'state':'FAILED','message':start_error}

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def allowed(self):
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}',f'localhost:{PORT}')
    def send(self,code,body,kind='application/json; charset=utf-8'):
        content=body.encode('utf-8')
        self.send_response(code);self.send_header('Content-Type',kind)
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
    def do_GET(self):
        if not self.allowed():self.send(403,'{}');return
        if self.path=='/identity':
            self.send(200,json.dumps(identity(),ensure_ascii=False));return
        if self.path=='/status':
            self.send(200,json.dumps({**status(),'workspace':str(ROOT)},ensure_ascii=False));return
        if self.path in ('/','/dashboard.html'):
            self.send(200,(ROOT/'app/static/launcher.html').read_text(encoding='utf-8'),'text/html; charset=utf-8');return
        self.send(404,'{}')
    def do_POST(self):
        # Require a same-origin page and a custom header. No CORS grant, reset,
        # arbitrary command/path input, remote binding or real-order capability.
        if (not self.allowed() or self.path!='/start' or self.headers.get('X-Edge-Launcher')!='start'
            or self.headers.get('Origin') not in (URL,f'http://localhost:{PORT}')):
            self.send(403,'{}');return
        if self.headers.get('Content-Length','0')!='0':self.send(400,'{}');return
        self.send(200,json.dumps(start(),ensure_ascii=False))

def ensure():
    try:
        existing_launcher()
        return
    except RuntimeError:raise
    except Exception:
        if listening(PORT):raise RuntimeError('LAUNCHER_ADDRESS_OCCUPIED') from None
    flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
    with (OUT/'helper.log').open('ab') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--serve'],cwd=ROOT,
                               stdout=log,stderr=log,creationflags=flags)
    deadline=time.monotonic()+10
    while time.monotonic()<deadline:
        try:
            existing_launcher()
            return
        except RuntimeError:raise
        except Exception:pass
        if child.poll() is not None:raise RuntimeError('LAUNCHER_START_FAILED')
        time.sleep(.2)
    raise RuntimeError('LAUNCHER_START_TIMEOUT')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='EDGE OS local PAPER_ONLY launcher')
    parser.add_argument('--serve',action='store_true')
    parser.add_argument('--open',action='store_true')
    args=parser.parse_args()
    if args.serve:ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()
    else:
        ensure()
        if args.open:webbrowser.open(URL)
        print(URL)
