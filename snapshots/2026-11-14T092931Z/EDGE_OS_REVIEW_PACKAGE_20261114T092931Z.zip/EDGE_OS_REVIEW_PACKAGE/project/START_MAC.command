#!/bin/bash
cd "$(dirname "$0")"
echo "=============================================="
echo "  Polymarket Edge OS - Paper Only"
echo "=============================================="
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 was not found. Install Python 3.11 or newer and retry."
  read -p "Press Enter to close..."
  exit 1
fi
if [ ! -d ".venv" ]; then
  echo "First run: preparing the local environment..."
  python3 -m venv .venv
  source .venv/bin/activate
  python -m pip install -q -r requirements.txt
else
  source .venv/bin/activate
fi
python -m pip install -q -r requirements.txt || exit 1
open "dashboard.html"
echo "Backend is starting. Keep this window open."
echo "Dashboard opens at http://127.0.0.1:8000"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
