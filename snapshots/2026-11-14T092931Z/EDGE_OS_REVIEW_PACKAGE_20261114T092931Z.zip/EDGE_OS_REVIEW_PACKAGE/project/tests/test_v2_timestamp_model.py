"""V4 clock-domain regression: deterministic fixtures and temporary DBs only."""
import asyncio
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
import sqlite3

import httpx
import pytest

from app.strict_paper import (BookLevel, BookSnapshot, MarketIdentity, MarketState,
    OrderIntent, LocalObservationEngineRules, WalletFollowEngineRules, execute_order)
from app.wallet_follow_runtime import WalletFollowRuntime, V2_CONFIG
from app.wallet_follow_v2 import WalletFollowV2
from app.polymarket import PolymarketClient

T=datetime(2026,10,2,tzinfo=timezone.utc)
ID=MarketIdentity('condition','token','YES');W='0x'+'1'*40

def book(name, request, received, source=-30000):
    levels=(BookLevel(Decimal('.4'),Decimal('1000')),)
    return BookSnapshot(name,'request-'+name,ID,'fixture',T+timedelta(milliseconds=source),
        T+timedelta(milliseconds=request),T+timedelta(milliseconds=received),
        (BookLevel(Decimal('.39'),Decimal('1000')),),levels,
        json.dumps({'raw_source_timestamp':str(int((T+timedelta(milliseconds=source)).timestamp()*1000)),
                    'raw_timestamp_type':'str','upstream_hash':'same-hash','phase':name.upper()}))

def evaluate(q=None,x=None,now=1000,rules=None,market=None,fee='0',side='BUY'):
    q=q or book('quote',10,20);x=x or book('execution',520,530)
    market=market or MarketState(ID,accepting_orders=True,minimum_order_size=Decimal('5'),
        minimum_order_source='fixture',state_source='fixture',observed_at=T+timedelta(milliseconds=now),
        request_timestamp=T,received_timestamp=T+timedelta(milliseconds=now))
    intent=OrderIntent('signal','idem',ID,side,Decimal('25'),True,edge_detected_timestamp=T)
    return execute_order(intent,market,q,x,rules or LocalObservationEngineRules(),
        fee_rate=Decimal(fee),fee_source='fixture',observed_at=T+timedelta(milliseconds=now)),intent

def test_request_after_detection_old_source_and_unchanged_book_pass_v4_only():
    d,i=evaluate()
    assert d.status=='FILLED' and d.engine_version=='strict-paper-engine-v4'
    ev=d.to_evidence(i)
    assert ev['execution']['source_equal_previous'] is True
    assert ev['execution']['hash_equal_previous'] is True
    assert ev['quote']['source_minus_received_ms'] < -30000
    assert ev['rule_config']['timestamp_model']=='LOCAL_CAUSAL_OBSERVATION_V1'
    old,_=evaluate(rules=WalletFollowEngineRules())
    assert old.reason=='QUOTE_PREDATES_SIGNAL' and old.engine_version=='strict-paper-engine-v3'

def test_v3_still_rejects_equal_source_after_valid_quote():
    q=book('quote',0,10,0);x=book('execution',510,520,0)
    assert evaluate(q,x,rules=WalletFollowEngineRules())[0].reason=='EXECUTION_BOOK_NOT_NEWER'
    assert evaluate(q,x)[0].status=='FILLED'

@pytest.mark.parametrize('q,x,now,reason',[
    (book('quote',-1,20),None,1000,'QUOTE_PREDATES_SIGNAL'),
    (None,None,3021,'STALE_QUOTE'),
    (None,book('execution',519,530),1000,'EXECUTION_BEFORE_FROZEN_LATENCY'),
    (None,book('execution',19,530),1000,'EXECUTION_BEFORE_FROZEN_LATENCY'),
    (book('quote',30,20),None,1000,'INVALID_QUOTE_LOCAL_TIMESTAMPS'),
    (book('quote',10,1001),None,1000,'INVALID_QUOTE_LOCAL_TIMESTAMPS'),
    (None,book('execution',520,510),1000,'INVALID_EXECUTION_LOCAL_TIMESTAMPS'),
    (None,book('execution',520,1001),1000,'INVALID_EXECUTION_LOCAL_TIMESTAMPS'),
])
def test_local_same_clock_failures(q,x,now,reason):
    assert evaluate(q,x,now)[0].reason==reason

def test_upstream_ahead_is_diagnostic_not_terminal():
    d,i=evaluate(book('quote',10,20,10000),book('execution',520,530,10000))
    assert d.status=='FILLED'
    assert d.to_evidence(i)['execution']['source_minus_received_ms']==9470

@pytest.mark.parametrize('field',['request_id','snapshot_id'])
def test_reused_request_or_snapshot_rejected(field):
    q=book('quote',10,20);x=replace(book('execution',520,530),**{field:getattr(q,field)})
    assert evaluate(q,x)[0].reason=='REUSED_QUOTE_SNAPSHOT'

def test_stale_execution_observation_reason_precedence():
    # With valid chronology stale execution implies stale quote too. V4 checks
    # execution age first to report the decisive unavailable execution evidence.
    d,_=evaluate(now=3531)
    assert d.reason=='STALE_EXECUTION_BOOK'

@pytest.mark.parametrize('ask,size,minimum,fee,reason',[
        ('.4','1000','5','0','EXECUTED'),
    ('.4','10','5','0','BELOW_MINIMUM_ORDER'),
    ('.99','1000','5','0','NET_ROI_BELOW_FLOOR'),
    ('.4','1000','5','NaN','INVALID_FEE_EVIDENCE'),
])
def test_valid_timestamp_enters_unchanged_financial_checks(ask,size,minimum,fee,reason):
    q=book('quote',10,20);x=replace(book('execution',520,530),asks=(BookLevel(Decimal(ask),Decimal(size)),))
    d,_=evaluate(q,x,fee=fee)
    assert d.reason==reason
    if d.status=='FILLED':assert d.filled_notional==Decimal('25')

class Clock:
    def __init__(self):self.at=T
    def now(self):return self.at
    async def sleep(self,s):self.at+=timedelta(seconds=s)

class Client:
    def __init__(self,clock,stamp='old',bad_phase=None,mode=None):
        self.clock=clock;self.stamp=stamp;self.bad_phase=bad_phase;self.mode=mode;self.calls=0
    async def market_state(self,token):
        return {'condition_id':'condition','token_id':'token','outcome':'YES','accepting_orders':True,
                'closed':False,'resolved':False,'minimum_order_size':5,'minimum_order_source':'Gamma.market.orderMinSize',
                'market_source_timestamp':int(T.timestamp()),'current_price':.4}
    async def research_fee(self,*args):return {'rate':'0.05','source':'fixture','exponent':1}
    async def orderbook(self,token):
        self.calls+=1;bad=self.calls==self.bad_phase
        if bad and self.mode=='network':raise httpx.ConnectError('fixture failure')
        stamp=int((T-timedelta(seconds=30) if self.stamp=='old' else T+timedelta(seconds=1)).timestamp()*1000)
        if bad and self.mode=='invalid':stamp='not-a-time'
        if bad and self.mode=='missing':stamp=None
        raw={'timestamp':stamp,'hash':'same-hash','asset_id':'token','market':'condition',
             'bids':[{'price':'.39','size':'1000'}],'asks':[{'price':'.40','size':'1000'}]}
        if bad and self.mode=='malformed':raw['asks']=[{'price':'bad','size':'1000'}]
        return {'timestamp':stamp,'raw':raw,'bids':raw['bids'],'asks':raw['asks'],
                'http_metadata':{'http_status':200,'http_date':'Fri, 02 Oct 2026 00:00:00 GMT','http_age':None,'http_cache_control':'no-cache'}}

def setup(tmp_path,**client_args):
    p=tmp_path/'paper.db';WalletFollowV2.initialize(p);sim=WalletFollowV2(p)
    sim.create_version(V2_CONFIG,created_at=T,evidence_cutoff=T);sim.activate(at=T)
    clock=Clock();client=Client(clock,**client_args)
    return p,sim,client,WalletFollowRuntime(p,client,clock=clock.now,sleep=clock.sleep)

def process(runtime,key='signal'):
    trade={'trade_key':key,'timestamp':T.timestamp(),'condition_id':'condition','token_id':'token',
           'outcome':'YES','side':'BUY','price':.4,'raw':{'source':'deterministic fixture'}}
    return asyncio.run(runtime.process_trade(W,trade,detected_at=T))

@pytest.mark.parametrize('stamp',['old','future'])
def test_runtime_v4_fill_ledger_reconciliation_and_duplicate(tmp_path,stamp):
    p,sim,c,r=setup(tmp_path,stamp=stamp);config_before=sim.version()['config_json']
    result=process(r);assert result['status']=='FILLED'
    assert result['decision']['engine_version']=='strict-paper-engine-v4'
    assert sim.ledger(W).reconcile()['ok']
    assert sim.version()['config_json']==config_before and json.loads(config_before)['live_orders'] is False
    ev=result['decision'];assert ev['execution']['hash_equal_previous'] is True
    assert ev['quote']['raw_timestamp_type']=='int' and ev['quote']['phase']=='QUOTE'
    assert ev['execution']['phase']=='EXECUTION' and ev['execution']['http_status']==200
    assert ev['execution']['bid_level_count']==ev['execution']['ask_level_count']==1
    assert process(r)['duplicate'] is True and c.calls==2
    # Process-death recovery recognizes V4 immutable committed evidence.
    with sim._connect() as con:
        con.execute("UPDATE wallet_v2_episodes SET paper_status='OBSERVED',paper_order_id=NULL")
    assert sim.recover_stale_observed(now=T+timedelta(seconds=121))==1
    assert sim.episode(result['episode_id'])['paper_status']=='FILLED'
    assert sim.ledger(W).reconcile()['ok']
    assert sim.recover_stale_observed(now=T+timedelta(seconds=122))==0

@pytest.mark.parametrize('phase',[1,2])
@pytest.mark.parametrize('mode,reason',[('invalid','INVALID_TIMESTAMP'),('missing','MISSING_TIMESTAMP'),
    ('malformed','INVALID_PRICE'),('network','ORDER_BOOK_RESPONSE_UNAVAILABLE')])
def test_adapter_failure_preserves_evidence_before_terminal(tmp_path,phase,mode,reason):
    p,sim,c,r=setup(tmp_path,bad_phase=phase,mode=mode)
    result=process(r)
    assert result['status']=='REJECTED'
    with sqlite3.connect(p) as con:
        ev=json.loads(con.execute('SELECT evidence_json FROM wallet_v2_runtime_events').fetchone()[0])
        assert con.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0]==0
    book_ev=ev['books'][-1]
    assert book_ev['phase']==('QUOTE' if phase==1 else 'EXECUTION')
    assert book_ev['request_id'] and book_ev['request_timestamp'] and book_ev['elapsed_ms']>=0
    if mode!='network':
        assert book_ev['received_timestamp'] and book_ev['upstream_hash']=='same-hash'
        assert book_ev['raw_book'] is not None and book_ev['http_status']==200
    else:assert book_ev['received_timestamp'] is None
    assert book_ev['validation_reason']
    assert result['reason']==reason
    assert process(r)['duplicate'] is True and c.calls==phase

def test_evidence_write_failure_never_creates_fill(tmp_path):
    p,sim,c,r=setup(tmp_path)
    with sqlite3.connect(p) as con:
        con.execute("CREATE TRIGGER deny_book_audit BEFORE INSERT ON wallet_v2_audit WHEN NEW.action='EXECUTION_ATTEMPT' BEGIN SELECT RAISE(ABORT,'fixture audit unavailable'); END")
    assert process(r)['status']=='REJECTED'
    with sqlite3.connect(p) as con:
        assert con.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0]==0
        ev=json.loads(con.execute('SELECT evidence_json FROM wallet_v2_runtime_events').fetchone()[0])
        assert len(ev['books'])==2

@pytest.mark.parametrize('status',[200,404])
def test_http_metadata_no_extra_network_call(status):
    calls=[]
    def handler(request):
        calls.append((request.method,str(request.url)))
        return httpx.Response(status,json={'timestamp':'1790899200000','hash':'h',
            'bids':[{'price':'.39','size':'10'}],'asks':[{'price':'.4','size':'10'}]},
            headers={'Date':'Fri, 02 Oct 2026 00:00:00 GMT','Age':'2','Cache-Control':'no-cache'})
    async def run():
        client=PolymarketClient.__new__(PolymarketClient)
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as transport:
            client.client=transport
            if status==200:
                ev=(await client.orderbook('token'))['http_metadata']
            else:
                with pytest.raises(Exception) as error:await client.orderbook('token')
                ev=error.value.response_metadata
            assert ev['http_status']==status and ev['http_age']=='2' and ev['http_cache_control']=='no-cache'
    asyncio.run(run())
    assert len(calls)==1 and calls[0][0]=='GET' and '/time' not in calls[0][1]

def test_v4_cannot_use_v3_rule_name():
    with pytest.raises(ValueError,match='INVALID_TIMESTAMP_MODEL_RULE_VERSION'):
        LocalObservationEngineRules(rule_version='strict-paper-rules-v3-wallet-follow-v2.0')


@pytest.mark.parametrize('phase',[1,2])
def test_http_error_through_runtime_retains_actual_receive_time(tmp_path,monkeypatch,phase):
    p,sim,c,r=setup(tmp_path)
    class ResponseClock(datetime):
        @classmethod
        def now(cls,tz=None):return c.clock.now()
    monkeypatch.setattr('app.polymarket.datetime',ResponseClock)
    requests=[]
    def handler(request):
        requests.append(request)
        c.clock.at+=timedelta(milliseconds=10)
        return httpx.Response(404 if len(requests)==phase else 200,
            json={'timestamp':int(T.timestamp()*1000),'hash':'response-hash',
                  'asset_id':'token','market':'condition',
                  'bids':[{'price':'.39','size':'1000'}],'asks':[{'price':'.4','size':'1000'}]},
            headers={'Date':'Fri, 02 Oct 2026 00:00:00 GMT','Age':'2','Cache-Control':'no-cache'})
    async def run():
        public=PolymarketClient.__new__(PolymarketClient)
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as transport:
            public.client=transport
            c.orderbook=public.orderbook
            trade={'trade_key':'http-error','timestamp':T.timestamp(),'condition_id':'condition',
                   'token_id':'token','outcome':'YES','side':'BUY','price':.4}
            return await r.process_trade(W,trade,detected_at=T)
    result=asyncio.run(run())
    assert result['status']=='REJECTED' and result['reason']=='ORDER_BOOK_RESPONSE_UNAVAILABLE'
    with sqlite3.connect(p) as con:
        evidence=json.loads(con.execute('SELECT evidence_json FROM wallet_v2_runtime_events').fetchone()[0])
        assert con.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0]==0
    failed=evidence['books'][-1]
    assert failed['http_status']==404 and failed['http_response_attempt']==1
    assert failed['received_timestamp']==c.clock.now().isoformat()
    assert failed['received_timestamp']==failed['http_response_received_timestamp']
    assert datetime.fromisoformat(failed['received_timestamp']) > datetime.fromisoformat(failed['request_timestamp'])
    assert failed['raw_book']['hash']=='response-hash' and failed['http_age']=='2'
    assert len(requests)==phase and sim.episode(result['episode_id'])['paper_status']=='REJECTED'


@pytest.mark.parametrize('failure',['validation','sqlite'])
def test_post_submit_ledger_failure_releases_cash_before_terminal_rejection(tmp_path,monkeypatch,failure):
    p,sim,c,r=setup(tmp_path)
    from app.strict_ledger import StrictPaperLedger
    if failure=='validation':
        def reject(*args,**kwargs):raise ValueError('INVALID_EXECUTION_EVIDENCE')
        monkeypatch.setattr('app.strict_ledger._validate_execution_evidence',reject)
    else:
        with sqlite3.connect(p) as con:
            con.execute("CREATE TRIGGER deny_fill BEFORE INSERT ON strict_fills BEGIN SELECT RAISE(ABORT,'fixture ledger unavailable'); END")
    result=process(r)
    assert result['status']=='REJECTED' and result['reason']=='EXECUTION_COMMIT_INCOMPLETE'
    ledger=sim.ledger(W);snapshot=ledger.account_snapshot()
    assert snapshot['fills']==[] and snapshot['positions']==[]
    assert snapshot['orders'][0]['status']=='CANCELLED'
    assert Decimal(snapshot['account']['reserved_cash'])==0
    assert Decimal(snapshot['account']['available_cash'])==Decimal(snapshot['account']['initial_cash'])
    assert ledger.reconcile()['ok']
    with sqlite3.connect(p) as con:
        event=con.execute('SELECT reason,evidence_json FROM wallet_v2_runtime_events').fetchone()
        assert event[0]=='EXECUTION_COMMIT_INCOMPLETE'
        evidence=json.loads(event[1]);assert len(evidence['books'])==2
        assert evidence['reservations_released'] and evidence['fill_ids']==[]
        assert con.execute("SELECT COUNT(*) FROM strict_audit_events WHERE event_type='ORDER_CANCELLED'").fetchone()[0]==1
    assert process(r)['duplicate'] and c.calls==2
    restarted=WalletFollowV2(p)
    assert restarted.recover_stale_observed(now=T+timedelta(seconds=121))==0
    assert restarted.ledger(W).reconcile()['ok']
    assert not restarted.record_runtime_failure(signal_id='signal',wallet=W,condition_id='condition',
        reason='duplicate failure',occurred_at=T+timedelta(seconds=122),episode_id=result['episode_id'])
    assert StrictPaperLedger(p,ledger.account_id).account_snapshot()['fills']==[]


def test_failure_record_rollback_keeps_observed_and_recovery_releases_reservation(tmp_path,monkeypatch):
    p,sim,c,r=setup(tmp_path)
    def reject(*args,**kwargs):raise ValueError('INVALID_EXECUTION_EVIDENCE')
    monkeypatch.setattr('app.strict_ledger._validate_execution_evidence',reject)
    with sqlite3.connect(p) as con:
        con.execute("CREATE TRIGGER deny_failure BEFORE INSERT ON wallet_v2_runtime_events BEGIN SELECT RAISE(ABORT,'fixture failure write unavailable'); END")
    with pytest.raises(sqlite3.IntegrityError,match='fixture failure write unavailable'):process(r)
    with sqlite3.connect(p) as con:
        episode_id=con.execute('SELECT episode_id FROM wallet_v2_episodes').fetchone()[0]
        assert con.execute('SELECT paper_status FROM wallet_v2_episodes').fetchone()[0]=='OBSERVED'
        assert con.execute('SELECT status FROM strict_orders').fetchone()[0]=='OPEN'
        assert con.execute("SELECT COUNT(*) FROM strict_audit_events WHERE event_type='ORDER_CANCELLED'").fetchone()[0]==0
        con.execute('DROP TRIGGER deny_failure')
    calls=c.calls
    assert sim.recover_stale_observed(now=T+timedelta(seconds=121))==1
    assert sim.episode(episode_id)['rejection_reason']=='EXECUTION_COMMIT_INCOMPLETE'
    assert Decimal(sim.ledger(W).account()['reserved_cash'])==0
    assert c.calls==calls and sim.ledger(W).reconcile()['ok']


def test_exception_after_fill_commit_does_not_mislabel_or_strand_position(tmp_path,monkeypatch):
    p,sim,c,r=setup(tmp_path)
    from app.strict_ledger import StrictPaperLedger
    original=StrictPaperLedger.apply_execution
    def committed_then_failed(self,*args,**kwargs):
        original(self,*args,**kwargs)
        raise RuntimeError('fixture failure after fill commit')
    monkeypatch.setattr(StrictPaperLedger,'apply_execution',committed_then_failed)
    result=process(r)
    assert result['status']=='RECOVERY_REQUIRED'
    assert sim.episode(result['episode_id'])['paper_status']=='OBSERVED'
    with sqlite3.connect(p) as con:
        assert con.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0]==1
        assert con.execute('SELECT COUNT(*) FROM wallet_v2_runtime_events').fetchone()[0]==0
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_audit WHERE action='EXECUTION_FAILURE_RECOVERY_REQUIRED'").fetchone()[0]==1
    assert sim.recover_stale_observed(now=T+timedelta(seconds=121))==1
    recovered=sim.episode(result['episode_id'])
    assert recovered['paper_status']=='FILLED' and recovered['paper_order_id']
    assert sim.recover_stale_observed(now=T+timedelta(seconds=122))==0
    assert process(r)['duplicate'] and c.calls==2
    assert sim.record_resolution(result['episode_id'],status='FORMALLY_RESOLVED',
        observed_at=T+timedelta(seconds=123),authoritative_source='fixture formal result',
        winning_token_id='token',payout_per_share='1')
    assert sim.ledger(W).reconcile()['ok']
    final=sim.ledger(W).account_snapshot()
    assert len(final['fills'])==1 and Decimal(final['positions'][0]['quantity'])==0
    assert Decimal(final['account']['reserved_cash'])==0
