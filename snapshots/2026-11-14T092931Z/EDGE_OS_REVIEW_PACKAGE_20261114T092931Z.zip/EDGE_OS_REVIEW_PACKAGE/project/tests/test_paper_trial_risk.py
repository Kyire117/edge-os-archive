"""Behavioral checks for a funded paper trial; no network or active database."""
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from decimal import Decimal
import json,sqlite3
import pytest
from app.paper_trial_risk import initialize,read_status,record_book,check_buy,policy,snapshot,observe,DEFAULTS
from app.strict_paper import MarketIdentity
from test_shared_pool import pooled,fill,read
from test_wallet_follow_v2 import T0,IDENT,book


def trial(tmp_path):
 sim=pooled(tmp_path)
 initialize(sim.path,at=T0)
 return sim


def test_fee_inclusive_order_cap_and_frozen_strategy(tmp_path):
 sim=trial(tmp_path);_,r=fill(sim,fee='.07')
 assert r['status']=='FILLED'
 f=read(sim,'SELECT * FROM strict_fills')[0]
 assert Decimal(f['gross_amount'])+Decimal(f['fee'])<=1
 assert Decimal(f['gross_amount'])>0
 assert DEFAULTS['version']=='paper-trial-risk-v2'
 assert DEFAULTS['max_market_exposure']=='1.000000'
 assert Decimal(read_status(sim.path,at=T0+timedelta(seconds=2))['market_exposure'][0]['exposure'])<=Decimal('1.000000')
 assert json.loads(sim.version()['config_json'])['fixed_notional']=='25'
 assert sim.ledger('0xabc').reconcile()['ok']


def test_event_limit_includes_other_wallets(tmp_path):
 sim=trial(tmp_path)
 assert fill(sim,signal='a',identity=MarketIdentity('event','token-a','YES'))[1]['status']=='FILLED'
 assert fill(sim,wallet='0xother',signal='b',identity=MarketIdentity('event','token-b','NO'))[1]['status']=='FILLED'
 r=fill(sim,wallet='0xthird',signal='c',identity=MarketIdentity('event','token-c','OVER'))[1]
 assert r['reason']=='TRIAL_RISK_EVENT_LIMIT'
 assert len(read(sim,'SELECT * FROM strict_fills'))==2


def test_add_on_to_full_market_is_rejected_at_cumulative_one_usdc(tmp_path):
 sim=trial(tmp_path);identity=MarketIdentity('event','token','YES')
 assert fill(sim,signal='first',identity=identity)[1]['status']=='FILLED'
 # A second wallet creates a distinct forward episode while preserving the
 # same market identity; same-wallet repeat observations are deduped earlier.
 episode,result=fill(sim,wallet='0xother',signal='add-on',identity=identity)
 assert result['reason']=='TRIAL_RISK_MARKET_LIMIT'
 status=read_status(sim.path,at=T0+timedelta(seconds=2))
 assert Decimal(status['market_exposure'][0]['exposure'])<=Decimal('1.000000')
 assert len(read(sim,'SELECT * FROM strict_fills'))==1


def test_pending_reservations_cannot_race_portfolio_limit(tmp_path):
 sim=trial(tmp_path)
 def reserve(i):
  ledger=sim.ledger('0xabc')
  try:
   ledger.submit_order(order_id='o'+str(i),idempotency_key='i'+str(i),signal_id='s'+str(i),
    identity=MarketIdentity('event'+str(i),'token'+str(i),'YES'),side='BUY',target_quantity=0,
    reserve_cash='1',requested_notional='1',engine_version='strict-paper-engine-v4',rule_version='fixture',
    evidence={},created_at=T0.isoformat())
   return True
  except ValueError as e:
   assert str(e)=='TRIAL_RISK_PORTFOLIO_LIMIT';return False
 with ThreadPoolExecutor(max_workers=12) as pool:result=list(pool.map(reserve,range(40)))
 assert sum(result)==30
 assert Decimal(sim.ledger('0xabc').account()['reserved_cash'])==30
 assert Decimal(sim.ledger('0xabc').account()['available_cash'])==70


def test_concurrent_same_market_reservations_cannot_exceed_one_usdc(tmp_path):
 sim=trial(tmp_path);identity=MarketIdentity('event','same-token','YES')
 def reserve(i):
  try:
   sim.ledger('0xabc').submit_order(order_id='m'+str(i),idempotency_key='mi'+str(i),signal_id='ms'+str(i),
    identity=identity,side='BUY',target_quantity=0,reserve_cash='1',requested_notional='1',
    engine_version='strict-paper-engine-v4',rule_version='fixture',evidence={},created_at=T0.isoformat())
   return True
  except ValueError as e:
   assert str(e)=='TRIAL_RISK_MARKET_LIMIT';return False
 with ThreadPoolExecutor(max_workers=12) as pool:result=list(pool.map(reserve,range(20)))
 assert sum(result)==1
 status=read_status(sim.path,at=T0)
 assert status['market_exposure']==[{'condition_id':'event','token_id':'same-token','outcome':'YES','exposure':'1.000000'}]


def test_market_exposure_counts_open_buy_reservations_by_full_identity(tmp_path):
 sim=trial(tmp_path);identity=MarketIdentity('event','token','YES')
 ledger=sim.ledger('0xabc')
 ledger.submit_order(order_id='first',idempotency_key='first-key',signal_id='first-signal',identity=identity,
  side='BUY',target_quantity=0,reserve_cash='.72',requested_notional='.72',engine_version='strict-paper-engine-v4',
  rule_version='fixture',evidence={},created_at=T0.isoformat())
 with sqlite3.connect(sim.path) as con:
  con.row_factory=sqlite3.Row
  assert snapshot(con,policy(con,ledger.account_id),T0)['market_exposure'][('event','token','YES')]==Decimal('.72')
  with pytest.raises(ValueError,match='TRIAL_RISK_MARKET_LIMIT'):
   check_buy(con,ledger.account_id,identity,'.29',T0)
  check_buy(con,ledger.account_id,identity,'.28',T0)
  check_buy(con,ledger.account_id,MarketIdentity('event','token','NO'),'.29',T0)


def test_market_exposure_sums_position_cost_and_open_buy_reserve(tmp_path,monkeypatch):
 sim=trial(tmp_path);identity=MarketIdentity('event','token','YES')
 from app import paper_trial_risk
 monkeypatch.setattr(paper_trial_risk,'entry_notional',lambda con,account_id,requested,fee_rate:Decimal('.60'))
 assert fill(sim,signal='position',identity=identity,fee='0')[1]['status']=='FILLED'
 ledger=sim.ledger('0xabc')
 ledger.submit_order(order_id='remaining',idempotency_key='remaining-key',signal_id='remaining-signal',identity=identity,
  side='BUY',target_quantity=0,reserve_cash='.4',requested_notional='.4',engine_version='strict-paper-engine-v4',
  rule_version='fixture',evidence={},created_at=(T0+timedelta(seconds=2)).isoformat())
 with sqlite3.connect(sim.path) as con:
  con.row_factory=sqlite3.Row
  now=T0+timedelta(seconds=2)
  exposure=snapshot(con,policy(con,ledger.account_id),now)['market_exposure'][('event','token','YES')]
  assert exposure==Decimal('1.000000')
  with pytest.raises(ValueError,match='TRIAL_RISK_MARKET_LIMIT'):
   check_buy(con,ledger.account_id,identity,'.000001',now)


def test_net_loss_pause_latches_and_settlement_still_works(tmp_path):
 sim=trial(tmp_path)
 for i in range(20):
  identity=MarketIdentity('event'+str(i),'yes'+str(i),'YES')
  ep,r=fill(sim,signal=str(i),identity=identity)
  assert r['status']=='FILLED'
  sim.record_resolution(ep['episode_id'],status='FORMALLY_RESOLVED',observed_at=T0+timedelta(seconds=3+i),
   authoritative_source='fixture',winning_token_id='no'+str(i),payout_per_share='0')
 s=read_status(sim.path,at=T0+timedelta(seconds=8))
 assert Decimal(s['realized_pnl'])==-20
 assert s['paused_reason']=='PAUSED_NET_LOSS'
 r=fill(sim,signal='after',identity=MarketIdentity('after','after','YES'))[1]
 assert r['reason']=='TRIAL_RISK_PAUSED_NET_LOSS'
 assert len(read(sim,'SELECT * FROM strict_fills'))==20
 assert sim.ledger('0xabc').reconcile()['ok']


def test_stale_marks_block_new_risk_and_recover_with_real_book(tmp_path):
 sim=trial(tmp_path);fill(sim)
 with sqlite3.connect(sim.path) as c:
  c.row_factory=sqlite3.Row
  with pytest.raises(ValueError,match='VALUATION_UNAVAILABLE'):
   check_buy(c,sim.ledger('0xabc').account_id,MarketIdentity('new','new','YES'),'.5',T0+timedelta(seconds=70))
 fresh=book('fresh',70000,bids=(('.4','100'),),asks=(('.5','100'),))
 record_book(sim.path,sim.ledger('0xabc').account_id,fresh,fee_rate='0',minimum_order_size='0',observed_at=T0+timedelta(seconds=71))
 with sqlite3.connect(sim.path) as c:
  c.row_factory=sqlite3.Row
  check_buy(c,sim.ledger('0xabc').account_id,MarketIdentity('new','new','YES'),'.5',T0+timedelta(seconds=71))


def test_shared_token_depth_is_not_counted_twice(tmp_path,monkeypatch):
 sim=trial(tmp_path)
 from app import paper_trial_risk
 monkeypatch.setattr(paper_trial_risk,'entry_notional',lambda con,account_id,requested,fee_rate:min(Decimal('.45'),Decimal(str(requested))))
 fill(sim,signal='one',fee='.04')
 fill(sim,wallet='0xother',signal='two',fee='.04')
 shallow=book('shallow',3000,bids=(('.4','10'),),asks=(('.5','10'),))
 record_book(sim.path,sim.ledger('0xabc').account_id,shallow,fee_rate='.04',minimum_order_size='0',observed_at=T0+timedelta(milliseconds=3100))
 s=read_status(sim.path,at=T0+timedelta(milliseconds=3100))
 assert s['missing_valuations']==1 # aggregate 1.8 shares exceeds the 1-share executable depth
 assert s['net_pnl'] is None
 deeper=book('deep',3000,bids=(('.4','20'),),asks=(('.5','20'),))
 record_book(sim.path,sim.ledger('0xabc').account_id,deeper,fee_rate='.04',minimum_order_size='0',observed_at=T0+timedelta(seconds=4))
 s=read_status(sim.path,at=T0+timedelta(seconds=4))
 assert s['missing_valuations']==0
 assert Decimal(s['net_pnl'])<0


def test_total_loss_stop_escalates_after_net_loss_pause(tmp_path,monkeypatch):
 sim=trial(tmp_path);account_id=sim.ledger('0xabc').account_id
 with sqlite3.connect(sim.path) as con:
  con.row_factory=sqlite3.Row
  con.execute("INSERT INTO paper_trial_risk_events(event_type,account_prefix,observed_at,evidence_json) VALUES('PAUSED_NET_LOSS','wallet-follow-v2.0:',?,'{}')",(T0.isoformat(),))
  from app import paper_trial_risk
  fake={'realized_pnl':Decimal('-70'),'open_cost_basis':Decimal('0'),'reserved_cash':Decimal('0'),
   'net_pnl':Decimal('-70'),'missing_valuations':0,'market_exposure':{},'event_exposure':{},
   'open_exposure':Decimal('0'),'paused_reason':'PAUSED_NET_LOSS','worst_case_net_loss':Decimal('70')}
  with monkeypatch.context() as m:
   m.setattr(paper_trial_risk,'snapshot',lambda *args:fake)
   observe(con,account_id,T0)
  assert con.execute("SELECT event_type FROM paper_trial_risk_events ORDER BY id DESC LIMIT 1").fetchone()[0]=='STOPPED_TOTAL_LOSS'


def test_venue_minimum_rejects_one_usdc_without_sizing_up(tmp_path):
 sim=trial(tmp_path)
 episode=sim.observe_buy(signal_id='min-signal',wallet='0xabc',identity=IDENT,leader_at=T0,detected_at=T0,
  leader_price='.5',source_mode='LIVE_OBSERVATION')
 quote=book('min-q',0,asks=(('.5','100'),))
 execution=book('min-e',600,asks=(('.5','100'),))
 from app.strict_paper import MarketState
 market=MarketState(IDENT,accepting_orders=True,state_source='fixture',observed_at=T0+timedelta(milliseconds=600),
  minimum_order_size=Decimal('3'),minimum_order_source='fixture-orderMinSize')
 result=sim.execute_first(episode['episode_id'],market=market,quote=quote,execution=execution,fee_rate='0',fee_source='fixture',
  observed_at=T0+timedelta(seconds=2))
 assert result['reason']=='BELOW_MINIMUM_ORDER'
 assert read(sim,'SELECT * FROM strict_fills')==[]


def test_policy_is_frozen(tmp_path):
 sim=trial(tmp_path)
 with sqlite3.connect(sim.path) as c:
  with pytest.raises(sqlite3.IntegrityError,match='FROZEN_RISK_POLICY'):
   c.execute("UPDATE paper_trial_risk SET config_json='{}'")


def test_without_opt_in_old_order_size_is_unchanged(tmp_path):
 sim=pooled(tmp_path);fill(sim)
 assert read(sim,'SELECT gross_amount FROM strict_fills')[0]['gross_amount']=='25.000000'
 assert read_status(sim.path)['enabled'] is False

def test_non_exit_policy_positions_get_fresh_portfolio_valuations(tmp_path):
 import asyncio
 from app.wallet_follow_runtime import WalletFollowRuntime
 sim=trial(tmp_path);fill(sim)
 runtime=WalletFollowRuntime(sim.path,object(),clock=lambda:T0+timedelta(seconds=11))
 async def market(identity,evidence):return (None,Decimal('0'),'fixture',Decimal('0'))
 async def get_book(identity,**kwargs):return book('refresh',10000,identity=identity,bids=(('.4','100'),),asks=(('.5','100'),))
 runtime._exit_market_evidence=market;runtime._book_snapshot=get_book
 result=asyncio.run(runtime.refresh_trial_valuations())
 assert result=={'checked':1,'errors':0}
 s=read_status(sim.path,at=T0+timedelta(seconds=11))
 assert s['missing_valuations']==0 and Decimal(s['net_pnl'])<0
