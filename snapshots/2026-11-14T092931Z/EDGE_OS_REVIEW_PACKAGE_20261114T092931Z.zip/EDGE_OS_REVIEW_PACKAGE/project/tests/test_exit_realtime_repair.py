"""Deterministic repair regressions. Temporary databases; no external network."""
import asyncio
import json
import sqlite3
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal

import pytest

from app.polygon_fast_path import PolygonProducer, ProducerConfig, decode_log
from app.wallet_follow_runtime import WalletFollowRuntime
from test_realtime_ingestion_exit_v1 import make_runtime, WALLET
from test_polygon_fast_path import database, producer, log, BLOCK, NOW, state


async def until(predicate, timeout=2):
    async def poll():
        while not predicate():await asyncio.sleep(.01)
    await asyncio.wait_for(poll(),timeout)


def test_sell_nonzero_network_latency_uses_three_distinct_books_and_fresh_market(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    original=client.orderbook;requests=[]
    async def book(token):
        start=clock.now();clock.value+=timedelta(milliseconds=120)
        value=await original(token);requests.append((start,clock.now()));return value
    client.orderbook=book;client.set_bids('0.54','0.53','0.52')
    outcome=asyncio.run(runtime.refresh_exit_v1())
    assert outcome['exited']==1 and len(requests)==3
    assert requests[1][0]>=requests[0][1]
    assert requests[2][0]>=requests[1][1]+timedelta(milliseconds=500)
    snap=engine.ledger(WALLET).account_snapshot()
    fill=next(f for f in snap['fills'] if f['side']=='SELL')
    evidence=json.loads(next(o for o in snap['orders'] if o['side']=='SELL')['evidence_json'])
    assert len({evidence['quote']['snapshot_id'],evidence['execution']['snapshot_id'],evidence['exit_v1']['trigger_snapshot_id']})==3
    assert evidence['quote']['request_timestamp']>=evidence['edge_detected_timestamp']
    assert engine.ledger(WALLET).reconcile()['ok']
    assert asyncio.run(runtime.refresh_exit_v1())['exited']==0


def test_exit_fee_and_partial_then_formal_settlement_reconcile(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    async def fee(*args):return {'rate':'0.02','source':'CLOB_FD','exponent':1}
    client.research_fee=fee;client.depth=100;client.set_bids('0.54','0.53','0.52')
    asyncio.run(runtime.refresh_exit_v1())
    ledger=engine.ledger(WALLET);snap=ledger.account_snapshot()
    sell=next(f for f in snap['fills'] if f['side']=='SELL')
    assert Decimal(sell['fee'])>0
    assert Decimal(snap['positions'][0]['reserved_quantity'])==0
    assert all(o['status']!='OPEN' for o in snap['orders'])
    assert ledger.reconcile()['ok']
    assert ledger.verify_audit_chain()['ok']
    client.formal=True
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    assert asyncio.run(runtime.refresh_settlements())['settled']==1
    assert asyncio.run(runtime.refresh_settlements())['settled']==0
    snap=ledger.account_snapshot()
    assert Decimal(snap['positions'][0]['quantity'])==0
    assert Decimal(snap['positions'][0]['cost_basis'])==0
    assert len([f for f in snap['fills'] if f['side']=='SELL'])==1
    with sqlite3.connect(path) as c:
        settled=sum((Decimal(r[0]) for r in c.execute("SELECT cash_flow FROM strict_settlements WHERE status='FORMALLY_RESOLVED'")),Decimal(0))
    expected=settled+sum((Decimal(f['gross_amount'])-Decimal(f['fee']) for f in snap['fills'] if f['side']=='SELL'),Decimal(0))-sum((Decimal(f['gross_amount'])+Decimal(f['fee']) for f in snap['fills'] if f['side']=='BUY'),Decimal(0))
    assert Decimal(snap['positions'][0]['realized_pnl'])==expected
    assert ledger.reconcile()['ok']
    assert ledger.verify_audit_chain()['ok']


def test_exit_stale_market_still_rejects_without_loosening_three_second_gate(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    async def slow_fee(*args):
        clock.value+=timedelta(seconds=4)
        return {'rate':'0','source':'GAMMA_FEES_DISABLED','exponent':1}
    client.research_fee=slow_fee;client.set_bids('0.54','0.53','0.52')
    asyncio.run(runtime.refresh_exit_v1())
    with sqlite3.connect(path) as c:
        assert c.execute("SELECT reason FROM strict_decisions WHERE side='SELL'").fetchone()[0]=='STALE_MARKET_STATE'
        assert c.execute("SELECT COUNT(*) FROM strict_fills WHERE side='SELL'").fetchone()[0]==0
    assert engine.ledger(WALLET).reconcile()['ok']


def test_exit_without_liquidity_does_not_fabricate_sell(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    client.depth=0;client.set_bids('0.54')
    asyncio.run(runtime.refresh_exit_v1())
    with sqlite3.connect(path) as c:assert c.execute("SELECT COUNT(*) FROM strict_fills WHERE side='SELL'").fetchone()[0]==0
    assert engine.ledger(WALLET).reconcile()['ok']


def test_stalled_backfill_does_not_block_live_staging_or_execution(database):
    async def run():
        p,calls=producer(database);p.config=replace(p.config,independent_lanes=True)
        p.confirmed_head=101;p.store.checkpoint(100)
        release=asyncio.Event();entered=asyncio.Event();oldrpc=p.rpc
        async def rpc(method,params):
            if method=='eth_getLogs':entered.set();await release.wait();return []
            return await oldrpc(method,params)
        p.rpc=rpc
        backfill=asyncio.create_task(p.backfill(101))
        staging=asyncio.create_task(p._queue_loop());processing=asyncio.create_task(p._processing_loop())
        try:
            await entered.wait();await p.queue.put((log(),NOW.isoformat()))
            await until(lambda:len(calls)==1)
            assert not backfill.done() and p.store.checkpoint()==100
            assert state(database)[0]['state']=='ROUTED'
            release.set();await backfill
            assert p.store.checkpoint()==101
        finally:
            for task in (staging,processing,backfill):task.cancel()
            await asyncio.gather(staging,processing,backfill,*p.processing_tasks.values(),return_exceptions=True)
    asyncio.run(run())


def test_slow_identity_does_not_block_another_event_and_retry_is_persistent(database):
    async def run():
        p,calls=producer(database);p.config=replace(p.config,independent_lanes=True)
        p.confirmed_head=101;first=log(1);second=log(2);p.stage(first);p.stage(second)
        original=p.rpc;slow=asyncio.Event();release=asyncio.Event()
        async def rpc(method,params):
            if method=='eth_getTransactionReceipt':return {'blockHash':BLOCK,'status':'0x1','logs':[first,second]}
            return await original(method,params)
        p.rpc=rpc;resolve=p.resolver.resolve
        count=0
        async def metadata(token):
            nonlocal count
            count+=1
            if count==1:slow.set();await release.wait();raise TimeoutError('provider-secret')
            return await resolve(token)
        p.resolver.resolve=metadata
        worker=asyncio.create_task(p._processing_loop())
        try:
            await slow.wait();await until(lambda:len(calls)==1)
            release.set();await until(lambda:len(p.processing_tasks)==0)
            with database.conn() as c:
                retry=c.execute("SELECT value FROM polygon_fast_state WHERE key LIKE 'event_retry:%'").fetchone()
                evidence=c.execute("SELECT evidence_json FROM polygon_fast_audit WHERE action='WORKER_ERROR'").fetchall()
            assert json.loads(retry[0])['failures']==1
            assert 'provider-secret' not in json.dumps([r[0] for r in evidence])
            diagnostic=json.loads(evidence[0][0])
            assert diagnostic['phase']=='TOKEN_METADATA' and diagnostic['rpc_method'] is None
            assert diagnostic['error_type']=='TimeoutError'
            restarted,_=producer(database);restarted.config=replace(p.config);restarted.confirmed_head=101
            restarted.rpc=rpc
            # Durable retry suppresses immediate re-query after restart.
            restarted_worker=asyncio.create_task(restarted._processing_loop())
            await asyncio.sleep(.03);assert not restarted.processing_tasks
            restarted_worker.cancel();await asyncio.gather(restarted_worker,return_exceptions=True)
        finally:
            worker.cancel();await asyncio.gather(worker,*p.processing_tasks.values(),return_exceptions=True)
    asyncio.run(run())


def test_simultaneous_chain_queries_are_coalesced_but_not_cached_forever(database):
    async def run():
        p,_=producer(database);del p.rpc;p.config=replace(p.config,independent_lanes=True)
        release=asyncio.Event();requests=[]
        async def request(method,params):requests.append(method);await release.wait();return {'hash':BLOCK}
        p._rpc_request=request
        a=asyncio.create_task(p.rpc('eth_getBlockByNumber',['0x65',False]))
        b=asyncio.create_task(p.rpc('eth_getBlockByNumber',['0x65',False]))
        await until(lambda:bool(requests));release.set();await asyncio.gather(a,b)
        assert len(requests)==1
        await p.rpc('eth_getBlockByNumber',['0x65',False]);assert len(requests)==2
        assert not p._rpc_inflight
    asyncio.run(run())


def test_removed_event_during_resolution_cannot_be_routed(database):
    async def run():
        p,calls=producer(database);p.stage(log())
        old=p.resolver.resolve
        async def resolver(token):
            value=await old(token);p.stage(log(removed=True));return value
        p.resolver.resolve=resolver
        await p.process_pending(101)
        assert not calls and state(database)[0]['state']=='REMOVED'
    asyncio.run(run())


def test_processing_backoff_does_not_starve_more_than_256_queued_events(database):
    async def run():
        p,calls=producer(database);p.config=replace(p.config,independent_lanes=True);p.confirmed_head=101
        for i in range(1,258):p.stage(log(i))
        with database.conn() as c:
            for row in p.store.pending(101,limit=256):
                c.execute('INSERT INTO polygon_fast_state VALUES(?,?)',(p._retry_key(row),json.dumps({'next_retry_at':9999999999,'failures':1})))
        # Receipt evidence must match the only due event.
        old=p.rpc
        async def rpc(method,params):
            if method=='eth_getTransactionReceipt':return {'blockHash':BLOCK,'status':'0x1','logs':[log(257)]}
            return await old(method,params)
        p.rpc=rpc;worker=asyncio.create_task(p._processing_loop())
        try:await until(lambda:len(calls)==1)
        finally:
            worker.cancel();await asyncio.gather(worker,*p.processing_tasks.values(),return_exceptions=True)
    asyncio.run(run())


@pytest.mark.parametrize('workers',[0,9,True])
def test_processing_concurrency_is_bounded(workers):
    with pytest.raises(ValueError,match='INVALID_WORKER_LIMITS'):ProducerConfig(processing_concurrency=workers).validate()


def test_independent_run_shutdown_drains_all_workers(database):
    async def run():
        p,calls=producer(database);p.config=replace(p.config,independent_lanes=True)
        p.confirmed_head=101
        async def connection():
            await p.queue.put((log(),NOW.isoformat()))
            await until(lambda:len(calls)==1)
            p.stop_event.set()
        p._connection_loop=connection
        await p.run()
        await asyncio.sleep(0)
        assert not p.worker_tasks and not p.processing_tasks and not p._rpc_inflight
        assert not [t for t in asyncio.all_tasks() if t is not asyncio.current_task() and not t.done()]
    asyncio.run(run())


def test_metadata_inflight_requests_are_coalesced(database):
    async def run():
        p,_=producer(database);entered=asyncio.Event();release=asyncio.Event();calls=[]
        async def metadata(token):
            calls.append(token);entered.set();await release.wait()
            return {'token_id':token,'condition_id':'0x'+'c'*64,'outcome':'YES','source':'GAMMA'}
        p.client.fast_token_metadata=metadata
        first=asyncio.create_task(p.resolver.resolve('123'))
        second=asyncio.create_task(p.resolver.resolve('123'))
        await entered.wait();release.set();await asyncio.gather(first,second)
        assert calls==['123'] and not p.resolver._inflight
    asyncio.run(run())


@pytest.mark.parametrize('depth,expected_state',[(1000,'EXITED'),(100,'ACTIVE')])
def test_crash_after_committed_sell_recovers_without_new_book_or_second_fill(tmp_path,depth,expected_state):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    ledger=engine.ledger(WALLET);apply=ledger.apply_execution
    def committed_then_crash(**kwargs):
        apply(**kwargs)
        raise RuntimeError('simulated process boundary after ledger commit')
    ledger.apply_execution=committed_then_crash
    runtime.engine.ledger=lambda wallet:ledger
    client.depth=depth;client.set_bids('0.54','0.53','0.52')
    first=asyncio.run(runtime.refresh_exit_v1())
    assert first['errors']==1
    calls=client.book_calls
    recovered=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    asyncio.run(recovered.refresh_exit_v1())
    assert client.book_calls==calls
    with sqlite3.connect(path) as c:
        assert c.execute("SELECT COUNT(*) FROM strict_fills WHERE side='SELL'").fetchone()[0]==1
        assert c.execute("SELECT state FROM wallet_v2_exit_positions").fetchone()[0]==expected_state
        assert c.execute("SELECT COUNT(*) FROM strict_orders WHERE status='OPEN'").fetchone()[0]==0
    assert ledger.reconcile()['ok'] and ledger.verify_audit_chain()['ok']


def test_latched_partial_stop_uses_improved_bid_depth_after_rebound(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    client.depth=100;client.set_bids('0.54','0.53','0.52')
    asyncio.run(runtime.refresh_exit_v1())
    client.depth=1000;client.set_bids('0.65','0.64','0.63')
    outcome=asyncio.run(WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep).refresh_exit_v1())
    assert outcome['exited']==1
    with sqlite3.connect(path) as c:
        assert c.execute('SELECT state,exit_reason FROM wallet_v2_exit_positions').fetchone()==('EXITED','DYNAMIC_HARD_STOP')
        assert c.execute("SELECT COUNT(*) FROM strict_fills WHERE side='SELL'").fetchone()[0]==2
    assert engine.ledger(WALLET).reconcile()['ok']


@pytest.mark.parametrize('handler_result',['FILLED','ERROR','NO_SIGNAL'])
def test_removed_during_routing_preserves_reorg_and_committed_fill(database,handler_result):
    from app.strict_paper import BookLevel, BookSnapshot, MarketIdentity, MarketState
    from app.wallet_follow_v2 import WalletFollowV2
    from app.wallet_follow_runtime import V2_CONFIG
    from test_polygon_fast_path import CONDITION
    WalletFollowV2.initialize(database.path)
    engine=WalletFollowV2(database.path)
    activated=NOW-timedelta(seconds=1)
    engine.create_version(V2_CONFIG,created_at=activated,evidence_cutoff=activated)
    engine.activate(at=activated)
    identity=MarketIdentity(CONDITION,'123','YES')
    def book(name,offset):
        at=NOW+timedelta(milliseconds=offset)
        return BookSnapshot(name,'request-'+name,identity,'fixture',at,at,at+timedelta(milliseconds=10),
            (BookLevel(Decimal('.49'),Decimal('1000')),),(BookLevel(Decimal('.50'),Decimal('1000')),))
    market_at=NOW+timedelta(milliseconds=650)
    market=MarketState(identity,accepting_orders=True,state_source='fixture',observed_at=market_at,
        request_timestamp=market_at-timedelta(milliseconds=1),received_timestamp=market_at,
        minimum_order_size=Decimal('1'),minimum_order_source='fixture-orderMinSize')
    async def run():
        entered=asyncio.Event();release=asyncio.Event();calls=[]
        async def ingest(wallet,trade):
            calls.append(trade['trade_key'])
            if handler_result=='FILLED':
                episode=engine.observe_buy(signal_id=trade['trade_key'],wallet=WALLET,identity=identity,
                    leader_at=NOW,detected_at=NOW,leader_price=trade['price'],source_mode='LIVE_OBSERVATION')
                result=engine.execute_first(episode['episode_id'],market=market,quote=book('quote',0),
                    execution=book('execution',600),fee_rate='0',fee_source='fixture',
                    observed_at=NOW+timedelta(milliseconds=700),local_timestamp_model=True)
                assert result['status']=='FILLED'
            entered.set();await release.wait()
            if handler_result=='ERROR':raise RuntimeError('handler interrupted')
            return result if handler_result=='FILLED' else None
        p,_=producer(database,ingest=ingest);p.stage(log())
        task=asyncio.create_task(p.process_pending(101))
        await asyncio.wait_for(entered.wait(),2)
        assert state(database)[0]['state']=='ROUTING'
        p.stage(log(removed=True));release.set();await task
        p.stage(log(removed=True))  # repeated removal cannot downgrade uncertainty
        assert state(database)[0]['state']=='REORG_AFTER_ADMISSION'
        p.store.restart_recovery();await p.process_pending(101)
        p.stage(log());await p.process_pending(101)
        assert len(calls)==1
        with database.conn() as c:
            assert c.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0]==int(handler_result=='FILLED')
            evidence=[json.loads(r[0]) for r in c.execute("SELECT evidence_json FROM polygon_fast_audit WHERE action='TRANSITION_NOT_APPLIED'")]
        assert evidence[-1]['current_state']=='REORG_AFTER_ADMISSION'
        assert evidence[-1]['execution_may_have_committed'] is True
        if handler_result=='FILLED':assert engine.ledger(WALLET).reconcile()['ok']
    asyncio.run(run())


def test_removed_after_routing_interrupted_keeps_uncertain_admission(database):
    p,_=producer(database);p.stage(log());event=decode_log(log())
    assert p.store.transition(event,'ROUTING')
    p.store.restart_recovery();p.stage(log(removed=True));p.stage(log(removed=True))
    assert state(database)[0]['state']=='REORG_AFTER_ADMISSION'
    for terminal in ('ROUTED','ROUTING_INTERRUPTED','RECONCILED_DUPLICATE','PENDING_METADATA'):
        assert not p.store.transition(event,terminal)
    assert state(database)[0]['state']=='REORG_AFTER_ADMISSION'


@pytest.mark.parametrize('fail_all',[False,True])
def test_concurrent_rpc_error_does_not_change_backfill_fallback(database,fail_all):
    from app.polygon_fast_path import integer
    async def run():
        p,_=producer(database);del p.rpc
        p.config=replace(p.config,independent_lanes=True,backfill_diagnostics=True,
                         backfill_blocks=256,diagnostic_backfill_chunk_size=256)
        p.store.checkpoint(0);requests=[]
        async def request(method,params):
            if method=='eth_getTransactionReceipt':raise ConnectionError('unrelated-secret')
            start=integer(params[0]['fromBlock']);end=integer(params[0]['toBlock'])
            requests.append((start,end))
            if end-start+1>64 or fail_all:raise TimeoutError('backfill-secret')
            return []
        p._rpc_request=request;original=p.rpc
        async def interleaved(method,params):
            try:return await original(method,params)
            except TimeoutError:
                # Another lane fails before this request's caller sees its error.
                await asyncio.gather(asyncio.create_task(original('eth_getTransactionReceipt',['fixture'])),return_exceptions=True)
                assert p.failed_rpc_method=='eth_getTransactionReceipt'
                raise
        p.rpc=interleaved
        if fail_all:
            with pytest.raises(TimeoutError):await p.backfill(256)
            assert requests==[(1,256),(1,128),(1,64)] and p.store.checkpoint()==0
        else:
            await p.backfill(256)
            assert requests[:3]==[(1,256),(1,128),(1,64)] and p.store.checkpoint()==256
        with database.conn() as c:
            diagnostics=[json.loads(r[0]) for r in c.execute("SELECT evidence_json FROM polygon_fast_audit WHERE action='BACKFILL_RPC_DIAGNOSTIC'")]
        assert all(row['rpc_method']=='eth_getLogs' for row in diagnostics)
        assert 'secret' not in json.dumps(diagnostics)
    asyncio.run(run())


def test_shutdown_during_metadata_restarts_same_producer_without_cancelled_task(database):
    async def run():
        p,calls=producer(database)
        p.config=replace(p.config,independent_lanes=True,enabled=True,url='wss://fixture.invalid')
        p.confirmed_head=101;entered=asyncio.Event();metadata_calls=[]
        async def metadata(token):
            metadata_calls.append(token)
            if len(metadata_calls)==1:entered.set();await asyncio.Event().wait()
            return {'token_id':token,'condition_id':'0x'+'c'*64,'outcome':'YES','source':'fixture'}
        p.client.fast_token_metadata=metadata
        async def connection():await p.stop_event.wait()
        p._connection_loop=connection
        p.stage(log());p.start();await asyncio.wait_for(entered.wait(),2)
        resolver_tasks=list(p.resolver._inflight.values())
        await p.stop()
        assert resolver_tasks and all(task.done() for task in resolver_tasks)
        assert not p.resolver._inflight and not p.processing_tasks and not p._rpc_inflight
        assert not calls
        p.start()
        try:
            await until(lambda:len(calls)==1)
            await until(lambda:state(database)[0]['state']=='ROUTED')
            p.stage(log());await asyncio.sleep(.02)
            assert len(calls)==1 and metadata_calls==['123','123']
        finally:await p.stop()
        assert not p.resolver._inflight
        assert not [t for t in asyncio.all_tasks() if t is not asyncio.current_task() and not t.done()]
    asyncio.run(run())
