"""Deterministic, temporary-database tests for opt-in wallet follow V2."""
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import sqlite3

import pytest

from app.strict_paper import (BookLevel, BookSnapshot, MarketIdentity, MarketState as _MarketState,
                              OrderIntent, WalletFollowEngineRules, execute_order)
from app.wallet_follow_v2 import StrategyConfig, WalletFollowV2

T0 = datetime(2026, 9, 30, tzinfo=timezone.utc)
IDENT = MarketIdentity("condition-1", "token-yes", "YES")


def MarketState(*args, **kwargs):
    kwargs.setdefault("minimum_order_size", Decimal("0"))
    kwargs.setdefault("minimum_order_source", "fixture-orderMinSize")
    observed=kwargs.get("observed_at")
    if observed is not None:
        kwargs.setdefault("request_timestamp",observed-timedelta(milliseconds=1))
        kwargs.setdefault("received_timestamp",observed)
    return _MarketState(*args, **kwargs)


def book(name, offset, *, asks=(("0.70", "100"),), bids=(("0.40", "100"),), identity=IDENT):
    at = T0 + timedelta(milliseconds=offset)
    return BookSnapshot(name, f"req-{name}", identity, "fixture-book", at, at,
                        at + timedelta(milliseconds=10),
                        tuple(BookLevel(Decimal(p), Decimal(q)) for p, q in bids),
                        tuple(BookLevel(Decimal(p), Decimal(q)) for p, q in asks))


def decision(*, quote_ask="0.40", asks=(("0.70", "100"),), bids=(("0.39", "100"),),
             probability=None, fee="0", fee_source="fixture-fee", market=None,
             quote=None, execution=None, leader_offset=0, observed_offset=2000):
    quote = quote if quote is not None else book("quote", 0, asks=((quote_ask, "100"),), bids=(("0.01", "100"),))
    execution = execution if execution is not None else book("execution", 600, asks=asks, bids=bids)
    intent = OrderIntent("signal", "idem", IDENT, "BUY", Decimal("25"), True,
                         T0 - timedelta(seconds=leader_offset), T0)
    market = market if market is not None else MarketState(IDENT, token_probability=probability, accepting_orders=True,
        state_source="fixture-market", observed_at=T0 + timedelta(milliseconds=600))
    rules = WalletFollowEngineRules(max_visible_depth_fraction=Decimal("1"))
    return execute_order(intent, market, quote, execution, rules, fee_rate=fee,
                         fee_source=fee_source, observed_at=T0 + timedelta(milliseconds=observed_offset))


def test_price_movement_extremes_and_legacy_gates_are_observations():
    high_move = decision(quote_ask="0.40", asks=(("0.70", "100"),))
    assert high_move.status == "FILLED"
    assert high_move.projected_net_roi_if_win > Decimal("0.05")
    assert decision(quote_ask="0.40", asks=(("0.70", "100"),), leader_offset=86400).status == "FILLED"
    assert decision(quote_ask="0.40", asks=(("0.99", "100"),)).reason == "NET_ROI_BELOW_FLOOR"
    assert decision(quote_ask="0.40", asks=(("0.98", "100"),)).reason == "NET_ROI_BELOW_FLOOR"
    assert decision(quote_ask="0.40", asks=(("0.01", "3000"),), bids=(("0.005", "100"),)).status == "FILLED"
    assert decision(quote_ask="0.40", asks=(("0.70", "100"),), bids=(("0.01", "100"),), probability=Decimal("0.99")).status == "FILLED"


@pytest.mark.parametrize("reason,kwargs", [
    ("INVALID_FEE_EVIDENCE", {"fee_source": "unknown"}),
    ("EMPTY_EXECUTION_BOOK", {"asks": (), "bids": (("0.39", "100"),)}),
    ("MARKET_CLOSED_OR_RESOLVED", {"market": MarketState(IDENT, closed=True, accepting_orders=True, state_source="fixture", observed_at=T0)}),
    ("MARKET_NOT_ACCEPTING_ORDERS", {"market": MarketState(IDENT, accepting_orders=False, state_source="fixture", observed_at=T0)}),
    ("MARKET_NOT_ACCEPTING_ORDERS", {"market": MarketState(IDENT, state_source="fixture", observed_at=T0)}),
    ("STALE_EXECUTION_BOOK", {"execution": book("stale", 600, asks=(("0.70", "100"),))}),
])
def test_real_execution_failures(reason, kwargs):
    if reason == "STALE_EXECUTION_BOOK":
        market = MarketState(IDENT, accepting_orders=True, state_source="fresh-market", observed_at=T0+timedelta(milliseconds=9900))
        assert decision(**kwargs, market=market, observed_offset=10000).reason == "STALE_EXECUTION_BOOK"
    else:
        assert decision(**kwargs).reason == reason


def test_roi_depth_stops_before_bad_level():
    result = decision(asks=(("0.70", "1"), ("0.99", "100")))
    assert result.status == "PARTIAL"
    assert result.reason == "PARTIAL_ROI_FLOOR"
    assert result.filled_quantity == Decimal("1")
    assert result.filled_notional == Decimal("0.7")
    assert result.unfilled_notional == Decimal("24.3")
    assert result.roi_limited_depth > 0


def test_venue_minimum_is_enforced_after_visible_depth_and_roi_limit():
    minimum = MarketState(IDENT, accepting_orders=True, state_source="fixture-market",
        observed_at=T0 + timedelta(milliseconds=600), minimum_order_size=Decimal("5"))
    below = decision(asks=(("0.70", "1"),), market=minimum)
    assert (below.status, below.reason, below.filled_quantity, below.total_cost) == (
        "REJECTED", "BELOW_MINIMUM_ORDER", Decimal("0"), Decimal("0"))
    allowed = decision(asks=(("0.70", "6"),), market=minimum)
    assert allowed.status == "PARTIAL" and allowed.filled_quantity == Decimal("6")
    roi_partial = decision(asks=(("0.70", "3"), ("0.99", "100")), market=minimum)
    assert roi_partial.reason == "BELOW_MINIMUM_ORDER" and roi_partial.fills == ()
    assert roi_partial.to_evidence(OrderIntent("signal", "idem", IDENT, "BUY", Decimal("25")))["market_state"]["minimum_order_size"] == "5"


@pytest.mark.parametrize("size,source", [(None,"fixture"),("bad","fixture"),(Decimal("-1"),"fixture"),(Decimal("NaN"),"fixture"),(Decimal("5"),"")])
def test_invalid_venue_minimum_fails_closed(size, source):
    market = _MarketState(IDENT, accepting_orders=True, state_source="fixture-market",
        observed_at=T0 + timedelta(milliseconds=600), minimum_order_size=size,
        minimum_order_source=source)
    result = decision(market=market)
    assert result.status == "REJECTED" and result.reason == "INVALID_MINIMUM_ORDER_EVIDENCE"


def setup(tmp_path, config=StrategyConfig()):
    path = tmp_path / "simulation.db"
    WalletFollowV2.initialize(path)
    sim = WalletFollowV2(path)
    sim.create_version(config, created_at=T0, evidence_cutoff=T0)
    sim.activate(at=T0)
    return sim


def observe(sim, signal="first", identity=IDENT, *, detected=T0, source="LIVE_OBSERVATION"):
    return sim.observe_buy(signal_id=signal, wallet="0xabc", identity=identity,
        leader_at=detected-timedelta(hours=12), detected_at=detected,
        leader_price="0.40", category="politics", source_mode=source)


def test_episodes_add_ons_reversal_and_no_fill_formal_resolution(tmp_path):
    sim = setup(tmp_path)
    first = observe(sim)
    assert first["event_type"] == "FIRST"
    assert observe(sim, "second")["event_type"] == "ADD_ON"
    assert observe(sim, "third", MarketIdentity("condition-1", "token-no", "NO"))["event_type"] == "REVERSAL"
    assert observe(sim, "first")["duplicate"]
    result = sim.execute_first(first["episode_id"], market=MarketState(IDENT, accepting_orders=True, state_source="fixture", observed_at=T0+timedelta(milliseconds=600)),
        quote=book("q", 0, asks=(("0.40", "100"),), bids=(("0.01", "100"),)),
        execution=book("e", 600, asks=(("0.99", "100"),), bids=(("0.39", "100"),)),
        fee_rate="0", fee_source="fixture", observed_at=T0+timedelta(seconds=2))
    assert result["reason"] == "NET_ROI_BELOW_FLOOR"
    assert sim.record_resolution(first["episode_id"], status="RESULT_PENDING", observed_at=T0+timedelta(days=1))
    assert sim.record_resolution(first["episode_id"], status="FORMALLY_RESOLVED", observed_at=T0+timedelta(days=2),
        authoritative_source="fixture-final", winning_token_id="token-yes", payout_per_share="1")
    metrics = sim.wallet_metrics("0xabc")
    assert metrics["observed_episode_count"] == 1
    assert metrics["resolved_directional_episode_count"] == 1
    assert metrics["directional_accuracy"] == "1"
    assert metrics["add_on_count"] == metrics["reversal_count"] == 1
    assert metrics["review_eligible"] is False


def test_partial_roi_fill_cash_release_and_reconcile(tmp_path):
    sim = setup(tmp_path)
    episode_id = observe(sim)["episode_id"]
    result = sim.execute_first(episode_id, market=MarketState(IDENT, accepting_orders=True, state_source="fixture", observed_at=T0+timedelta(milliseconds=600)),
        quote=book("q", 0, asks=(("0.40", "100"),), bids=(("0.01", "100"),)),
        execution=book("e", 600, asks=(("0.70", "1"), ("0.99", "100")), bids=(("0.39", "100"),)),
        fee_rate="0", fee_source="fixture", observed_at=T0+timedelta(seconds=2))
    assert result["status"] == "PARTIAL"
    ledger = sim.ledger("0xabc")
    assert ledger.account()["reserved_cash"] == "0.000000"
    assert ledger.account_snapshot()["orders"][0]["status"] == "PARTIALLY_FILLED"
    assert ledger.reconcile()["ok"]
    assert sim.execute_first(episode_id, market=None, quote=None, execution=None, fee_rate="0", fee_source="fixture", observed_at=T0)["duplicate"]
    assert len(ledger.account_snapshot()["fills"]) == 1


def test_below_venue_minimum_keeps_directional_episode_without_paper_fill(tmp_path):
    sim = setup(tmp_path)
    episode_id = observe(sim)["episode_id"]
    market = MarketState(IDENT, accepting_orders=True, state_source="fixture-market",
        observed_at=T0+timedelta(milliseconds=600), minimum_order_size=Decimal("5"))
    result = sim.execute_first(episode_id, market=market,
        quote=book("q", 0, asks=(("0.40", "100"),), bids=(("0.01", "100"),)),
        execution=book("e", 600, asks=(("0.70", "3"), ("0.99", "100")), bids=(("0.39", "100"),)),
        fee_rate="0", fee_source="fixture", observed_at=T0+timedelta(seconds=2))
    assert result["status"] == "REJECTED" and result["reason"] == "BELOW_MINIMUM_ORDER"
    assert sim.wallet_metrics("0xabc")["observed_episode_count"] == 1
    assert sim.ledger("0xabc").account_snapshot()["fills"] == []
    assert sim.ledger("0xabc").reconcile()["ok"]


def test_version_immutable_and_historical_replay_rejected(tmp_path):
    sim = setup(tmp_path)
    with pytest.raises(ValueError, match="IMMUTABLE_STRATEGY_VERSION"):
        sim.create_version(StrategyConfig(min_net_roi_if_win=Decimal("0.06")), created_at=T0, evidence_cutoff=T0)
    with sqlite3.connect(sim.path) as con, pytest.raises(sqlite3.IntegrityError, match="IMMUTABLE_STRATEGY_VERSION"):
        con.execute("UPDATE wallet_v2_versions SET config_json='{}' WHERE strategy_version=?", (sim.strategy_version,))
    with pytest.raises(ValueError, match="NOT_FORWARD_OBSERVATION"):
        observe(sim, detected=T0-timedelta(seconds=1))
    with pytest.raises(ValueError, match="NOT_FORWARD_OBSERVATION"):
        observe(sim, source="HISTORICAL_REPLAY")
    assert sim.wallet_metrics("0xabc")["observed_episode_count"] == 0


def test_evidence_cutoff_precedes_creation_and_activation_is_frozen(tmp_path):
    path = tmp_path / "lineage.db"
    WalletFollowV2.initialize(path)
    sim = WalletFollowV2(path)
    assert sim.create_version(StrategyConfig(), created_at=T0,
        evidence_cutoff=T0-timedelta(days=1))
    with pytest.raises(ValueError, match="INVALID_STRATEGY_ACTIVATION"):
        sim.activate(at=T0-timedelta(seconds=1))
    sim.activate(at=T0)
    with sqlite3.connect(path) as con, pytest.raises(sqlite3.IntegrityError, match="IMMUTABLE_STRATEGY_ACTIVATION"):
        con.execute("UPDATE wallet_v2_versions SET activated_at=? WHERE strategy_version=?",
                    ((T0+timedelta(days=1)).isoformat(), sim.strategy_version))
    with pytest.raises(ValueError, match="NOT_FORWARD_OBSERVATION"):
        observe(sim, detected=T0-timedelta(seconds=1))
    assert observe(sim, detected=T0)["event_type"] == "FIRST"


def test_future_evidence_cutoff_rejected_and_completed_parent_preserves_history(tmp_path):
    path = tmp_path / "lineage.db"
    WalletFollowV2.initialize(path)
    parent = WalletFollowV2(path, strategy_version="wallet-follow-parent")
    with pytest.raises(ValueError, match="CUTOFF_AFTER_VERSION_CREATION"):
        parent.create_version(StrategyConfig(), created_at=T0,
            evidence_cutoff=T0+timedelta(days=1))
    parent.create_version(StrategyConfig(), created_at=T0,
        evidence_cutoff=T0-timedelta(days=1))
    parent.activate(at=T0)
    observe(parent, detected=T0)
    parent.close("COMPLETED", at=T0+timedelta(days=1))
    child = WalletFollowV2(path, strategy_version="wallet-follow-child")
    child.create_version(StrategyConfig(), created_at=T0+timedelta(days=2),
        evidence_cutoff=T0+timedelta(days=1), parent_version=parent.strategy_version)
    child.activate(at=T0+timedelta(days=2))
    with pytest.raises(ValueError, match="NOT_FORWARD_OBSERVATION"):
        observe(child, signal="old", detected=T0)
    assert observe(child, signal="future", detected=T0+timedelta(days=2))["event_type"] == "FIRST"
    assert parent.wallet_metrics("0xabc")["observed_episode_count"] == 1
    assert child.wallet_metrics("0xabc")["observed_episode_count"] == 1


def test_filled_episode_settles_from_explicit_formal_result(tmp_path):
    sim = setup(tmp_path)
    episode_id = observe(sim)["episode_id"]
    result = sim.execute_first(episode_id,
        market=MarketState(IDENT, accepting_orders=True, state_source="fixture", observed_at=T0+timedelta(milliseconds=600)),
        quote=book("q", 0, asks=(("0.40", "100"),), bids=(("0.01", "100"),)),
        execution=book("e", 600, asks=(("0.70", "100"),), bids=(("0.39", "100"),)),
        fee_rate="0", fee_source="fixture", observed_at=T0+timedelta(seconds=2))
    assert result["status"] == "FILLED"
    assert sim.ledger("0xabc").reconcile()["ok"]
    with pytest.raises(ValueError, match="MISSING_AUTHORITATIVE_RESOLUTION"):
        sim.record_resolution(episode_id, status="FORMALLY_RESOLVED", observed_at=T0+timedelta(days=1))
    with pytest.raises(ValueError, match="INCONSISTENT_FORMAL_PAYOUT"):
        sim.record_resolution(episode_id, status="FORMALLY_RESOLVED", observed_at=T0+timedelta(days=1),
            authoritative_source="fixture-final", winning_token_id="token-yes", payout_per_share="0")
    assert sim.record_resolution(episode_id, status="FORMALLY_RESOLVED", observed_at=T0+timedelta(days=1),
        authoritative_source="fixture-final", winning_token_id="token-yes", payout_per_share="1")
    metrics = sim.wallet_metrics("0xabc")
    assert metrics["resolved_directional_episode_count"] == 1
    assert Decimal(metrics["realized_pnl"]) > 0
    assert Decimal(metrics["realized_paper_net_roi"]) > Decimal("0.05")
    assert sim.ledger("0xabc").reconcile()["ok"]


def test_cash_shortage_is_rejected_without_fill(tmp_path):
    sim = setup(tmp_path, StrategyConfig(initial_cash_per_wallet=Decimal("1")))
    episode_id = observe(sim)["episode_id"]
    result = sim.execute_first(episode_id,
        market=MarketState(IDENT, accepting_orders=True, state_source="fixture", observed_at=T0+timedelta(milliseconds=600)),
        quote=book("q", 0, asks=(("0.40", "100"),), bids=(("0.01", "100"),)),
        execution=book("e", 600, asks=(("0.70", "100"),), bids=(("0.39", "100"),)),
        fee_rate="0", fee_source="fixture", observed_at=T0+timedelta(seconds=2))
    assert result["reason"] == "INSUFFICIENT_PAPER_CASH"
    assert sim.ledger("0xabc").account_snapshot()["fills"] == []
    assert sim.ledger("0xabc").reconcile()["ok"]


@pytest.mark.parametrize("hours", [0.5, 24 * 7])
def test_expected_end_horizon_is_observation_only(tmp_path, hours):
    sim = setup(tmp_path)
    first = sim.observe_buy(signal_id="first", wallet="0xabc", identity=IDENT,
        leader_at=T0-timedelta(hours=12), detected_at=T0, leader_price="0.40",
        expected_end_at=T0+timedelta(hours=hours))
    result = sim.execute_first(first["episode_id"],
        market=MarketState(IDENT, accepting_orders=True, state_source="fixture", observed_at=T0+timedelta(milliseconds=600)),
        quote=book("q", 0, asks=(("0.40", "100"),), bids=(("0.01", "100"),)),
        execution=book("e", 600, asks=(("0.70", "100"),), bids=(("0.39", "100"),)),
        fee_rate="0", fee_source="fixture", observed_at=T0+timedelta(seconds=2))
    assert result["status"] == "FILLED"
    assert Decimal(sim.episode(first["episode_id"])["time_to_expected_end_seconds"]) == Decimal(str(hours * 3600))
