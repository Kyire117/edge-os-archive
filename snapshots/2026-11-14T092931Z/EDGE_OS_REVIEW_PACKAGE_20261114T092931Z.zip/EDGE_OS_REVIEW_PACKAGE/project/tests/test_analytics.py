from app.analytics import analyze_wallet, category_for, fee_usdc


def test_category_classifier():
    assert category_for("Will Bitcoin be above $100k?") == "Crypto"
    assert category_for("Will the Fed cut interest rates?") == "Macro"
    assert category_for("Will Trump win the election?") == "Politics"


def test_wallet_analysis_concentration_and_score():
    closed=[]
    for i in range(12):
        closed.append({
            "title":"Bitcoin market" if i < 8 else "Fed decision",
            "total_cost_usdc":100,
            "realized_pnl":20 if i < 9 else -10,
            "avg_price":0.4,
        })
    stats, analytics, status = analyze_wallet("0x"+"1"*40, closed, [], {}, {}, [])
    assert stats["closed_market_count"] == 12
    assert stats["realized_pnl"] == 150
    assert round(stats["roi"], 3) == 0.125
    assert analytics["profit_concentration"]["top1"] < 0.2
    assert analytics["category_breakdown"][0]["category"] in {"Crypto", "Macro"}
    assert 0 <= analytics["trader_skill"] <= 100


def test_fee_formula():
    # 100 politics shares at 0.50, 0.04 rate => 1 USDC
    assert fee_usdc(100, 0.5, 0.04) == 1.0
