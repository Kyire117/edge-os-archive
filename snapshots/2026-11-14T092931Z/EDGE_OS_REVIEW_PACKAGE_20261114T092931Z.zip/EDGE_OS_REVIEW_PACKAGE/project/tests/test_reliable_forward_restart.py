import asyncio
import json
from pathlib import Path

import pytest

import edge_runtime
from app.db import Database
from app.polygon_fast_path import EventStore,PolygonProducer,ProducerConfig
from app.polymarket import PolymarketClient,PolymarketError


def make_producer(tmp_path):
    database=Database(str(tmp_path/'isolated.db'));database.init()
    async def no_fill(*args):raise AssertionError('no synthetic fills')
    p=PolygonProducer(database,object(),no_fill,ProducerConfig(url='wss://fixture.invalid',
        recovery_chunk_blocks=8,max_catchup_blocks=512,max_chunks_per_cycle=4))
    p.store.initialize()
    async def no_pending(*args):pass
    p.process_pending=no_pending
    return p


def test_large_gap_recovers_in_bounded_cycles_without_skipping(tmp_path):
    p=make_producer(tmp_path);p.store.checkpoint(100);ranges=[]
    async def rpc(method,params):
        assert method=='eth_getLogs'
        start=int(params[0]['fromBlock'],16);end=int(params[0]['toBlock'],16)
        ranges.append((start,end));return []
    p.rpc=rpc
    asyncio.run(p.backfill(400))
    assert p.store.checkpoint()==132 and len(ranges)==4 and p.catchup_remaining_blocks==268
    for _ in range(9):asyncio.run(p.backfill(400))
    assert p.store.checkpoint()==400 and p.catchup_remaining_blocks==0
    assert ranges[0][0]==101 and ranges[-1][1]==400
    assert all(b[0]==a[1]+1 for a,b in zip(ranges,ranges[1:]))
    assert max(end-start+1 for start,end in ranges)<=8


def test_failed_chunk_retains_last_complete_chunk_and_restart_resumes(tmp_path):
    p=make_producer(tmp_path);p.store.checkpoint(100)
    async def rpc(method,params):
        if int(params[0]['fromBlock'],16)>108:
            p.failed_rpc_method=method;raise ConnectionError('fixture')
        return []
    p.rpc=rpc
    with pytest.raises(ConnectionError):asyncio.run(p.backfill(140))
    assert p.store.checkpoint()==108
    restarted=make_producer(tmp_path);ranges=[]
    async def recovered(method,params):
        ranges.append(int(params[0]['fromBlock'],16));return []
    restarted.rpc=recovered
    asyncio.run(restarted.backfill(140))
    assert ranges[0]==109 and restarted.store.checkpoint()==140


def test_catchup_still_has_a_hard_total_bound(tmp_path):
    p=make_producer(tmp_path);p.store.checkpoint(100)
    with pytest.raises(ValueError,match='BACKFILL_GAP_EXCEEDS_BOUND'):
        asyncio.run(p.backfill(613))
    assert p.store.checkpoint()==100


def test_continuous_mode_segments_overnight_gap_with_same_work_budget(tmp_path):
    from dataclasses import replace
    p=make_producer(tmp_path);p.config=replace(p.config,segment_large_gaps=True)
    p.store.checkpoint(100);ranges=[]
    async def rpc(method,params):
        ranges.append((int(params[0]['fromBlock'],16),int(params[0]['toBlock'],16)));return []
    p.rpc=rpc
    asyncio.run(p.backfill(100000))
    assert ranges==[(101,108),(109,116),(117,124),(125,132)]
    assert p.store.checkpoint()==132 and p.catchup_remaining_blocks==99868
    asyncio.run(p.backfill(100000))
    assert ranges[4][0]==133 and p.store.checkpoint()==164


def test_http_recovery_checks_chain_identity(tmp_path):
    p=make_producer(tmp_path)
    async def wrong(method,params):return '0x1'
    p.http_read_rpc=wrong
    with pytest.raises(ValueError,match='WRONG_CHAIN_ID'):asyncio.run(p.http_recovery_cycle())
    assert p.store.checkpoint() is None


def test_http_read_adapter_cannot_submit_transactions():
    async def run():
        client=PolymarketClient()
        try:
            with pytest.raises(PolymarketError,match='CHAIN_METHOD_NOT_READ_ONLY'):
                await client.polygon_read_rpc('eth_sendRawTransaction',['private-fixture'])
            assert client._chain_client is None
        finally:await client.close()
    asyncio.run(run())


def test_active_experiment_selection_rejects_path_escape_and_live_orders(tmp_path,monkeypatch):
    monkeypatch.setattr(edge_runtime,'ROOT',tmp_path)
    monkeypatch.setattr(edge_runtime,'MANIFEST',tmp_path/'manifest.json')
    edge_runtime.MANIFEST.write_text(json.dumps({'database':'data/edge_forward_fixture.db','live_orders':False}))
    assert edge_runtime.active_database()==tmp_path/'data/edge_forward_fixture.db'
    assert edge_runtime.public_run(tmp_path/'other.db')['run_id']=='UNBOUND'
    edge_runtime.MANIFEST.write_text(json.dumps({'database':'../other/edge_forward_fixture.db','live_orders':False}))
    with pytest.raises(ValueError,match='INVALID_ACTIVE_EXPERIMENT_DATABASE'):edge_runtime.active_database()
    edge_runtime.MANIFEST.write_text(json.dumps({'database':'data/edge_forward_fixture.db','live_orders':True}))
    with pytest.raises(ValueError,match='LIVE_ORDERS_NOT_ALLOWED'):edge_runtime.active_database()


def test_poll_page_uses_one_attempt_inside_scheduler_budget():
    async def run():
        client=PolymarketClient()
        async def get(url,params,**kwargs):
            assert kwargs['attempts']==1
            return {'data':[],'pagination':{'has_more':False,'next_cursor':None}}
        client._get=get
        try:
            result=await client.trades_page('fixture',start=1,cursor=None)
            assert result['trades']==[] and result['has_more'] is False
        finally:await client.close()
    asyncio.run(run())
