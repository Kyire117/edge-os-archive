import json
import time

from fastapi.testclient import TestClient

from app import main, research_api
from app.analytics import analyze_wallet, wallet_card_data
from app.db import Database
from app.polymarket import normalize_public_profile, public_profile_view, safe_profile_image, verified_market_url


WALLET = "0x" + "a" * 40


def test_public_profile_missing_partial_and_unsafe_image():
    assert normalize_public_profile(None, WALLET)["source"] == "UNAVAILABLE"
    partial = normalize_public_profile({"name": "Alice", "profileImage": "javascript:alert(1)"}, WALLET)
    assert partial["username"] is None and partial["profile_url"] is None and partial["avatar_url"] is None
    other = "0x" + "b" * 40
    mismatched = normalize_public_profile({"proxyWallet": other, "name": "Wrong", "profileImage": "https://imagedelivery.net/id/avatar"}, WALLET)
    assert mismatched["source"] == "UNVERIFIED_IDENTITY"
    assert mismatched["username"] is None and mismatched["avatar_url"] is None and mismatched["profile_url"] is None
    assert mismatched["proxy_wallet"] is None
    hidden = normalize_public_profile({"proxyWallet": WALLET, "name": "Secret", "displayUsernamePublic": False}, WALLET)
    assert hidden["username"] is None
    assert hidden["profile_url"] == f"https://polymarket.com/profile/{WALLET}"
    assert safe_profile_image("https://127.0.0.1/a.png") is None
    assert safe_profile_image("https://evil.example/a.png") is None
    assert safe_profile_image("https://imagedelivery.net/id/avatar")
    assert public_profile_view({"proxy_wallet": other, "username": "Wrong", "avatar_url": "https://imagedelivery.net/id/avatar", "profile_url": f"https://polymarket.com/profile/{other}", "source": "GAMMA_PUBLIC_PROFILE"}, WALLET)["username"] is None


def test_profile_cache_persists_and_failure_retains_stale_identity(tmp_path):
    path = str(tmp_path / "ui.db")
    database = Database(path); database.init(); database.upsert_wallet(WALLET)
    good = normalize_public_profile({"proxyWallet": WALLET, "name": "Alice"}, WALLET)
    database.save_public_profile(WALLET, good, 1000)
    restarted = Database(path); restarted.init()
    assert restarted.get_wallet(WALLET)["public_profile"]["username"] == "Alice"
    restarted.save_public_profile(WALLET, {"source": "UNAVAILABLE"}, 2000)
    cached = restarted.get_wallet(WALLET)["public_profile"]
    assert cached["username"] == "Alice" and cached["source"] == "STALE_GAMMA_PUBLIC_PROFILE"
    assert cached["refreshed_at"] == 1000 and cached["checked_at"] == 2000
    assert restarted.public_profile_refresh_candidates(2001) == []
    assert restarted.public_profile_refresh_candidates(2000 + 21601) == [WALLET]


def test_metric_denominators_and_activity_category_order():
    closed = [
        {"title": "Election", "category": "politics", "realized_pnl": 5, "total_cost_usdc": 20},
        {"title": "Bitcoin", "category": "crypto", "realized_pnl": -1, "total_cost_usdc": 20},
    ]
    opened = [{"title": "Bitcoin", "category": "crypto", "total_pnl": 2} for _ in range(3)]
    stats, analytics, _ = analyze_wallet(WALLET, closed, opened)
    card = wallet_card_data({"stats": stats, "analytics": analytics})
    assert card["profitable_settled_positions"] == 1
    assert card["settled_position_sample"] == 2
    assert card["profitable_position_rate"] == 0.5
    assert card["frequent_categories"][0]["category"] == "Crypto"
    assert card["frequent_categories"][0]["observed_positions"] == 4
    assert card["categories"][0]["settled_positions"] == 1
    assert len(card["style_sentences"]) == 3
    empty = wallet_card_data({"stats": {}, "analytics": {}})
    assert empty["profitable_position_rate"] is None
    assert len(empty["style_sentences"]) == 3


def test_verified_market_links_never_guess_title():
    assert verified_market_url({"trade": {"title": "fed-decision"}}) is None
    assert verified_market_url({"trade": {"raw": {"eventSlug": "fed-decision"}}}) == "https://polymarket.com/event/fed-decision"
    assert verified_market_url({"market": {"event_slug": "../../evil"}}) is None
    assert verified_market_url({"trade": {"raw": {"eventSlug": "https://evil.example"}}}) is None


def test_wallet_and_journal_api_separate_old_and_new_records(tmp_path, monkeypatch):
    database = Database(str(tmp_path / "api.db")); database.init(); database.upsert_wallet(WALLET)
    database.save_public_profile(WALLET, normalize_public_profile({"proxyWallet": WALLET, "name": "<Alice>"}, WALLET), time.time())
    monkeypatch.setattr(database, "public_profile_refresh_candidates", lambda *_: [])
    monkeypatch.setattr(main, "db", database)
    monkeypatch.setattr(research_api, "db", database)
    monkeypatch.setattr(research_api.ai, "db", database)
    with database.conn() as con:
        con.execute("INSERT INTO research_experiments(id,rule_version,status,started_at,ends_at,started_utc,ends_utc,rules_json) VALUES(?,?,?,?,?,?,?,?)",
                    ("ex-prior", "v0", "COMPLETED", 0, 1, "1970-01-01T00:00:00Z", "1970-01-01T00:00:01Z", "{}"))
        con.execute("INSERT INTO research_experiments(id,rule_version,status,started_at,ends_at,started_utc,ends_utc,rules_json) VALUES(?,?,?,?,?,?,?,?)",
                    ("ex-ui", "v0", "RUNNING", 1, 9999999999, "1970-01-01T00:00:01Z", "2286-11-20T17:46:39Z", "{}"))
        con.execute("INSERT INTO research_entries(trade_key,wallet,title,status,entry_json,pnl) VALUES(?,?,?,?,?,?)",
                    ("old", WALLET, "Old market", "SETTLED", json.dumps({"trade": {"raw": {"eventSlug": "old-market"}}}), 7))
        con.execute("INSERT INTO research_experiment_entries(experiment_id,trade_key,wallet,title,status,detected_ts,entry_json,unrealized_pnl) VALUES(?,?,?,?,?,?,?,?)",
                    ("ex-ui", "new", WALLET, "New market", "OPEN", 2, json.dumps({"market": {"event_slug": "new-market"}}), 2))
        con.execute("INSERT INTO research_experiment_entries(experiment_id,trade_key,wallet,title,status,detected_ts,entry_json,pnl) VALUES(?,?,?,?,?,?,?,?)",
                    ("ex-prior", "prior", WALLET, "Prior experiment", "SETTLED", 0, "{}", 11))
    client = TestClient(main.app)
    wallets = client.get("/api/wallets").json()
    assert wallets[0]["card"]["identity"]["username"] == "<Alice>"
    assert wallets[0]["card"]["paper"]["experiment"]["realized_pnl"] == 0
    assert wallets[0]["card"]["paper"]["prior_experiments"]["realized_pnl"] == 11
    assert wallets[0]["card"]["paper"]["older_research"]["realized_pnl"] == 7
    older = client.get("/api/research/entries").json()
    current = client.get("/api/research/experiment/entries").json()
    assert older["total"] == current["total"] == 1
    assert older["entries"][0]["title"] == "Old market"
    assert current["entries"][0]["title"] == "New market"
    assert current["entries"][0]["leader_identity"]["username"] == "<Alice>"
    assert current["entries"][0]["market_url"] == "https://polymarket.com/event/new-market"
    detail = client.get(f"/api/research/experiment/entries/{current['entries'][0]['id']}").json()
    assert detail["evidence"]["market"]["event_slug"] == "new-market"
    health = client.get("/api/health").json()
    assert health["live_trading"] is False and "api_key" not in json.dumps(health)
    assert set(health["ai"]) == {"provider", "enabled", "has_key", "daily_call_limit", "calls_today"}


def test_api_does_not_attribute_mismatched_cached_profile(tmp_path, monkeypatch):
    database = Database(str(tmp_path / "identity.db")); database.init(); database.upsert_wallet(WALLET)
    other = "0x" + "b" * 40
    with database.conn() as con:
        con.execute("""INSERT INTO wallet_public_profiles(address,proxy_wallet,username,avatar_url,profile_url,source,checked_at)
                       VALUES(?,?,?,?,?,'GAMMA_PUBLIC_PROFILE',?)""",
                    (WALLET, other, "Wrong", "https://imagedelivery.net/id/avatar", f"https://polymarket.com/profile/{other}", time.time()))
        con.execute("INSERT INTO research_entries(trade_key,wallet,title,status,entry_json) VALUES(?,?,?,?,?)",
                    ("bad-identity", WALLET, "Market", "SKIP", "{}"))
    monkeypatch.setattr(database, "public_profile_refresh_candidates", lambda *_: [])
    monkeypatch.setattr(main, "db", database)
    monkeypatch.setattr(research_api, "db", database)
    monkeypatch.setattr(research_api.ai, "db", database)
    client = TestClient(main.app)
    card = client.get("/api/wallets").json()[0]["card"]
    detail = client.get(f"/api/wallets/{WALLET}").json()["card"]
    journal = client.get("/api/research/entries").json()["entries"][0]
    for identity in (card["identity"], detail["identity"], journal["leader_identity"]):
        assert identity["source"] == "UNVERIFIED_IDENTITY"
        assert identity["username"] is None
        assert identity["avatar_url"] is None
        assert identity["profile_url"] is None
