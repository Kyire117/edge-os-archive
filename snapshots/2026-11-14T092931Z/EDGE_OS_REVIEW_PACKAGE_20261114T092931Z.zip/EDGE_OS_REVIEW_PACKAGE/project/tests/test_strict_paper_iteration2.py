"""Forward-only, opt-in strict-paper v2 execution and ledger regression tests."""
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest

from app.strict_paper import (BookLevel, BookSnapshot, EngineRules, MarketIdentity,
                              MarketState, OrderIntent, execute_order)
from app.strict_ledger import StrictPaperLedger


T0 = datetime(2026, 9, 29, tzinfo=timezone.utc)
IDENT = MarketIdentity("v2-condition", "v2-token-yes", "YES")


def book(name, offset, *, ask="0.50", ask_qty="20", bid="0.49", bid_qty="20"):
    at = T0 + timedelta(milliseconds=offset)
    return BookSnapshot(name, f"request-{name}", IDENT, "deterministic-book",
                        at, at, at + timedelta(milliseconds=10),
                        (BookLevel(Decimal(bid), Decimal(bid_qty)),) if bid_qty else (),
                        (BookLevel(Decimal(ask), Decimal(ask_qty)),) if ask_qty else ())


def decide(*, side="BUY", amount="5", quote_ask="0.50", execution_ask="0.50",
           execution_ask_qty="20", execution_bid="0.48", execution_bid_qty="20",
           signal="signal-1", fee="0", allow_partial=True):
    quote = book(f"q-{signal}", 0, ask=quote_ask)
    execution = book(f"e-{signal}", 600, ask=execution_ask, ask_qty=execution_ask_qty,
                     bid=execution_bid, bid_qty=execution_bid_qty)
    intent = OrderIntent(signal, f"idem-{signal}", IDENT, side, Decimal(amount),
                         allow_partial=allow_partial, edge_detected_timestamp=T0)
    rules = EngineRules(rule_version="strict-paper-rules-v2", execution_latency_ms=500,
                        max_book_age_ms=2000, max_visible_depth_fraction=Decimal("1"),
                        allow_partial_fills=True)
    decision = execute_order(intent, MarketState(IDENT, token_probability=Decimal("0.5"),
                             state_source="fixture", observed_at=T0), quote, execution, rules,
                             fee_rate=Decimal(fee), fee_source="fixture-fee",
                             observed_at=T0 + timedelta(seconds=2))
    return decision, intent


def ledger_at(path):
    StrictPaperLedger.initialize(path)
    ledger = StrictPaperLedger(path, account_id="isolated-v2-test")
    ledger.create_account("100", created_at="initial")
    return ledger


def apply(ledger, decision, intent, *, order_id="order", fill_id="fill", reserve="5.1"):
    ledger.submit_order(order_id=order_id, idempotency_key=intent.idempotency_key,
                        signal_id=intent.signal_id, identity=IDENT, side=intent.side,
                        target_quantity=decision.target_quantity,
                        reserve_cash=reserve if intent.side == "BUY" else "0",
                        requested_notional=intent.amount if intent.side == "BUY" else None,
                        engine_version=decision.engine_version, rule_version=decision.rule_version,
                        evidence=decision.to_evidence(intent), created_at=f"submit-{order_id}")
    return ledger.apply_execution(fill_id=fill_id, order_id=order_id, decision=decision,
                                  intent=intent, created_at=f"fill-{order_id}")


def test_buy_budget_uses_fresh_execution_price_and_not_quote_shares(tmp_path):
    for price, expected_side in (("0.49", "more"), ("0.51", "fewer")):
        decision, intent = decide(execution_ask=price)
        assert decision.status == "FILLED"
        assert (decision.filled_quantity > 10) if expected_side == "more" else (decision.filled_quantity < 10)
        assert decision.target_quantity == 0
        assert decision.requested_notional == Decimal("5")
        assert decision.filled_notional <= decision.requested_notional
        assert decision.filled_notional + decision.unfilled_notional == decision.requested_notional
        ledger = ledger_at(tmp_path / f"{price}.db")
        assert apply(ledger, decision, intent)
        assert ledger.account_snapshot()["orders"][0]["status"] == "FILLED"
        assert ledger.reconcile()["ok"]


def test_buy_partial_releases_cash_and_is_terminal_after_restart(tmp_path):
    path = tmp_path / "partial-buy.db"
    ledger = ledger_at(path)
    decision, intent = decide(execution_ask_qty="4", fee="0.02")
    assert decision.status == "PARTIAL"
    assert decision.filled_notional == Decimal("2.000000")
    assert decision.unfilled_notional == Decimal("3.000000")
    assert apply(ledger, decision, intent)
    recovered = StrictPaperLedger(path, account_id="isolated-v2-test")
    snapshot = recovered.account_snapshot()
    order, account = snapshot["orders"][0], snapshot["account"]
    assert order["status"] == "PARTIALLY_FILLED"
    assert order["remaining_notional"] == "3.000000"
    assert order["reserve_cash_remaining"] == "0.000000"
    assert account["reserved_cash"] == "0.000000"
    assert Decimal(account["available_cash"]) == Decimal("100") - decision.total_cost - decision.total_fee
    assert not recovered.apply_execution(fill_id="different-fill-id", order_id="order",
                                         decision=decision, intent=intent, created_at="retry")
    assert len(recovered.account_snapshot()["fills"]) == 1
    assert recovered.reconcile()["ok"]


def test_partial_sell_releases_share_reservation_and_is_terminal(tmp_path):
    path = tmp_path / "partial-sell.db"
    ledger = ledger_at(path)
    buy, buy_intent = decide(amount="5", signal="buy")
    assert buy.status == "FILLED"
    assert apply(ledger, buy, buy_intent, order_id="buy", fill_id="buy-fill")
    sell, sell_intent = decide(side="SELL", amount="4", signal="sell", execution_bid_qty="2")
    assert sell.status == "PARTIAL"
    assert apply(ledger, sell, sell_intent, order_id="sell", fill_id="sell-fill")
    recovered = StrictPaperLedger(path, account_id="isolated-v2-test")
    snapshot = recovered.account_snapshot()
    sell_order = next(row for row in snapshot["orders"] if row["order_id"] == "sell")
    assert sell_order["status"] == "PARTIALLY_FILLED"
    assert sell_order["remaining_quantity"] == "2.000000"
    assert sell_order["reserved_quantity_remaining"] == "0"
    assert snapshot["positions"][0]["reserved_quantity"] == "0.000000"
    assert snapshot["positions"][0]["quantity"] == "8.000000"
    assert recovered.reconcile()["ok"]


def test_buy_budget_and_fee_debit_cannot_exceed_cash_reservation(tmp_path):
    path = tmp_path / "budget.db"
    ledger = ledger_at(path)
    decision, intent = decide(execution_ask="0.49", fee="0.02")
    assert decision.total_cost <= intent.amount
    assert decision.total_cost + decision.total_fee > intent.amount
    ledger.submit_order(order_id="under-reserved", idempotency_key=intent.idempotency_key,
                        signal_id=intent.signal_id, identity=IDENT, side="BUY",
                        target_quantity=0, requested_notional="5", reserve_cash="5",
                        engine_version=decision.engine_version, rule_version=decision.rule_version,
                        evidence=decision.to_evidence(intent), created_at="submit")
    with pytest.raises(ValueError, match="FILL_EXCEEDS_CASH_RESERVATION"):
        ledger.apply_execution(fill_id="no-fill", order_id="under-reserved", decision=decision,
                               intent=intent, created_at="fill")
    assert ledger.account_snapshot()["fills"] == []
    assert ledger.account()["available_cash"] == "95.000000"
    assert ledger.reconcile()["ok"]


def test_repeat_initialization_is_additive_and_preserves_v2_orders(tmp_path):
    path = tmp_path / "migration.db"
    ledger = ledger_at(path)
    decision, intent = decide(execution_ask_qty="4")
    assert apply(ledger, decision, intent)
    before = ledger.account_snapshot()
    StrictPaperLedger.initialize(path)
    assert ledger.account_snapshot() == before
    assert ledger.reconcile()["ok"]
