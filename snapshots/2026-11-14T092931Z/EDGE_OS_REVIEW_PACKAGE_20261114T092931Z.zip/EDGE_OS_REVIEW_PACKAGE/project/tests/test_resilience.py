import asyncio
import time

import pytest

from app.db import Database, utc_now_iso
from app.polymarket import PolymarketError, normalize_market_state
from app.settlement import refresh_open_paper_positions
from app import service
from app import discovery as discovery_module


def test_wallet_gather_degrades_when_one_large_source_fails(monkeypatch):
    async def ok_profile(_):
        return {"trades": 42}

    async def ok_volume(_):
        return {"trade_count": 42}

    async def fail_pnl(_):
        raise PolymarketError("read timeout")

    async def ok_positions(_, status):
        return [{"status": status}]

    async def ok_trades(*_, **__):
        return [{"trade_key": "one"}]

    monkeypatch.setattr(service.pm, "user_stats", ok_profile)
    monkeypatch.setattr(service.pm, "user_volume", ok_volume)
    monkeypatch.setattr(service.pm, "user_pnl", fail_pnl)
    monkeypatch.setattr(service.pm, "positions", ok_positions)
    monkeypatch.setattr(service.pm, "trades", ok_trades)

    profile, volume, pnl, closed, opened, trades, warnings = asyncio.run(
        service._gather_wallet("0x" + "1" * 40)
    )

    assert profile["trades"] == 42
    assert pnl == []
    assert closed and opened and trades
    assert len(warnings) == 1
    assert warnings[0].startswith("pnl:")


def test_wallet_gather_fails_only_when_every_source_fails(monkeypatch):
    async def fail(*_, **__):
        raise PolymarketError("offline")

    for name in ("user_stats", "user_volume", "user_pnl", "positions", "trades"):
        monkeypatch.setattr(service.pm, name, fail)

    with pytest.raises(PolymarketError):
        asyncio.run(service._gather_wallet("0x" + "2" * 40))


def test_alpha_decay_uses_real_snapshots(tmp_path):
    database = Database(str(tmp_path / "edge.db"))
    database.init()
    wallet = "0x" + "3" * 40
    database.upsert_wallet(wallet)

    with database.conn() as con:
        con.execute(
            "INSERT INTO signals(trade_key,wallet,decision,created_at) VALUES(?,?,?,?)",
            ("trade-1", wallet, "WATCH", "2026-09-18T00:00:00+00:00"),
        )
        signal_id = con.execute("SELECT id FROM signals WHERE trade_key='trade-1'").fetchone()["id"]
        con.executemany(
            """
            INSERT INTO signal_snapshots(signal_id,wallet,token_id,horizon_seconds,price,adverse_move,actual_delay_seconds,recorded_at)
            VALUES(?,?,?,?,?,?,?,?)
            """,
            [
                (signal_id, wallet, "token", 30, 0.51, 0.01, 30.1, "2026-09-18T00:00:30+00:00"),
                (signal_id, wallet, "token", 120, 0.53, 0.03, 120.2, "2026-09-18T00:02:00+00:00"),
            ],
        )

    assert database.alpha_decay() == [
        {"h": 30, "v": 0.01, "samples": 1, "updated_at": "2026-09-18T00:00:30+00:00"},
        {"h": 120, "v": 0.03, "samples": 1, "updated_at": "2026-09-18T00:02:00+00:00"},
    ]


def test_legacy_100_row_initial_sync_is_hidden_not_deleted(tmp_path):
    database = Database(str(tmp_path / "edge.db"))
    database.init()
    wallet = "0x" + "4" * 40
    database.upsert_wallet(wallet)
    database.set_wallet_analysis(wallet, {}, {"category_breakdown": []}, "QUALIFIED")

    with database.conn() as con:
        con.executemany(
            "INSERT INTO signals(trade_key,wallet,decision,skip_reason,created_at) VALUES(?,?,?,?,?)",
            [
                (f"seed-race-{i}", wallet, "SKIP", "LOW_TRADER_CONFIDENCE", utc_now_iso())
                for i in range(100)
            ],
        )

    assert database.mark_legacy_initial_sync_signals() == 100
    assert database.recent_signals() == []
    assert database.dashboard()["signals_today"] == 0
    with database.conn() as con:
        row = con.execute(
            "SELECT COUNT(*) total, SUM(is_initial_sync) ignored FROM signals WHERE wallet=?",
            (wallet,),
        ).fetchone()
    assert row["total"] == 100
    assert row["ignored"] == 100


def test_new_wallet_is_not_tracked_until_history_is_seeded(monkeypatch):
    from dataclasses import replace
    monkeypatch.setattr(service, "settings", replace(service.settings, research_enabled=False))
    operations = []

    class FakeDb:
        def get_wallet(self, _):
            if operations and operations[-1] == ("track", True):
                return {"address": "0x" + "5" * 40, "tracked": True}
            return None

        def upsert_wallet(self, _, tracked):
            operations.append(("upsert", tracked))

        def set_wallet_analysis(self, *_):
            operations.append(("analysis", True))

        def set_wallet_alpha_target(self, *_):
            operations.append(("target", "MANUAL"))

        def replace_seed_trades(self, *_):
            operations.append(("seed", True))

        def recompute_copyability(self, *_):
            operations.append(("copyability", True))

        def set_wallet_tracked(self, _, tracked):
            operations.append(("track", tracked))

        def set_wallet_error(self, *_):
            operations.append(("error", True))

    async def gathered(_):
        return {}, {}, [], [], [], [], []

    monkeypatch.setattr(service, "db", FakeDb())
    monkeypatch.setattr(service, "_gather_wallet", gathered)
    monkeypatch.setattr(
        service,
        "analyze_wallet",
        lambda *_: ({}, {"category_breakdown": []}, "OBSERVING"),
    )

    asyncio.run(service.analyze_and_store("0x" + "5" * 40))

    assert operations == [
        ("upsert", False),
        ("target", "MANUAL"),
        ("analysis", True),
        ("seed", True),
        ("copyability", True),
        ("track", True),
    ]


def test_resolved_gamma_prices_are_normalized_to_redeemable_payout():
    market = {
        "closed": True,
        "umaResolutionStatus": "resolved",
        "clobTokenIds": '["yes-token", "no-token"]',
        "outcomes": '["Yes", "No"]',
        "outcomePrices": '["0.995", "0.005"]',
    }

    yes = normalize_market_state(market, "yes-token")
    no = normalize_market_state(market, "no-token")

    assert yes["resolved"] is True
    assert yes["settlement_price"] == 1.0
    assert yes["winner_outcome"] == "Yes"
    assert no["settlement_price"] == 0.0

    market["outcomePrices"] = '["0.5", "0.5"]'
    invalid = normalize_market_state(market, "yes-token")
    assert invalid["settlement_price"] == 0.5


def _paper_database(tmp_path):
    database = Database(str(tmp_path / "paper.db"))
    database.init()
    wallet = "0x" + "6" * 40
    database.upsert_wallet(wallet)
    with database.conn() as con:
        con.execute(
            "INSERT INTO signals(trade_key,wallet,decision,created_at) VALUES(?,?,?,?)",
            ("paper-signal", wallet, "COPY", utc_now_iso()),
        )
        signal_id = con.execute(
            "SELECT id FROM signals WHERE trade_key='paper-signal'"
        ).fetchone()["id"]
    paper_id = database.create_paper_trade(
        {
            "signal_id": signal_id,
            "wallet": wallet,
            "token_id": "yes-token",
            "market_title": "Test market",
            "outcome": "Yes",
            "side": "BUY",
            "entry_price": 0.4,
            "shares": 250.0,
            "cost_usd": 100.0,
            "fees_usd": 1.0,
        }
    )
    return database, paper_id


def test_open_paper_position_is_marked_to_best_bid(tmp_path):
    database, paper_id = _paper_database(tmp_path)

    class FakeClient:
        async def market_state(self, _):
            return {"resolved": False, "settlement_price": None, "current_price": 0.57}

        async def orderbook(self, _):
            return {"bids": [{"price": 0.55, "size": 1000}], "asks": []}

    result = asyncio.run(refresh_open_paper_positions(database, FakeClient()))
    paper = database.paper_trades()[0]

    assert result["paper_marked"] == 1
    assert result["paper_settled"] == 0
    assert paper["id"] == paper_id
    assert paper["status"] == "OPEN"
    assert paper["mark_price"] == pytest.approx(0.55)
    assert paper["unrealized_pnl"] == pytest.approx(36.5)


def test_resolved_market_automatically_closes_paper_position(tmp_path):
    database, _ = _paper_database(tmp_path)

    class FakeClient:
        async def market_state(self, _):
            return {"resolved": True, "settlement_price": 1.0, "current_price": 0.995}

    result = asyncio.run(refresh_open_paper_positions(database, FakeClient()))
    paper = database.paper_trades()[0]

    assert result["paper_settled"] == 1
    assert paper["status"] == "CLOSED"
    assert paper["close_reason"] == "MARKET_SETTLED"
    assert paper["exit_price"] == 1.0
    assert paper["pnl"] == pytest.approx(149.0)
    assert paper["roi"] == pytest.approx(1.49)


def test_batch_trade_key_lookup_avoids_per_trade_database_work(tmp_path):
    database = Database(str(tmp_path / "dedupe.db"))
    database.init()
    wallet = "0x" + "7" * 40
    database.upsert_wallet(wallet)
    database.replace_seed_trades(
        wallet,
        [
            {"trade_key": "known-1"},
            {"trade_key": "known-2"},
        ],
    )

    assert database.existing_trade_keys(["known-1", "new", "known-2", "known-1"]) == {
        "known-1",
        "known-2",
    }


def test_slow_wallet_is_automatically_paused_but_history_is_kept(tmp_path):
    database = Database(str(tmp_path / "pause.db"))
    database.init()
    wallet = "0x" + "8" * 40
    database.upsert_wallet(wallet)
    with database.conn() as con:
        con.execute("UPDATE wallets SET alpha_class='FAST_ALPHA' WHERE address=?", (wallet,))
    with database.conn() as con:
        con.executemany(
            """
            INSERT INTO signals(trade_key,wallet,delay_ms,scan_latency_ms,decision,created_at)
            VALUES(?,?,?,?,?,?)
            """,
            [
                (f"slow-{i}", wallet, 90_000 + i, 100, "SKIP", utc_now_iso())
                for i in range(5)
            ],
        )
    paused = database.auto_pause_slow_wallets()

    updated = database.get_wallet(wallet)
    assert len(paused) == 1
    assert updated["tracked"] is False
    assert updated["status"] == "PAUSED_DELAY"
    assert "Fast Alpha" in updated["tracking_reason"]
    with database.conn() as con:
        assert con.execute("SELECT COUNT(*) c FROM signals").fetchone()["c"] == 5


def test_slow_alpha_candidate_is_not_paused_for_upstream_delay_alone(tmp_path):
    database = Database(str(tmp_path / "slow-delay-ok.db"))
    database.init()
    wallet = "0x" + "1" * 40
    database.upsert_wallet(wallet)
    with database.conn() as con:
        con.execute("UPDATE wallets SET alpha_class='SLOW_CANDIDATE' WHERE address=?", (wallet,))
        con.executemany(
            """
            INSERT INTO signals(trade_key,wallet,delay_ms,scan_latency_ms,decision,created_at)
            VALUES(?,?,?,?,?,?)
            """,
            [(f"slow-ok-{i}", wallet, 150_000, 120, "WATCH", utc_now_iso()) for i in range(5)],
        )

    assert database.auto_pause_slow_wallets() == []
    assert database.get_wallet(wallet)["tracked"] is True


def test_candidate_pool_keeps_best_leaderboard_observation(tmp_path):
    database = Database(str(tmp_path / "candidates.db"))
    database.init()
    wallet = "0x" + "9" * 40
    database.upsert_candidate(
        {"address": wallet, "rank": 12, "pnl": 1000, "volume": 5000, "score": 50, "time_period": "day"}
    )
    database.upsert_candidate(
        {"address": wallet, "rank": 3, "pnl": 800, "volume": 7000, "score": 80, "time_period": "week"}
    )

    candidate = database.candidates()[0]
    assert candidate["best_rank"] == 3
    assert candidate["leaderboard_pnl"] == 1000
    assert candidate["leaderboard_volume"] == 7000
    assert candidate["discovery_score"] == 80
    assert candidate["appearances"] == 2


def test_discovery_analyzes_and_promotes_qualified_candidate(tmp_path, monkeypatch):
    database = Database(str(tmp_path / "discovery.db"))
    database.init()
    wallet = "0x" + "a" * 40

    class FakePM:
        async def leaderboard(self, **_):
            return [{"user_id": wallet, "rank": 2, "pnl": 5000, "volume": 20000}]

    async def fake_analyze(address, tracked=False):
        database.upsert_wallet(address, tracked=tracked)
        stats = {"closed_market_count": 30, "realized_pnl": 5000}
        analytics = {
            "trader_skill": 80,
            "profit_concentration": {"top1": 0.2},
            "category_breakdown": [],
        }
        database.set_wallet_analysis(address, stats, analytics, "QUALIFIED")
        return database.get_wallet(address)

    monkeypatch.setattr(discovery_module, "db", database)
    monkeypatch.setattr(discovery_module, "pm", FakePM())
    monkeypatch.setattr(discovery_module, "analyze_and_store", fake_analyze)

    result = asyncio.run(discovery_module.WalletDiscovery().run_once())

    candidate = database.candidates()[0]
    promoted = database.get_wallet(wallet)
    assert result["promoted"] == 1
    assert candidate["status"] == "FORWARD_TEST"
    assert promoted["tracked"] is True
    assert promoted["auto_managed"] == 1
    assert promoted["discovery_source"] == "POLYMARKET_LEADERBOARD"


def test_stale_signal_skips_orderbook_work(monkeypatch):
    from dataclasses import replace
    monkeypatch.setattr(service, "settings", replace(service.settings, research_enabled=False))
    captured = {}

    class FakeDb:
        def insert_trade_if_new(self, *_):
            return True

        def insert_signal(self, signal):
            captured.update(signal)
            return 42

    class FakePM:
        async def orderbook(self, _):
            raise AssertionError("stale signals must not fetch an order book")

    monkeypatch.setattr(service, "db", FakeDb())
    monkeypatch.setattr(service, "pm", FakePM())
    wallet = {
        "address": "0x" + "b" * 40,
        "analytics": {"trader_skill": 90},
        "category_stats": [],
    }
    trade = {
        "trade_key": "stale",
        "token_id": "token",
        "side": "BUY",
        "price": 0.4,
        "size": 10,
        "timestamp": int(time.time()) - 1000,
        "category": "Other",
    }

    signal = asyncio.run(service.process_new_trade(wallet, trade, time.time()))

    assert signal["id"] == 42
    assert captured["decision"] == "SKIP"
    assert captured["skip_reason"] == "STALE_SIGNAL"


def _insert_delay_replay_market(database, wallet, index, settlement_price=1.0, delayed_edge=0.04):
    trade_key = f"replay-{index}"
    token = f"token-{index}"
    condition = f"condition-{index}"
    with database.conn() as con:
        con.execute(
            """
            INSERT INTO trades(trade_key,wallet,token_id,condition_id,is_seed,discovered_at)
            VALUES(?,?,?,?,0,?)
            """,
            (trade_key, wallet, token, condition, utc_now_iso()),
        )
        con.execute(
            """
            INSERT INTO signals(
                trade_key,wallet,token_id,leader_side,leader_price,expected_alpha,
                settlement_price,settled_at,decision,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?)
            """,
            (trade_key, wallet, token, "BUY", 0.4, 0.1, settlement_price, utc_now_iso(), "WATCH", utc_now_iso()),
        )
        signal_id = con.execute("SELECT id FROM signals WHERE trade_key=?", (trade_key,)).fetchone()["id"]
        con.execute(
            """
            INSERT INTO signal_snapshots(
                signal_id,wallet,token_id,horizon_seconds,price,adverse_move,
                actual_delay_seconds,filled,cost_usd,shares,fees_usd,slippage,spread,
                delayed_net_edge,recorded_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (signal_id, wallet, token, 120, 0.5, 0.1, 120.2, 1, 100, 200, 0, 0, 0.01, delayed_edge, utc_now_iso()),
        )


def test_slow_alpha_requires_forward_replay_and_settled_roi(tmp_path):
    database = Database(str(tmp_path / "slow-alpha.db"))
    database.init()
    wallet = "0x" + "c" * 40
    database.upsert_wallet(wallet)
    for index in range(5):
        _insert_delay_replay_market(database, wallet, index)

    database.recompute_copyability(wallet)
    updated = database.get_wallet(wallet)
    p120 = updated["analytics"]["copyability"]["delay_profile"]["120"]

    assert updated["alpha_class"] == "SLOW_ALPHA"
    assert p120["markets"] == 5
    assert p120["settled_markets"] == 5
    assert p120["fillability"] == 1
    assert p120["avg_settled_roi"] == pytest.approx(1.0)


def test_auto_managed_non_copyable_wallet_exits_tracking(tmp_path):
    database = Database(str(tmp_path / "non-copyable.db"))
    database.init()
    wallet = "0x" + "d" * 40
    database.upsert_wallet(wallet)
    database.set_wallet_origin(wallet, "POLYMARKET_LEADERBOARD", auto_managed=True)
    for index in range(5):
        _insert_delay_replay_market(database, wallet, index, settlement_price=0.0, delayed_edge=-0.03)

    database.recompute_copyability(wallet)
    updated = database.get_wallet(wallet)

    assert updated["alpha_class"] == "NON_COPYABLE"
    assert updated["tracked"] is False


def test_upgrade_clears_legacy_discovery_wallets_but_keeps_manual_wallets(tmp_path):
    database = Database(str(tmp_path / "reset.db"))
    database.init()
    auto_wallet = "0x" + "e" * 40
    manual_wallet = "0x" + "f" * 40
    database.upsert_wallet(auto_wallet)
    database.set_wallet_origin(auto_wallet, "POLYMARKET_LEADERBOARD", auto_managed=True)
    database.upsert_wallet(manual_wallet)
    database.upsert_candidate({"address": auto_wallet, "rank": 1, "pnl": 1, "volume": 1, "score": 1})
    with database.conn() as con:
        con.execute("DELETE FROM system_state WHERE key='slow_alpha_reset_v1'")

    result = database.reset_legacy_discovery_once()

    assert result["deleted"] == 1
    assert database.get_wallet(auto_wallet) is None
    assert database.get_wallet(manual_wallet) is not None
    assert database.candidates() == []
