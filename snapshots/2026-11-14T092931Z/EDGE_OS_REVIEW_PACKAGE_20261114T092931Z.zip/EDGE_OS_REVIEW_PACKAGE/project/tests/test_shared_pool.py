"""Fixed cash pool tests use temporary databases and deterministic books only."""
from datetime import timedelta
from decimal import Decimal
from concurrent.futures import ThreadPoolExecutor
import json
import sqlite3
import pytest

from app.shared_pool import activate_pool, capital_metrics, initialize_schema
from app.strict_ledger import StrictPaperLedger
from app.strict_paper import MarketIdentity, OrderIntent, execute_order
from app.wallet_follow_v2 import StrategyConfig, WalletFollowV2
from app.wallet_follow_runtime import status_v2
from test_wallet_follow_v2 import T0, IDENT, setup, book, MarketState


def pooled(tmp_path, amount='100'):
    sim = setup(tmp_path, StrategyConfig(initial_cash_per_wallet=Decimal(amount)))
    sim.ledger('0xabc').create_account(amount, created_at=T0.isoformat())
    activate_pool(sim.path, initial_cash=amount, at=T0)
    return sim


def fill(sim, wallet='0xabc', signal='signal', identity=IDENT, partial=False, fee='0'):
    episode = sim.observe_buy(signal_id=signal, wallet=wallet, identity=identity,
        leader_at=T0, detected_at=T0, leader_price='.5', source_mode='LIVE_OBSERVATION')
    quote = book('q-'+signal, 0, identity=identity, asks=(('.5','100'),))
    execution = book('e-'+signal, 600, identity=identity, asks=(('.5','4' if partial else '100'),))
    market = MarketState(identity, accepting_orders=True, state_source='fixture', observed_at=T0+timedelta(milliseconds=600))
    result = sim.execute_first(episode['episode_id'], market=market, quote=quote, execution=execution,
        fee_rate=fee, fee_source='fixture', observed_at=T0+timedelta(seconds=2))
    return episode, result


def read(sim, sql, args=()):
    with sqlite3.connect(sim.path) as con:
        con.row_factory=sqlite3.Row
        return [dict(x) for x in con.execute(sql,args)]


def test_activation_preserves_open_books_and_never_adds_capital(tmp_path):
    sim=setup(tmp_path,StrategyConfig(initial_cash_per_wallet=Decimal('100')))
    episode,result=fill(sim,fee='.04')
    before=read(sim,'SELECT * FROM strict_fills');positions=read(sim,'SELECT * FROM strict_positions')
    config=read(sim,'SELECT * FROM wallet_v2_versions')
    activated=activate_pool(sim.path,initial_cash='100',at=T0+timedelta(seconds=3))
    assert activated['available_cash']=='74.500000'
    assert read(sim,'SELECT * FROM strict_fills')==before
    assert read(sim,'SELECT * FROM strict_positions')==positions
    assert read(sim,'SELECT * FROM wallet_v2_versions')==config
    assert sim.ledger('0xabc').reconcile()['ok']
    assert read(sim,'SELECT * FROM strict_cash_ledger WHERE entry_type="INITIAL_CASH"')[0]['cash_flow']=='100.000000'
    assert sim.ledger('0xabc').book_account()['available_cash']=='0.000000'
    assert sim.ledger('0xabc').verify_audit_chain()['ok']


def test_new_wallet_has_zero_initial_cash_and_shared_buy_balance(tmp_path):
    sim=pooled(tmp_path)
    fill(sim,signal='one')
    fill(sim,wallet='0xnew',signal='two')
    assert sim.ledger('0xnew').book_account()['initial_cash']=='0.000000'
    assert sim.ledger('0xnew').account()['available_cash']=='50.000000'
    assert len(read(sim,"SELECT * FROM strict_cash_ledger WHERE entry_type='INITIAL_CASH'"))==1
    assert sim.ledger('0xabc').reconcile()['ok'] and sim.ledger('0xnew').reconcile()['ok']
    assert sim.wallet_metrics('0xabc')['paper_fill_rate']=='1'
    assert sim.wallet_metrics('0xnew')['paper_fill_rate']=='1'


def test_shared_cash_shortage_is_rejected_without_wallet_topup(tmp_path):
    sim=pooled(tmp_path,'25')
    fill(sim,signal='one')
    episode,result=fill(sim,wallet='0xnew',signal='two')
    assert result['reason']=='INSUFFICIENT_PAPER_CASH'
    assert sim.episode(episode['episode_id'])['paper_status']=='REJECTED'
    assert sim.ledger('0xnew').account()['available_cash']=='0.000000'
    assert read(sim,'SELECT SUM(CAST(initial_cash AS REAL)) AS value FROM strict_accounts')[0]['value']==25


def test_partial_buy_releases_shared_reserve_immediately_and_restart(tmp_path):
    sim=pooled(tmp_path)
    episode,result=fill(sim,partial=True,fee='.04')
    assert result['status']=='PARTIAL'
    assert sim.ledger('0xabc').account()['available_cash']=='97.960000'
    assert sim.ledger('0xabc').account()['reserved_cash']=='0.000000'
    restarted=WalletFollowV2(sim.path)
    assert restarted.ledger('0xabc').reconcile()['ok']
    assert restarted.execute_first(episode['episode_id'],market=None,quote=None,execution=None,
        fee_rate='0',fee_source='fixture',observed_at=T0)['duplicate']
    assert len(read(sim,'SELECT * FROM strict_fills'))==1


def test_old_wallet_settlement_returns_cash_to_pool_with_correct_attribution(tmp_path):
    sim=setup(tmp_path,StrategyConfig(initial_cash_per_wallet=Decimal('100')))
    episode,result=fill(sim)
    activate_pool(sim.path,initial_cash='100',at=T0+timedelta(seconds=3))
    sim.record_resolution(episode['episode_id'],status='FORMALLY_RESOLVED',observed_at=T0+timedelta(days=1),
        authoritative_source='fixture-final',winning_token_id=IDENT.token_id,payout_per_share='1')
    assert sim.ledger('0xabc').account()['available_cash']=='125.000000'
    assert sim.wallet_metrics('0xabc')['realized_pnl']=='25.000000'
    assert sim.ledger('0xabc').book_account()['available_cash']=='0.000000'
    assert sim.ledger('0xabc').reconcile()['ok']
    assert not sim.record_resolution(episode['episode_id'],status='FORMALLY_RESOLVED',observed_at=T0+timedelta(days=1),
        authoritative_source='fixture-final',winning_token_id=IDENT.token_id,payout_per_share='1')
    assert len(read(sim,"SELECT * FROM strict_capital_events WHERE event_type='SETTLEMENT'"))==1


def test_sell_proceeds_and_fees_return_to_shared_cash(tmp_path):
    sim=pooled(tmp_path)
    fill(sim)
    ledger=sim.ledger('0xabc')
    quote=book('sq',3000,bids=(('.60','100'),),asks=(('.70','100'),))
    execution=book('se',3600,bids=(('.60','100'),),asks=(('.70','100'),))
    market=MarketState(IDENT,accepting_orders=True,state_source='fixture',observed_at=T0+timedelta(milliseconds=3600))
    intent=OrderIntent('sell','sell-idem',IDENT,'SELL',Decimal('50'),True)
    rules=StrategyConfig().engine_rules(sim.strategy_version)
    result=execute_order(intent,market,quote,execution,rules,fee_rate='.04',fee_source='fixture',observed_at=T0+timedelta(seconds=5))
    ledger.submit_order(order_id='sell-order',idempotency_key=intent.idempotency_key,signal_id=intent.signal_id,
        identity=IDENT,side='SELL',target_quantity='50',engine_version=result.engine_version,rule_version=result.rule_version,
        evidence=result.to_evidence(intent),created_at=(T0+timedelta(seconds=5)).isoformat())
    ledger.apply_execution(fill_id='sell-fill',order_id='sell-order',decision=result,intent=intent,created_at=(T0+timedelta(seconds=5)).isoformat())
    assert ledger.account()['available_cash']=='104.520000'
    assert sim.wallet_metrics('0xabc')['realized_pnl']=='4.520000'
    assert ledger.reconcile()['ok']


def test_concurrent_orders_cannot_overspend_global_cash_and_cancel_restores(tmp_path):
    sim=pooled(tmp_path)
    wallets=['0x'+str(i) for i in range(6)]
    for wallet in wallets:sim.ledger(wallet).create_account('1000',created_at=T0.isoformat())
    def reserve(wallet):
        ledger=sim.ledger(wallet)
        try:
            ledger.submit_order(order_id=wallet,idempotency_key=wallet,signal_id=wallet,identity=IDENT,
                side='BUY',target_quantity=0,reserve_cash='25',requested_notional='25',
                engine_version='strict-paper-engine-v2',rule_version='reserve-rules',evidence={},created_at=T0.isoformat())
            return True
        except ValueError as exc:
            assert str(exc)=='INSUFFICIENT_AVAILABLE_CASH'
            return False
    with ThreadPoolExecutor(max_workers=6) as executor:results=list(executor.map(reserve,wallets))
    assert sum(results)==4
    assert sim.ledger('0xabc').account()['reserved_cash']=='100.000000'
    assert sim.ledger('0xabc').reconcile()['ok']
    for wallet,result in zip(wallets,results):
        if result:sim.ledger(wallet).cancel_order(wallet,created_at=(T0+timedelta(seconds=2)).isoformat())
    assert WalletFollowV2(sim.path).ledger('0xabc').account()['available_cash']=='100.000000'
    assert sim.ledger('0xabc').reconcile()['ok']


def test_activation_idempotency_and_frozen_budget(tmp_path):
    sim=pooled(tmp_path)
    before=read(sim,'SELECT * FROM strict_cash_ledger')
    assert activate_pool(sim.path,initial_cash='100',at=T0+timedelta(days=1))['already_active']
    assert read(sim,'SELECT * FROM strict_cash_ledger')==before
    with pytest.raises(ValueError,match='FROZEN_POOL_CONFIG_CONFLICT'):
        activate_pool(sim.path,initial_cash='101',at=T0)
    with sqlite3.connect(sim.path) as con:
        with pytest.raises(sqlite3.IntegrityError,match='append-only'):
            con.execute("UPDATE strict_cash_pools SET fixed_initial_cash='101'")


def test_wrong_total_and_inflight_activation_fail_closed(tmp_path):
    sim=setup(tmp_path)
    sim.ledger('0xabc').create_account('1000',created_at=T0.isoformat())
    with pytest.raises(ValueError,match='POOL_INITIAL_CAPITAL_MISMATCH'):
        activate_pool(sim.path,initial_cash='100',at=T0)
    ledger=sim.ledger('0xabc')
    ledger.submit_order(order_id='open',idempotency_key='open',signal_id='open',identity=IDENT,side='BUY',target_quantity=0,
        reserve_cash='25',requested_notional='25',engine_version='strict-paper-engine-v2',rule_version='reserve-rules',evidence={},created_at=T0.isoformat())
    with pytest.raises(ValueError,match='POOL_HAS_INFLIGHT_RESERVATIONS'):
        activate_pool(sim.path,initial_cash='1000',at=T0)


def test_metrics_weight_time_and_curve_only_committed_financial_results(tmp_path):
    sim=pooled(tmp_path)
    episode,result=fill(sim)
    at=T0+timedelta(seconds=10)
    with sqlite3.connect(sim.path) as con:
        con.row_factory=sqlite3.Row
        metrics=capital_metrics(con,sim.strategy_version,now=at)
    assert Decimal(metrics['current_utilization'])==Decimal('.25')
    assert Decimal(metrics['average_utilization'])==Decimal('.20') # 25 held for 8 of 10 seconds
    assert Decimal(metrics['buy_turnover'])==Decimal('.25')
    assert metrics['average_holding_seconds'] is None
    assert len(metrics['return_curve'])==1
    sim.record_resolution(episode['episode_id'],status='API_FAILURE',observed_at=T0+timedelta(seconds=15))
    assert len(read(sim,"SELECT * FROM strict_capital_events WHERE event_type='SETTLEMENT'"))==0
    sim.record_resolution(episode['episode_id'],status='FORMALLY_RESOLVED',observed_at=T0+timedelta(seconds=20),
        authoritative_source='fixture-final',winning_token_id=IDENT.token_id,payout_per_share='1')
    with sqlite3.connect(sim.path) as con:
        con.row_factory=sqlite3.Row;metrics=capital_metrics(con,sim.strategy_version,now=T0+timedelta(seconds=22))
    assert metrics['average_holding_seconds']=='18.0'
    assert metrics['return_curve'][-1]['return']=='0.25'
    assert metrics['current_utilization']=='0'


def test_legacy_strict_account_constraint_upgrade_preserves_rows_and_foreign_keys(tmp_path):
    sim=setup(tmp_path)
    fill(sim)
    # Reproduce the actual deployed >0 constraint on a separate temporary DB.
    with sqlite3.connect(sim.path) as con:
        con.execute('PRAGMA writable_schema=ON')
        con.execute("UPDATE sqlite_master SET sql=replace(sql,'CAST(initial_cash AS REAL) >= 0','CAST(initial_cash AS REAL) > 0') WHERE name='strict_accounts'")
        con.execute('PRAGMA writable_schema=OFF')
    tables=['strict_accounts','strict_fills','strict_positions','strict_cash_ledger','strict_audit_events','wallet_v2_versions']
    before={t:read(sim,'SELECT * FROM '+t) for t in tables}
    initialize_schema(sim.path)
    assert {t:read(sim,'SELECT * FROM '+t) for t in tables}==before
    assert read(sim,'PRAGMA foreign_key_check')==[]
    assert read(sim,'PRAGMA integrity_check')[0]['integrity_check']=='ok'


def test_status_api_capital_contract_is_readonly(database):
    # Existing integration fixture is not imported here; supplied by local fixture below.
    sim=database
    before=read(sim,'SELECT * FROM strict_capital_events')
    state=status_v2(sim.path)
    assert state['capital_pool']['fixed_initial_cash']=='100.000000'
    assert state['capital_pool']['reconciliation']['ok']
    assert state['frozen_config']['live_orders'] is False
    assert read(sim,'SELECT * FROM strict_capital_events')==before


def test_crash_after_reserving_shared_cash_recovers_without_replay(tmp_path,monkeypatch):
    sim=pooled(tmp_path)
    original=StrictPaperLedger.apply_execution
    def died(*args,**kwargs):raise RuntimeError('process-death')
    monkeypatch.setattr(StrictPaperLedger,'apply_execution',died)
    with pytest.raises(RuntimeError,match='process-death'):fill(sim)
    assert sim.ledger('0xabc').account()['reserved_cash']=='25.000000'
    monkeypatch.setattr(StrictPaperLedger,'apply_execution',original)
    result=sim.recover_stale_observed(now=T0+timedelta(seconds=200))
    assert sim.ledger('0xabc').account()['available_cash']=='100.000000'
    assert sim.ledger('0xabc').account()['reserved_cash']=='0.000000'
    assert read(sim,'SELECT * FROM strict_fills')==[]
    before=read(sim,'SELECT * FROM strict_cash_ledger')
    sim.recover_stale_observed(now=T0+timedelta(seconds=300))
    assert read(sim,'SELECT * FROM strict_cash_ledger')==before
    assert sim.ledger('0xabc').reconcile()['ok']


def test_wallets_on_same_market_keep_financial_results_separate(tmp_path):
    sim=pooled(tmp_path)
    first,_=fill(sim,signal='one');second,_=fill(sim,wallet='0xnew',signal='two')
    sim.record_resolution(first['episode_id'],status='FORMALLY_RESOLVED',observed_at=T0+timedelta(days=1),
        authoritative_source='fixture',winning_token_id=IDENT.token_id,payout_per_share='1')
    assert sim.wallet_metrics('0xabc')['realized_pnl']=='25.000000'
    assert sim.wallet_metrics('0xnew')['realized_pnl']=='0'
    assert Decimal(sim.ledger('0xnew').account_snapshot()['positions'][0]['quantity'])==50
    assert sim.ledger('0xnew').reconcile()['ok']
    sim.record_resolution(second['episode_id'],status='FORMALLY_RESOLVED',observed_at=T0+timedelta(days=1),
        authoritative_source='fixture',winning_token_id=IDENT.token_id,payout_per_share='1')
    assert sim.ledger('0xabc').account()['available_cash']=='150.000000'
    assert sim.ledger('0xnew').reconcile()['ok']


def test_financial_transaction_rolls_back_pool_cash_and_capital_events(tmp_path,monkeypatch):
    sim=pooled(tmp_path)
    import app.strict_ledger as module
    original=module.observe_capital
    def fail_on_fill(con,aid,key,kind,at):
        if kind=='BUY_FILL':raise RuntimeError('capital-write-failed')
        return original(con,aid,key,kind,at)
    monkeypatch.setattr(module,'observe_capital',fail_on_fill)
    with pytest.raises(RuntimeError,match='capital-write-failed'):fill(sim)
    assert read(sim,'SELECT * FROM strict_fills')==[]
    assert read(sim,'SELECT * FROM strict_positions')==[]
    assert sim.ledger('0xabc').account()['available_cash']=='75.000000'
    assert sim.ledger('0xabc').account()['reserved_cash']=='25.000000'
    assert sim.ledger('0xabc').reconcile()['ok']
    sim.recover_stale_observed(now=T0+timedelta(seconds=200))
    assert sim.ledger('0xabc').account()['available_cash']=='100.000000'


def test_stale_per_wallet_funding_code_cannot_add_capital(tmp_path):
    sim=pooled(tmp_path)
    with sqlite3.connect(sim.path) as con:
        with pytest.raises(sqlite3.IntegrityError,match='SHARED_POOL_NO_NEW_CAPITAL'):
            con.execute("INSERT INTO strict_accounts VALUES('wallet-follow-v2.0:0xstale','strict-paper-ledger-v1','1000','1000','0','0','0',?)",(T0.isoformat(),))
        with pytest.raises(sqlite3.IntegrityError,match='SHARED_POOL_FROZEN_CAPITAL'):
            con.execute("UPDATE strict_accounts SET initial_cash='200' WHERE account_id='wallet-follow-v2.0:0xabc'")
        with pytest.raises(sqlite3.IntegrityError,match='SHARED_POOL_NO_NEW_CAPITAL'):
            con.execute("INSERT INTO strict_cash_ledger VALUES('bad','wallet-follow-v2.0:0xabc',NULL,NULL,'INITIAL_CASH','1000','0',?,'{}')",(T0.isoformat(),))
    assert sim.ledger('0xabc').reconcile()['ok']


def test_http_status_exposes_pool_without_writes(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    from types import SimpleNamespace
    from app import main
    sim=pooled(tmp_path)
    monkeypatch.setattr(main,'db',SimpleNamespace(path=sim.path))
    before=read(sim,'SELECT * FROM strict_capital_events')
    response=TestClient(main.app).get('/api/wallet-follow-v2')
    assert response.status_code==200
    assert response.json()['capital_pool']['fixed_initial_cash']=='100.000000'
    assert response.json()['capital_pool']['reconciliation']['ok']
    assert read(sim,'SELECT * FROM strict_capital_events')==before


def test_cash_reservation_race_is_named_rejection_not_data_failure(tmp_path,monkeypatch):
    sim=pooled(tmp_path,'25')
    fill(sim,signal='first')
    original=StrictPaperLedger.account
    def stale_balance(self):
        row=original(self)
        return {**row,'available_cash':'100'} if self.account_id.endswith(':0xnew') else row
    monkeypatch.setattr(StrictPaperLedger,'account',stale_balance)
    episode,result=fill(sim,wallet='0xnew',signal='second')
    assert result['reason']=='INSUFFICIENT_PAPER_CASH'
    assert sim.episode(episode['episode_id'])['paper_status']=='REJECTED'
    assert len(read(sim,'SELECT * FROM strict_fills'))==1
    assert sim.ledger('0xnew').reconcile()['ok']


def test_resolution_cancelling_unfilled_order_ends_reserved_capital_time(tmp_path):
    sim=pooled(tmp_path)
    ledger=sim.ledger('0xabc')
    ledger.submit_order(order_id='pending',idempotency_key='pending',signal_id='pending',identity=IDENT,
        side='BUY',target_quantity=0,reserve_cash='25',requested_notional='25',
        engine_version='strict-paper-engine-v2',rule_version='reserve-rules',evidence={},created_at=T0.isoformat())
    ledger.record_settlement(settlement_id='unfilled-final',identity=IDENT,status='FORMALLY_RESOLVED',
        observed_at=(T0+timedelta(seconds=20)).isoformat(),authoritative_source='fixture-final',payout_per_share='1')
    with sqlite3.connect(sim.path) as con:
        con.row_factory=sqlite3.Row
        metrics=capital_metrics(con,sim.strategy_version,now=T0+timedelta(seconds=40))
    assert metrics['current_utilization']=='0'
    assert Decimal(metrics['average_utilization'])==Decimal('.125')
    assert len(metrics['return_curve'])==1
    assert ledger.account()['available_cash']=='100.000000'
    assert ledger.reconcile()['ok']


@pytest.fixture
def database(tmp_path):
    return pooled(tmp_path)
