"""P1 regressions: budget dust priority and authoritative financial VOID."""
import asyncio
import hashlib
import json
import sqlite3
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal

import pytest
from app.strict_ledger import StrictPaperLedger
from app.strict_paper import OrderIntent, WalletFollowEngineRules, execute_order
from app.polymarket import normalize_market_state
from app.wallet_follow_runtime import WalletFollowRuntime, status_v2
from test_wallet_follow_v2 import IDENT, T0, MarketState, book, setup, observe
from test_wallet_follow_v2_activation import FakeClock, FakePolymarket, _activated_v2, _trade, WALLET


def run_buy(tmp_path, asks, *, amount='25'):
    intent=OrderIntent('p1','p1',IDENT,'BUY',Decimal(amount),True,edge_detected_timestamp=T0)
    rules=WalletFollowEngineRules(max_visible_depth_fraction=Decimal('1'))
    market=MarketState(IDENT,accepting_orders=True,state_source='fixture',observed_at=T0)
    d=execute_order(intent,market,book('q',0,asks=(('0.30','100'),),bids=(('0.01','100'),)),
        book('e',600,asks=asks,bids=(('0.01','100'),)),rules,fee_rate='0',fee_source='fixture',observed_at=T0+timedelta(seconds=2))
    StrictPaperLedger.initialize(tmp_path/'p1.db');ledger=StrictPaperLedger(tmp_path/'p1.db')
    ledger.create_account('100',created_at='start')
    ledger.submit_order(order_id='p1',idempotency_key='p1',signal_id='p1',identity=IDENT,side='BUY',
        target_quantity=0,reserve_cash=amount,requested_notional=amount,engine_version=d.engine_version,
        rule_version=d.rule_version,evidence=d.to_evidence(intent),created_at='submit')
    assert ledger.apply_execution(fill_id='p1',order_id='p1',decision=d,intent=intent,created_at='fill')
    assert ledger.reconcile()['ok']
    return d,ledger,intent


def test_budget_dust_does_not_skip_to_dearer_rounding_quantum(tmp_path):
    d,ledger,intent=run_buy(tmp_path,(('0.30','83.33333'),('0.49','0.6'),('0.50','100')))
    assert d.status=='FILLED' and d.total_cost==Decimal('24.999999')
    assert d.unfilled_notional==Decimal('0.000001')
    assert d.fills==((Decimal('0.30'),Decimal('83.333330')),)
    # The old evidence consumed two micro-shares at .50 after skipping .49.
    forged=replace(d,filled_quantity=d.filled_quantity+Decimal('0.000002'),total_cost=Decimal('25'),
        filled_notional=Decimal('25'),unfilled_notional=Decimal('0'),
        vwap=(Decimal('25')/(d.filled_quantity+Decimal('0.000002'))).quantize(Decimal('0.000001')),
        fills=d.fills+((Decimal('0.50'),Decimal('0.000002')),))
    from app.strict_ledger import _validate_execution_evidence
    order=ledger.account_snapshot()['orders'][0]
    with pytest.raises(ValueError):
        _validate_execution_evidence(order,forged.to_evidence(intent),forged.filled_quantity,forged.vwap,forged.total_cost,forged.total_fee)


def test_microscopic_full_capacity_is_nonexecutable_in_engine_and_ledger(tmp_path):
    d,_,_=run_buy(tmp_path,(('0.49','0.000001'),('0.50','100')))
    assert d.fills==((Decimal('0.50'),Decimal('50')),)
    assert d.total_cost==Decimal('25')


def test_normal_multiple_price_levels_and_roi_partial_unchanged(tmp_path):
    d,_,_=run_buy(tmp_path,(('0.4','10'),('0.5','10'),('0.7','100')))
    assert [p for p,q in d.fills]==list(map(Decimal,('0.4','0.5','0.7')))
    assert d.status=='FILLED'
    child=tmp_path/'roi';child.mkdir()
    d,_,_=run_buy(child,(('0.70','1'),('0.99','100')))
    assert d.status=='PARTIAL' and d.reason=='PARTIAL_ROI_FLOOR' and d.total_cost==Decimal('0.7')


def filled_sim(tmp_path):
    sim=setup(tmp_path);eid=observe(sim)['episode_id']
    result=sim.execute_first(eid,market=MarketState(IDENT,accepting_orders=True,state_source='fixture',observed_at=T0),
        quote=book('q',0,asks=(('0.4','1000'),),bids=(('0.01','100'),)),execution=book('e',600,asks=(('0.4','1000'),),bids=(('0.01','100'),)),
        fee_rate='0.02',fee_source='fixture',observed_at=T0+timedelta(seconds=2))
    assert result['status']=='FILLED'
    return sim,eid


def void_evidence(identity=IDENT):
    return dict(condition_id=identity.condition_id,token_id=identity.token_id,outcome=identity.outcome,
        resolved=True,resolution_is_void=True,authoritative_source='official-resolution',settlement_price='0.5')


def test_void_financial_terminal_cash_pnl_reservations_metrics_and_idempotency(tmp_path):
    sim,eid=filled_sim(tmp_path);ledger=sim.ledger('0xabc');before=ledger.account_snapshot();pos=before['positions'][0]
    qty=Decimal(pos['quantity']);basis=Decimal(pos['cost_basis']);cash=Decimal(before['account']['available_cash'])
    # Both reservation types must be released in the same terminal transaction.
    ledger.submit_order(order_id='buy-open',idempotency_key='buy-open',signal_id='buy-open',identity=IDENT,
        side='BUY',target_quantity='1',reserve_cash='1',engine_version='strict-paper-engine-v1',rule_version='fixture',evidence={},created_at='open')
    ledger.submit_order(order_id='sell-open',idempotency_key='sell-open',signal_id='sell-open',identity=IDENT,
        side='SELL',target_quantity='1',reserve_cash='0',engine_version='strict-paper-engine-v1',rule_version='fixture',evidence={},created_at='open')
    assert sim.record_resolution(eid,status='VOID',observed_at=T0+timedelta(days=1),authoritative_source='official-resolution',
        payout_per_share='0.5',evidence=void_evidence())
    snap=ledger.account_snapshot();pos=snap['positions'][0];flow=(qty*Decimal('0.5')).quantize(Decimal('0.000001'))
    assert all(Decimal(pos[k])==0 for k in ('quantity','cost_basis','reserved_quantity'))
    assert Decimal(pos['realized_pnl'])==flow-basis
    assert Decimal(snap['account']['available_cash'])==cash+flow
    assert Decimal(snap['account']['reserved_cash'])==0
    assert all(o['status']!='OPEN' for o in snap['orders'])
    episode=sim.episode(eid);assert episode['resolution_status']=='VOID' and episode['direction_correct'] is None
    assert Decimal(episode['payout_per_share'])==Decimal('0.5')
    metrics=sim.wallet_metrics('0xabc')
    assert metrics['resolved_directional_episode_count']==0 and metrics['directional_accuracy'] is None
    assert Decimal(metrics['realized_paper_net_roi'])==(flow-basis)/basis
    assert ledger.reconcile()['ok'] and ledger.verify_audit_chain()['ok']
    assert not sim.record_resolution(eid,status='VOID',observed_at=T0+timedelta(days=2),authoritative_source='official-resolution',
        payout_per_share='0.5',evidence=void_evidence())
    assert ledger.account_snapshot()==snap


@pytest.mark.parametrize('field,value', [('resolved',False),('resolution_is_void',False),('condition_id','wrong'),
    ('token_id','wrong'),('outcome','NO'),('authoritative_source',''),('settlement_price','0'),('settlement_price','NaN')])
def test_untrusted_void_fails_closed(tmp_path,field,value):
    sim,eid=filled_sim(tmp_path);e=void_evidence();e[field]=value;before=sim.ledger('0xabc').account_snapshot()
    with pytest.raises(ValueError):
        sim.record_resolution(eid,status='VOID',observed_at=T0+timedelta(days=1),authoritative_source='official-resolution',payout_per_share='0.5',evidence=e)
    assert sim.ledger('0xabc').account_snapshot()==before


@pytest.mark.parametrize('source,payout', [('', '0.5'),('official-resolution','0'),('official-resolution','1'),('official-resolution',None)])
def test_void_rejects_missing_source_or_non_half_payout(tmp_path,source,payout):
    sim,eid=filled_sim(tmp_path)
    with pytest.raises(ValueError):
        sim.record_resolution(eid,status='VOID',observed_at=T0+timedelta(days=1),authoritative_source=source,payout_per_share=payout,evidence=void_evidence())


def test_historical_void_correction_preserves_original_and_is_atomic_idempotent(tmp_path):
    sim,eid=filled_sim(tmp_path);ledger=sim.ledger('0xabc')
    sid=hashlib.sha256(f'settle|{eid}|VOID'.encode()).hexdigest()
    old={'historical':'untouched'}
    ledger.record_settlement(settlement_id=sid,identity=IDENT,status='VOID',observed_at=T0.isoformat(),authoritative_source='old-source',details=old)
    with sim._connect() as con:
        con.execute("UPDATE wallet_v2_episodes SET resolution_status='VOID',direction_correct=NULL,resolution_evidence_json=?,settled_at=? WHERE episode_id=?",(json.dumps(old),T0.isoformat(),eid))
        original=tuple(con.execute('SELECT * FROM strict_settlements WHERE settlement_id=?',(sid,)).fetchone())
    assert sim.reconcile_void(eid,observed_at=T0+timedelta(days=1),authoritative_source='official-resolution',evidence=void_evidence())
    with sim._connect() as con:
        assert tuple(con.execute('SELECT * FROM strict_settlements WHERE settlement_id=?',(sid,)).fetchone())==original
        assert con.execute('SELECT count(*) FROM strict_settlements').fetchone()[0]==2
        assert con.execute("SELECT count(*) FROM wallet_v2_audit WHERE action='VOID_FINANCIAL_RECONCILIATION'").fetchone()[0]==1
    assert ledger.reconcile()['ok']
    assert not sim.reconcile_void(eid,observed_at=T0+timedelta(days=2),authoritative_source='official-resolution',evidence=void_evidence())


def test_runtime_propagates_authoritative_void_half_payout(tmp_path):
    path=tmp_path/'runtime.db';sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    result=asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=clock.now()))
    async def final(token):
        return dict(condition_id='condition-1',token_id=token,outcome='YES',resolved=True,closed=True,
            resolution_is_void=True,resolution_source='official-resolution',settlement_price=0.5)
    client.market_state=final
    totals=asyncio.run(runtime.refresh_settlements())
    assert totals['settled']==1
    episode=sim.episode(result['episode_id']);assert episode['resolution_status']=='VOID' and episode['direction_correct'] is None
    assert sim.ledger(WALLET).reconcile()['ok']
    assert status_v2(path)['performance']['realized_paper_net_roi'] is not None
    assert asyncio.run(runtime.refresh_settlements())['checked']==0


def test_gamma_void_normalization_retains_source_exact_identity_and_payout():
    value=normalize_market_state(dict(conditionId='cond',clobTokenIds=['yes','no'],outcomes=['YES','NO'],
        outcomePrices=['0.5','0.5'],closed=True,umaResolutionStatus='resolved',resolutionSource='official'), 'yes')
    assert value['resolved'] and value['resolution_is_void'] and value['settlement_price']==0.5
    assert value['authoritative_source']=='official' and value['condition_id']=='cond' and value['outcome']=='YES'


def test_void_ledger_rejects_unverified_payout_and_atomic_episode_failure(tmp_path,monkeypatch):
    sim,eid=filled_sim(tmp_path);ledger=sim.ledger('0xabc');before=ledger.account_snapshot()
    with pytest.raises(ValueError):
        ledger.record_settlement(settlement_id='unverified',identity=IDENT,status='VOID',observed_at=T0.isoformat(),
            authoritative_source='official-resolution',payout_per_share='0.5',details={})
    original=StrictPaperLedger.record_settlement
    def commit_then_fail(self,**kwargs):
        original(self,**kwargs)
        raise RuntimeError('simulated-process-boundary')
    monkeypatch.setattr(StrictPaperLedger,'record_settlement',commit_then_fail)
    with pytest.raises(RuntimeError):
        sim.record_resolution(eid,status='VOID',observed_at=T0+timedelta(days=1),authoritative_source='official-resolution',
            payout_per_share='0.5',evidence=void_evidence())
    assert ledger.account_snapshot()==before and sim.episode(eid)['resolution_status']=='PENDING'
    with sim._connect() as con:assert con.execute('SELECT count(*) FROM strict_settlements').fetchone()[0]==0
    assert ledger.reconcile()['ok'] and ledger.verify_audit_chain()['ok']
