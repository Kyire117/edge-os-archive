from datetime import datetime, timedelta, timezone
from decimal import Decimal
import sqlite3
from dataclasses import replace
from concurrent.futures import ThreadPoolExecutor

import pytest

from app.strict_paper import (
    BookLevel, BookSnapshot, EngineRules, MarketIdentity, MarketState,
    OrderIntent, execute_order,
)
from app.strict_ledger import StrictPaperLedger, _validate_execution_evidence


T0 = datetime(2026, 9, 26, 0, 0, tzinfo=timezone.utc)
IDENT = MarketIdentity("condition-A", "token-A-YES", "YES")


def book(name, *, offset_ms=0, bids=None, asks=None, identity=IDENT, request_id=None):
    source_ts = T0 + timedelta(milliseconds=offset_ms)
    return BookSnapshot(name, request_id or f"req-{name}", identity, "fixture-exchange",
        source_ts, source_ts, source_ts + timedelta(milliseconds=10),
        tuple(BookLevel(Decimal(str(p)), Decimal(str(q))) for p, q in (bids or [])),
        tuple(BookLevel(Decimal(str(p)), Decimal(str(q))) for p, q in (asks or [])))


def execute(*, side="BUY", amount="5", quote=None, execution=None, rules=None,
            market=None, fee="0", edge_at=None):
    quote = quote or book("quote", bids=[("0.48", "100")], asks=[("0.50", "100")])
    execution = execution or book("exec", offset_ms=600, bids=[("0.48", "100")], asks=[("0.50", "100")])
    intent = OrderIntent("sig-1", "idem-1", IDENT, side, Decimal(amount),
        allow_partial=True, edge_detected_timestamp=edge_at)
    market = market or MarketState(IDENT, token_probability=Decimal("0.50"), state_source="fixture", observed_at=T0)
    rules = rules or EngineRules(execution_latency_ms=500, max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("1"), allow_partial_fills=True)
    return execute_order(intent, market, quote, execution, rules, fee_rate=Decimal(fee), fee_source="fixture-fee",
        observed_at=T0 + timedelta(seconds=2)), intent


def decision_case(quantity, price, fee, *, side="BUY", rule="r", signal="s", idem="i"):
    q=Decimal(str(quantity)); p=Decimal(str(price)); f=Decimal(str(fee))
    rate=(f/(q*p*(1-p))) if f else Decimal("0")
    bid,ask=(p-Decimal("0.01"),p) if side=="BUY" else (p,p+Decimal("0.01"))
    qt=T0; qrecv=T0+timedelta(milliseconds=10); et=T0+timedelta(milliseconds=20); erecv=T0+timedelta(milliseconds=30)
    quote=BookSnapshot("quote-case","quote-request",IDENT,"fixture",qt,qt,qrecv,
        (BookLevel(bid,q),),(BookLevel(ask,q),))
    execution=BookSnapshot("execution-case","execution-request",IDENT,"fixture",et,qrecv,erecv,
        (BookLevel(bid,q),),(BookLevel(ask,q),))
    intent=OrderIntent(signal,idem,IDENT,side,q*p if side=="BUY" else q,
        allow_partial=False,leader_trade_timestamp=T0,edge_detected_timestamp=qt)
    market=MarketState(IDENT,token_probability=Decimal("0.5"),state_source="fixture",observed_at=T0)
    rules=EngineRules(rule_version=rule,execution_latency_ms=0,max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("1"),allow_partial_fills=False)
    decision=execute_order(intent,market,quote,execution,rules,fee_rate=rate,fee_source="fixture-fee",
        observed_at=T0+timedelta(seconds=2))
    # Preserve ledger-v1 fixture semantics while v2 cases exercise the new engine.
    return replace(decision, engine_version="strict-paper-engine-v1", target_quantity=q,
                   unfilled_quantity=Decimal("0")),intent


def test_book_walk_uses_asks_and_level_weighted_cost():
    q = book("q", bids=[("0.49", "20")], asks=[("0.52", "20")])
    x = book("x", offset_ms=600, bids=[("0.49", "100")], asks=[("0.51", "4"), ("0.52", "6")])
    result, _ = execute(amount="5.2", quote=q, execution=x, rules=EngineRules(
        execution_latency_ms=500, max_book_age_ms=2000, max_visible_depth_fraction=Decimal("1"), allow_partial_fills=True))
    assert result.status == "PARTIAL"
    assert result.filled_quantity == Decimal("10.000000")
    assert result.total_cost == Decimal("5.160000")
    assert result.unfilled_notional == Decimal("0.040000")
    assert result.vwap == Decimal("0.516000")
    assert result.vwap >= Decimal("0.51") and result.vwap <= Decimal("0.52")
    assert result.total_cost == sum((p*q).quantize(Decimal("0.000001")) for p, q in result.fills)


def test_buy_does_not_fill_beyond_visible_depth_and_partial_is_explicit():
    rules = EngineRules(execution_latency_ms=500, max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("0.5"), allow_partial_fills=True)
    x = book("x", offset_ms=600, bids=[], asks=[("0.50", "4")])
    result, _ = execute(amount="5", execution=x, rules=rules)
    assert result.status == "PARTIAL"
    assert result.filled_quantity == Decimal("2.000000")
    assert result.unfilled_notional == Decimal("4.000000")
    assert result.raw_visible_executable_amount == Decimal("2.00")
    assert result.strict_allowed_executable_amount == Decimal("1.000")
    assert result.filled_quantity <= Decimal("4")


def test_partial_rejected_when_engine_rule_disallows_it():
    rules = EngineRules(execution_latency_ms=500, max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("0.1"), allow_partial_fills=False)
    result, _ = execute(amount="5.05", rules=rules)
    assert result.status == "REJECTED"
    assert result.reason == "PARTIAL_FILL_NOT_ALLOWED"
    assert result.filled_quantity == 0


def test_empty_book_creates_no_fill():
    x = book("x", offset_ms=600, bids=[], asks=[])
    result, _ = execute(execution=x)
    assert (result.status, result.reason, result.filled_quantity) == ("REJECTED", "EMPTY_EXECUTION_BOOK", Decimal("0"))


def test_sell_walks_bids_and_uses_requested_share_quantity():
    x = book("x", offset_ms=600, bids=[("0.49", "3"), ("0.48", "3")], asks=[("0.51", "10")])
    rules = EngineRules(execution_latency_ms=500, max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("1"), allow_partial_fills=True)
    result, _ = execute(side="SELL", amount="5", execution=x, rules=rules)
    assert result.status == "FILLED"
    assert result.filled_quantity == Decimal("5.000000")
    assert result.total_cost == Decimal("2.430000")
    assert result.vwap == Decimal("0.486000")


def test_quote_and_execution_snapshots_must_be_distinct_and_later():
    q = book("q", asks=[("0.5", "10")], bids=[("0.49", "10")])
    same = book("q", offset_ms=600, asks=[("0.5", "10")], bids=[("0.49", "10")])
    result, _ = execute(quote=q, execution=same)
    assert result.reason == "REUSED_QUOTE_SNAPSHOT"
    too_soon = book("x", offset_ms=100, asks=[("0.5", "10")], bids=[("0.49", "10")])
    result, _ = execute(quote=q, execution=too_soon)
    assert result.reason == "EXECUTION_BEFORE_FROZEN_LATENCY"


def test_source_freshness_and_timestamp_fail_closed():
    stale = BookSnapshot("stale", "stale-r", IDENT, "fixture", T0, T0, T0+timedelta(seconds=5),
                         (), (BookLevel(Decimal("0.5"), Decimal("10")),))
    result, _ = execute(quote=stale)
    assert result.reason == "STALE_QUOTE"
    invalid = BookSnapshot("invalid", "invalid-r", IDENT, "fixture", T0+timedelta(seconds=2), T0, T0+timedelta(seconds=1),
                           (), (BookLevel(Decimal("0.5"), Decimal("10")),))
    result, _ = execute(quote=invalid)
    assert result.reason == "INVALID_QUOTE_TIMESTAMP"


def test_exact_market_token_outcome_and_signal_time_are_required():
    other = MarketIdentity("condition-A", "token-A-NO", "NO")
    x = book("x", offset_ms=600, identity=other, asks=[("0.5", "10")])
    result, _ = execute(execution=x)
    assert result.reason == "MARKET_IDENTITY_MISMATCH"
    result, _ = execute(edge_at=T0+timedelta(seconds=1))
    assert result.reason == "QUOTE_PREDATES_SIGNAL"


def test_quote_source_timestamp_must_follow_signal_detection():
    quote=BookSnapshot("quote-after-request","quote-after-request-id",IDENT,"fixture",
        T0,T0+timedelta(milliseconds=1500),T0+timedelta(milliseconds=1510),
        (BookLevel(Decimal("0.48"),Decimal("100")),),
        (BookLevel(Decimal("0.50"),Decimal("100")),))
    execution=BookSnapshot("execution-after-request","execution-after-request-id",IDENT,"fixture",
        T0+timedelta(milliseconds=2200),T0+timedelta(milliseconds=2200),T0+timedelta(milliseconds=2210),
        (BookLevel(Decimal("0.48"),Decimal("100")),),
        (BookLevel(Decimal("0.50"),Decimal("100")),))
    intent=OrderIntent("sig-time","idem-time",IDENT,"BUY",Decimal("5"),
        allow_partial=True,edge_detected_timestamp=T0+timedelta(milliseconds=1600))
    market=MarketState(IDENT,token_probability=Decimal("0.5"),state_source="fixture",
        observed_at=T0+timedelta(milliseconds=2200))
    result=execute_order(intent,market,quote,execution,EngineRules(
        execution_latency_ms=500,max_book_age_ms=5000,max_visible_depth_fraction=Decimal("1"),
        allow_partial_fills=True),observed_at=T0+timedelta(milliseconds=2300))
    assert result.reason=="QUOTE_PREDATES_SIGNAL"


def test_adverse_move_exact_boundary_passes_and_excess_rejects():
    q = book("q", bids=[("0.47", "10")], asks=[("0.50", "10")])
    at_boundary = book("x", offset_ms=600, bids=[("0.46", "10")], asks=[("0.53", "10")])
    result, _ = execute(quote=q, execution=at_boundary, rules=EngineRules(
        execution_latency_ms=500,max_book_age_ms=2000,max_visible_depth_fraction=Decimal("1"),
        max_adverse_move=Decimal("0.03"),allow_partial_fills=True))
    assert result.status in ("FILLED", "PARTIAL")
    assert result.reason != "ADVERSE_PRICE_MOVEMENT"
    beyond = book("x2", offset_ms=600, bids=[("0.46", "10")], asks=[("0.530001", "10")])
    result, _ = execute(quote=q, execution=beyond, rules=EngineRules(
        execution_latency_ms=500,max_book_age_ms=2000,max_visible_depth_fraction=Decimal("1"),
        max_adverse_move=Decimal("0.03"),allow_partial_fills=True))
    assert result.reason == "ADVERSE_PRICE_MOVEMENT"


@pytest.mark.parametrize("probability", ["0.98", "0.02"])
def test_near_certainty_lockout(probability):
    result, _ = execute(market=MarketState(IDENT, token_probability=Decimal(probability),state_source="fixture",observed_at=T0))
    assert result.reason == "NEAR_CERTAINTY_LOCKOUT"


def test_unknown_or_stale_market_state_fails_closed():
    result,_=execute(market=MarketState(IDENT))
    assert result.reason=="INVALID_MARKET_STATE"
    result,_=execute(market=MarketState(IDENT,state_source="fixture",observed_at=T0-timedelta(seconds=5)))
    assert result.reason=="STALE_MARKET_STATE"


def test_execution_quote_into_near_certainty_is_locked_out():
    x=book("near",offset_ms=600,bids=[("0.98","10")],asks=[("0.99","10")])
    result,_=execute(execution=x)
    assert result.reason=="NEAR_CERTAINTY_LOCKOUT"


def test_closed_or_resolved_market_rejected_without_using_end_date():
    result, _ = execute(market=MarketState(IDENT, closed=True))
    assert result.reason == "MARKET_CLOSED_OR_RESOLVED"
    result, _ = execute(market=MarketState(IDENT, resolved=True))
    assert result.reason == "MARKET_CLOSED_OR_RESOLVED"


def test_depth_fraction_applies_exactly_and_quantity_rounds_down():
    rules = EngineRules(execution_latency_ms=500,max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("0.25"),allow_partial_fills=True)
    x = book("x", offset_ms=600, bids=[], asks=[("0.50", "1.000003")])
    result, _ = execute(amount="0.5", execution=x, rules=rules)
    assert result.strict_allowed_executable_amount == Decimal("0.125000375")
    assert result.filled_quantity == Decimal("0.250000")
    assert result.total_cost == Decimal("0.125000")


@pytest.mark.parametrize("bad", [("0", "1"), ("1", "1"), ("0.5", "0"), ("NaN", "1")])
def test_invalid_book_level_fails_closed(bad):
    with pytest.raises(ValueError):
        BookLevel(Decimal(bad[0]), Decimal(bad[1]))


def test_book_is_sorted_and_crossed_market_is_rejected():
    good = BookSnapshot("sort", "sort-r", IDENT, "fixture", T0,T0,T0,
        (BookLevel(Decimal("0.4"),Decimal("1")),BookLevel(Decimal("0.45"),Decimal("1"))),
        (BookLevel(Decimal("0.6"),Decimal("1")),BookLevel(Decimal("0.55"),Decimal("1"))))
    assert good.bids[0].price == Decimal("0.45") and good.asks[0].price == Decimal("0.55")
    with pytest.raises(ValueError, match="CROSSED_BOOK"):
        BookSnapshot("cross", "cross-r", IDENT, "fixture", T0,T0,T0,
            (BookLevel(Decimal("0.60"),Decimal("1")),),(BookLevel(Decimal("0.59"),Decimal("1")),))


def make_ledger(path):
    # Legacy rows already exist; initialization must leave them byte-for-byte intact.
    with sqlite3.connect(path) as con:
        con.execute("CREATE TABLE paper_trades(id INTEGER PRIMARY KEY, pnl REAL NOT NULL)")
        con.execute("INSERT INTO paper_trades VALUES(1, 12.5)")
    StrictPaperLedger.initialize(path)
    ledger=StrictPaperLedger(path)
    ledger.create_account("100",created_at="2026-09-26T00:00:00Z")
    return ledger


def test_additive_migration_preserves_legacy_and_is_repeatable(tmp_path):
    path=tmp_path/"only-test.db"
    ledger=make_ledger(path)
    with sqlite3.connect(path) as con: before=con.execute("SELECT * FROM paper_trades").fetchall()
    StrictPaperLedger.initialize(path)
    with sqlite3.connect(path) as con:
        after=con.execute("SELECT * FROM paper_trades").fetchall()
        strict_tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'strict_%'")}
    assert before==after==[(1,12.5)]
    assert {"strict_accounts","strict_rule_versions","strict_decisions","strict_orders","strict_fills","strict_positions","strict_marks","strict_cash_ledger","strict_settlements","strict_audit_events"} <= strict_tables
    assert ledger.account()["ledger_version"] == "strict-paper-ledger-v1"


def test_ledger_cash_reservation_duplicate_fill_and_restart_reconcile(tmp_path):
    ledger=make_ledger(tmp_path/"ledger.db")
    decision,intent=decision_case("10","0.5","0.1",rule="rules-v1",signal="s1",idem="i1")
    evidence=decision.to_evidence(intent)
    assert ledger.submit_order(order_id="o1",idempotency_key="i1",signal_id="s1",identity=IDENT,side="BUY",
        target_quantity="10",reserve_cash="10",engine_version="strict-paper-engine-v1",rule_version="rules-v1",evidence={"rule_config":evidence["rule_config"]},created_at="t1")
    assert not ledger.submit_order(order_id="o1",idempotency_key="i1",signal_id="s1",identity=IDENT,side="BUY",
        target_quantity="10",reserve_cash="10",engine_version="strict-paper-engine-v1",rule_version="rules-v1",evidence={"rule_config":evidence["rule_config"]},created_at="t1")
    assert ledger.apply_execution(fill_id="f1",order_id="o1",decision=decision,intent=intent,created_at="t2")
    assert not ledger.apply_execution(fill_id="f1",order_id="o1",decision=decision,intent=intent,created_at="t2")
    # New object proves file-backed state survives a process/restart boundary.
    recovered=StrictPaperLedger(tmp_path/"ledger.db")
    snapshot=recovered.account_snapshot()
    assert snapshot["account"]["available_cash"] == "94.900000"
    assert snapshot["account"]["reserved_cash"] == "0.000000"
    assert snapshot["positions"][0]["quantity"] == "10.000000"
    assert recovered.reconcile()["ok"]
    with sqlite3.connect(tmp_path/"ledger.db") as con:
        assert con.execute("SELECT * FROM paper_trades").fetchall()==[(1,12.5)]


def test_same_partial_execution_snapshot_cannot_be_replayed_with_new_fill_id(tmp_path):
    ledger=make_ledger(tmp_path/"partial-idempotency.db")
    rules=EngineRules(rule_version="partial-v1",execution_latency_ms=500,max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("0.1"),allow_partial_fills=True)
    execution=book("partial-execution",offset_ms=600,bids=[("0.48","20")],asks=[("0.50","20")])
    result,intent=execute(amount="5",execution=execution,rules=rules)
    assert result.status=="PARTIAL"
    ledger.submit_order(order_id="partial-order",idempotency_key=intent.idempotency_key,
        signal_id=intent.signal_id,identity=IDENT,side="BUY",target_quantity=result.target_quantity,
        reserve_cash="5.1",engine_version=result.engine_version,rule_version=result.rule_version,
        evidence=result.to_evidence(intent),created_at="submit")
    assert ledger.apply_execution(fill_id="partial-fill-1",order_id="partial-order",
        decision=result,intent=intent,created_at="fill")
    assert not ledger.apply_execution(fill_id="caller-retry-new-id",order_id="partial-order",
        decision=result,intent=intent,created_at="retry")
    snapshot=ledger.account_snapshot()
    assert len(snapshot["fills"])==1
    assert snapshot["positions"][0]["quantity"]==str(result.filled_quantity)
    assert ledger.reconcile()["ok"]


def test_concurrent_retry_of_partial_snapshot_creates_one_fill(tmp_path):
    ledger=make_ledger(tmp_path/"concurrent-partial.db")
    rules=EngineRules(rule_version="concurrent-partial-v1",execution_latency_ms=500,max_book_age_ms=2000,
        max_visible_depth_fraction=Decimal("0.1"),allow_partial_fills=True)
    execution=book("concurrent-execution",offset_ms=600,bids=[("0.48","20")],asks=[("0.50","20")])
    result,intent=execute(amount="5",execution=execution,rules=rules)
    ledger.submit_order(order_id="concurrent-order",idempotency_key=intent.idempotency_key,
        signal_id=intent.signal_id,identity=IDENT,side="BUY",target_quantity=result.target_quantity,
        reserve_cash="5.1",engine_version=result.engine_version,rule_version=result.rule_version,
        evidence=result.to_evidence(intent),created_at="submit")

    def apply(fill_id):
        return ledger.apply_execution(fill_id=fill_id,order_id="concurrent-order",
            decision=result,intent=intent,created_at="fill")

    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(apply,("concurrent-fill-a","concurrent-fill-b")))
    assert sum(results)==1
    assert len(ledger.account_snapshot()["fills"])==1
    assert ledger.reconcile()["ok"]


def test_ledger_rejects_fill_levels_out_of_executable_price_order(tmp_path):
    path=tmp_path/"fill-order.db"
    ledger=make_ledger(path)
    quote=book("ordered-quote",asks=[("0.51","20")],bids=[("0.50","20")])
    execution=book("ordered-execution",offset_ms=600,asks=[("0.51","4"),("0.52","6")],
        bids=[("0.50","20")])
    result,intent=execute(amount="5.2",quote=quote,execution=execution,
        rules=EngineRules(rule_version="ordered-v1",execution_latency_ms=500,max_book_age_ms=2000,
            max_visible_depth_fraction=Decimal("1"),allow_partial_fills=True))
    assert result.status in {"FILLED","PARTIAL"}
    ledger.submit_order(order_id="ordered-order",idempotency_key=intent.idempotency_key,
        signal_id=intent.signal_id,identity=IDENT,side="BUY",target_quantity=result.target_quantity,
        reserve_cash="5.3",engine_version=result.engine_version,rule_version=result.rule_version,
        evidence=result.to_evidence(intent),created_at="submit")
    tampered=replace(result,fills=tuple(reversed(result.fills)))
    with sqlite3.connect(path) as con:
        con.row_factory=sqlite3.Row
        order=con.execute("SELECT * FROM strict_orders WHERE order_id='ordered-order'").fetchone()
    with pytest.raises(ValueError,match="INVALID_EXECUTION_EVIDENCE"):
        _validate_execution_evidence(tampered.to_evidence(intent),order,tampered.filled_quantity,
            tampered.vwap,tampered.total_fee,tampered.total_cost)
    assert ledger.account_snapshot()["fills"]==[]
    assert ledger.reconcile()["ok"]


def test_sell_reservation_prevents_oversell_and_realized_pnl_reconciles(tmp_path):
    ledger=make_ledger(tmp_path/"ledger.db")
    buy_decision,buy_intent=decision_case("10","0.5","0.1",signal="sb",idem="ib")
    sell_decision,sell_intent=decision_case("4","0.6","0.06",side="SELL",signal="ss",idem="is")
    cfg={"rule_config":buy_decision.to_evidence(buy_intent)["rule_config"]}
    ledger.submit_order(order_id="b",idempotency_key="ib",signal_id="sb",identity=IDENT,side="BUY",target_quantity="10",reserve_cash="10",engine_version=buy_decision.engine_version,rule_version="r",evidence=cfg,created_at="1")
    ledger.apply_execution(fill_id="fb",order_id="b",decision=buy_decision,intent=buy_intent,created_at="2")
    ledger.submit_order(order_id="s",idempotency_key="is",signal_id="ss",identity=IDENT,side="SELL",target_quantity="4",engine_version=sell_decision.engine_version,rule_version="r",evidence=cfg,created_at="3")
    with pytest.raises(ValueError,match="INSUFFICIENT_POSITION"):
        ledger.submit_order(order_id="s2",idempotency_key="is2",signal_id="ss2",identity=IDENT,side="SELL",target_quantity="7",engine_version=sell_decision.engine_version,rule_version="r",evidence=cfg,created_at="3")
    ledger.apply_execution(fill_id="fs",order_id="s",decision=sell_decision,intent=sell_intent,created_at="4")
    position=ledger.account_snapshot()["positions"][0]
    assert position["quantity"]=="6.000000"
    assert position["realized_pnl"]=="0.300000"
    assert ledger.reconcile()["ok"]


def test_insufficient_cash_negative_cash_and_over_reserved_fill_rejected(tmp_path):
    ledger=make_ledger(tmp_path/"ledger.db")
    decision,intent=decision_case("1","0.6","0",signal="s",idem="i")
    evidence=decision.to_evidence(intent)
    with pytest.raises(ValueError,match="INSUFFICIENT_AVAILABLE_CASH"):
        ledger.submit_order(order_id="o",idempotency_key="i",signal_id="s",identity=IDENT,side="BUY",target_quantity="1",reserve_cash="101",engine_version=decision.engine_version,rule_version="r",evidence={"rule_config":evidence["rule_config"]},created_at="t")
    ledger.submit_order(order_id="o",idempotency_key="i",signal_id="s",identity=IDENT,side="BUY",target_quantity="1",reserve_cash="0.5",engine_version=decision.engine_version,rule_version="r",evidence={"rule_config":evidence["rule_config"]},created_at="t")
    with pytest.raises(ValueError,match="FILL_EXCEEDS_CASH_RESERVATION"):
        ledger.apply_execution(fill_id="f",order_id="o",decision=decision,intent=intent,created_at="u")
    assert ledger.account()["available_cash"]=="99.500000"
    assert ledger.account()["reserved_cash"]=="0.500000"
    assert ledger.reconcile()["ok"]


def test_formal_resolution_only_pays_authoritative_explicit_result(tmp_path):
    ledger=make_ledger(tmp_path/"ledger.db")
    decision,intent=decision_case("2","0.5","0",signal="sb",idem="ib")
    evidence=decision.to_evidence(intent)
    ledger.submit_order(order_id="b",idempotency_key="ib",signal_id="sb",identity=IDENT,side="BUY",target_quantity="2",reserve_cash="2",engine_version=decision.engine_version,rule_version="r",evidence={"rule_config":evidence["rule_config"]},created_at="1")
    ledger.apply_execution(fill_id="fb",order_id="b",decision=decision,intent=intent,created_at="2")
    assert ledger.record_settlement(settlement_id="pending",identity=IDENT,status="RESULT_PENDING",observed_at="3")
    assert ledger.record_settlement(settlement_id="failure",identity=IDENT,status="API_FAILURE",observed_at="4",details={"reason":"timeout"})
    assert ledger.account()["available_cash"]=="99.000000"
    with pytest.raises(ValueError,match="MISSING_AUTHORITATIVE_RESOLUTION"):
        ledger.record_settlement(settlement_id="bad",identity=IDENT,status="FORMALLY_RESOLVED",observed_at="5",payout_per_share="1")
    ledger.submit_order(order_id="unfilled-buy",idempotency_key="unfilled-idem",signal_id="unfilled-signal",identity=IDENT,
        side="BUY",target_quantity="1",reserve_cash="0.5",engine_version=decision.engine_version,rule_version="r",
        evidence={"rule_config":evidence["rule_config"]},created_at="5a")
    assert ledger.record_settlement(settlement_id="resolved",identity=IDENT,status="FORMALLY_RESOLVED",observed_at="6",authoritative_source="official-resolution-feed",payout_per_share="1")
    assert ledger.account()["available_cash"]=="101.000000"
    assert ledger.account()["reserved_cash"]=="0.000000"
    assert ledger.account_snapshot()["positions"][0]["quantity"]=="0.000000"
    assert ledger.account_snapshot()["orders"][1]["status"]=="CANCELLED"
    assert ledger.reconcile()["ok"]


def test_audit_chain_detects_edit_delete_and_reordering(tmp_path):
    path=tmp_path/"tamper.db"; ledger=make_ledger(path)
    assert ledger.verify_audit_chain()["ok"]
    with sqlite3.connect(path) as con:
        con.execute("DROP TRIGGER strict_audit_no_update")  # emulate out-of-band file editing
        con.execute("UPDATE strict_audit_events SET payload_json='{}' WHERE seq=1")
    assert ledger.verify_audit_chain()["ok"] is False
    with sqlite3.connect(path) as con:
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("DELETE FROM strict_audit_events WHERE seq=1")


def test_audit_chain_detects_out_of_band_delete_and_reordering(tmp_path):
    path=tmp_path/"audit-mutated.db"; ledger=make_ledger(path)
    ledger.submit_order(order_id="o",idempotency_key="i",signal_id="s",identity=IDENT,side="BUY",target_quantity="1",reserve_cash="1",engine_version="e",rule_version="r",evidence={},created_at="2")
    with sqlite3.connect(path) as con:
        con.execute("DROP TRIGGER strict_audit_no_delete")
        con.execute("DELETE FROM strict_audit_events WHERE seq=1")
    assert ledger.verify_audit_chain()["ok"] is False


def test_audit_chain_detects_unhashed_insertion(tmp_path):
    path=tmp_path/"audit-insert.db"; ledger=make_ledger(path)
    with sqlite3.connect(path) as con:
        con.execute("INSERT INTO strict_audit_events(event_id,account_id,event_type,created_at,payload_json,prev_hash,event_hash) VALUES('inserted','strict-paper-v1','FORGED','t','{}',?,?)",("0"*64,"0"*64))
    assert ledger.verify_audit_chain()["ok"] is False

    path=tmp_path/"audit-reordered.db"; ledger=make_ledger(path)
    ledger.submit_order(order_id="o",idempotency_key="i",signal_id="s",identity=IDENT,side="BUY",target_quantity="1",reserve_cash="1",engine_version="e",rule_version="r",evidence={},created_at="2")
    with sqlite3.connect(path) as con:
        con.execute("DROP TRIGGER strict_audit_no_update")
        con.execute("UPDATE strict_audit_events SET seq=101 WHERE seq=1")
        con.execute("UPDATE strict_audit_events SET seq=1 WHERE seq=2")
        con.execute("UPDATE strict_audit_events SET seq=2 WHERE seq=101")
    assert ledger.verify_audit_chain()["ok"] is False


def test_rule_version_configuration_is_frozen_when_first_order_is_written(tmp_path):
    ledger=make_ledger(tmp_path/"rules.db")
    base={"rule_config":{"execution_latency_ms":500,"depth_fraction":"0.1"}}
    ledger.submit_order(order_id="o1",idempotency_key="i1",signal_id="s1",identity=IDENT,side="BUY",target_quantity="1",reserve_cash="1",engine_version="e1",rule_version="same-v1",evidence=base,created_at="t1")
    with pytest.raises(ValueError,match="FROZEN_RULE_VERSION_CONFLICT"):
        ledger.submit_order(order_id="o2",idempotency_key="i2",signal_id="s2",identity=IDENT,side="BUY",target_quantity="1",reserve_cash="1",engine_version="e1",rule_version="same-v1",evidence={"rule_config":{"execution_latency_ms":1000,"depth_fraction":"0.1"}},created_at="t2")


def test_engine_fill_applies_same_execution_evidence_to_isolated_ledger(tmp_path):
    ledger=make_ledger(tmp_path/"engine-ledger.db")
    result,intent=execute(amount="5",fee="0.04")
    assert result.status=="FILLED"
    ledger.submit_order(order_id="from-signal",idempotency_key=intent.idempotency_key,signal_id=intent.signal_id,
        identity=IDENT,side=intent.side,target_quantity=result.target_quantity,reserve_cash="5.2",
        engine_version=result.engine_version,rule_version=result.rule_version,
        evidence=result.to_evidence(intent),created_at="submit")
    ledger.apply_execution(fill_id="realized-on-paper",order_id="from-signal",decision=result,intent=intent,created_at="fill")
    assert ledger.account_snapshot()["fills"][0]["evidence_json"]
    assert ledger.reconcile()["ok"]


def test_rejected_decision_persists_without_creating_order_or_fill(tmp_path):
    ledger=make_ledger(tmp_path/"rejected.db")
    empty=book("empty",offset_ms=600,bids=[],asks=[])
    decision,intent=execute(execution=empty)
    assert decision.reason=="EMPTY_EXECUTION_BOOK"
    assert ledger.record_decision(decision,intent,created_at="decision-time")
    assert not ledger.record_decision(decision,intent,created_at="retry-time")
    snapshot=ledger.account_snapshot()
    assert len(snapshot["decisions"])==1
    assert snapshot["decisions"][0]["reason"]=="EMPTY_EXECUTION_BOOK"
    assert snapshot["orders"]==[] and snapshot["fills"]==[]
    assert ledger.account()["available_cash"]=="100.000000"


def test_observed_bid_mark_tracks_unrealized_pnl_and_rejects_stale_data(tmp_path):
    ledger=make_ledger(tmp_path/"marks.db")
    decision,intent=decision_case("2","0.5","0",signal="mark-signal",idem="mark-idem")
    ledger.submit_order(order_id="mark-order",idempotency_key=intent.idempotency_key,signal_id=intent.signal_id,
        identity=IDENT,side="BUY",target_quantity=decision.target_quantity,reserve_cash="1",
        engine_version=decision.engine_version,rule_version=decision.rule_version,
        evidence={"rule_config":decision.to_evidence(intent)["rule_config"]},created_at="submit")
    ledger.apply_execution(fill_id="mark-fill",order_id="mark-order",decision=decision,intent=intent,created_at="fill")
    observed=book("mark-book",offset_ms=1000,bids=[("0.60","5")],asks=[("0.61","5")])
    assert ledger.mark_position(IDENT,observed,observed_at=T0+timedelta(seconds=2))
    position=ledger.account_snapshot()["positions"][0]
    assert position["mark_price"]=="0.60"
    assert position["unrealized_pnl"]=="0.200000"
    assert ledger.reconcile()["ok"]
    with sqlite3.connect(tmp_path/"marks.db") as con:
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("UPDATE strict_marks SET mark_price='0.99'")
    assert not ledger.mark_position(IDENT,observed,observed_at=T0+timedelta(seconds=2))
    stale=BookSnapshot("stale-mark","stale-mark-request",IDENT,"fixture",T0,T0,T0+timedelta(seconds=5),
        (BookLevel(Decimal("0.7"),Decimal("5")),),(BookLevel(Decimal("0.71"),Decimal("5")),))
    with pytest.raises(ValueError,match="STALE_MARK_DATA"):
        ledger.mark_position(IDENT,stale,observed_at=T0+timedelta(seconds=6))
    empty=book("no-bid-mark",offset_ms=1500,bids=[],asks=[("0.61","5")])
    assert not ledger.mark_position(IDENT,empty,observed_at=T0+timedelta(seconds=2))
    assert ledger.account_snapshot()["positions"][0]["unrealized_pnl"]=="0.200000"


def test_append_only_audit_and_cash_position_mutation_checks(tmp_path):
    path=tmp_path/"audit.db"; ledger=make_ledger(path)
    decision,intent=decision_case("2","0.5","0",signal="s",idem="i")
    evidence=decision.to_evidence(intent)
    ledger.submit_order(order_id="o",idempotency_key="i",signal_id="s",identity=IDENT,side="BUY",target_quantity="2",reserve_cash="1",
        engine_version=decision.engine_version,rule_version="r",evidence={"rule_config":evidence["rule_config"]},created_at="t")
    ledger.apply_execution(fill_id="f",order_id="o",decision=decision,intent=intent,created_at="u")
    ledger.record_settlement(settlement_id="api-error",identity=IDENT,status="API_FAILURE",observed_at="v")
    with sqlite3.connect(path) as con:
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("UPDATE strict_audit_events SET event_type='FORGED' WHERE seq=1")
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("DELETE FROM strict_audit_events WHERE seq=1")
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("UPDATE strict_accounts SET available_cash='-1' WHERE account_id='strict-paper-v1'")
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("UPDATE strict_fills SET fee='999' WHERE fill_id='f'")
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("UPDATE strict_decisions SET reason='FORGED' WHERE decision_id='i'")
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("DELETE FROM strict_cash_ledger WHERE fill_id='f'")
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("UPDATE strict_settlements SET payout_per_share='1' WHERE settlement_id='api-error'")


def test_engine_decision_evidence_contains_both_books_and_fee_basis():
    result,intent=execute(fee="0.04")
    evidence=result.to_evidence(intent)
    assert evidence["quote"]["snapshot_id"]=="quote"
    assert evidence["execution"]["snapshot_id"]=="exec"
    assert evidence["fee_source"]=="fixture-fee"
    assert evidence["engine_version"]=="strict-paper-engine-v2"
    assert evidence["market_state"]["source"]=="fixture"
