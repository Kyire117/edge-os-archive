from app.paper import simulate_buy, simulate_sell, top_of_book

BOOK={
    "asks":[{"price":0.40,"size":100},{"price":0.42,"size":100}],
    "bids":[{"price":0.38,"size":100},{"price":0.36,"size":100}],
}


def test_top_of_book():
    bid, ask, spread=top_of_book(BOOK)
    assert bid == 0.38
    assert ask == 0.40
    assert round(spread,2) == 0.02


def test_buy_walks_book():
    r=simulate_buy(BOOK, 50, 0.0)
    assert r["filled"] is True
    assert r["avg_price"] > 0.40
    assert r["avg_price"] < 0.42
    assert r["shares"] > 100


def test_sell_walks_book():
    r=simulate_sell(BOOK, 150, 0.0)
    assert r["filled"] is True
    assert 0.36 < r["avg_price"] < 0.38
