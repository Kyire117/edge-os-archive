import asyncio
import json
import time
from types import SimpleNamespace

import pytest

from app.db import Database
from app import main, research_api, research as r
from app.polymarket import PolymarketClient, normalize_market_state
from app import monitor as monitor_module
from fastapi.testclient import TestClient


W = "0x" + "1" * 40
NOW = 1_800_000_000.0


@pytest.fixture
def database(tmp_path):
    db = Database(str(tmp_path / "experiment.db"))
    db.init()
    db.upsert_wallet(W)
    with db.conn() as c:
        c.execute("UPDATE wallets SET stats_json=? WHERE address=?", (json.dumps({"closed_market_count": 12}), W))
    return db


class Market:
    def __init__(self, end_offset=36 * 3600):
        self.state = {
            "closed": False,
            "resolved": False,
            "accepting_orders": True,
            "description": "Official market resolution rules",
            "resolution_source": "Official source",
            "end_timestamp": NOW + end_offset if end_offset is not None else None,
            "expected_end_time_quality": "VERIFIED_GAMMA_MARKET_END_DATE",
            "event_id": "event",
            "minimum_order_size": 5,
        }
        self.book = {"bids": [{"price": 0.49, "size": 1000}], "asks": [{"price": 0.50, "size": 1000}], "timestamp": NOW}
        self.rate = 0.04
        self.market_calls = 0
        self.fee_calls = 0
        self.book_calls = 0
        self.clock_time = NOW
        self.advance_clock_by = 0

    def clock(self):
        return self.clock_time

    async def market_state(self, _):
        self.market_calls += 1
        return dict(self.state)

    async def research_fee(self, *_):
        self.fee_calls += 1
        return {"rate": self.rate, "source": "TEST"}

    async def orderbook(self, _):
        self.book_calls += 1
        self.clock_time += self.advance_clock_by
        return self.book


def trade(key="trade-1", **changes):
    result = {
        "trade_key": key,
        "wallet": W,
        "condition_id": "condition-1",
        "token_id": "token-yes",
        "event_id": "event-1",
        "side": "BUY",
        "price": 0.49,
        "size": 50,
        "timestamp": NOW - 5,
        "title": "Test market",
        "outcome": "YES",
        "category": "Politics",
    }
    result.update(changes)
    return result


def start(db, now=NOW):
    return r.start_experiment(db, now)


def capture(db, client, t=None, detected=NOW):
    return asyncio.run(r.capture_experiment(db, client, {"address": W}, t or trade(), detected))


def test_activation_persists_frozen_rules_utc_and_fourteen_day_window(database):
    result = start(database)
    ex = result["experiment"]
    assert ex["id"].startswith("FC14-")
    assert ex["status"] == "RUNNING"
    assert ex["rules"]["rule_version"] == "forward-copy-v0.4"
    assert ex["rules"]["min_seconds_to_end"] == 3600
    assert ex["rules"]["max_seconds_to_end"] == 5 * 86400
    assert ex["rules"]["expected_end_time_policy"] == "REQUIRE_SEMANTICALLY_VERIFIED_MARKET_END"
    assert ex["rules"]["require_book_source_timestamp"] is True
    assert ex["rules"]["max_book_age_seconds"] == 15
    assert ex["rules"]["trade_notional_usd"] == 25
    assert ex["rules"]["live_orders"] is False
    assert ex["remaining_seconds"] == 14 * 86400
    assert ex["started_utc"].endswith("Z") and ex["ends_utc"].endswith("Z")
    assert ex["cohort_size"] == 1
    with pytest.raises(ValueError, match="已有未完成"):
        start(database, NOW + 1)


@pytest.mark.parametrize("end_offset", [3600, 48 * 3600, 3 * 86400, 5 * 86400])
def test_horizon_boundaries_are_inclusive(database, end_offset):
    start(database)
    client = Market(end_offset)
    result = capture(database, client)
    assert result["status"] == "OPEN"
    assert result["horizon_eligible"] == 1
    assert result["horizon_seconds"] == pytest.approx(end_offset)
    assert result["horizon_calculated_ts"] == NOW
    assert result["cost"] == pytest.approx(25)
    assert result["fee"] == pytest.approx(0.5)
    assert result["shares"] == pytest.approx(50)
    assert result["quoted_ts"] is not None
    expected_category = r._entry_time_distance_category(end_offset)
    assert result["entry_time_distance_category"] == expected_category


@pytest.mark.parametrize(
    "end_offset,reason,eligible",
    [
        (None, "MISSING_END_TIME", 0),
        (-1, "EXPIRED_END_TIME", 0),
        (3599, "OUTSIDE_HORIZON_TOO_SHORT", 0),
        (5 * 86400 + 1, "OUTSIDE_HORIZON_TOO_LONG", 0),
        (8 * 365 * 86400, "INCONSISTENT_END_TIME", 0),
    ],
)
def test_unknown_expired_inconsistent_and_out_of_window_markets_skip(database, end_offset, reason, eligible):
    start(database)
    client = Market(end_offset)
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == reason
    assert result["horizon_eligible"] == eligible
    assert client.book_calls == 0


def test_historical_signal_cannot_be_backfilled_into_started_experiment(database):
    start(database)
    client = Market()
    result = capture(database, client, detected=NOW - 1)
    assert result is None
    assert r.rows(database, "SELECT * FROM research_experiment_entries") == []
    assert client.book_calls == 0


@pytest.mark.parametrize(
    "case,reason",
    [
        ("missing", "INVALID_ORDER_BOOK"),
        ("bad-price", "INVALID_ORDER_BOOK"),
        ("crossed", "INVALID_ORDER_BOOK"),
        ("stale", "STALE_ORDER_BOOK"),
        ("future", "STALE_ORDER_BOOK"),
        ("future-1", "STALE_ORDER_BOOK"),
        ("future-5", "STALE_ORDER_BOOK"),
        ("missing-timestamp", "UNKNOWN_ORDER_BOOK_AGE"),
        ("invalid-timestamp", "UNKNOWN_ORDER_BOOK_AGE"),
        ("depth", "INSUFFICIENT_DEPTH"),
        ("minimum", "BELOW_MINIMUM_ORDER"),
    ],
)
def test_invalid_stale_thin_books_and_minimum_size_never_fill(database, case, reason):
    start(database)
    client = Market()
    if case == "missing":
        client.book = {"bids": [], "asks": [], "timestamp": NOW}
    elif case == "bad-price":
        client.book["asks"] = [{"price": 1.2, "size": 100}]
    elif case == "crossed":
        client.book["bids"] = [{"price": 0.51, "size": 100}]
    elif case == "stale":
        client.book["timestamp"] = NOW - 16
    elif case == "future":
        client.book["timestamp"] = NOW + 6
    elif case == "future-1":
        client.book["timestamp"] = NOW + 1
    elif case == "future-5":
        client.book["timestamp"] = NOW + 5
    elif case == "missing-timestamp":
        client.book.pop("timestamp")
    elif case == "invalid-timestamp":
        client.book["timestamp"] = "not-a-time"
    elif case == "depth":
        client.book["asks"] = [{"price": 0.5, "size": 20}]
    elif case == "minimum":
        client.state["minimum_order_size"] = 60
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == reason
    assert result["cost"] is None


def test_frozen_cohort_caps_at_ten_and_new_discoveries_wait_for_next_run(database):
    for i in range(2, 13):
        address = "0x" + f"{i:040x}"
        database.upsert_wallet(address)
        with database.conn() as c:
            c.execute("UPDATE wallets SET stats_json=? WHERE address=?", (json.dumps({"closed_market_count": 12}), address))
    started = start(database)
    assert started["experiment"]["cohort_size"] == 10
    new_wallet = "0x" + "f" * 40
    database.upsert_wallet(new_wallet)
    with database.conn() as c:
        c.execute("UPDATE wallets SET stats_json=? WHERE address=?", (json.dumps({"closed_market_count": 20}), new_wallet))
    refreshed = r.experiment_summary(database)
    assert refreshed["experiment"]["cohort_size"] == 10
    assert new_wallet not in {w["wallet"] for w in refreshed["experiment"]["wallets"]}


def test_per_wallet_ten_entry_cap_and_realized_fee_reconciliation(database):
    start(database)
    client = Market()
    for i in range(10):
        item = capture(database, client, trade(f"trade-{i}", condition_id=f"condition-{i}", token_id=f"token-{i}"))
        assert item["status"] == "OPEN"
    eleventh = capture(database, client, trade("trade-10", condition_id="condition-10", token_id="token-10"))
    assert eleventh["status"] == "SKIP" and eleventh["reason"] == "WALLET_ENTRY_LIMIT"
    client.state.update(resolved=True, closed=True, settlement_price=1.0)
    asyncio.run(r.refresh_experiment(database, client, NOW + 100))
    settled = r.rows(database, "SELECT * FROM research_experiment_entries WHERE status='SETTLED'")
    assert len(settled) == 10
    assert settled[0]["pnl"] == pytest.approx(24.5)


def test_concurrent_duplicate_signal_creates_one_experiment_entry(database):
    start(database)
    client = Market()
    async def run():
        await asyncio.gather(
            r.capture_experiment(database, client, {"address": W}, trade(), NOW),
            r.capture_experiment(database, client, {"address": W}, trade(), NOW),
        )
    asyncio.run(run())
    entries = r.rows(database, "SELECT * FROM research_experiment_entries")
    assert len(entries) == 1
    assert entries[0]["status"] == "OPEN"
    assert client.market_calls == 1


def test_two_trade_keys_cannot_open_duplicate_wallet_market_outcome(database):
    start(database)
    client = Market()
    async def run():
        return await asyncio.gather(
            r.capture_experiment(database, client, {"address": W}, trade("a"), NOW),
            r.capture_experiment(database, client, {"address": W}, trade("b"), NOW),
        )
    asyncio.run(run())
    assert r.rows(database, "SELECT * FROM research_experiment_entries WHERE status='OPEN'")
    assert len(r.rows(database, "SELECT * FROM research_experiment_entries WHERE status='OPEN'")) == 1
    assert len(r.rows(database, "SELECT * FROM research_experiment_entries WHERE reason='DUPLICATE_POSITION'")) == 1


def test_opposite_tokens_for_same_market_cannot_open_two_positions(database):
    start(database)
    client = Market()
    async def run():
        return await asyncio.gather(
            r.capture_experiment(database, client, {"address": W}, trade("yes", token_id="token-yes", outcome="YES"), NOW),
            r.capture_experiment(database, client, {"address": W}, trade("no", token_id="token-no", outcome="NO"), NOW),
        )
    asyncio.run(run())
    assert len(r.rows(database, "SELECT * FROM research_experiment_entries WHERE status='OPEN'")) == 1
    assert len(r.rows(database, "SELECT * FROM research_experiment_entries WHERE reason='DUPLICATE_POSITION'")) == 1


def test_entry_horizon_is_rechecked_when_orderbook_arrives(database):
    start(database)
    client = Market(end_offset=3600)
    client.advance_clock_by = 2
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == "OUTSIDE_HORIZON_AT_QUOTE"
    assert result["horizon_eligible"] == 1
    assert result["entry_horizon_eligible"] == 0
    assert result["entry_horizon_seconds"] == pytest.approx(3598)


def test_crash_recovery_skips_pending_without_fetching_a_new_book(database):
    start(database)
    with database.conn() as c:
        c.execute("""INSERT INTO research_experiment_entries
          (experiment_id,trade_key,wallet,condition_id,token_id,leader_ts,detected_ts,status,entry_json)
          VALUES(?,?,?,?,?,?,?,'PENDING','{}')""",
          (r._experiment(database)["id"], "crashed", W, "c", "t", NOW - 5, NOW - 121))
    client = Market()
    asyncio.run(r.refresh_experiment(database, client, NOW))
    item = r.rows(database, "SELECT * FROM research_experiment_entries WHERE trade_key='crashed'")[0]
    assert item["status"] == "SKIP"
    assert item["reason"] == "CRASH_RECOVERY_NO_FILL"
    assert client.market_calls == 0 and client.book_calls == 0


def test_crash_recovery_only_counts_signals_inside_experiment_window(database):
    start(database)
    ex = r._experiment(database)
    with database.conn() as c:
        for key, detected in (("before", NOW - 1), ("inside", NOW + 10), ("after", ex["ends_at"] + 1)):
            c.execute("INSERT INTO trades(trade_key,wallet,is_seed,discovered_at,timestamp,condition_id,token_id) VALUES(?,?,0,?,?,?,?)",
                (key, W, r._utc(detected), detected, "c-" + key, "t-" + key))
    client = Market()
    asyncio.run(r.refresh_experiment(database, client, NOW + 300))
    missed = r.rows(database, "SELECT trade_key FROM research_experiment_entries WHERE reason='CRASH_RECOVERY_NO_FILL'")
    assert [x["trade_key"] for x in missed] == ["inside"]
    assert client.market_calls == 0 and client.book_calls == 0


def test_experiment_settlement_worker_is_not_awaited_by_wallet_scan(monkeypatch):
    monitor = monitor_module.WalletMonitor()
    monkeypatch.setattr(monitor_module, "db", SimpleNamespace(tracked_wallets=lambda: [], auto_pause_slow_wallets=lambda: []))
    monkeypatch.setattr(monitor_module, "settings", SimpleNamespace(
        research_enabled=True, paper_refresh_seconds=100, signal_settlement_refresh_seconds=100,
        realtime_request_timeout_seconds=8, monitor_max_concurrency=8,
    ))
    async def must_not_run(*_args, **_kwargs):
        raise AssertionError("experiment refresh must run on its own worker")
    monkeypatch.setattr(monitor_module.research_module, "refresh_experiment", must_not_run)
    recent = time.monotonic()
    monitor._last_paper_refresh = recent
    monitor._last_freshness_check = recent
    result = asyncio.run(monitor.scan_once())
    assert result["wallets_scanned"] == 0
    assert result["ok"] is True


def test_restart_keeps_experiment_cohort_rules_entries_and_old_tables(tmp_path):
    path = str(tmp_path / "restart.db")
    first = Database(path); first.init(); first.upsert_wallet(W)
    with first.conn() as c:
        c.execute("UPDATE wallets SET stats_json=? WHERE address=?", (json.dumps({"closed_market_count": 12}), W))
        c.execute("INSERT INTO trades(trade_key,wallet,is_seed,discovered_at) VALUES('legacy',?,1,'2026-01-01T00:00:00+00:00')", (W,))
    start(first)
    capture(first, Market())
    before = (r.rows(first, "SELECT COUNT(*) n FROM trades")[0]["n"],
              r.rows(first, "SELECT COUNT(*) n FROM research_experiment_entries")[0]["n"])
    restarted = Database(path); restarted.init()
    after = (r.rows(restarted, "SELECT COUNT(*) n FROM trades")[0]["n"],
             r.rows(restarted, "SELECT COUNT(*) n FROM research_experiment_entries")[0]["n"])
    assert before == after == (1, 1)
    assert r.experiment_summary(restarted)["experiment"]["rules"]["rule_version"] == "forward-copy-v0.4"


def test_fourteen_day_cutoff_closes_entries_but_keeps_open_positions_for_settlement(database):
    start(database)
    client = Market()
    position = capture(database, client)
    end = r._experiment(database)["ends_at"]
    summary = asyncio.run(r.refresh_experiment(database, client, end + 1))
    assert summary["experiment"]["status"] == "ENTRY_CLOSED"
    assert summary["experiment"]["counts"]["open"] == 1
    late = asyncio.run(r.capture_experiment(database, client, {"address": W}, trade("late"), end + 1))
    assert late is None
    client.state.update(resolved=True, closed=True, settlement_price=1.0)
    completed = asyncio.run(r.refresh_experiment(database, client, end + 20))
    assert completed["experiment"]["status"] == "COMPLETED"
    assert completed["experiment"]["counts"]["settled"] == 1
    assert completed["experiment"]["realized_pnl"] == pytest.approx(24.5)
    assert completed["experiment"]["entries"][0]["settlement_delay_seconds"] > 0


def test_resolution_is_never_inferred_from_expected_end_time(database):
    start(database)
    client = Market()
    capture(database, client)
    client.state.update(closed=True, resolved=False, current_price=0.8)
    summary = asyncio.run(r.refresh_experiment(database, client, NOW + 100))
    item = summary["experiment"]["entries"][0]
    assert item["status"] == "OPEN"
    assert item["pnl"] is None
    assert item["unrealized_pnl"] == pytest.approx(14.5)


def test_existing_data_survives_schema_upgrade_without_backfill(database):
    database.upsert_wallet(W)
    with database.conn() as c:
        c.execute("INSERT INTO trades(trade_key,wallet,is_seed,discovered_at) VALUES('seed',?,1,'2026-01-01T00:00:00+00:00')", (W,))
    before = r.rows(database, "SELECT COUNT(*) n FROM trades")[0]["n"]
    database.init()
    assert r.rows(database, "SELECT COUNT(*) n FROM trades")[0]["n"] == before == 1
    assert r.rows(database, "SELECT * FROM research_experiment_entries") == []


def test_experiment_api_and_dashboard_expose_separate_experiment(database, monkeypatch):
    monkeypatch.setattr(research_api, "db", database)
    client = TestClient(main.app)
    assert client.get("/api/research/experiment").json() == {"active": False, "experiment": None}
    response = client.post("/api/research/experiment/start", headers={
        "X-Edge-Client": "dashboard", "Origin": "http://testserver",
    })
    assert response.status_code == 200
    assert response.json()["experiment"]["cohort_size"] == 1
    dashboard = client.get("/").text
    assert "Wallet Follow V2.0" in dashboard
    assert "14 天短周期跟单实验" not in dashboard
    assert client.get("/api/research/experiment").json()["experiment"]["rules"]["max_seconds_to_end"] == 5 * 86400
    assert client.get("/api/research/experiment/entries?limit=10").json()["total"] == 0


def test_market_data_failure_is_audited_as_skip_never_a_fill(database):
    start(database)

    class Offline(Market):
        async def market_state(self, _):
            raise TimeoutError("test-only timeout")

    client = Offline()
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == "MARKET_DATA_UNAVAILABLE"
    assert result["cost"] is None
    assert "data_error" in json.loads(result["entry_json"])


def test_market_end_time_can_come_from_source_event_without_being_invented():
    market = {
        "clobTokenIds": ["token"], "outcomes": ["Yes"], "outcomePrices": ["0.5"],
        "events": [{"id": "event", "endDate": "2030-01-02T03:04:05Z"}],
    }
    normalized = normalize_market_state(market, "token")
    assert normalized["end_timestamp"] > 0
    assert normalized["end_timestamp_source"] == "event"

    market["endDate"] = "not-a-date"
    normalized = normalize_market_state(market, "token")
    assert normalized["end_timestamp"] == 0
    assert normalized["end_timestamp_source"] == "market"


def test_market_end_matching_sports_game_start_is_marked_unreliable():
    market = {
        "clobTokenIds": ["token"], "outcomes": ["Yes"], "outcomePrices": ["0.5"],
        "endDate": "2030-01-02T03:04:05Z", "gameStartTime": "2030-01-02T03:04:05Z",
    }
    normalized = normalize_market_state(market, "token")
    assert normalized["end_timestamp_source"] == "market"
    assert normalized["game_start_timestamp_source"] == "market.gameStartTime"
    assert normalized["end_timestamp_matches_game_start"] is True
    assert normalized["expected_end_time_quality"] == "UNRELIABLE_GAME_START"


def test_sports_market_without_game_start_fails_end_semantics_closed():
    normalized = normalize_market_state({
        "clobTokenIds": ["token"], "outcomes": ["Yes"], "outcomePrices": ["0.5"],
        "endDate": "2030-01-02T03:04:05Z", "category": "Sports", "sportsMarketType": "moneyline",
    }, "token")
    assert normalized["expected_end_time_quality"] == "UNVERIFIED"
    assert normalized["expected_end_time_quality_reason"] == "SPORTS_GAME_START_MISSING"


def test_event_level_game_start_and_event_only_end_are_handled_conservatively():
    same_time = "2030-01-02T03:04:05Z"
    normalized = normalize_market_state({
        "clobTokenIds": ["token"], "outcomes": ["Yes"], "outcomePrices": ["0.5"],
        "endDate": same_time, "category": "Sports", "events": [{"gameStartTime": same_time}],
    }, "token")
    assert normalized["end_timestamp_matches_game_start"] is True
    assert normalized["expected_end_time_quality"] == "UNRELIABLE_GAME_START"

    event_only = normalize_market_state({
        "clobTokenIds": ["token"], "outcomes": ["Yes"], "outcomePrices": ["0.5"],
        "events": [{"endDate": same_time}],
    }, "token")
    assert event_only["end_timestamp_source"] == "event"
    assert event_only["expected_end_time_quality"] == "UNVERIFIED"
    assert event_only["expected_end_time_quality_reason"] == "EVENT_END_DATE_ONLY"


def test_missing_category_invalid_and_conflicting_time_fields_fail_closed():
    base = {"clobTokenIds": ["token"], "outcomes": ["Yes"], "outcomePrices": ["0.5"],
            "endDate": "2030-01-02T03:04:05Z"}
    no_category = normalize_market_state(base, "token")
    assert no_category["expected_end_time_quality"] == "UNVERIFIED"
    assert no_category["expected_end_time_quality_reason"] == "MARKET_CATEGORY_MISSING"
    unknown_category = normalize_market_state({**base, "category": "unknown", "sportsMarketType": "moneyline",
                                               "gameStartTime": "2030-01-02T05:04:05Z"}, "token")
    assert unknown_category["expected_end_time_quality"] == "UNVERIFIED"
    assert unknown_category["expected_end_time_quality_reason"] == "UNRECOGNIZED_MARKET_CATEGORY"

    invalid_start = normalize_market_state({**base, "category": "Sports", "sportsMarketType": "moneyline",
                                             "gameStartTime": "bad-time"}, "token")
    assert invalid_start["expected_end_time_quality"] == "UNVERIFIED"
    assert invalid_start["expected_end_time_quality_reason"] == "INVALID_GAME_START_TIME"

    conflict = normalize_market_state({**base, "category": "Sports", "sportsMarketType": "moneyline",
        "gameStartTime": "2030-01-02T03:04:05Z",
        "events": [{"gameStartTime": "2030-01-02T05:04:05Z"}]}, "token")
    assert conflict["expected_end_time_quality"] == "UNVERIFIED"
    assert conflict["expected_end_time_quality_reason"] == "CONFLICTING_GAME_START_TIMES"

    hidden_conflict = normalize_market_state({**base, "category": "Sports", "sportsMarketType": "moneyline",
        "gameStartTime": "2030-01-02T05:04:05Z", "sports": {"gameStartTime": "2030-01-02T03:04:05Z"}}, "token")
    assert hidden_conflict["expected_end_time_quality"] == "UNVERIFIED"
    assert hidden_conflict["expected_end_time_quality_reason"] == "CONFLICTING_GAME_START_TIMES"

    invalid_with_valid_event = normalize_market_state({**base, "category": "Sports", "sportsMarketType": "moneyline",
        "gameStartTime": "not-a-time", "events": [{"gameStartTime": "2030-01-02T05:04:05Z"}]}, "token")
    assert invalid_with_valid_event["expected_end_time_quality"] == "UNVERIFIED"
    assert invalid_with_valid_event["expected_end_time_quality_reason"] == "INVALID_GAME_START_TIME"

    blank_with_valid_event = normalize_market_state({**base, "category": "Sports", "sportsMarketType": "moneyline",
        "gameStartTime": "  ", "events": [{"gameStartTime": "2030-01-02T05:04:05Z"}]}, "token")
    assert blank_with_valid_event["expected_end_time_quality"] == "UNVERIFIED"
    assert blank_with_valid_event["expected_end_time_quality_reason"] == "INVALID_GAME_START_TIME"


@pytest.mark.parametrize("quality_reason", ["UNRECOGNIZED_MARKET_CATEGORY", "INVALID_GAME_START_TIME", "CONFLICTING_GAME_START_TIMES"])
def test_unverified_source_cases_are_rejected_before_execution_requests(database, quality_reason):
    start(database)
    client = Market()
    client.state.update(expected_end_time_quality="UNVERIFIED",
                        expected_end_time_quality_reason=quality_reason)
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == "UNVERIFIED_END_TIME"
    assert result["horizon_eligible"] == 0
    assert client.fee_calls == 0
    assert client.book_calls == 0


@pytest.mark.parametrize("gamma_market", [
    {"category": "unknown", "sportsMarketType": "moneyline", "gameStartTime": "2030-01-02T05:04:05Z"},
    {"category": "Sports", "sportsMarketType": "moneyline", "gameStartTime": "not-a-time"},
    {"category": "Sports", "sportsMarketType": "moneyline", "gameStartTime": "2030-01-02T05:04:05Z",
     "sports": {"gameStartTime": "2030-01-02T03:04:05Z"}},
    {"category": "Sports", "sportsMarketType": "moneyline", "gameStartTime": "  ",
     "events": [{"gameStartTime": "2030-01-02T05:04:05Z"}]},
])
def test_unrecognized_invalid_or_conflicting_gamma_metadata_blocks_entry(database, gamma_market):
    start(database)
    raw = {"clobTokenIds": ["token-yes"], "outcomes": ["YES"], "outcomePrices": ["0.5"],
           "endDate": "2030-01-02T03:04:05Z", **gamma_market}
    client = Market()
    client.state.update(normalize_market_state(raw, "token-yes"))
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == "UNVERIFIED_END_TIME"
    assert client.fee_calls == 0
    assert client.book_calls == 0


def test_explicit_nonsports_gamma_market_end_is_semantically_verified():
    normalized = normalize_market_state({
        "clobTokenIds": ["token"], "outcomes": ["Yes"], "outcomePrices": ["0.5"],
        "endDate": "2030-01-02T03:04:05Z", "category": "Politics",
    }, "token")
    assert normalized["expected_end_time_quality"] == "VERIFIED_GAMMA_MARKET_END_DATE"


def test_v03_rejects_start_time_as_market_end_without_fetching_fees_or_book(database):
    start(database)
    client = Market(end_offset=12 * 60)
    client.state.update({
        "game_start_timestamp": NOW + 12 * 60,
        "end_timestamp_matches_game_start": True,
        "end_timestamp_source": "market",
        "expected_end_time_quality": "UNRELIABLE_GAME_START",
    })
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == "UNRELIABLE_END_TIME"
    assert result["horizon_eligible"] == 0
    assert result["expected_end_ts"] is None
    assert result["horizon_seconds"] is None
    assert client.book_calls == 0
    evidence = json.loads(result["entry_json"])
    assert evidence["horizon"]["end_matches_game_start"] is True
    assert evidence["horizon"]["eligibility_timestamp_quality"] == "UNRELIABLE_GAME_START"


def test_v03_rejects_unverified_end_semantics_without_fetching_fees_or_book(database):
    start(database)
    client = Market()
    client.state.pop("expected_end_time_quality")
    result = capture(database, client)
    assert result["status"] == "SKIP"
    assert result["reason"] == "UNVERIFIED_END_TIME"
    assert result["horizon_eligible"] == 0
    assert result["expected_end_ts"] is None
    assert result["horizon_seconds"] is None
    assert client.book_calls == 0
    evidence = json.loads(result["entry_json"])
    assert evidence["horizon"]["eligibility_timestamp_quality"] == "UNVERIFIED"


def test_frozen_v01_experiment_keeps_its_original_time_interpretation(database):
    start(database)
    ex = r._experiment(database)
    legacy_rules = json.loads(ex["rules_json"])
    legacy_rules["rule_version"] = "forward-copy-v0.1"
    legacy_rules.pop("expected_end_time_policy")
    with database.conn() as c:
        c.execute("UPDATE research_experiments SET rule_version=?,rules_json=? WHERE id=?",
                  ("forward-copy-v0.1", json.dumps(legacy_rules), ex["id"]))
    client = Market(end_offset=12 * 60)
    client.state["end_timestamp_matches_game_start"] = True
    result = capture(database, client)
    assert result["reason"] == "OUTSIDE_HORIZON_TOO_SHORT"
    assert client.book_calls == 0


def test_frozen_v02_match_only_policy_keeps_its_original_interpretation(database):
    start(database)
    ex = r._experiment(database)
    legacy_rules = json.loads(ex["rules_json"])
    legacy_rules.update(rule_version="forward-copy-v0.2",
                        expected_end_time_policy="REJECT_IF_GAMMA_END_MATCHES_SPORTS_GAME_START")
    with database.conn() as c:
        c.execute("UPDATE research_experiments SET rule_version=?,rules_json=? WHERE id=?",
                  ("forward-copy-v0.2", json.dumps(legacy_rules), ex["id"]))
    client = Market()
    client.state.pop("expected_end_time_quality")
    client.state["end_timestamp_matches_game_start"] = False
    result = capture(database, client)
    assert result["status"] == "OPEN"


def test_experiment_api_summary_groups_skips_by_reason(database, monkeypatch):
    start(database)
    accepted = capture(database, Market(3 * 86400), trade("three-days", condition_id="three-days"))
    assert accepted["status"] == "OPEN"
    assert accepted["entry_time_distance_category"] == "EARLY"
    client = Market(end_offset=5 * 86400 + 1)
    capture(database, client)
    monkeypatch.setattr(research_api, "db", database)
    response = TestClient(main.app).get("/api/research/experiment")
    assert response.status_code == 200
    counts = response.json()["experiment"]["counts"]
    assert counts["skip_reasons"] == {"OUTSIDE_HORIZON_TOO_LONG": 1}
    assert counts["skip_categories"]["Horizon"] == 1
    assert counts["skip_categories"]["Data quality"] == 0
    assert counts["entry_time_distance_categories"] == {"LAST_DAY": 0, "EARLY": 1, "FAR_EARLY": 0}


@pytest.mark.parametrize("seconds,category", [
    (24 * 3600, "LAST_DAY"), (24 * 3600 + 1, "EARLY"),
    (72 * 3600, "EARLY"), (72 * 3600 + 1, "FAR_EARLY"),
    (120 * 3600, "FAR_EARLY"),
])
def test_entry_distance_category_boundaries(seconds, category):
    assert r._entry_time_distance_category(seconds) == category


@pytest.mark.parametrize("version,policy", [
    ("forward-copy-v0.1", None),
    ("forward-copy-v0.2", "REJECT_IF_GAMMA_END_MATCHES_SPORTS_GAME_START"),
    ("forward-copy-v0.3", "REQUIRE_SEMANTICALLY_VERIFIED_MARKET_END"),
])
def test_legacy_frozen_horizon_rules_remain_48_hours(database, version, policy):
    start(database)
    ex = r._experiment(database)
    rules = json.loads(ex["rules_json"])
    rules["rule_version"] = version
    rules["max_seconds_to_end"] = 48 * 3600
    if policy is None:
        rules.pop("expected_end_time_policy", None)
    else:
        rules["expected_end_time_policy"] = policy
    with database.conn() as c:
        c.execute("UPDATE research_experiments SET rule_version=?,rules_json=? WHERE id=?",
                  (version, json.dumps(rules), ex["id"]))
    result = capture(database, Market(48 * 3600 + 1))
    assert result["status"] == "SKIP"
    assert result["reason"] == "OUTSIDE_HORIZON_TOO_LONG"
    stored = r._experiment(database)
    assert stored["rule_version"] == version
    assert json.loads(stored["rules_json"])["max_seconds_to_end"] == 48 * 3600


def test_additive_distance_migration_does_not_rewrite_historical_skip(database):
    start(database)
    ex = r._experiment(database)
    with database.conn() as c:
        c.execute("ALTER TABLE research_experiment_entries DROP COLUMN entry_time_distance_category")
        c.execute("""INSERT INTO research_experiment_entries
          (experiment_id,trade_key,wallet,detected_ts,status,reason,entry_json)
          VALUES(?,?,?,?,?,?,?)""", (ex["id"], "historic-skip", W, NOW, "SKIP",
          "OUTSIDE_HORIZON_TOO_LONG", "{}"))
    database.init()
    row = r.rows(database, "SELECT status,reason,entry_time_distance_category FROM research_experiment_entries WHERE trade_key='historic-skip'")[0]
    assert row == {"status": "SKIP", "reason": "OUTSIDE_HORIZON_TOO_LONG", "entry_time_distance_category": None}


def test_v04_summary_does_not_combine_previous_experiment_skips(database):
    start(database)
    old = r._experiment(database)
    old_rules = json.loads(old["rules_json"])
    old_rules["rule_version"] = "forward-copy-v0.1"
    old_rules["max_seconds_to_end"] = 48 * 3600
    with database.conn() as c:
        c.execute("UPDATE research_experiments SET rule_version='forward-copy-v0.1',status='COMPLETED',rules_json=? WHERE id=?",
                  (json.dumps(old_rules), old["id"]))
        c.execute("""INSERT INTO research_experiment_entries
          (experiment_id,trade_key,wallet,detected_ts,status,reason,entry_json)
          VALUES(?,?,?,?,?,?,?)""", (old["id"], "old-skip", W, NOW, "SKIP", "OUTSIDE_HORIZON_TOO_LONG", "{}"))
    start(database, NOW + 1)
    current = r._experiment(database)
    accepted = capture(database, Market(3 * 86400), trade("current-open", condition_id="current-market"), NOW + 1)
    assert accepted["status"] == "OPEN"
    current_summary = r.experiment_summary(database, current["id"])
    old_summary = r.experiment_summary(database, old["id"])
    assert current_summary["experiment"]["counts"]["skipped"] == 0
    assert current_summary["experiment"]["counts"]["filled"] == 1
    assert old_summary["experiment"]["counts"]["skipped"] == 1
    assert old_summary["experiment"]["counts"]["filled"] == 0


def test_monitor_errors_clear_only_after_successful_wallet_scan(database):
    database.set_wallet_error(W, "monitor: TimeoutError: no details")
    database.clear_wallet_monitor_error(W)
    assert database.get_wallet(W)["last_error"] is None
    database.set_wallet_error(W, "profile: unavailable")
    database.clear_wallet_monitor_error(W)
    assert database.get_wallet(W)["last_error"] == "profile: unavailable"


def test_monitor_records_exception_type_and_clears_stale_error_on_recovery(monkeypatch):
    state = {"error": None, "cleared": 0}
    class FakeDB:
        def existing_trade_keys(self, _keys): return set()
        def set_wallet_error(self, _address, error): state["error"] = error
        def clear_wallet_monitor_error(self, _address): state["cleared"] += 1
    class BlankTimeout(TimeoutError): pass
    async def offline(*_args, **_kwargs): raise BlankTimeout()
    async def recovered(*_args, **_kwargs): return []
    monkeypatch.setattr(monitor_module, "db", FakeDB())
    monkeypatch.setattr(monitor_module, "settings", SimpleNamespace(realtime_trade_limit=10, realtime_request_timeout_seconds=1))
    wallet = {"address": W, "last_trade_ts": NOW - 60}
    monitor = monitor_module.WalletMonitor()
    monkeypatch.setattr(monitor_module.pm, "trades", offline)
    first = asyncio.run(monitor._scan_wallet(wallet, asyncio.Semaphore(1)))
    assert state["error"] == "monitor: BlankTimeout: 无详细错误信息"
    assert "BlankTimeout" in first["errors"][0]
    assert monitor._failure_counts[W] == 1
    monitor._next_scan_at[W] = 0
    monkeypatch.setattr(monitor_module.pm, "trades", recovered)
    second = asyncio.run(monitor._scan_wallet(wallet, asyncio.Semaphore(1)))
    assert second["errors"] == []
    assert state["cleared"] == 1
    assert W not in monitor._failure_counts
    assert W not in monitor._next_scan_at


@pytest.mark.parametrize("source_timestamp", [str(int(NOW)), str(int(NOW * 1000))])
def test_numeric_string_upstream_book_timestamp_survives_adapter_and_fills(database, source_timestamp):
    start(database)

    class RawBookAdapter(PolymarketClient):
        async def _get(self, *_args, **_kwargs):
            return {"timestamp": source_timestamp,
                "bids": [{"price": "0.49", "size": "1000"}],
                "asks": [{"price": "0.50", "size": "1000"}]}

    class AdapterMarket(Market):
        async def orderbook(self, token_id):
            self.book_calls += 1
            return await RawBookAdapter().orderbook(token_id)

    client = AdapterMarket()
    result = capture(database, client)
    assert result["status"] == "OPEN"
    assert result["book_source_ts"] == NOW
    evidence = json.loads(result["entry_json"])
    assert evidence["book"]["timestamp"] == source_timestamp
    assert evidence["book_timestamps"]["source_age_verified"] is True


@pytest.mark.parametrize("timestamp", ["NaN", "Infinity", "-1", "", "2026-01-01T00:00:00"])
def test_invalid_source_timestamp_forms_are_not_parsed(timestamp):
    assert r._epoch_value(timestamp) is None


def test_previous_experiment_schema_with_opposite_outcomes_migrates_without_data_loss(tmp_path):
    path = str(tmp_path / "iteration-1.db")
    first = Database(path)
    first.init()
    first.upsert_wallet(W)
    ex_id = "FC14-ITERATION1"
    started = r._utc(NOW)
    ended = r._utc(NOW + 14 * 86400)
    with first.conn() as c:
        c.execute("DROP INDEX research_experiment_one_open_market")
        c.execute("""CREATE UNIQUE INDEX research_experiment_one_open_outcome
            ON research_experiment_entries(experiment_id,wallet,condition_id,token_id)
            WHERE status IN ('OPEN','SETTLED')""")
        for column in ("entry_horizon_checked_ts", "entry_horizon_seconds", "entry_horizon_eligible"):
            c.execute(f"ALTER TABLE research_experiment_entries DROP COLUMN {column}")
        c.execute("INSERT INTO research_experiments(id,rule_version,status,started_at,ends_at,started_utc,ends_utc,rules_json) VALUES(?,?, 'RUNNING',?,?,?,?,?)",
            (ex_id, r.EXPERIMENT_RULES["rule_version"], NOW, NOW + 14 * 86400, started, ended, json.dumps(r.EXPERIMENT_RULES)))
        c.execute("INSERT INTO research_experiment_wallets(experiment_id,wallet,frozen_at_utc,qualification_json) VALUES(?,?,?,?)",
            (ex_id, W, started, "{}"))
        for key, token in (("old-yes", "yes-token"), ("old-no", "no-token")):
            c.execute("""INSERT INTO research_experiment_entries
              (experiment_id,trade_key,wallet,condition_id,token_id,detected_ts,status,entry_json)
              VALUES(?,?,?,?,?,?, 'OPEN','{}')""", (ex_id, key, W, "same-condition", token, NOW))
    upgraded = Database(path)
    upgraded.init()
    old_rows = r.rows(upgraded, "SELECT trade_key,status FROM research_experiment_entries ORDER BY trade_key")
    assert old_rows == [{"trade_key": "old-no", "status": "OPEN"}, {"trade_key": "old-yes", "status": "OPEN"}]
    assert not r.rows(upgraded, "SELECT 1 FROM sqlite_master WHERE type='index' AND name='research_experiment_one_open_market'")

    result = capture(upgraded, Market(), trade("new-buy", condition_id="same-condition", token_id="later-token"))
    assert result["status"] == "SKIP" and result["reason"] == "DUPLICATE_POSITION"
    assert len(r.rows(upgraded, "SELECT * FROM research_experiment_entries WHERE status='OPEN'")) == 2
