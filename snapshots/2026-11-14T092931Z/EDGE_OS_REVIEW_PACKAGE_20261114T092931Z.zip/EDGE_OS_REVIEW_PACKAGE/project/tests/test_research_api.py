import json
import pytest
from fastapi.testclient import TestClient
from app.db import Database
from app import main, research_api, research as r

@pytest.fixture
def client(tmp_path,monkeypatch):
    d=Database(str(tmp_path/'api.db'));d.init()
    monkeypatch.setattr(main,'db',d);monkeypatch.setattr(research_api,'db',d);monkeypatch.setattr(research_api.ai,'db',d)
    # No lifespan here: isolate HTTP contracts from external background traffic.
    yield TestClient(main.app),d


def test_dashboard_and_write_protection(client):
    c,d=client
    assert c.get('/').status_code==200
    assert '钱包研究室' in c.get('/').text
    assert c.get('/api/research/overview').status_code==200
    path='/api/research/ai/config';body=dict(provider='deepseek',model='deepseek-chat',api_key='private-secret',enabled=False)
    assert c.post(path,json=body).status_code==403
    assert c.post(path,json=body,headers={'X-Edge-Client':'dashboard','Origin':'https://evil.example'}).status_code==403
    result=c.post(path,json=body,headers={'X-Edge-Client':'dashboard','Origin':'http://testserver'})
    assert result.status_code==200 and result.json()['has_key']
    assert 'private-secret' not in result.text
    assert 'private-secret' not in c.get('/api/research/export').text
    assert 'api_key' not in c.get(path).text
    assert c.get(path).headers['cache-control']=='no-store'


def test_remove_restore_and_entries(client):
    c,d=client;w='0x'+'8'*40;d.upsert_wallet(w);d.upsert_candidate(dict(address=w,score=1))
    headers={'X-Edge-Client':'dashboard'}
    assert c.delete('/api/research/wallets/'+w,headers=headers).status_code==200
    assert r.excluded(d,w)
    assert c.post('/api/wallets/'+w+'/track',headers=headers,json={'tracked':True}).status_code==409
    assert c.post('/api/research/wallets/'+w+'/restore',headers=headers).status_code==200
    assert not r.excluded(d,w)
    assert c.get('/api/research/entries').json()=={'total':0,'entries':[]}
    assert c.get('/api/research/entries/100').status_code==404
