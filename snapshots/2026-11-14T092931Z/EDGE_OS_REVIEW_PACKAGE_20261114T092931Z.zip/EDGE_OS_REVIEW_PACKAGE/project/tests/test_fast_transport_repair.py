"""Transport-only synthetic regressions; no real endpoints or production database."""
import asyncio
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from websockets.exceptions import ConnectionClosedError
from websockets.frames import Close

from app import monitor as monitor_module, polymarket
from app.polygon_fast_path import PolygonProducer, ProducerConfig
from app.wallet_follow_runtime import V2ActivationState


@pytest.mark.parametrize('size', [0, 2**20-1, 16*2**20+1, True, float('inf')])
def test_message_limit_stays_bounded(size):
    with pytest.raises(ValueError, match='INVALID_WSS_MESSAGE_LIMIT'):
        ProducerConfig(url='wss://fixture.invalid', max_message_bytes=size).validate()


def test_default_message_limit_allows_observed_multi_megabyte_response():
    config = ProducerConfig(url='wss://fixture.invalid')
    config.validate()
    assert config.max_message_bytes == 16*2**20
    assert config.max_message_bytes > 5_355_660


def test_explicit_public_proxy_overrides_missing_system_proxy(monkeypatch):
    captured = {}
    monkeypatch.setattr(polymarket.sys, 'platform', 'win32')
    monkeypatch.setattr(polymarket.urllib.request, 'getproxies', lambda: {})
    monkeypatch.setattr(polymarket.httpx, 'AsyncClient',
                        lambda **kwargs: captured.update(kwargs) or object())
    polymarket.PolymarketClient(public_http_proxy='http://127.0.0.1:7897')
    assert captured['proxy'] == 'http://127.0.0.1:7897'


@pytest.mark.parametrize('proxy', ['http://user:secret@127.0.0.1:7897',
    'http://external.invalid:7897', 'http://127.0.0.1:7897?token=secret'])
def test_isolated_proxy_cli_rejects_credentials_or_external_host(proxy):
    script = Path(__file__).resolve().parents[1] / 'execution_output/polygon_fast_path/observe_forward.py'
    result = subprocess.run([sys.executable, str(script), '--public-http-proxy', proxy],
                            capture_output=True, text=True)
    assert result.returncode == 2
    assert 'credential-free local HTTP proxy' in result.stderr
    assert 'secret' not in result.stderr


def test_oversized_frame_classification_never_exposes_reason():
    async def run():
        class Socket:
            async def __aiter__(self):
                raise ConnectionClosedError(None, Close(1009, 'provider-secret'))
                yield
        p = object.__new__(PolygonProducer)
        p.socket = Socket()
        pending = asyncio.get_running_loop().create_future()
        p.pending_rpc = {1: pending}
        with pytest.raises(ConnectionClosedError):
            await p.reader()
        with pytest.raises(ValueError, match='^WSS_MESSAGE_TOO_BIG$'):
            await pending
    asyncio.run(run())


def test_isolated_chain_timeout_option_is_bounded():
    script = Path(__file__).resolve().parents[1] / 'execution_output/polygon_fast_path/observe_forward.py'
    result = subprocess.run([sys.executable, str(script), '--rpc-timeout', '0'],
                            capture_output=True, text=True)
    assert result.returncode == 2
    help_result = subprocess.run([sys.executable, str(script), '--help'], capture_output=True, text=True)
    assert help_result.returncode == 0
    assert '--rpc-timeout {8,15,20}' in help_result.stdout


def test_cancelled_scan_drains_freshness_failure(monkeypatch):
    async def run():
        errors = []
        asyncio.get_running_loop().set_exception_handler(lambda loop, context: errors.append(context))
        entered = asyncio.Event()
        freshness_finished = asyncio.Event()
        class Client:
            async def data_freshness(self):
                freshness_finished.set()
                raise RuntimeError('fixture request failure')
        monkeypatch.setattr(monitor_module, 'pm', Client())
        monkeypatch.setattr(monitor_module, 'db', SimpleNamespace(tracked_wallets=lambda: [{'address':'fixture'}]))
        monkeypatch.setattr(monitor_module, 'settings', SimpleNamespace(
            monitor_max_concurrency=1, signal_settlement_refresh_seconds=30, research_enabled=True))
        monitor = monitor_module.WalletMonitor()
        monkeypatch.setattr(monitor, '_v2_state', lambda: V2ActivationState.ACTIVE)
        async def slow(*args):
            entered.set()
            await asyncio.Event().wait()
        monkeypatch.setattr(monitor, '_scan_wallet', slow)
        task = asyncio.create_task(monitor.scan_once(require_v2=True))
        await entered.wait()
        await freshness_finished.wait()
        task.cancel()
        with pytest.raises(asyncio.CancelledError):await task
        await asyncio.sleep(0)
        assert not errors
        assert not [t for t in asyncio.all_tasks() if t is not asyncio.current_task() and not t.done()]
    asyncio.run(run())
