import asyncio

import httpx
import pytest

from app.polymarket import PolymarketClient, PolymarketError


def test_transport_failure_has_diagnostic_type_without_explicit_metadata():
    async def run():
        client=PolymarketClient()
        await client.client.aclose()
        def fail(request):raise httpx.ReadError('',request=request)
        client.client=httpx.AsyncClient(transport=httpx.MockTransport(fail))
        try:
            with pytest.raises(PolymarketError,match='ReadError') as caught:
                await client._get('https://fixture.invalid/markets',attempts=1)
            assert caught.value.response_metadata['last_error_type']=='ReadError'
            assert isinstance(caught.value.__cause__,httpx.ReadError)
        finally:await client.close()
    asyncio.run(run())


def test_failed_pool_rotates_without_cancelling_inflight_read():
    async def run():
        client=PolymarketClient()
        await client.client.aclose()
        held=asyncio.Event();release=asyncio.Event()
        async def handler(request):
            if request.url.path=='/held':
                held.set();await release.wait()
                return httpx.Response(200,json={'held':True})
            raise httpx.ReadError('',request=request)
        old=httpx.AsyncClient(transport=httpx.MockTransport(handler))
        fresh=httpx.AsyncClient(transport=httpx.MockTransport(lambda _:httpx.Response(200,json={'ok':True})))
        client.client=old;client._new_public_client=lambda:fresh
        task=asyncio.create_task(client._get('https://fixture.invalid/held',attempts=1))
        await held.wait()
        try:
            for _ in range(3):
                with pytest.raises(PolymarketError):
                    await client._get('https://fixture.invalid/fail',attempts=1)
            assert client.pool_reset_count==1 and client.client is fresh
            assert not old.is_closed
            assert await client._get('https://fixture.invalid/good',attempts=1)=={'ok':True}
            release.set();assert await task=={'held':True}
            assert old.is_closed and not client._retired_clients
        finally:
            release.set();await asyncio.gather(task,return_exceptions=True);await client.close()
    asyncio.run(run())


def test_http_permission_failures_do_not_rotate_pool():
    async def run():
        client=PolymarketClient();await client.client.aclose()
        client.client=httpx.AsyncClient(transport=httpx.MockTransport(lambda _:httpx.Response(403)))
        try:
            for _ in range(4):
                with pytest.raises(PolymarketError):
                    await client._get('https://fixture.invalid/markets',attempts=1)
            assert client.pool_reset_count==0
        finally:await client.close()
    asyncio.run(run())


def test_gamma_open_and_closed_requests_fit_outer_timeout_budget():
    async def run():
        client=PolymarketClient();seen=[]
        async def get(url,params,**kwargs):
            seen.append(kwargs)
            return [] if params['closed']=='false' else [{
                'conditionId':'c','clobTokenIds':['yes'],'outcomes':['YES'],
                'outcomePrices':['1'],'closed':True,'umaResolutionStatus':'resolved'}]
        client._get=get
        try:
            assert (await client.market_state('yes'))['resolved']
            assert len(seen)==2 and all(x['attempts']==1 and x['timeout_seconds']==6 for x in seen)
        finally:await client.close()
    asyncio.run(run())
