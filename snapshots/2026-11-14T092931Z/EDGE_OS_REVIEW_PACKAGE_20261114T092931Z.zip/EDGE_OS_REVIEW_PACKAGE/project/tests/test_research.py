import asyncio
import hashlib
import json
import time
from dataclasses import replace
import pytest
import httpx
from app.db import Database
from app import research as r, service
from app.ai_research import AIResearch
from app.polymarket import PolymarketClient, normalize_market_state
from app.paper import simulate_buy

W='0x'+'1'*40
@pytest.fixture
def database(tmp_path):
    d=Database(str(tmp_path/'test.db'));d.init();d.upsert_wallet(W);return d

def trade(key='t1',**kw):
    t=dict(trade_key=key,wallet=W,condition_id='condition',token_id='yes',event_id='event',side='BUY',
      price=.49,size=100,usd_value=49,timestamp=time.time()-5,title='Election president test',outcome='YES',category='Politics',
      tx_hash='0x'+hashlib.sha256(key.encode()).hexdigest())
    t.update(kw);return t

class Market:
    def __init__(self):
        self.state=dict(closed=False,resolved=False,accepting_orders=True,description='Official rule',end_timestamp=time.time()+86400,event_id='event',fees_enabled=False,minimum_order_size=5)
        self.book=dict(bids=[dict(price=.49,size=1000)],asks=[dict(price=.5,size=1000)])
        self.rate=.04
    async def market_state(self,_):return self.state
    async def orderbook(self,_):return self.book
    async def research_fee(self,*_):return {'rate':self.rate,'source':'TEST'}
    async def positions(self,*_):return []

def capture(d,m,t=None):
    t=t or trade();d.insert_trade_if_new(W,t)
    return asyncio.run(r.capture(d,m,{'address':W},t))

def proposal():
    return dict(recommendation='REFINE',summary='仅试跑政治类低延迟买单',risks=['样本少'],hypothesis='政治类可跟',falsification='未来净收益差于基线',supporting_entry_ids=[1],rule=dict(categories=['Politics']))

def test_baseline_uses_executable_price_fees_and_deduplicates(database):
    m=Market();x=capture(database,m)
    assert x['status']=='OPEN' and x['cost']==25 and x['shares']==50
    assert x['fee']==pytest.approx(.5)
    assert x['evidence']['simulation']['avg_price']==.5
    assert capture(database,m)['id']==x['id']
    assert len(r.rows(database,'SELECT * FROM research_entries'))==1

@pytest.mark.parametrize('change,reason',[
    ({'side':'SELL'},'EXIT_ARCHIVED_HOLD_EXPERIMENT'),
    ({'timestamp':time.time()-2000},'STALE_OR_INVALID_TIMESTAMP'),
    ({'timestamp':time.time()+100},'STALE_OR_INVALID_TIMESTAMP'),
    ({'price':0},'INVALID_LEADER_PRICE'),
    ({'condition_id':''},'MISSING_MARKET_ID')])
def test_non_entry_signals_archived(database,change,reason):
    x=capture(database,Market(),trade(**change));assert x['status']=='SKIP' and x['reason']==reason
    assert x['evidence']['trade']['trade_key']=='t1'

@pytest.mark.parametrize('case,reason',[('rules','MISSING_RESOLUTION_RULES'),('near','NEAR_END'),('spread','SPREAD'),('depth','INSUFFICIENT_DEPTH'),('price','PRICE_MOVED'),('minimum','BELOW_MINIMUM_ORDER')])
def test_cold_start_guards(database,case,reason):
    m=Market()
    if case=='rules':m.state['description']=''
    if case=='near':m.state['end_timestamp']=time.time()+30
    if case=='spread':m.book['bids'][0]['price']=.4
    if case=='depth':m.book['asks'][0]['size']=1
    if case=='price':m.book['bids'][0]['price']=.79;m.book['asks'][0]['price']=.8
    if case=='minimum':m.state['minimum_order_size']=30
    assert capture(database,m)['reason']==reason


def test_exclusion_survives_discovery_and_blocks_tracking(database,monkeypatch):
    from app import discovery
    database.upsert_candidate(dict(address=W,score=1))
    r.exclude(database,W)
    assert not database.get_wallet(W)['tracked']
    with pytest.raises(ValueError):database.set_wallet_tracked(W,True)
    class PM:
        async def leaderboard(self,**_):return [{'proxyWallet':W,'rank':1,'pnl':200}]
    monkeypatch.setattr(discovery,'db',database);monkeypatch.setattr(discovery,'pm',PM())
    asyncio.run(discovery.WalletDiscovery().run_once())
    assert database.candidates()[0]['status']=='EXCLUDED'
    r.exclude(database,W,restore=True)
    assert not r.excluded(database,W) and database.candidates()[0]['status']=='NEW'


def test_delete_during_network_capture_cannot_create_open_position(database):
    class Slow(Market):
        async def orderbook(self,_):
            r.exclude(database,W);return self.book
    x=capture(database,Slow());assert x['reason']=='MANUALLY_EXCLUDED'


def test_one_wallet_condition_only_one_experiment(database):
    capture(database,Market());x=capture(database,Market(),trade('another',token_id='no'))
    assert x['reason']=='EXPERIMENT_ALREADY_EXISTS'
    assert len(r.rows(database,'SELECT * FROM research_entries'))==2


def test_formal_settlement_and_separate_reference_pnl(database):
    m=Market();x=capture(database,m)
    m.state.update(resolved=True,closed=True,settlement_price=1.)
    asyncio.run(r.refresh(database,m));x=r.entry(database,x['id'])
    assert x['status']=='SETTLED' and x['pnl']==pytest.approx(24.5)
    assert x['leader_reference_pnl']==pytest.approx(25/.49-25)
    assert x['leader_reported_market_pnl'] is None


def test_closed_price_is_not_resolution():
    market=dict(closed=True,clobTokenIds=['yes','no'],outcomes=['Yes','No'],outcomePrices=[1,0])
    state=normalize_market_state(market,'yes');assert not state['resolved'] and state['settlement_price'] is None


def test_market_lookup_includes_closed_markets(monkeypatch):
    pm=PolymarketClient();seen=[]
    async def get(url,params,**kw):
        seen.append(params['closed'])
        return [] if params['closed']=='false' else [dict(closed=True,umaResolutionStatus='resolved',clobTokenIds=['yes'],outcomes=['Yes'],outcomePrices=[1])]
    monkeypatch.setattr(pm,'_get',get)
    async def run():
        try:return await pm.market_state('yes')
        finally:await pm.close()
    assert asyncio.run(run())['resolved'];assert seen==['false','true']


def test_unknown_fee_curve_is_not_guessed(monkeypatch):
    pm=PolymarketClient()
    async def get(*_,**kw):return {'fd':{'r':.05,'e':2}}
    monkeypatch.setattr(pm,'_get',get)
    async def run():
        try:
            with pytest.raises(Exception,match='unsupported fee exponent'):await pm.research_fee('c',{})
        finally:await pm.close()
    asyncio.run(run())


def test_fee_is_sum_of_price_levels():
    sim=simulate_buy({'asks':[{'price':.2,'size':50},{'price':.8,'size':50}]},50,.04)
    assert sim['fee']==pytest.approx(.64) # 50*.04*.2*.8 twice; differs from fee at VWAP .5


def test_consensus_groups_related_and_offsets_sells(database):
    second='0x'+'2'*40;third='0x'+'3'*40
    for w in [W,second,third]:
        database.upsert_wallet(w)
        with database.conn() as c:
            c.execute('INSERT INTO wallet_category_stats(address,category,market_count,pnl,roi) VALUES(?,?,?,?,?)',(w,'Politics',20,50,.1))
    for key,w in [('a',W),('b',second),('c',third)]:database.insert_trade_if_new(w,trade(key,wallet=w))
    v=r.consensus(database,trade(),time.time());assert v['expert_groups']==3
    with database.conn() as c:
        c.executemany('INSERT INTO research_identity VALUES(?,?)',[(W,'same-person'),(second,'same-person')])
    assert r.consensus(database,trade(),time.time())['expert_groups']==2
    database.insert_trade_if_new(third,trade('sell',side='SELL',wallet=third,size=200,usd_value=100))
    v=r.consensus(database,trade(),time.time());assert v['expert_groups']==1 and v['opposing_groups']==1
    assert v['independence']=='UNVERIFIED'


def test_proposal_requires_grounded_evidence_and_future_only(database):
    x=capture(database,Market());context=r.evidence(database,W);context['totals']['independent_events']=8
    bad=proposal();bad['supporting_entry_ids']=[999]
    with pytest.raises(ValueError,match='absent'):r.propose(database,W,bad,context)
    version=r.propose(database,W,proposal(),context)
    assert version
    assert r.entry(database,x['id'])['version_id'] is None
    y=capture(database,Market(),trade('future',condition_id='new'))
    assert y['version_id']==version and y['selected']
    assert r.propose(database,W,proposal(),context) is None


def test_schema_rejects_unsafe_rule():
    with pytest.raises(ValueError):r.Rule(categories=['Politics'],max_adverse=.5)
    with pytest.raises(ValueError):r.Rule(categories=['Politics'],min_price=.9,max_price=.1)
    with pytest.raises(ValueError):r.Rule(categories=['Politics'],max_adverse=float('nan'))
    with pytest.raises(ValueError):r.Rule(categories=['Politics'],execute_code='anything')


def test_rule_uses_topic_and_experienced_consensus():
    rule=dict(categories=['Politics'],title_keywords=['election'],min_consensus=2)
    assert not r.matches(rule,trade(),.5,10,.01,{'support_groups':3,'expert_groups':1})
    assert r.matches(rule,trade(),.5,10,.01,{'support_groups':3,'expert_groups':2})
    assert not r.matches(rule,trade(title='Other topic'),.5,10,.01,{'expert_groups':2})


def test_version_requires_future_independent_events_and_can_fail_later(database):
    with database.conn() as c:
        version=c.execute("INSERT INTO research_versions(wallet,created_ts,cutoff_id,state,rule_json,review_json) VALUES(?,?,0,'SHADOW','{}','{}')",(W,time.time())).lastrowid
        for i in range(20):
            c.execute("""INSERT INTO research_entries(trade_key,wallet,condition_id,token_id,event_id,status,entry_json,version_id,selected,cost,fee,pnl,settled_ts)
            VALUES(?,?,?,?,?,'SETTLED','{}',?,1,25,0,5,?)""",(str(i),W,str(i),'yes','shared-event',version,time.time()+i))
    r.evaluate(database)
    assert r.rows(database,'SELECT state FROM research_versions')[0]['state']=='SHADOW'
    with database.conn() as c:c.execute('UPDATE research_entries SET event_id=condition_id')
    r.evaluate(database);assert r.rows(database,'SELECT state FROM research_versions')[0]['state']=='VALIDATED'
    with database.conn() as c:c.execute('UPDATE research_entries SET pnl=-25 WHERE id<=10')
    r.evaluate(database);assert r.rows(database,'SELECT state FROM research_versions')[0]['state']=='REJECTED'


def test_pending_recovery_keeps_original_strategy_snapshot(database):
    m=Market();x=capture(database,m)
    with database.conn() as c:c.execute("UPDATE research_entries SET status='PENDING',detected_ts=? WHERE id=?",(time.time()-150,x['id']))
    context=r.evidence(database,W);context['totals']['independent_events']=8
    assert r.propose(database,W,proposal(),context)
    asyncio.run(r.refresh(database,m))
    assert r.entry(database,x['id'])['version_id'] is None


def test_new_pipeline_does_not_require_legacy_skill(database,monkeypatch):
    monkeypatch.setattr(service,'db',database);monkeypatch.setattr(service,'pm',Market())
    x=asyncio.run(service.process_new_trade({'address':W,'analytics':{'trader_skill':0}},trade()))
    assert x['status']=='OPEN'


def test_new_wallet_seed_failure_never_enables_tracking(database,monkeypatch):
    async def gather(_):return {},{},[],[],[],[],['trades: offline']
    monkeypatch.setattr(service,'db',database);monkeypatch.setattr(service,'_gather_wallet',gather)
    with pytest.raises(Exception,match='历史成交读取失败'):asyncio.run(service.analyze_and_store(W))
    assert not database.get_wallet(W)['tracked']


def test_ai_compatible_request_and_key_isolation(database,monkeypatch):
    engine=AIResearch(database,Market());engine.save_config(dict(provider='qwen_cn',model='qwen-plus',api_key='secret-test',enabled=True,daily_call_limit=1,max_tokens=500))
    assert 'api_key' not in engine.public_config() and engine.public_config()['has_key']
    request={}
    class Client:
        def __init__(self,**kw):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*_):pass
        async def post(self,url,**kw):
            request.update(url=url,**kw)
            return httpx.Response(200,json={'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'summary':'连接成功','risks':[],'next_actions':[]})}}],'usage':{'total_tokens':100}},request=httpx.Request('POST',url))
    monkeypatch.setattr('app.ai_research.httpx.AsyncClient',Client)
    assert asyncio.run(engine.call('TEST','test',{}))['summary']=='连接成功'
    assert request['json']['enable_thinking'] is False and request['json']['response_format']=={'type':'json_object'}
    assert request['headers']['Authorization']=='Bearer secret-test'
    assert 'secret-test' not in json.dumps(r.rows(database,'SELECT * FROM research_ai_runs'))
    with pytest.raises(ValueError,match='上限'):asyncio.run(engine.call('TEST','test',{}))


def test_ai_bad_citation_cannot_change_strategy(database,monkeypatch):
    engine=AIResearch(database,Market());engine.save_config(dict(provider='deepseek',model='deepseek-chat',api_key='secret-test',enabled=True))
    class Client:
        def __init__(self,**kw):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*_):pass
        async def post(self,url,**kw):
            return httpx.Response(200,json={'choices':[{'message':{'content':json.dumps(proposal())}}]},request=httpx.Request('POST',url))
    monkeypatch.setattr('app.ai_research.httpx.AsyncClient',Client)
    with pytest.raises(ValueError):asyncio.run(engine.call('WALLET',W,r.evidence(database,W)))
    assert not r.rows(database,'SELECT * FROM research_versions')
    assert r.rows(database,'SELECT status FROM research_ai_runs')[0]['status']=='ERROR'


def test_upgrade_preserves_existing_wallets_and_history(database):
    database.set_wallet_origin(W,'POLYMARKET_LEADERBOARD',auto_managed=True)
    capture(database,Market());database.init()
    assert database.get_wallet(W) and len(r.rows(database,'SELECT * FROM research_entries'))==1


def test_leader_reported_pnl_stays_market_level(database):
    class PM(Market):
        async def positions(self,*_):return [dict(condition_id='condition',token_id='yes',realized_pnl=123)]
    x=capture(database,PM());asyncio.run(r.refresh_leader(database,PM(),W));x=r.entry(database,x['id'])
    assert x['leader_reported_market_pnl']['reported_pnl']==123 and x['leader_reference_pnl'] is None
