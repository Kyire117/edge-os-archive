"""Integration-boundary tests. Every database in this file is temporary."""
import asyncio
import hashlib
import hashlib
import json
import sqlite3
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.db import Database
from app import main, research, service, monitor as monitor_module
from app.strict_paper import MarketIdentity
from app.wallet_follow_runtime import (V2_CONFIG, WalletFollowRuntime, activate_v2,
    has_active_v2, status_v2, V2ActivationState, v2_activation_state)
from app.wallet_follow_v2 import WalletFollowV2, STRATEGY_VERSION

T0=datetime(2026,9,30,tzinfo=timezone.utc)
WALLET="0x"+"1"*40


@pytest.fixture
def database(tmp_path):
    value=Database(str(tmp_path/"temporary.db"))
    value.init()
    value.upsert_wallet(WALLET)
    return value


def _add_running_experiment(db):
    with db.conn() as con:
        con.execute("""INSERT INTO research_experiments(id,rule_version,status,started_at,ends_at,
            started_utc,ends_utc,completed_utc,rules_json) VALUES('FC14-OLD','forward-copy-v0.1',
            'RUNNING',?,? ,?,?,NULL,'{"rule_version":"forward-copy-v0.1","frozen":true}')""",
            (T0.timestamp()-3600,T0.timestamp()+86400,(T0-timedelta(hours=1)).isoformat(),(T0+timedelta(days=1)).isoformat()))
        con.execute("INSERT INTO research_experiment_wallets VALUES(?,?,?,?,?,?)",
            ("FC14-OLD",WALLET,(T0-timedelta(hours=1)).isoformat(),T0.timestamp()-100,"FAST","{}"))
        con.execute("""INSERT INTO research_experiment_entries(experiment_id,trade_key,wallet,condition_id,
            token_id,title,outcome,leader_ts,detected_ts,status,cost,shares,fee,entry_json)
            VALUES('FC14-OLD','old-entry',?,'condition-old','token-old','old title','YES',?,?, 'OPEN',
            25,50,0,'{}')""",(WALLET,T0.timestamp()-500,T0.timestamp()-400))


def _trade(key="signal-1", *, token="token-yes", condition="condition-1", outcome="YES", side="BUY", price=.4):
    return {"trade_key":key,"condition_id":condition,"token_id":token,"outcome":outcome,
        "side":side,"timestamp":(T0-timedelta(seconds=60)).timestamp(),"price":price,
        "size":10,"title":"Verified market title","category":"Politics",
        "tx_hash":"0x"+hashlib.sha256(key.encode()).hexdigest(),"raw":{"tradeId":key}}


def test_activation_freezes_config_backs_up_and_entry_closes_v0x_atomically(database):
    _add_running_experiment(database)
    result=activate_v2(database,now=T0)
    backup_path=Path(database.path).with_name(result["backup_file"])
    assert result["activated"] and backup_path.exists()
    with sqlite3.connect(backup_path) as backup_db:
        assert backup_db.execute("SELECT status FROM research_experiments WHERE id='FC14-OLD'").fetchone()[0]=="RUNNING"
        assert backup_db.execute("SELECT COUNT(*) FROM sqlite_master WHERE name='wallet_v2_versions'").fetchone()[0]==0
    assert result["frozen_config"]["fixed_notional"]=="25"
    assert result["frozen_config"]["min_net_roi_if_win"]=="0.05"
    assert result["frozen_config"]["max_visible_depth_fraction"]=="0.10"
    assert result["frozen_config"]["min_resolved_for_review"]==20
    assert result["frozen_config"]["execution_latency_ms"]==500
    assert result["frozen_config"]["max_book_age_ms"]==3000
    assert result["frozen_config"]["observed_recovery_grace_seconds"]==120
    assert result["frozen_config"]["exit"]=="HOLD_TO_FORMAL_RESOLUTION"
    assert result["frozen_config"]["live_orders"] is False
    with database.conn() as con:
        old=con.execute("SELECT * FROM research_experiments WHERE id='FC14-OLD'").fetchone()
        entry_count=con.execute("SELECT COUNT(*) FROM research_experiment_entries WHERE experiment_id='FC14-OLD'").fetchone()[0]
        event=con.execute("SELECT event_type FROM research_experiment_events WHERE experiment_id='FC14-OLD'").fetchone()[0]
        version=con.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version=?",(STRATEGY_VERSION,)).fetchone()
    assert old["status"]=="ENTRY_CLOSED"
    assert old["started_utc"]==(T0-timedelta(hours=1)).isoformat()
    assert old["ends_utc"]==(T0+timedelta(days=1)).isoformat()
    assert entry_count==1 and event=="SUPERSEDED_BY_WALLET_FOLLOW_V2"
    legacy_view=research.experiment_summary(database,"FC14-OLD",now=T0.timestamp()+1)
    assert legacy_view["active"] is False
    assert legacy_view["experiment"]["counts"]["signals"]==1
    assert version["state"]=="FORWARD_TEST"
    assert version["created_at"]==version["evidence_cutoff"]==version["activated_at"]==T0.isoformat()
    after=activate_v2(database,now=T0+timedelta(minutes=1))
    assert after["already_active"] and after["activated_at"]==T0.isoformat()


def test_backup_failure_aborts_before_schema_or_legacy_mutation(database):
    _add_running_experiment(database)
    before=hashlib.sha256(open(database.path,"rb").read()).hexdigest()
    def broken(_):
        raise RuntimeError("BACKUP_FAILED")
    with pytest.raises(RuntimeError,match="BACKUP_FAILED"):
        activate_v2(database,now=T0,backup_fn=broken)
    with database.conn() as con:
        status=con.execute("SELECT status FROM research_experiments WHERE id='FC14-OLD'").fetchone()[0]
        v2=con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wallet_v2_versions'").fetchone()
    assert status=="RUNNING" and v2 is None
    assert hashlib.sha256(open(database.path,"rb").read()).hexdigest()==before


def test_activation_additively_creates_missing_legacy_event_table(database):
    _add_running_experiment(database)
    with database.conn() as con:
        con.execute("DROP TABLE research_experiment_events")
    result=activate_v2(database,now=T0)
    assert result["activated"]
    with database.conn() as con:
        row=con.execute("SELECT event_type FROM research_experiment_events WHERE experiment_id='FC14-OLD'").fetchone()
        entries=con.execute("SELECT COUNT(*) FROM research_experiment_entries WHERE experiment_id='FC14-OLD'").fetchone()[0]
    assert row[0]=="SUPERSEDED_BY_WALLET_FOLLOW_V2"
    assert entries==1


def test_restart_and_read_only_status_do_not_initialize_or_reactivate(database):
    before=hashlib.sha256(open(database.path,"rb").read()).hexdigest()
    assert status_v2(database.path)["state"]=="NOT_CONFIGURED"
    assert not has_active_v2(database.path)
    assert hashlib.sha256(open(database.path,"rb").read()).hexdigest()==before
    activate_v2(database,now=T0)
    first=status_v2(database.path)
    WalletFollowV2(database.path).version()  # reopening simulates process restart
    second=status_v2(database.path)
    assert first["activated_at"]==second["activated_at"]==T0.isoformat()
    assert has_active_v2(database.path)


class FakeClock:
    def __init__(self): self.value=T0; self.sleeps=[]
    def now(self): return self.value
    async def sleep(self, seconds):
        self.sleeps.append(seconds)
        self.value += timedelta(seconds=seconds)


class FakePolymarket:
    def __init__(self,clock,*,bad_market=False,bad_minimum=False,bad_fee=False,bad_book=False,
                 missing_market_timestamp=False,old_market_timestamp=False,low_roi=False,formal=False,depth=1000):
        self.clock=clock;self.bad_market=bad_market;self.bad_fee=bad_fee;self.bad_book=bad_book
        self.bad_minimum=bad_minimum;self.missing_market_timestamp=missing_market_timestamp
        self.old_market_timestamp=old_market_timestamp
        self.low_roi=low_roi;self.formal=formal;self.depth=depth;self.book_calls=0;self.market_calls=0
    async def market_state(self,token_id):
        self.market_calls+=1
        token_id=token_id or "token-yes"
        resolved=self.formal
        return {"condition_id":"condition-1" if not self.bad_market else "wrong-condition",
            "token_id":token_id,"outcome":"YES","closed":resolved,"resolved":resolved,
            "accepting_orders":not resolved,"minimum_order_size":"malformed" if self.bad_minimum else 1,
            "minimum_order_source":"Gamma.market.orderMinSize","market_source_timestamp":None if self.missing_market_timestamp else int((self.clock.now()-timedelta(hours=6) if self.old_market_timestamp else self.clock.now()).timestamp()*1000),
            "current_price":.4,"fees_enabled":False,"resolution_status":"resolved" if resolved else None,
            "resolution_source":"Polymarket resolution source" if resolved else None,
            "resolution_is_void":False,"winning_token_id":"token-yes" if resolved else None,
            "settlement_price":1 if resolved else None}
    async def research_fee(self,condition_id,market):
        if self.bad_fee:return {"rate":"NaN","source":"CLOB_FD","exponent":1}
        return {"rate":0,"source":"GAMMA_FEES_DISABLED","exponent":1}
    async def orderbook(self,token_id):
        self.book_calls+=1
        stamp=int(self.clock.now().timestamp()*1000)
        if self.bad_book:
            raw={"bids":[{"price":"bad","size":"1000"}],"asks":[]}
            return {"timestamp":stamp,"bids":[],"asks":[],"raw":raw}
        ask="0.99" if self.low_roi else "0.40"
        raw={"bids":[{"price":"0.39","size":str(self.depth)}],"asks":[{"price":ask,"size":str(self.depth)}]}
        return {"timestamp":stamp,"bids":[{"price":.39,"size":self.depth}],
            "asks":[{"price":float(ask),"size":self.depth}],"raw":raw}


def _activated_v2(path, *, config=V2_CONFIG):
    WalletFollowV2.initialize(path)
    sim=WalletFollowV2(path)
    sim.create_version(config,created_at=T0,evidence_cutoff=T0)
    sim.activate(at=T0)
    return sim


def test_api_failure_retries_preserve_fill_then_settle_once(tmp_path):
    from app.polymarket import PolymarketError
    path=tmp_path/'settlement-retry.db';sim=_activated_v2(path)
    clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    result=asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    ledger=sim.ledger(WALLET);before=ledger.account_snapshot()
    async def offline(_):
        error=PolymarketError('ReadError');error.response_metadata={'last_error_type':'ReadError'}
        raise error
    client.market_state=offline
    clock.value=T0+timedelta(seconds=3)
    assert asyncio.run(runtime.refresh_settlements())['errors']==1
    original=sim.episode(result['episode_id'])['resolution_evidence_json']
    clock.value+=timedelta(seconds=1)
    assert asyncio.run(runtime.refresh_settlements())['errors']==1
    assert sim.episode(result['episode_id'])['resolution_status']=='API_FAILURE'
    assert sim.episode(result['episode_id'])['resolution_evidence_json']==original
    assert ledger.account_snapshot()['fills']==before['fills']
    assert ledger.account_snapshot()['positions']==before['positions']
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM strict_settlements WHERE status='API_FAILURE'").fetchone()[0]==1
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_audit WHERE action='SETTLEMENT_CHECK'").fetchone()[0]==2
    client.market_state=FakePolymarket(clock,formal=True).market_state
    clock.value+=timedelta(seconds=1)
    assert asyncio.run(runtime.refresh_settlements())['settled']==1
    assert sim.episode(result['episode_id'])['resolution_status']=='FORMALLY_RESOLVED'
    assert asyncio.run(runtime.refresh_settlements())['checked']==0
    assert ledger.reconcile()['ok']
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM strict_settlements WHERE status='FORMALLY_RESOLVED'").fetchone()[0]==1


def test_settlement_limit_rotates_across_process_refreshes(tmp_path):
    from app.strict_paper import MarketIdentity
    path=tmp_path/'fair-refresh.db';sim=_activated_v2(path);clock=FakeClock()
    for i in range(6):
        ep=sim.observe_buy(wallet=WALLET,signal_id=f'signal-{i}',
            identity=MarketIdentity(f'c-{i}',f't-{i}','YES'),leader_at=T0,detected_at=T0,
            leader_price='.4')
        with sim._connect() as con:
            con.execute("UPDATE wallet_v2_episodes SET paper_status='REJECTED' WHERE episode_id=?",(ep['episode_id'],))
    class Pending:
        calls=[]
        async def market_state(self,token):
            self.calls.append(token)
            return {'condition_id':token.replace('t-','c-'),'token_id':token,'outcome':'YES',
                    'closed':False,'resolved':False}
    client=Pending()
    for _ in range(3):
        clock.value+=timedelta(seconds=1)
        runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
        assert asyncio.run(runtime.refresh_settlements(limit=2))['checked']==2
    assert len(client.calls)==len(set(client.calls))==6
    with sim._connect() as con:
        assert con.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0]==0


def test_api_failure_persistence_error_is_reported(tmp_path,monkeypatch):
    path=tmp_path/'failure-record.db';_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    async def offline(_):raise TimeoutError()
    client.market_state=offline
    def broken(*args,**kwargs):raise sqlite3.OperationalError('fixture')
    monkeypatch.setattr(runtime.engine,'record_resolution',broken)
    result=asyncio.run(runtime.refresh_settlements())
    assert result['errors']==1 and result['persistence_errors']==1
    with runtime.engine._connect() as con:
        evidence=json.loads(con.execute("SELECT evidence_json FROM wallet_v2_audit WHERE action='SETTLEMENT_CHECK'").fetchone()[0])
    assert evidence['result']=='FAILED' and evidence['error_type']=='TimeoutError'


def _simulate_episode_update_crash(sim, episode_id):
    """Keep committed strict-ledger rows while reverting only the final episode write."""
    with sim._connect() as con:
        con.execute("""UPDATE wallet_v2_episodes SET paper_status='OBSERVED',rejection_reason=NULL,
            execution_eligible=NULL,quote_price=NULL,execution_price=NULL,price_delta=NULL,
            requested_notional=NULL,filled_notional=NULL,filled_quantity=NULL,entry_fee=NULL,
            paper_order_id=NULL WHERE episode_id=?""",(episode_id,))


def test_live_adapter_uses_distinct_books_frozen_latency_depth_and_budget(tmp_path):
    path=tmp_path/"runtime.db";sim=_activated_v2(path)
    clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    result=asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    assert result["status"]=="FILLED"
    assert client.book_calls==2 and len(clock.sleeps)==1 and clock.sleeps[0]==pytest.approx(.5)
    ledger=sim.ledger(WALLET);order=ledger.account_snapshot()["orders"][0]
    decision=json.loads(sqlite3.connect(path).execute("SELECT evidence_json FROM strict_decisions").fetchone()[0])
    assert decision["quote"]["snapshot_id"]!=decision["execution"]["snapshot_id"]
    assert decision["quote"]["request_id"]!=decision["execution"]["request_id"]
    assert decision["execution_latency_ms"]==500
    assert decision["rule_config"]["max_visible_depth_fraction"]=="0.10"
    assert decision["rule_config"]["min_net_roi_if_win"]=="0.05"
    assert decision["rule_config"]["adverse_price_gate"]=="OBSERVE_ONLY"
    assert decision["rule_config"]["near_certainty_gate"]=="DISABLED"
    assert "max_spread" not in decision["rule_config"]
    assert "horizon" not in decision["rule_config"]
    assert decision["market_state"]["minimum_order_size"]=="1"
    assert decision["market_state"]["minimum_order_source"]=="Gamma.market.orderMinSize"
    assert Decimal(order["requested_notional"])==Decimal("25")
    assert Decimal(decision["total_cost"])<=Decimal("25")
    assert ledger.reconcile()["ok"]


def test_ten_percent_depth_cap_produces_terminal_partial_not_extra_liquidity(tmp_path):
    path=tmp_path/"depth.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock,depth=300)
    result=asyncio.run(WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep).process_trade(WALLET,_trade(),detected_at=T0))
    assert result["status"]=="PARTIAL"
    snapshot=sim.ledger(WALLET).account_snapshot()
    assert snapshot["orders"][0]["status"]=="PARTIALLY_FILLED"
    evidence=json.loads(sqlite3.connect(path).execute("SELECT evidence_json FROM strict_decisions").fetchone()[0])
    assert Decimal(evidence["strict_allowed_executable_amount"])==Decimal("12.000000")
    assert Decimal(evidence["filled_notional"])==Decimal("12.000000")
    assert Decimal(evidence["unfilled_notional"])==Decimal("13.000000")
    assert Decimal(evidence["filled_notional"])+Decimal(evidence["unfilled_notional"])==Decimal("25")
    assert sim.ledger(WALLET).reconcile()["ok"]


@pytest.mark.parametrize("kwargs,reason",[
    ({"bad_market":True},"MARKET_IDENTITY_MISMATCH"),
    ({"bad_minimum":True},"MINIMUM_ORDER_EVIDENCE_UNAVAILABLE"),
    ({"bad_fee":True},"INVALID_FEE_EVIDENCE"),
    ({"bad_book":True},"MALFORMED_ORDER_BOOK"),
])
def test_unverifiable_external_evidence_is_persisted_as_no_fill(tmp_path,kwargs,reason):
    path=tmp_path/(reason+".db");sim=_activated_v2(path);clock=FakeClock()
    result=asyncio.run(WalletFollowRuntime(path,FakePolymarket(clock,**kwargs),clock=clock.now,
        sleep=clock.sleep).process_trade(WALLET,_trade(),detected_at=T0))
    assert result["status"]=="REJECTED" and result["reason"]==reason
    episode=sim.episode(result.get("episode_id") or sim._connect().execute("SELECT episode_id FROM wallet_v2_episodes").fetchone()[0])
    assert episode["paper_status"]=="REJECTED" and episode["rejection_reason"]==reason
    assert sim.ledger(WALLET).account_snapshot()["fills"]==[]
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_runtime_events WHERE episode_id IS NOT NULL").fetchone()[0]==1


def test_no_fill_episode_still_formally_resolves_direction(tmp_path):
    path=tmp_path/"no-fill.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock,low_roi=True)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    result=asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    assert result["status"]=="REJECTED" and result["reason"]=="NET_ROI_BELOW_FLOOR"
    client.formal=True
    async def resolved_state(token_id):
        return await FakePolymarket(clock,formal=True).market_state(token_id)
    client.market_state=resolved_state
    totals=asyncio.run(runtime.refresh_settlements())
    episode=sim.episode(result["episode_id"])
    assert totals["settled"]==1
    assert episode["resolution_status"]=="FORMALLY_RESOLVED" and episode["direction_correct"]==1
    assert sim.ledger(WALLET).account_snapshot()["fills"]==[]


@pytest.mark.parametrize("market_kwargs",[{"old_market_timestamp":True},{"missing_market_timestamp":True}])
def test_gamma_updated_at_is_audit_metadata_not_execution_freshness_gate(tmp_path,market_kwargs):
    path=tmp_path/"gamma-source-time.db";sim=_activated_v2(path);clock=FakeClock()
    client=FakePolymarket(clock,**market_kwargs)
    result=asyncio.run(WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep).process_trade(
        WALLET,_trade(),detected_at=T0))
    assert result["status"]=="FILLED"
    with sqlite3.connect(path) as con:
        evidence=json.loads(con.execute("SELECT evidence_json FROM strict_decisions").fetchone()[0])
        adapter=json.loads(con.execute("SELECT evidence_json FROM wallet_v2_audit WHERE action='EXECUTION_ATTEMPT'").fetchone()[0])
    market=evidence["market_state"]
    assert market["request_timestamp"] and market["received_timestamp"]
    assert market["request_timestamp"]<=market["received_timestamp"]
    if market_kwargs.get("old_market_timestamp"):
        source_time=datetime.fromisoformat(market["source_timestamp"])
        assert T0-source_time>timedelta(hours=5)
        assert adapter["adapter_evidence"]["market_state"]["market_source_timestamp"]<T0.timestamp()*1000
    else:
        assert market["source_timestamp"] is None


def test_filled_position_settles_only_after_formal_resolution_and_restart_is_idempotent(tmp_path):
    path=tmp_path/"formal.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    result=asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    assert result["status"]=="FILLED"
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM strict_settlements").fetchone()[0]==0
    client.market_state=lambda token: asyncio.sleep(0,result={"condition_id":"condition-1","token_id":token,
        "outcome":"YES","closed":True,"resolved":False,"resolution_status":"pending",
        "market_source_timestamp":int(clock.now().timestamp()*1000)})
    asyncio.run(runtime.refresh_settlements())
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM strict_settlements WHERE status='FORMALLY_RESOLVED'").fetchone()[0]==0
    client.market_state=lambda token: asyncio.sleep(0,result={"condition_id":"condition-1","token_id":token,
        "outcome":"YES","closed":True,"resolved":True,"resolution_status":"resolved",
        "resolution_source":"Gamma authoritative resolution","resolution_is_void":False,
        "winning_token_id":"token-yes","market_source_timestamp":int(clock.now().timestamp()*1000)})
    asyncio.run(runtime.refresh_settlements())
    before=len(sim.ledger(WALLET).account_snapshot()["fills"])
    # New process object sees the final row and must not send the same settlement twice.
    asyncio.run(WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep).refresh_settlements())
    assert len(sim.ledger(WALLET).account_snapshot()["fills"])==before==1
    assert sim.ledger(WALLET).reconcile()["ok"]
    assert sim.record_resolution(result["episode_id"],status="FORMALLY_RESOLVED",
        observed_at=T0+timedelta(days=2),authoritative_source="Gamma authoritative resolution",
        winning_token_id="token-yes",payout_per_share="1") is False
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM strict_settlements WHERE status='FORMALLY_RESOLVED'").fetchone()[0]==1


def test_add_on_reversal_and_duplicate_never_make_another_first_paper_trade(tmp_path):
    path=tmp_path/"episodes.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    first=asyncio.run(runtime.process_trade(WALLET,_trade("first"),detected_at=T0))
    addon=asyncio.run(runtime.process_trade(WALLET,_trade("addon"),detected_at=clock.now()))
    reversal=asyncio.run(runtime.process_trade(WALLET,_trade("reverse",token="token-no",outcome="NO"),detected_at=clock.now()))
    duplicate=asyncio.run(runtime.process_trade(WALLET,_trade("first"),detected_at=clock.now()))
    assert first["status"]=="FILLED"
    assert addon["decision"]=="ADD_ON" and reversal["decision"]=="REVERSAL"
    assert duplicate["duplicate"] is True
    assert client.book_calls==2
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_episodes").fetchone()[0]==1
        assert con.execute("SELECT COUNT(*) FROM strict_fills").fetchone()[0]==1


def test_legacy_closed_experiment_still_settles_open_entries_without_recovery_admissions(database):
    _add_running_experiment(database);activate_v2(database,now=T0)
    database.insert_trade_if_new(WALLET,_trade("post-activation"))
    class Unresolved:
        calls=0
        async def market_state(self,token):
            self.calls+=1
            return {"resolved":False,"closed":False,"current_price":.5}
    client=Unresolved()
    before=research.rows(database,"SELECT COUNT(*) n FROM research_experiment_entries WHERE experiment_id='FC14-OLD'")[0]["n"]
    asyncio.run(research.refresh_experiment(database,client,now=(T0+timedelta(minutes=5)).timestamp()))
    after=research.rows(database,"SELECT COUNT(*) n FROM research_experiment_entries WHERE experiment_id='FC14-OLD'")[0]["n"]
    assert client.calls==1 and before==after==1
    assert research.experiment_summary(database,"FC14-OLD")["experiment"]["status"]=="ENTRY_CLOSED"


def test_live_service_routes_buy_exclusively_to_v2_and_ignores_sell_and_seed(database,monkeypatch):
    _add_running_experiment(database)
    activate_v2(database,now=T0)
    monkeypatch.setattr(service,"db",database)
    calls=[]
    class Runtime:
        def __init__(self,*args): pass
        async def process_trade(self,wallet,trade,*,detected_at):
            calls.append((wallet,trade["trade_key"],detected_at))
            return {"decision":"FILLED","episode_id":"episode"}
    class Client: pass
    monkeypatch.setattr(service,"pm",Client())
    monkeypatch.setattr("app.wallet_follow_runtime.WalletFollowRuntime",Runtime)
    async def legacy(*args,**kwargs): raise AssertionError("legacy research must not admit V2 signal")
    monkeypatch.setattr(research,"capture_experiment",legacy)
    monkeypatch.setattr(research,"capture",legacy)
    buy=_trade("live-buy")
    routed=asyncio.run(service.process_new_trade({"address":WALLET},buy))
    assert routed["wallet_follow_v2"] and calls[0][1]=="live-buy"
    assert asyncio.run(service.process_new_trade({"address":WALLET},buy)) is None
    sell=asyncio.run(service.process_new_trade({"address":WALLET},_trade("live-sell",side="SELL")))
    assert sell["decision"]=="V2_NON_BUY_IGNORED" and len(calls)==1
    seed=_trade("seeded")
    with database.conn() as con:
        con.execute("""INSERT INTO trades(trade_key,wallet,token_id,condition_id,side,price,size,timestamp,
            title,outcome,category,is_seed,discovered_at,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (seed["trade_key"],WALLET,seed["token_id"],seed["condition_id"],seed["side"],seed["price"],seed["size"],seed["timestamp"],
             seed["title"],seed["outcome"],seed["category"],1,T0.isoformat(),json.dumps(seed["raw"])))
    assert asyncio.run(service.process_new_trade({"address":WALLET},seed)) is None
    assert len(calls)==1
    with database.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_episodes").fetchone()[0]==0
        assert con.execute("SELECT COUNT(*) FROM research_experiment_entries WHERE experiment_id='FC14-OLD'").fetchone()[0]==1


def test_v2_state_read_error_preserves_raw_trade_without_legacy_admission(database,monkeypatch):
    _add_running_experiment(database);activate_v2(database,now=T0)
    monkeypatch.setattr(service,"db",database)
    class Client: pass
    monkeypatch.setattr(service,"pm",Client())
    import app.wallet_follow_runtime as runtime_module
    monkeypatch.setattr(runtime_module,"v2_activation_state",lambda _path:V2ActivationState.READ_ERROR)
    legacy_calls=[]
    async def legacy(*args,**kwargs):
        legacy_calls.append("capture")
        return {"decision":"LEGACY"}
    monkeypatch.setattr(research,"capture_experiment",legacy)
    monkeypatch.setattr(research,"capture",legacy)
    trade=_trade("state-read-error")
    result=asyncio.run(service.process_new_trade({"address":WALLET},trade))
    assert result["decision"]=="V2_ROUTING_STATE_ERROR"
    assert legacy_calls==[]
    with database.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM trades WHERE trade_key='state-read-error'").fetchone()[0]==1
        event=con.execute("SELECT reason FROM wallet_v2_runtime_events WHERE signal_id='state-read-error'").fetchone()
        assert event[0]=="V2_ACTIVATION_STATE_READ_ERROR"
        assert con.execute("SELECT COUNT(*) FROM research_experiment_entries WHERE experiment_id='FC14-OLD'").fetchone()[0]==1


def test_restart_retires_stale_observed_episode_without_replaying_books(tmp_path):
    path=tmp_path/"crash-recovery.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    identity=MarketIdentity("condition-1","token-yes","YES")
    observed=sim.observe_buy(signal_id="died-before-decision",wallet=WALLET,identity=identity,
        leader_at=T0-timedelta(seconds=60),detected_at=T0,leader_price="0.4",source_mode="LIVE_OBSERVATION",
        evidence={"source":"LIVE_WALLET_MONITOR"})
    clock.value=T0+timedelta(seconds=121)
    restarted=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    result=asyncio.run(restarted.refresh_settlements())
    episode=sim.episode(observed["episode_id"])
    assert episode["paper_status"]=="REJECTED"
    assert episode["rejection_reason"]=="CRASH_RECOVERY_NO_FILL"
    assert client.book_calls==0 and client.market_calls==0
    assert sim.ledger(WALLET).account_snapshot()["fills"]==[]
    with sim._connect() as con:
        event=con.execute("SELECT reason,evidence_json FROM wallet_v2_runtime_events WHERE signal_id='died-before-decision'").fetchone()
        assert event[0]=="CRASH_RECOVERY_NO_FILL"
        assert json.loads(event[1])["book_fetch_performed"] is False
        assert con.execute("SELECT COUNT(*) FROM strict_decisions").fetchone()[0]==0
        audit_count=con.execute("SELECT COUNT(*) FROM wallet_v2_audit WHERE action='CRASH_RECOVERY_NO_FILL'").fetchone()[0]
    assert audit_count==1
    assert sim.recover_stale_observed(now=clock.now())==0
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_audit WHERE action='CRASH_RECOVERY_NO_FILL'").fetchone()[0]==audit_count


def test_crash_after_submit_order_cancels_order_and_releases_cash_atomically(tmp_path,monkeypatch):
    from app.strict_ledger import StrictPaperLedger
    path=tmp_path/"crash-after-order.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    original=StrictPaperLedger.apply_execution
    def process_death(self,*args,**kwargs):
        raise SystemExit("simulated process death after order commit")
    monkeypatch.setattr(StrictPaperLedger,"apply_execution",process_death)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    with pytest.raises(SystemExit):
        asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    monkeypatch.setattr(StrictPaperLedger,"apply_execution",original)
    calls_before=(client.market_calls,client.book_calls)
    snapshot=sim.ledger(WALLET).account_snapshot()
    assert len(snapshot["orders"])==1 and snapshot["orders"][0]["status"]=="OPEN"
    assert Decimal(snapshot["account"]["reserved_cash"])>0
    clock.value=T0+timedelta(seconds=121)

    assert sim.recover_stale_observed(now=clock.now())==1
    recovered=sim.episode(sim._connect().execute("SELECT episode_id FROM wallet_v2_episodes").fetchone()[0])
    final=sim.ledger(WALLET).account_snapshot()
    assert recovered["paper_status"]=="REJECTED"
    assert recovered["rejection_reason"]=="EXECUTION_COMMIT_INCOMPLETE"
    assert final["orders"][0]["status"]=="CANCELLED"
    assert Decimal(final["orders"][0]["reserve_cash_remaining"])==0
    assert Decimal(final["account"]["reserved_cash"])==0
    assert Decimal(final["account"]["available_cash"])==Decimal(final["account"]["initial_cash"])
    assert final["fills"]==[] and sim.ledger(WALLET).reconcile()["ok"]
    assert (client.market_calls,client.book_calls)==calls_before
    assert sim.recover_stale_observed(now=clock.now())==0


def test_crash_after_rejected_decision_restores_original_reason_without_new_decision(tmp_path):
    path=tmp_path/"crash-after-rejection.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock,low_roi=True)
    result=asyncio.run(WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep).process_trade(
        WALLET,_trade(),detected_at=T0))
    assert result["status"]=="REJECTED" and result["reason"]=="NET_ROI_BELOW_FLOOR"
    _simulate_episode_update_crash(sim,result["episode_id"])
    before_calls=(client.market_calls,client.book_calls)
    clock.value=T0+timedelta(seconds=121)

    assert sim.recover_stale_observed(now=clock.now())==1
    episode=sim.episode(result["episode_id"])
    with sim._connect() as con:
        decisions=con.execute("SELECT status,reason FROM strict_decisions").fetchall()
        runtime_events=con.execute("SELECT COUNT(*) FROM wallet_v2_runtime_events").fetchone()[0]
        action=con.execute("SELECT action FROM wallet_v2_audit ORDER BY audit_id DESC LIMIT 1").fetchone()[0]
    assert episode["paper_status"]=="REJECTED"
    assert episode["rejection_reason"]=="NET_ROI_BELOW_FLOOR"
    assert episode["execution_eligible"]==0
    assert len(decisions)==1 and tuple(decisions[0])==("REJECTED","NET_ROI_BELOW_FLOOR")
    assert runtime_events==0 and action=="CRASH_RECOVERY_REJECTED_DECISION_SYNC"
    assert sim.ledger(WALLET).account_snapshot()["fills"]==[]
    assert (client.market_calls,client.book_calls)==before_calls


def test_crash_after_committed_fill_restores_episode_and_later_settles_once(tmp_path):
    path=tmp_path/"crash-after-fill.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    result=asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    assert result["status"]=="FILLED"
    _simulate_episode_update_crash(sim,result["episode_id"])
    before_calls=(client.market_calls,client.book_calls)
    clock.value=T0+timedelta(seconds=121)

    assert sim.recover_stale_observed(now=clock.now())==1
    episode=sim.episode(result["episode_id"])
    snapshot=sim.ledger(WALLET).account_snapshot()
    assert episode["paper_status"]=="FILLED"
    assert episode["paper_order_id"]==snapshot["orders"][0]["order_id"]
    assert Decimal(episode["requested_notional"])==Decimal("25")
    assert Decimal(episode["filled_notional"])==Decimal(snapshot["fills"][0]["gross_amount"])
    assert Decimal(episode["filled_quantity"])==Decimal(snapshot["fills"][0]["quantity"])
    assert Decimal(episode["entry_fee"])==Decimal(snapshot["fills"][0]["fee"])
    assert episode["execution_price"]==snapshot["fills"][0]["vwap"]
    assert len(snapshot["fills"])==1 and sim.ledger(WALLET).reconcile()["ok"]
    assert (client.market_calls,client.book_calls)==before_calls

    assert sim.record_resolution(result["episode_id"],status="FORMALLY_RESOLVED",
        observed_at=clock.now(),authoritative_source="test formal result",
        winning_token_id="token-yes",payout_per_share="1")
    assert not sim.record_resolution(result["episode_id"],status="FORMALLY_RESOLVED",
        observed_at=clock.now()+timedelta(seconds=1),authoritative_source="test formal result",
        winning_token_id="token-yes",payout_per_share="1")
    settled=sim.ledger(WALLET).account_snapshot()
    position=settled["positions"][0]
    expected_pnl=(Decimal(snapshot["fills"][0]["quantity"])-Decimal(snapshot["fills"][0]["gross_amount"])
                  -Decimal(snapshot["fills"][0]["fee"]))
    assert Decimal(position["quantity"])==0
    assert Decimal(position["realized_pnl"])==expected_pnl
    assert sim.ledger(WALLET).reconcile()["ok"]
    with sim._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM strict_settlements WHERE status='FORMALLY_RESOLVED'").fetchone()[0]==1


def test_crash_after_fill_commit_recovers_partial_status_from_fill_evidence(tmp_path):
    path=tmp_path/"crash-after-partial.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock,depth=300)
    result=asyncio.run(WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep).process_trade(
        WALLET,_trade(),detected_at=T0))
    assert result["status"]=="PARTIAL"
    _simulate_episode_update_crash(sim,result["episode_id"])
    clock.value=T0+timedelta(seconds=121)

    assert sim.recover_stale_observed(now=clock.now())==1
    episode=sim.episode(result["episode_id"])
    snapshot=sim.ledger(WALLET).account_snapshot()
    assert episode["paper_status"]=="PARTIAL"
    assert episode["paper_order_id"]==snapshot["orders"][0]["order_id"]
    assert Decimal(episode["filled_quantity"])==Decimal(snapshot["fills"][0]["quantity"])
    assert len(snapshot["fills"])==1 and sim.ledger(WALLET).reconcile()["ok"]


def test_incomplete_accepted_decision_cancels_reservation_without_synthesizing_fill(tmp_path,monkeypatch):
    from app.strict_ledger import StrictPaperLedger
    path=tmp_path/"crash-after-decision.db";sim=_activated_v2(path);clock=FakeClock();client=FakePolymarket(clock)
    original=StrictPaperLedger._apply_fill
    def process_death(self,*args,**kwargs):
        raise SystemExit("simulated process death after immutable decision commit")
    monkeypatch.setattr(StrictPaperLedger,"_apply_fill",process_death)
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    with pytest.raises(SystemExit):
        asyncio.run(runtime.process_trade(WALLET,_trade(),detected_at=T0))
    monkeypatch.setattr(StrictPaperLedger,"_apply_fill",original)
    calls_before=(client.market_calls,client.book_calls)
    before=sim.ledger(WALLET).account_snapshot()
    assert before["decisions"][0]["status"]=="FILLED" and before["fills"]==[]
    assert before["orders"][0]["status"]=="OPEN"
    clock.value=T0+timedelta(seconds=121)

    assert sim.recover_stale_observed(now=clock.now())==1
    episode=sim.episode(sim._connect().execute("SELECT episode_id FROM wallet_v2_episodes").fetchone()[0])
    after=sim.ledger(WALLET).account_snapshot()
    assert episode["paper_status"]=="REJECTED"
    assert episode["rejection_reason"]=="EXECUTION_COMMIT_INCOMPLETE"
    assert after["orders"][0]["status"]=="CANCELLED"
    assert Decimal(after["account"]["reserved_cash"])==0
    assert after["fills"]==[] and sim.ledger(WALLET).reconcile()["ok"]
    assert (client.market_calls,client.book_calls)==calls_before


def test_read_only_status_and_explicit_activation_api(database,monkeypatch):
    monkeypatch.setattr(main,"db",database)
    client=TestClient(main.app)
    before=hashlib.sha256(open(database.path,"rb").read()).hexdigest()
    status=client.get("/api/wallet-follow-v2")
    assert status.status_code==200 and status.json()["state"]=="NOT_CONFIGURED"
    assert hashlib.sha256(open(database.path,"rb").read()).hexdigest()==before
    activated=client.post("/api/wallet-follow-v2/activate",headers={"X-Edge-Client":"dashboard"})
    assert activated.status_code==200 and activated.json()["activated"]
    status=client.get("/api/wallet-follow-v2")
    assert status.status_code==200
    body=status.json()
    assert body["state"]=="FORWARD_TEST" and body["frozen_config"]["max_visible_depth_fraction"]=="0.10"
    assert body["counts"]=={"observed_episodes":0,"resolved_episodes":0,"filled":0,
        "partial":0,"rejected_no_fill":0,"pending_resolution":0}


def test_v2_activation_disables_every_legacy_refresh_and_new_v0x_start(database,monkeypatch):
    _add_running_experiment(database)
    activate_v2(database,now=T0)
    assert v2_activation_state(database.path) is V2ActivationState.ACTIVE
    with pytest.raises(ValueError,match="WALLET_FOLLOW_V2_OWNS_RUNTIME"):
        research.start_experiment(database,now=T0.timestamp()+10)

    calls=[]
    async def legacy_refresh(*_args,**_kwargs):
        calls.append("legacy_experiment")
        raise AssertionError("legacy experiment refresh must stop after V2 activation")
    async def legacy_paper(*_args,**_kwargs):
        calls.append("legacy_paper")
        raise AssertionError("legacy paper position refresh must stop after V2 activation")
    async def legacy_signals(*_args,**_kwargs):
        calls.append("legacy_signals")
        raise AssertionError("legacy signal settlement must stop after V2 activation")
    monkeypatch.setattr(monitor_module.research_module,"refresh_experiment",legacy_refresh)
    monkeypatch.setattr(monitor_module,"refresh_open_paper_positions",legacy_paper)
    monkeypatch.setattr(monitor_module,"refresh_signal_settlements",legacy_signals)
    class MonitorDb:
        path=database.path
        def tracked_wallets(self): return []
        def auto_pause_slow_wallets(self): return []
    monkeypatch.setattr(monitor_module,"db",MonitorDb())
    monkeypatch.setattr(monitor_module,"settings",type("S",(),{
        "research_enabled":False,"paper_refresh_seconds":0,
        "signal_settlement_refresh_seconds":0,"monitor_max_concurrency":1,
        "realtime_request_timeout_seconds":8})())
    monitor=monitor_module.WalletMonitor()
    monitor._last_freshness_check=float("inf")
    result=asyncio.run(monitor.scan_once())
    assert result["legacy_refresh_enabled"] is False
    assert result["wallet_follow_v2_state"]=="ACTIVE"
    assert calls==[]

    refreshed=asyncio.run(monitor._refresh_once())
    assert refreshed["legacy_refresh_enabled"] is False
    assert refreshed["v2_state"]=="ACTIVE"
    assert calls==[]


def test_completed_v2_keeps_legacy_runtime_locked_after_restart(database,monkeypatch):
    sim=WalletFollowV2(database.path)
    activate_v2(database,now=T0)
    clock=FakeClock();client=FakePolymarket(clock)
    runtime=WalletFollowRuntime(database.path,client,clock=clock.now,sleep=clock.sleep)
    placed=asyncio.run(runtime.process_trade(WALLET,_trade("before-retirement"),detected_at=T0))
    assert placed["status"]=="FILLED"
    sim.close("RETIRED",at=T0+timedelta(seconds=1))
    assert v2_activation_state(database.path) is V2ActivationState.LOCKED
    with pytest.raises(ValueError,match="WALLET_FOLLOW_V2_OWNS_RUNTIME"):
        research.start_experiment(database,now=T0.timestamp()+20)
    monitor=monitor_module.WalletMonitor()
    monkeypatch.setattr(monitor_module,"db",database)
    calls=[]
    async def legacy_refresh(*_args,**_kwargs): calls.append(True)
    monkeypatch.setattr(monitor_module.research_module,"refresh_experiment",legacy_refresh)
    class NoNetworkV2Runtime:
        def __init__(self,*_args,**_kwargs): pass
        async def refresh_settlements(self): return {"checked":0,"settled":0,"errors":0}
    monkeypatch.setattr(monitor_module,"WalletFollowRuntime",NoNetworkV2Runtime)
    result=asyncio.run(monitor._refresh_once())
    assert result["v2_state"]=="LOCKED" and result["legacy_refresh_enabled"] is False
    assert result["v2_settlement"]=={"checked":0,"settled":0,"errors":0}
    assert calls==[]
    clock.value=T0+timedelta(seconds=2);client.formal=True
    totals=asyncio.run(runtime.refresh_settlements())
    assert totals=={"checked":1,"settled":1,"errors":0}
    settled=sim.ledger(WALLET).account_snapshot()
    assert Decimal(settled["positions"][0]["quantity"])==0
    assert len([x for x in settled["decisions"] if x["status"]=="FILLED"])==1
    assert sim.ledger(WALLET).reconcile()["ok"]
    with sqlite3.connect(database.path) as con:
        assert con.execute("SELECT COUNT(*) FROM strict_settlements WHERE status='FORMALLY_RESOLVED'").fetchone()[0]==1
    monkeypatch.setattr(service,"db",database)
    monkeypatch.setattr(service,"pm",object())
    async def legacy_capture(*_args,**_kwargs):
        calls.append("legacy_capture")
        raise AssertionError("legacy trade admission must remain disabled")
    monkeypatch.setattr(research,"capture_experiment",legacy_capture)
    monkeypatch.setattr(research,"capture",legacy_capture)
    routed=asyncio.run(service.process_new_trade({"address":WALLET},_trade("post-retirement")))
    assert routed["decision"]=="V2_RUNTIME_LOCKED"
    assert calls==[]


def test_one_bad_live_signal_does_not_block_next_wallet_trade(database,monkeypatch):
    from app.monitor import WalletMonitor
    activate_v2(database,now=T0)
    start=datetime.now(timezone.utc)
    class DynamicClock:
        def now(self): return datetime.now(timezone.utc)
        async def sleep(self,seconds): await asyncio.sleep(seconds)
    clock=DynamicClock()
    class Client(FakePolymarket):
        async def trades(self,*args,**kwargs):
            return [
                _trade("broken",token="bad-token",condition="condition-bad"),
                _trade("good",token="token-yes",condition="condition-good"),
            ]
        async def market_state(self,token_id):
            self.market_calls+=1
            condition="wrong-condition" if token_id=="bad-token" else "condition-good"
            now=datetime.now(timezone.utc)
            return {"condition_id":condition,"token_id":token_id,"outcome":"YES","closed":False,
                "resolved":False,"accepting_orders":True,"minimum_order_size":1,
                "minimum_order_source":"Gamma.market.orderMinSize","market_source_timestamp":int(now.timestamp()*1000),
                "current_price":.4,"fees_enabled":False,"resolution_status":None,
                "resolution_source":None,"resolution_is_void":False,"winning_token_id":None}
    client=Client(clock)
    monkeypatch.setattr(service,"db",database);monkeypatch.setattr(service,"pm",client)
    import app.monitor as monitor_module
    monkeypatch.setattr(monitor_module,"db",database);monkeypatch.setattr(monitor_module,"pm",client)
    result=asyncio.run(WalletMonitor()._scan_wallet({"address":WALLET,"last_trade_ts":int(start.timestamp())},asyncio.Semaphore(1)))
    assert result["new_trades"]==2 and result["errors"]==[]
    with database.conn() as con:
        episodes=[dict(x) for x in con.execute("SELECT paper_status,rejection_reason,condition_id FROM wallet_v2_episodes ORDER BY condition_id")]
    assert len(episodes)==2
    assert [x["paper_status"] for x in episodes]==["REJECTED","FILLED"]
    assert episodes[0]["rejection_reason"]=="MARKET_IDENTITY_MISMATCH"
