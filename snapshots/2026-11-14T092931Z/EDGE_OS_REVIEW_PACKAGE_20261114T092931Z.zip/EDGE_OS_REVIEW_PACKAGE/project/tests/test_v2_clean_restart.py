"""Clean forward restart checks use temporary databases only."""
import asyncio
import hashlib
import json
import sqlite3
import time
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from app import main, polymarket, research
from app.ai_research import AIResearch
from app.db import Database
from app.strict_paper import MarketIdentity
from app.v2_clean_restart import clean_restart_v2
from app.wallet_follow_runtime import V2_CONFIG, WalletFollowRuntime, status_v2, v2_episode_detail, v2_episode_list
from app.wallet_follow_v2 import WalletFollowV2


T0 = datetime(2026, 10, 1, tzinfo=timezone.utc)
WALLET = "0x" + "1" * 40


def _copy(source, target):
    with sqlite3.connect(source) as src, sqlite3.connect(target) as dst:
        src.backup(dst)
        assert dst.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


@pytest.fixture
def prepared(tmp_path):
    db = Database(str(tmp_path / "temporary.db"))
    db.init()
    db.upsert_wallet(WALLET)
    WalletFollowV2.initialize(db.path)
    sim = WalletFollowV2(db.path)
    sim.create_version(V2_CONFIG, created_at=T0, evidence_cutoff=T0)
    sim.activate(at=T0)
    with db.conn() as con:
        con.execute("INSERT INTO trades(trade_key,wallet,side,timestamp,is_seed,discovered_at) "
                    "VALUES(?,?,?, ?,0,?)", ("historical-raw", WALLET, "BUY", int(T0.timestamp()), T0.isoformat()))
        con.execute("INSERT INTO wallet_candidates(address,source,discovered_at,updated_at) VALUES(?,?,?,?)",
                    (WALLET, "TEST", T0.isoformat(), T0.isoformat()))
        con.execute("INSERT INTO research_experiments(id,rule_version,status,started_at,ends_at,started_utc,ends_utc,rules_json) "
                    "VALUES('FC14-OLD','forward-copy-v0.1','ENTRY_CLOSED',?,?,?,?,?)",
                    (T0.timestamp(), T0.timestamp()+86400, T0.isoformat(), (T0+timedelta(days=1)).isoformat(), '{}'))
        con.execute("INSERT INTO research_experiment_entries(experiment_id,trade_key,wallet,detected_ts,status,entry_json) "
                    "VALUES('FC14-OLD','old-skip',?,?,'SKIP','{}')", (WALLET, T0.timestamp()))
        con.execute("INSERT INTO research_entries(trade_key,wallet,status,entry_json) VALUES('old-research',?,'SKIP','{}')", (WALLET,))
        con.execute("INSERT INTO signals(trade_key,wallet,decision,created_at) VALUES('old-signal',?,'SKIP',?)",
                    (WALLET, T0.isoformat()))
        signal_id = con.execute("SELECT id FROM signals WHERE trade_key='old-signal'").fetchone()[0]
        con.execute("INSERT INTO paper_trades(signal_id,wallet,status,opened_at) VALUES(?,?,'OPEN',?)",
                    (signal_id, WALLET, T0.isoformat()))
    sim.observe_buy(signal_id="old-v2", wallet=WALLET,
                    identity=MarketIdentity("condition-old", "token-old", "YES"),
                    leader_at=T0, detected_at=T0 + timedelta(seconds=1),
                    leader_price="0.4", evidence={"trade": {"title": "Old episode"}})
    backup = tmp_path / "verified-full.backup"
    _copy(db.path, backup)
    return db, backup


def test_clean_restart_preserves_sources_and_frozen_version(prepared):
    db, backup = prepared
    before_version = WalletFollowV2(db.path).version()
    with db.conn() as con:
        protected = {name: con.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
                     for name in ("wallets", "trades", "wallet_candidates", "research_leader_outcomes")}
    result = clean_restart_v2(db.path, backup, now=T0+timedelta(hours=1))
    assert result["removed_counts"]["wallet_v2_episodes"] == 1
    assert result["removed_counts"]["research_experiment_entries"] == 1
    assert result["removed_counts"]["paper_trades"] == 1
    assert WalletFollowV2(db.path).version() == before_version
    with db.conn() as con:
        for name, count in protected.items():
            assert con.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0] == count
        for name in (*result["removed_counts"], "strict_fills", "strict_settlements"):
            assert con.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0] == 0
        assert con.execute("SELECT COUNT(*) FROM trades WHERE trade_key='historical-raw'").fetchone()[0] == 1
        assert con.execute("PRAGMA foreign_key_check").fetchone() is None
        row = con.execute("SELECT evidence_json FROM wallet_v2_audit WHERE action='CLEAN_FORWARD_RESTART'").fetchone()
        assert json.loads(row[0])["forward_started_at"] == (T0+timedelta(hours=1)).isoformat()
    view = status_v2(db.path)
    assert view["state"] == "FORWARD_TEST"
    assert view["counts"]["observed_episodes"] == 0
    assert view["observation"]["observed_trades"] == 0
    assert view["frozen_config"]["live_orders"] is False
    assert view["observation"]["tracked_wallets"] == 1
    assert v2_episode_list(db.path)["entries"] == []
    assert v2_episode_detail(db.path, "old-v2") is None
    with sqlite3.connect(backup) as copy:
        assert copy.execute("SELECT COUNT(*) FROM wallet_v2_episodes").fetchone()[0] == 1
        assert copy.execute("SELECT COUNT(*) FROM research_experiment_entries").fetchone()[0] == 1


def test_bad_backup_and_second_restart_fail_without_deleting(prepared, tmp_path):
    db, backup = prepared
    with pytest.raises(RuntimeError, match="CLEAN_RESTART_SOURCE_CHANGED"):
        clean_restart_v2(db.path, backup, expected_source_sha256="0" * 64)
    corrupt = tmp_path / "corrupt.backup"
    corrupt.write_bytes(b"not a database")
    with pytest.raises(sqlite3.DatabaseError):
        clean_restart_v2(db.path, corrupt)
    with db.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_episodes").fetchone()[0] == 1
    clean_restart_v2(db.path, backup, now=T0+timedelta(hours=1))
    second = tmp_path / "second.backup"
    _copy(db.path, second)
    with pytest.raises(RuntimeError, match="CLEAN_RESTART_ALREADY_DONE"):
        clean_restart_v2(db.path, second, now=T0+timedelta(hours=2))


def test_pre_restart_leader_trade_cannot_create_episode_or_call_books(prepared, monkeypatch):
    db, backup = prepared
    cutoff = T0 + timedelta(hours=1)
    clean_restart_v2(db.path, backup, now=cutoff)
    class NoNetwork:
        async def market_state(self, *_): raise AssertionError("market called for historical trade")
        async def orderbook(self, *_): raise AssertionError("book called for historical trade")
    runtime = WalletFollowRuntime(db.path, NoNetwork())
    old = {"trade_key": "delayed-historical", "side": "BUY", "condition_id": "condition-old",
           "token_id": "token-old", "outcome": "YES", "timestamp": (cutoff-timedelta(seconds=1)).timestamp(), "price": 0.4}
    result = asyncio.run(runtime.process_trade(WALLET, old, detected_at=cutoff+timedelta(minutes=1)))
    assert result["decision"] == "V2_PRE_RESTART_TRADE_IGNORED"
    assert status_v2(db.path)["counts"]["observed_episodes"] == 0
    calls = []
    async def capture(*args, **kwargs):
        calls.append(args[0])
        return {"status": "REJECTED", "reason": "TEST_NO_EXECUTION"}
    monkeypatch.setattr(runtime, "_execute_episode", capture)
    new = {**old, "trade_key": "genuine-new", "condition_id": "condition-new",
           "timestamp": (cutoff+timedelta(seconds=1)).timestamp()}
    asyncio.run(runtime.process_trade(WALLET, new, detected_at=cutoff+timedelta(seconds=2)))
    assert len(calls) == 1
    assert status_v2(db.path)["counts"]["observed_episodes"] == 1
    entries = v2_episode_list(db.path)
    assert entries["total"] == 1
    assert entries["entries"][0]["market_url"] is None
    assert v2_episode_detail(db.path, entries["entries"][0]["episode_id"])["events"]


def test_v2_scan_endpoint_uses_v2_only_and_status_is_read_only(prepared, monkeypatch):
    db, backup = prepared
    clean_restart_v2(db.path, backup, now=T0+timedelta(hours=1))
    monkeypatch.setattr(main, "db", db)
    class Monitor:
        async def scan_once(self, *args, **kwargs):
            assert args == () and kwargs == {"require_v2": True}
            return {"ok": True, "wallet_follow_v2_state": "ACTIVE", "legacy_refresh_enabled": False}
    monkeypatch.setattr(main, "monitor", Monitor())
    client = TestClient(main.app)
    first = client.get("/api/wallet-follow-v2")
    assert first.status_code == 200 and first.json()["counts"]["observed_episodes"] == 0
    scan = client.post("/api/wallet-follow-v2/scan", headers={"X-Edge-Client": "dashboard"})
    assert scan.status_code == 200 and scan.json()["legacy_refresh_enabled"] is False
    assert client.get("/api/wallet-follow-v2/episodes").json() == {"total": 0, "entries": []}
    with db.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_episodes").fetchone()[0] == 0


def test_windows_public_data_client_uses_existing_system_https_proxy(monkeypatch):
    captured = {}
    monkeypatch.setattr(polymarket.sys, "platform", "win32")
    monkeypatch.setattr(polymarket.urllib.request, "getproxies",
                        lambda: {"https": "http://127.0.0.1:7897"})
    monkeypatch.setattr(polymarket.httpx, "AsyncClient",
                        lambda **kwargs: captured.update(kwargs) or object())
    polymarket.PolymarketClient()
    assert captured["proxy"] == "http://127.0.0.1:7897"


def test_background_ai_research_does_not_rebuild_retired_entries(prepared, monkeypatch):
    db, backup = prepared
    clean_restart_v2(db.path, backup, now=T0+timedelta(hours=1))
    async def forbidden(*_args):
        raise AssertionError("retired research refresh called")
    monkeypatch.setattr(research, "refresh", forbidden)
    engine = AIResearch(db, object())
    engine.leader_refresh[WALLET] = time.time()
    asyncio.run(engine.refresh_research_once())
    with db.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM research_entries").fetchone()[0] == 0
