# Wallet Follow V2 activation integration — Iteration 1

## Scope

This change adds an opt-in live-monitor route for the already reviewed `wallet-follow-v2.0` strategy. It does not activate the production database. Application startup only reads V2 state; it does not create `wallet_v2_*` or `strict_*` tables.

## Frozen first-forward configuration

The explicit activation function freezes:

| Setting | Value |
| --- | ---: |
| Gross BUY notional, excluding fees | USD 25 |
| Minimum net ROI if the outcome wins | 5% |
| Maximum visible depth consumed | 10% |
| Resolved directional episodes before review eligibility | 20 |
| Execution latency | 500 ms |
| Maximum book and Gamma state age | 3,000 ms |
| Exit | Hold to formal resolution |
| Live orders | Disabled |

The immutable strategy row records `created_at`, `evidence_cutoff`, `activated_at`, the full config and `FORWARD_TEST` state. These are parameters for this V2.0 validation sample, not permanent trading truths.

## Live routing

```text
Polymarket realtime monitor
  -> persist/deduplicate raw trade in legacy trades table
  -> if V2 is not explicitly active: existing V0.x/legacy routing
  -> if V2 is active:
       BUY -> persist one directional episode/event
           -> FIRST only: Gamma identity/tradability/minimum + fee evidence
           -> CLOB quote snapshot
           -> wait until the frozen 500 ms latency has elapsed
           -> distinct CLOB execution snapshot
           -> strict-paper-engine-v3 / isolated V2 ledger
       SELL -> raw observation only; no new BUY episode or paper order
```

The Gamma adapter requires exact condition/token/outcome identity, `acceptingOrders=true`, a finite non-negative `orderMinSize` with its source, a supported fee schedule, and a fresh source `updatedAt`. Missing or malformed evidence creates a durable no-fill rejection. The adapter never uses an end date to settle a position. When Gamma does not expose a verifiable source update timestamp, V2 fails closed; this may reduce fills until the source returns adequate metadata.

Quote and execution books use separate request IDs and snapshot IDs, retain source/request/receive timestamps, and retain the normalized visible levels. Execution consumes only the configured visible-depth fraction. One failed signal is logged and persisted; it cannot trigger a later retry against a newer book. Repeated raw monitor delivery is stopped by the existing raw-trade key, and repeated directional activity becomes `ADD_ON` or `REVERSAL`; neither creates another first-entry order.

## Legacy V0.x behavior

Activation changes only a currently `RUNNING` experiment's status to `ENTRY_CLOSED`; its ID, frozen rules, cohort, timestamps and entries are preserved. The transition appends `SUPERSEDED_BY_WALLET_FOLLOW_V2` to experiment event/audit records. After production V2 activation, the runtime suppresses all V0.x experiment recovery/settlement, legacy paper-position marking/settlement and legacy signal settlement. The prior experiment is shown as superseded in its own read-only history view, and the API refuses to start another V0.x experiment. Historical rows and SKIPs are not rewritten.

## Formal settlement

The monitor refresh loop checks unresolved V2 episodes independently of legacy refresh. A closed market or pending result remains unresolved. Only Gamma's formal `resolved` status together with an authoritative resolution source and an exact winning token can settle a filled strict-paper position or classify a no-fill directional episode. Temporary API failures are recorded as `API_FAILURE`; they do not erase positions. Terminal settlement IDs are deterministic per episode/result so a restart cannot create a second settlement cash flow.

## API

- `GET /api/wallet-follow-v2`: read-only status, frozen config, counts, directional accuracy, realized paper PnL/net ROI, no-fill reasons, available/reserved cash and recent episodes. Before explicit initialization, returns `configured=false`, `state=NOT_CONFIGURED` without creating tables.
- `POST /api/wallet-follow-v2/activate`: explicit one-time activation. It first creates and integrity-checks a SQLite online backup, then initializes only additive reviewed V2/strict tables, closes legacy entry admission and creates the V2 version in one activation transaction. It is idempotent on retry and returns the backup filename. The route is not called by startup and was not invoked against the production database during this iteration.

## Evidence and limitations

Every successful execution has the full strict engine evidence in `strict_decisions`; adapter failures have a durable `wallet_v2_runtime_events` record; activation and execution snapshots are recorded in append-only `wallet_v2_audit`. The status API is read-only; no UI strategy-edit controls were added. Formal void outcomes are recorded as `VOID` and are not counted as directional wins/losses. The external Gamma schema may omit `updatedAt` or resolution fields; those cases remain no-fill/pending rather than being inferred.

Tests use temporary databases and deterministic fixtures only. Production activation was not part of the original integration review; activation is performed only through the explicit endpoint or the equivalent one-time activation function after a verified database backup.
