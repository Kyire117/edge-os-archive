# Strict paper execution, Iteration 2

This is an isolated, opt-in correction to the strict paper engine. It is not
connected to the running Forward Copy experiment, legacy `paper_trades`, or
live orders. The engine version is `strict-paper-engine-v2`; the default
frozen rule version is `strict-paper-rules-v2`. Existing v1 account rows and
historical experiment rows are not rewritten.

## BUY budget

`OrderIntent.amount` for BUY is a gross trade notional **excluding fees**,
rounded down to six decimal places. The quote is retained as evidence and
for movement checks. It never fixes the number of shares. A distinct, newer
execution book is walked in ask-price order. At each level, the engine buys
only the quantity allowed by the remaining gross budget and the frozen
visible-depth fraction. Per-level gross is rounded down to six decimals;
the existing fee formula and per-level upward fee rounding are unchanged.
Fees are charged **in addition** to the requested notional. The caller must
reserve enough virtual cash for actual gross plus fees. The ledger refuses a
debit above the reservation, so available cash cannot become negative.

For a v2 BUY, `target_quantity=0` explicitly means no quote-derived share
target. Evidence and the order row carry `requested_notional`,
`filled_notional`, and `unfilled_notional`; `filled_quantity`, actual VWAP,
fee, both books, timestamps, and frozen rules remain separate. A remainder
larger than one money quantum (`0.000001`) means PARTIAL. Smaller rounding
dust is considered filled but remains visible in `unfilled_notional`.
SELL remains quantity driven.

## One-shot partial execution

Each v2 execution uses one fresh execution snapshot. A partial result is
recorded once and the order becomes terminal `PARTIALLY_FILLED`. The same
transaction applies the fill, releases unused BUY cash or SELL shares, stores
the unfilled amount or quantity, and appends audit evidence. A later book
requires a new decision and order. Duplicate evidence cannot create another
fill. Existing v1 ledger rows retain their original interpretation.

`StrictPaperLedger.initialize(path)` adds nullable `requested_notional` and
`remaining_notional` columns only when missing. It touches only the provided
database path; nothing initializes this ledger against the production
database automatically. New tests use temporary databases and a distinct
test account ID. The local audit chain detects accidental edits but cannot
prove that a local database is unforgeable.
