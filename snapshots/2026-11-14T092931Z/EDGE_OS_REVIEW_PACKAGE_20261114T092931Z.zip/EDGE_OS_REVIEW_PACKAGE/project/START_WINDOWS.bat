@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo EDGE OS runtime is missing. Existing data has not been changed.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" "edge_launcher.py" --open
if errorlevel 1 (
  echo Could not open the local EDGE OS launcher. Existing data has not been reset.
  pause
  exit /b 1
)
exit /b 0
