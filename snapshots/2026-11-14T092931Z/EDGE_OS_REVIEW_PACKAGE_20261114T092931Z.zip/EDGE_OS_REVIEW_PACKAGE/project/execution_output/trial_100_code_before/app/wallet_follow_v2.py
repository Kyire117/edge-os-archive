"""Opt-in, forward-only wallet research and strict paper simulation.

This module is intentionally not imported by the running V0.x service. Call
``initialize`` only with an explicitly selected simulation database path.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_DOWN, ROUND_UP
from pathlib import Path
from typing import Any

from app.strict_ledger import StrictPaperLedger, validate_void_resolution
from app.exit_v1 import EXIT_RULE_VERSION, append_exit_event
from app.strict_paper import (ENGINE_VERSION_V3, ENGINE_VERSION_V4, MONEY_QUANTUM, BookSnapshot,
                              MarketIdentity, MarketState, OrderIntent,
                              WalletFollowEngineRules, LocalObservationEngineRules, execute_order)

STRATEGY_VERSION = "wallet-follow-v2.0"


def _utc(value: datetime) -> datetime:
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("INVALID_UTC_TIMESTAMP")
    return value.astimezone(timezone.utc)


def _decimal(value: Any) -> Decimal:
    result = Decimal(str(value))
    if not result.is_finite():
        raise ValueError("INVALID_DECIMAL")
    return result


@dataclass(frozen=True)
class StrategyConfig:
    fixed_notional: Decimal = Decimal("25")
    min_net_roi_if_win: Decimal = Decimal("0.05")
    initial_cash_per_wallet: Decimal = Decimal("1000")
    min_resolved_for_review: int = 20
    execution_latency_ms: int = 500
    max_book_age_ms: int = 3000
    max_visible_depth_fraction: Decimal = Decimal("1")
    min_quantity: Decimal = Decimal("0.000001")
    observed_recovery_grace_seconds: int = 120

    def __post_init__(self) -> None:
        for name in ("fixed_notional", "min_net_roi_if_win", "initial_cash_per_wallet",
                     "max_visible_depth_fraction", "min_quantity"):
            object.__setattr__(self, name, _decimal(getattr(self, name)))
        if (self.fixed_notional <= 0 or self.min_net_roi_if_win < 0
                or self.initial_cash_per_wallet <= 0 or self.min_resolved_for_review < 1
                or self.execution_latency_ms < 0 or self.max_book_age_ms < 0
                or self.observed_recovery_grace_seconds < 1
                or not (0 < self.max_visible_depth_fraction <= 1) or self.min_quantity <= 0):
            raise ValueError("INVALID_STRATEGY_CONFIG")

    def evidence(self) -> dict[str, Any]:
        return {"fixed_notional": str(self.fixed_notional),
                "min_net_roi_if_win": str(self.min_net_roi_if_win),
                "initial_cash_per_wallet": str(self.initial_cash_per_wallet),
                "min_resolved_for_review": self.min_resolved_for_review,
                "execution_latency_ms": self.execution_latency_ms,
                "max_book_age_ms": self.max_book_age_ms,
                "max_visible_depth_fraction": str(self.max_visible_depth_fraction),
                "min_quantity": str(self.min_quantity),
                "observed_recovery_grace_seconds": self.observed_recovery_grace_seconds,
                "exit": "HOLD_TO_FORMAL_RESOLUTION", "partial_execution": "IOC",
                "live_orders": False, "buy_budget": "GROSS_NOTIONAL_EXCLUDING_FEES"}

    @classmethod
    def from_evidence(cls, data: dict[str, Any]) -> "StrategyConfig":
        values={key:data[key] for key in cls.__dataclass_fields__ if key in data}
        # Earlier opt-in V2 configs did not freeze a recovery grace period.
        # Keep them readable without rewriting their stored rule evidence.
        values.setdefault("observed_recovery_grace_seconds",120)
        return cls(**values)

    def engine_rules(self, version: str, *, local_timestamp_model: bool = False) -> WalletFollowEngineRules:
        rules_type = LocalObservationEngineRules if local_timestamp_model else WalletFollowEngineRules
        return rules_type(rule_version=f"strict-paper-rules-v{'4' if local_timestamp_model else '3'}-{version}",
            execution_latency_ms=self.execution_latency_ms,
            max_book_age_ms=self.max_book_age_ms,
            max_visible_depth_fraction=self.max_visible_depth_fraction,
            min_quantity=self.min_quantity, min_net_roi_if_win=self.min_net_roi_if_win)


class WalletFollowV2:
    def __init__(self, path: str | Path, *, strategy_version: str = STRATEGY_VERSION):
        self.path = Path(path)
        self.strategy_version = strategy_version

    @staticmethod
    def initialize(path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        StrictPaperLedger.initialize(path)
        with sqlite3.connect(path) as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS wallet_v2_versions (
                strategy_version TEXT PRIMARY KEY, parent_version TEXT,
                created_at TEXT NOT NULL, config_json TEXT NOT NULL,
                evidence_cutoff TEXT NOT NULL, state TEXT NOT NULL
                    CHECK(state IN ('CANDIDATE','FORWARD_TEST','COMPLETED','RETIRED')),
                activated_at TEXT, ended_at TEXT);
            CREATE TRIGGER IF NOT EXISTS wallet_v2_version_immutable
            BEFORE UPDATE OF strategy_version,parent_version,created_at,config_json,evidence_cutoff
            ON wallet_v2_versions BEGIN SELECT RAISE(ABORT,'IMMUTABLE_STRATEGY_VERSION'); END;
            CREATE TRIGGER IF NOT EXISTS wallet_v2_activation_immutable
            BEFORE UPDATE OF activated_at ON wallet_v2_versions
            WHEN OLD.activated_at IS NOT NULL AND NEW.activated_at IS NOT OLD.activated_at
            BEGIN SELECT RAISE(ABORT,'IMMUTABLE_STRATEGY_ACTIVATION'); END;
            CREATE TABLE IF NOT EXISTS wallet_v2_episodes (
                episode_id TEXT PRIMARY KEY, strategy_version TEXT NOT NULL,
                wallet TEXT NOT NULL, condition_id TEXT NOT NULL,
                first_token_id TEXT NOT NULL, first_outcome TEXT NOT NULL,
                category TEXT, first_signal_id TEXT NOT NULL UNIQUE,
                first_leader_at TEXT NOT NULL, first_detected_at TEXT NOT NULL,
                leader_price TEXT, quote_price TEXT, execution_price TEXT,
                detection_delay_seconds TEXT, price_delta TEXT,
                expected_end_at TEXT, time_to_expected_end_seconds TEXT,
                paper_status TEXT NOT NULL DEFAULT 'OBSERVED', rejection_reason TEXT,
                execution_eligible INTEGER,
                requested_notional TEXT, filled_notional TEXT, filled_quantity TEXT,
                entry_fee TEXT, paper_order_id TEXT,
                resolution_status TEXT NOT NULL DEFAULT 'PENDING',
                winning_token_id TEXT, direction_correct INTEGER,
                payout_per_share TEXT, authoritative_source TEXT, settled_at TEXT,
                resolution_evidence_json TEXT,
                UNIQUE(strategy_version,wallet,condition_id));
            CREATE TABLE IF NOT EXISTS wallet_v2_events (
                event_id TEXT PRIMARY KEY, episode_id TEXT NOT NULL,
                signal_id TEXT NOT NULL UNIQUE, event_type TEXT NOT NULL
                    CHECK(event_type IN ('FIRST','ADD_ON','REVERSAL')),
                token_id TEXT NOT NULL, outcome TEXT NOT NULL,
                leader_at TEXT NOT NULL, detected_at TEXT NOT NULL,
                leader_price TEXT, evidence_json TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS wallet_v2_episode_wallet
                ON wallet_v2_episodes(strategy_version,wallet);
            CREATE TABLE IF NOT EXISTS wallet_v2_runtime_events (
                signal_id TEXT PRIMARY KEY, wallet TEXT NOT NULL, condition_id TEXT,
                event_type TEXT NOT NULL, reason TEXT NOT NULL, occurred_at TEXT NOT NULL,
                episode_id TEXT, evidence_json TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS wallet_v2_audit (
                audit_id INTEGER PRIMARY KEY, action TEXT NOT NULL, occurred_at TEXT NOT NULL,
                evidence_json TEXT NOT NULL);
            CREATE TRIGGER IF NOT EXISTS wallet_v2_audit_no_update
                BEFORE UPDATE ON wallet_v2_audit BEGIN SELECT RAISE(ABORT,'APPEND_ONLY_AUDIT'); END;
            CREATE TRIGGER IF NOT EXISTS wallet_v2_audit_no_delete
                BEFORE DELETE ON wallet_v2_audit BEGIN SELECT RAISE(ABORT,'APPEND_ONLY_AUDIT'); END;
            """)

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        return con

    def create_version(self, config: StrategyConfig, *, created_at: datetime,
                       evidence_cutoff: datetime, parent_version: str | None = None) -> bool:
        created, cutoff = _utc(created_at), _utc(evidence_cutoff)
        if cutoff > created:
            raise ValueError("CUTOFF_AFTER_VERSION_CREATION")
        data = json.dumps(config.evidence(), sort_keys=True, separators=(",", ":"))
        with self._connect() as con:
            prior = con.execute("SELECT config_json,parent_version,evidence_cutoff FROM wallet_v2_versions WHERE strategy_version=?",
                                (self.strategy_version,)).fetchone()
            if prior:
                if tuple(prior) == (data, parent_version, cutoff.isoformat()):
                    return False
                raise ValueError("IMMUTABLE_STRATEGY_VERSION")
            if parent_version is not None:
                parent = con.execute("SELECT state FROM wallet_v2_versions WHERE strategy_version=?",
                                     (parent_version,)).fetchone()
                if parent is None or parent["state"] != "COMPLETED":
                    raise ValueError("PARENT_STRATEGY_NOT_COMPLETED")
            con.execute("INSERT INTO wallet_v2_versions(strategy_version,parent_version,created_at,config_json,evidence_cutoff,state) VALUES(?,?,?,?,?,'CANDIDATE')",
                        (self.strategy_version, parent_version, created.isoformat(), data, cutoff.isoformat()))
        return True

    def version(self) -> dict[str, Any]:
        with self._connect() as con:
            row = con.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version=?", (self.strategy_version,)).fetchone()
        if row is None:
            raise ValueError("STRATEGY_VERSION_NOT_FOUND")
        return dict(row)

    def activate(self, *, at: datetime) -> None:
        at = _utc(at)
        with self._connect() as con:
            row = con.execute("SELECT state,created_at FROM wallet_v2_versions WHERE strategy_version=?", (self.strategy_version,)).fetchone()
            if row is None or row["state"] != "CANDIDATE" or at.isoformat() < row["created_at"]:
                raise ValueError("INVALID_STRATEGY_ACTIVATION")
            con.execute("UPDATE wallet_v2_versions SET state='FORWARD_TEST',activated_at=? WHERE strategy_version=?",
                        (at.isoformat(), self.strategy_version))

    def close(self, state: str, *, at: datetime) -> None:
        if state not in {"COMPLETED", "RETIRED"}:
            raise ValueError("INVALID_STRATEGY_STATE")
        with self._connect() as con:
            row = con.execute("SELECT state FROM wallet_v2_versions WHERE strategy_version=?", (self.strategy_version,)).fetchone()
            if row is None or row["state"] != "FORWARD_TEST":
                raise ValueError("INVALID_STRATEGY_TRANSITION")
            con.execute("UPDATE wallet_v2_versions SET state=?,ended_at=? WHERE strategy_version=?",
                        (state, _utc(at).isoformat(), self.strategy_version))

    def ledger(self, wallet: str) -> StrictPaperLedger:
        return StrictPaperLedger(self.path, account_id=f"{self.strategy_version}:{wallet.lower()}")

    def observe_buy(self, *, signal_id: str, wallet: str, identity: MarketIdentity,
                    leader_at: datetime, detected_at: datetime, leader_price: Any | None,
                    category: str | None = None, expected_end_at: datetime | None = None,
                    source_mode: str = "LIVE_OBSERVATION", evidence: dict[str, Any] | None = None) -> dict[str, Any]:
        version = self.version()
        leader, detected = _utc(leader_at), _utc(detected_at)
        if source_mode != "LIVE_OBSERVATION" or version["state"] != "FORWARD_TEST" or detected.isoformat() < version["activated_at"] or detected.isoformat() < version["evidence_cutoff"]:
            raise ValueError("NOT_FORWARD_OBSERVATION")
        if not signal_id or not wallet or detected < leader:
            raise ValueError("INVALID_SIGNAL")
        price = None if leader_price is None else _decimal(leader_price)
        if price is not None and not (0 < price < 1):
            raise ValueError("INVALID_LEADER_PRICE")
        expected_end = _utc(expected_end_at) if expected_end_at is not None else None
        episode_id = hashlib.sha256(f"{self.strategy_version}|{wallet.lower()}|{identity.condition_id}".encode()).hexdigest()
        event_json = json.dumps(evidence or {}, sort_keys=True, separators=(",", ":"), default=str)
        with self._connect() as con:
            existing_signal = con.execute("SELECT e.episode_id,e.event_type FROM wallet_v2_events e WHERE signal_id=?", (signal_id,)).fetchone()
            if existing_signal:
                prior_event = con.execute("SELECT token_id,outcome FROM wallet_v2_events WHERE signal_id=?", (signal_id,)).fetchone()
                prior_episode = con.execute("SELECT wallet,condition_id FROM wallet_v2_episodes WHERE episode_id=?", (existing_signal["episode_id"],)).fetchone()
                if tuple(prior_event) != (identity.token_id, identity.outcome) or tuple(prior_episode) != (wallet.lower(), identity.condition_id):
                    raise ValueError("SIGNAL_IDEMPOTENCY_CONFLICT")
                return {"episode_id": existing_signal["episode_id"], "event_type": existing_signal["event_type"], "duplicate": True}
            existing = con.execute("SELECT * FROM wallet_v2_episodes WHERE strategy_version=? AND wallet=? AND condition_id=?",
                                   (self.strategy_version, wallet.lower(), identity.condition_id)).fetchone()
            event_type = "FIRST" if existing is None else "ADD_ON" if (existing["first_token_id"], existing["first_outcome"]) == (identity.token_id, identity.outcome) else "REVERSAL"
            if existing is None:
                con.execute("""INSERT INTO wallet_v2_episodes(episode_id,strategy_version,wallet,condition_id,first_token_id,first_outcome,category,first_signal_id,first_leader_at,first_detected_at,leader_price,detection_delay_seconds,expected_end_at,time_to_expected_end_seconds)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                            (episode_id,self.strategy_version,wallet.lower(),identity.condition_id,identity.token_id,identity.outcome,
                             category,signal_id,leader.isoformat(),detected.isoformat(),str(price) if price is not None else None,
                             str(Decimal(str((detected-leader).total_seconds()))),expected_end.isoformat() if expected_end else None,
                             str(Decimal(str((expected_end-detected).total_seconds()))) if expected_end else None))
            con.execute("INSERT INTO wallet_v2_events VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (hashlib.sha256(signal_id.encode()).hexdigest(),episode_id,signal_id,event_type,identity.token_id,
                         identity.outcome,leader.isoformat(),detected.isoformat(),str(price) if price is not None else None,event_json))
        return {"episode_id": episode_id, "event_type": event_type, "duplicate": False}

    def episode(self, episode_id: str) -> dict[str, Any]:
        with self._connect() as con:
            row = con.execute("SELECT * FROM wallet_v2_episodes WHERE episode_id=? AND strategy_version=?",
                              (episode_id,self.strategy_version)).fetchone()
        if row is None:
            raise ValueError("EPISODE_NOT_FOUND")
        return dict(row)

    def record_runtime_failure(self, *, signal_id: str, wallet: str, condition_id: str | None,
                               reason: str, occurred_at: datetime, episode_id: str | None = None,
                               evidence: dict[str, Any] | None = None) -> bool:
        """Atomically retire no-fill failures and release abandoned reservations.

        A financial commit wins over an adapter exception: leave that episode
        recoverable for local immutable-evidence synchronization, never label
        it a no-fill rejection. No market client is involved in this boundary.
        """
        if not signal_id or not reason:
            raise ValueError("INVALID_RUNTIME_FAILURE")
        when = _utc(occurred_at).isoformat()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            payload_evidence=dict(evidence or {})
            if episode_id:
                episode=con.execute("SELECT * FROM wallet_v2_episodes WHERE episode_id=? AND strategy_version=?",
                                    (episode_id,self.strategy_version)).fetchone()
                if (episode is None or episode["first_signal_id"]!=signal_id
                        or episode["wallet"]!=wallet.lower() or episode["condition_id"]!=condition_id):
                    raise ValueError("RUNTIME_FAILURE_EPISODE_MISMATCH")
                if episode["paper_status"]!="OBSERVED":
                    return False
                account_id=f"{self.strategy_version}:{wallet.lower()}"
                decision_key=f"{self.strategy_version}:{signal_id}"
                order=con.execute("SELECT * FROM strict_orders WHERE idempotency_key=?",(decision_key,)).fetchone()
                if order:
                    if (order["account_id"]!=account_id or order["signal_id"]!=signal_id
                            or order["condition_id"]!=episode["condition_id"]
                            or order["token_id"]!=episode["first_token_id"]
                            or order["outcome"]!=episode["first_outcome"] or order["side"]!="BUY"):
                        raise ValueError("RUNTIME_FAILURE_ORDER_MISMATCH")
                    fills=con.execute("SELECT fill_id FROM strict_fills WHERE order_id=?",(order["order_id"],)).fetchall()
                    payload_evidence.update(episode_id=episode_id,order_id=order["order_id"],
                        original_failure_reason=reason,network_requests_performed=False,
                        book_fetch_performed=False,fill_ids=[fill["fill_id"] for fill in fills])
                    if fills:
                        # An exception may arrive after apply_execution committed.
                        # Stale-OBSERVED recovery validates and restores that fill;
                        # no rejection event may hide it from the recovery loop.
                        payload_evidence["recovery_required"]=True
                        con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                            ("EXECUTION_FAILURE_RECOVERY_REQUIRED",when,
                             json.dumps(payload_evidence,sort_keys=True,separators=(",", ":"),default=str)))
                        return False
                    reason="EXECUTION_COMMIT_INCOMPLETE"
                    released=StrictPaperLedger(self.path,account_id=account_id).cancel_order_in_transaction(
                        con,order["order_id"],created_at=when,force=True,reason=reason)
                    payload_evidence.update(reason=reason,reservations_released=released)
            payload = json.dumps(payload_evidence, sort_keys=True, separators=(",", ":"), default=str)
            cur = con.execute("""INSERT OR IGNORE INTO wallet_v2_runtime_events
                (signal_id,wallet,condition_id,event_type,reason,occurred_at,episode_id,evidence_json)
                VALUES(?,?,?,'EXECUTION_REJECTED',?,?,?,?)""",
                (signal_id, wallet.lower(), condition_id, reason, when, episode_id, payload))
            if episode_id:
                config = con.execute("SELECT config_json FROM wallet_v2_versions WHERE strategy_version=?",
                                     (self.strategy_version,)).fetchone()
                requested = str(json.loads(config[0])["fixed_notional"]) if config else None
                con.execute("""UPDATE wallet_v2_episodes SET paper_status='REJECTED',rejection_reason=?,
                    execution_eligible=0,requested_notional=COALESCE(requested_notional,?)
                    WHERE episode_id=? AND strategy_version=? AND paper_status='OBSERVED'""",
                    (reason, requested, episode_id, self.strategy_version))
            if cur.rowcount:
                con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                            ("RUNTIME_FAILURE_RECORDED",when,payload))
        return cur.rowcount > 0

    def recover_stale_observed(self, *, now: datetime,
                               include_episode_ids: bool = False) -> int | tuple[int, set[str]]:
        """Reconcile stale V2 episodes from local immutable evidence only.

        The episode, any reservation release, runtime event and audit entry are
        committed together. This routine deliberately has no market client and
        never reconstructs an execution from a later quote or order book.
        """
        cutoff_now=_utc(now)
        recovered_ids: set[str] = set()

        def result() -> int | tuple[int, set[str]]:
            return (len(recovered_ids), set(recovered_ids)) if include_episode_ids else len(recovered_ids)

        def object_json(raw: str | None) -> dict[str, Any] | None:
            try:
                value=json.loads(raw) if raw is not None else None
            except (TypeError,ValueError):
                return None
            return value if isinstance(value,dict) else None

        def identity_matches(record: sqlite3.Row, row: sqlite3.Row,
                             account_id: str, signal_id: str, decision_key: str) -> bool:
            return (record["account_id"]==account_id and record["signal_id"]==signal_id
                    and record["idempotency_key"]==decision_key
                    and record["condition_id"]==row["condition_id"]
                    and record["token_id"]==row["first_token_id"]
                    and record["outcome"]==row["first_outcome"] and record["side"]=="BUY")

        def evidence_matches(evidence: dict[str, Any] | None, row: sqlite3.Row,
                             signal_id: str, decision_key: str) -> bool:
            if not evidence:
                return False
            identity=evidence.get("identity")
            return (isinstance(identity,dict)
                    and identity.get("condition_id")==row["condition_id"]
                    and identity.get("token_id")==row["first_token_id"]
                    and identity.get("outcome")==row["first_outcome"]
                    and evidence.get("signal_id")==signal_id
                    and evidence.get("idempotency_key")==decision_key
                    and evidence.get("side")=="BUY"
                    and evidence.get("engine_version") in {ENGINE_VERSION_V3, ENGINE_VERSION_V4})

        def finite_decimal(value: Any) -> Decimal | None:
            try:
                return _decimal(value)
            except (TypeError,ValueError,ArithmeticError):
                return None

        def quote_price(evidence: dict[str, Any] | None) -> str | None:
            quote=evidence.get("quote") if evidence else None
            asks=quote.get("asks") if isinstance(quote,dict) else None
            if not isinstance(asks,list) or not asks or not isinstance(asks[0],list) or not asks[0]:
                return None
            value=finite_decimal(asks[0][0])
            return str(value) if value is not None and value > 0 else None

        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            version=con.execute("SELECT state,config_json FROM wallet_v2_versions WHERE strategy_version=?",
                                (self.strategy_version,)).fetchone()
            if version is None or version["state"]!="FORWARD_TEST":
                con.rollback()
                return result()
            config=StrategyConfig.from_evidence(json.loads(version["config_json"]))
            eligible_before=cutoff_now-timedelta(seconds=config.observed_recovery_grace_seconds)
            rows=con.execute("""SELECT * FROM wallet_v2_episodes
                WHERE strategy_version=? AND paper_status='OBSERVED' ORDER BY first_detected_at,episode_id""",
                (self.strategy_version,)).fetchall()

            for index,row in enumerate(rows):
                try:
                    detected=_utc(datetime.fromisoformat(row["first_detected_at"]))
                except (TypeError,ValueError):
                    continue
                if detected > eligible_before:
                    continue

                savepoint=f"recover_episode_{index}"
                con.execute(f"SAVEPOINT {savepoint}")
                signal_id=row["first_signal_id"]
                decision_key=f"{self.strategy_version}:{signal_id}"
                account_id=f"{self.strategy_version}:{row['wallet'].lower()}"
                ledger=StrictPaperLedger(self.path,account_id=account_id)
                try:
                    decision=con.execute("SELECT * FROM strict_decisions WHERE idempotency_key=?",
                                         (decision_key,)).fetchone()
                    order=con.execute("SELECT * FROM strict_orders WHERE idempotency_key=?",
                                      (decision_key,)).fetchone()
                    fills=(con.execute("SELECT * FROM strict_fills WHERE order_id=? AND account_id=? ORDER BY created_at,fill_id",
                                       (order["order_id"],account_id)).fetchall() if order else [])
                    runtime_event=con.execute("""SELECT * FROM wallet_v2_runtime_events
                        WHERE episode_id=? OR signal_id=? ORDER BY occurred_at LIMIT 1""",
                        (row["episode_id"],signal_id)).fetchone()
                    decision_evidence=object_json(decision["evidence_json"]) if decision else None
                    order_evidence=object_json(order["evidence_json"]) if order else None
                    fill_evidence=object_json(fills[0]["evidence_json"]) if len(fills)==1 else None
                    order_matches=bool(order and identity_matches(order,row,account_id,signal_id,decision_key))
                    decision_matches=bool(decision and identity_matches(decision,row,account_id,signal_id,decision_key))
                    decision_evidence_matches=evidence_matches(decision_evidence,row,signal_id,decision_key)
                    fill_evidence_matches=evidence_matches(fill_evidence,row,signal_id,decision_key)

                    terminal_status="REJECTED"
                    terminal_reason="CRASH_RECOVERY_NO_FILL"
                    accepted_evidence: dict[str,Any] | None=None
                    linked_order_id=order["order_id"] if order_matches else None
                    fill=None
                    action="CRASH_RECOVERY_NO_FILL"

                    valid_fill=False
                    if order_matches and len(fills)==1 and len(fills[0]):
                        fill=fills[0]
                        order_payload=dict(order_evidence or {})
                        order_payload.pop("_ledger_order",None)
                        same_execution=(fill_evidence_matches and order_evidence is not None
                            and order_payload==fill_evidence
                            and order["status"] in {"FILLED","PARTIALLY_FILLED"}
                            and order["engine_version"] in {ENGINE_VERSION_V3, ENGINE_VERSION_V4}
                            and order["engine_version"]==fill_evidence.get("engine_version")
                            and order["rule_version"]==fill_evidence.get("rule_version")
                            and fill["condition_id"]==row["condition_id"]
                            and fill["token_id"]==row["first_token_id"]
                            and fill["outcome"]==row["first_outcome"] and fill["side"]=="BUY"
                            and fill["account_id"]==account_id and fill["order_id"]==order["order_id"]
                            and fill_evidence.get("status") in {"FILLED","PARTIAL"})
                        qty=finite_decimal(fill["quantity"])
                        price=finite_decimal(fill["vwap"])
                        gross=finite_decimal(fill["gross_amount"])
                        fee=finite_decimal(fill["fee"])
                        ev_qty=finite_decimal(fill_evidence.get("filled_quantity")) if fill_evidence else None
                        ev_price=finite_decimal(fill_evidence.get("vwap")) if fill_evidence else None
                        ev_gross=finite_decimal(fill_evidence.get("filled_notional")) if fill_evidence else None
                        ev_fee=finite_decimal(fill_evidence.get("total_fee")) if fill_evidence else None
                        same_execution=(same_execution and qty is not None and qty>0 and price is not None and price>0
                            and gross is not None and gross>0 and fee is not None and fee>=0
                            and (qty,price,gross,fee)==(ev_qty,ev_price,ev_gross,ev_fee))
                        if decision:
                            same_execution=(same_execution and decision_matches and decision_evidence_matches
                                and decision["status"]==fill_evidence.get("status")
                                and decision["reason"]==fill_evidence.get("reason")
                                and decision["engine_version"] in {ENGINE_VERSION_V3, ENGINE_VERSION_V4})
                            same_execution = same_execution and decision["engine_version"]==fill_evidence.get("engine_version")
                        if same_execution:
                            valid_fill=True
                            accepted_evidence=fill_evidence
                            terminal_status="PARTIAL" if fill_evidence["status"]=="PARTIAL" else "FILLED"
                            terminal_reason=str(fill_evidence.get("reason") or terminal_status)
                            action="CRASH_RECOVERY_FILL_SYNC"

                    # A single authoritative rejection is recoverable without
                    # inventing another decision, provided no fill committed.
                    if (not valid_fill and not fills and decision and decision_matches
                            and decision_evidence_matches and decision["status"]=="REJECTED"
                            and decision["reason"] and decision["engine_version"] in {ENGINE_VERSION_V3, ENGINE_VERSION_V4}):
                        accepted_evidence=decision_evidence
                        terminal_reason=decision["reason"]
                        action="CRASH_RECOVERY_REJECTED_DECISION_SYNC"

                    if valid_fill:
                        ev_requested=finite_decimal(accepted_evidence.get("requested_notional"))
                        if ev_requested is None or ev_requested<=0:
                            valid_fill=False
                            terminal_reason="EXECUTION_COMMIT_INCOMPLETE"
                            accepted_evidence=None
                            action="CRASH_RECOVERY_INCOMPLETE_COMMIT"
                        else:
                            terminal_status="PARTIAL" if accepted_evidence["status"]=="PARTIAL" else "FILLED"

                    # Abandoned reservations are returned before the episode
                    # is made terminal, in this very same SQLite transaction.
                    has_committed_fill=bool(fills)
                    if order_matches and (not valid_fill) and (order["status"]=="OPEN"
                            or order["status"]!="CANCELLED"
                            or finite_decimal(order["reserve_cash_remaining"])!=0
                            or finite_decimal(order["reserved_quantity_remaining"])!=0):
                        ledger.cancel_order_in_transaction(con,order["order_id"],
                            created_at=cutoff_now.isoformat(),force=True,
                            reason="V2_CRASH_RECOVERY_NO_FILL")

                    if not valid_fill and action!="CRASH_RECOVERY_REJECTED_DECISION_SYNC":
                        # An accepted decision without its fill/order commit is
                        # never repaired by synthesizing the missing fill.
                        if decision and decision["status"] in {"FILLED","PARTIAL"}:
                            terminal_reason="EXECUTION_COMMIT_INCOMPLETE"
                            action="CRASH_RECOVERY_INCOMPLETE_COMMIT"
                        elif fills or decision:
                            terminal_reason="EXECUTION_COMMIT_INCOMPLETE"
                            action="CRASH_RECOVERY_INCOMPLETE_COMMIT"
                        elif order and order_matches and order["status"]!="CANCELLED":
                            terminal_reason="EXECUTION_COMMIT_INCOMPLETE"
                            action="CRASH_RECOVERY_INCOMPLETE_COMMIT"
                        elif runtime_event and not decision and not fills:
                            terminal_reason=str(runtime_event["reason"] or "CRASH_RECOVERY_NO_FILL")
                            action="CRASH_RECOVERY_RUNTIME_EVENT_SYNC"

                    # A mismatched order/decision must not be treated as valid
                    # evidence for this episode. Leave foreign reservations
                    # untouched; the recovery audit records the inconsistency.
                    if ((order and not order_matches) or (decision and not decision_matches)):
                        valid_fill=False
                        accepted_evidence=None
                        terminal_reason="EXECUTION_COMMIT_INCOMPLETE"
                        action="CRASH_RECOVERY_INCOMPLETE_COMMIT"

                    if valid_fill and accepted_evidence:
                        quote=quote_price(accepted_evidence)
                        execution_price=accepted_evidence.get("vwap")
                        leader_price=finite_decimal(row["leader_price"]) if row["leader_price"] is not None else None
                        fill_price=finite_decimal(execution_price)
                        delta=str(fill_price-leader_price) if fill_price is not None and leader_price is not None else None
                        requested=str(finite_decimal(accepted_evidence["requested_notional"]))
                        filled_notional=str(finite_decimal(fill["gross_amount"]))
                        filled_quantity=str(finite_decimal(fill["quantity"]))
                        entry_fee=str(finite_decimal(fill["fee"]))
                        con.execute("""UPDATE wallet_v2_episodes SET paper_status=?,rejection_reason=?,
                            execution_eligible=1,quote_price=?,execution_price=?,price_delta=?,requested_notional=?,
                            filled_notional=?,filled_quantity=?,entry_fee=?,paper_order_id=?
                            WHERE episode_id=? AND strategy_version=? AND paper_status='OBSERVED'""",
                            (terminal_status,terminal_reason,quote,execution_price,delta,requested,filled_notional,
                             filled_quantity,entry_fee,order["order_id"],row["episode_id"],self.strategy_version))
                    elif action=="CRASH_RECOVERY_REJECTED_DECISION_SYNC" and accepted_evidence:
                        quote=quote_price(accepted_evidence)
                        requested=finite_decimal(accepted_evidence.get("requested_notional"))
                        filled_notional=finite_decimal(accepted_evidence.get("filled_notional"))
                        filled_quantity=finite_decimal(accepted_evidence.get("filled_quantity"))
                        fee=finite_decimal(accepted_evidence.get("total_fee"))
                        if None in (requested,filled_notional,filled_quantity,fee):
                            terminal_reason="EXECUTION_COMMIT_INCOMPLETE"
                            action="CRASH_RECOVERY_INCOMPLETE_COMMIT"
                            accepted_evidence=None
                        else:
                            con.execute("""UPDATE wallet_v2_episodes SET paper_status='REJECTED',rejection_reason=?,
                                execution_eligible=0,quote_price=?,execution_price=?,requested_notional=?,filled_notional=?,
                                filled_quantity=?,entry_fee=?,paper_order_id=? WHERE episode_id=? AND strategy_version=?
                                AND paper_status='OBSERVED'""",
                                (terminal_reason,quote,accepted_evidence.get("vwap"),str(requested),str(filled_notional),
                                 str(filled_quantity),str(fee),linked_order_id,row["episode_id"],self.strategy_version))

                    if not valid_fill and action!="CRASH_RECOVERY_REJECTED_DECISION_SYNC":
                        source_evidence=(decision_evidence if decision_evidence_matches else order_evidence if order_evidence else None)
                        requested=finite_decimal((source_evidence or {}).get("requested_notional")) or config.fixed_notional
                        quote=quote_price(source_evidence)
                        linked_order_id=(order["order_id"] if order_matches and (has_committed_fill or order["status"]=="CANCELLED") else None)
                        con.execute("""UPDATE wallet_v2_episodes SET paper_status='REJECTED',rejection_reason=?,
                            execution_eligible=0,quote_price=COALESCE(?,quote_price),execution_price=NULL,
                            requested_notional=?,filled_notional='0.000000',filled_quantity='0.000000',
                            entry_fee='0.000000',paper_order_id=? WHERE episode_id=? AND strategy_version=?
                            AND paper_status='OBSERVED'""",
                            (terminal_reason,quote,str(requested),linked_order_id,row["episode_id"],self.strategy_version))

                    changed=con.execute("SELECT paper_status FROM wallet_v2_episodes WHERE episode_id=?",
                                        (row["episode_id"],)).fetchone()
                    if changed and changed["paper_status"]!="OBSERVED":
                        audit={"episode_id":row["episode_id"],"signal_id":signal_id,
                            "detected_at":row["first_detected_at"],"recovered_at":cutoff_now.isoformat(),
                            "grace_seconds":config.observed_recovery_grace_seconds,"action":action,
                            "reason":terminal_reason,"decision_id":decision["decision_id"] if decision else None,
                            "order_id":order["order_id"] if order else None,
                            "fill_ids":[item["fill_id"] for item in fills],
                            "book_fetch_performed":False,"network_requests_performed":False,
                            "reservations_released":bool(order and not valid_fill)}
                        payload=json.dumps(audit,sort_keys=True,separators=(",",":"),default=str)
                        if action in {"CRASH_RECOVERY_NO_FILL","CRASH_RECOVERY_INCOMPLETE_COMMIT",
                                      "CRASH_RECOVERY_RUNTIME_EVENT_SYNC"}:
                            con.execute("""INSERT OR IGNORE INTO wallet_v2_runtime_events
                                (signal_id,wallet,condition_id,event_type,reason,occurred_at,episode_id,evidence_json)
                                VALUES(?,?,?,'EXECUTION_REJECTED',?,?,?,?)""",
                                (signal_id,row["wallet"],row["condition_id"],terminal_reason,
                                 cutoff_now.isoformat(),row["episode_id"],payload))
                        con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                                    (action,cutoff_now.isoformat(),payload))
                        recovered_ids.add(row["episode_id"])
                    con.execute(f"RELEASE SAVEPOINT {savepoint}")
                except Exception as exc:
                    con.execute(f"ROLLBACK TO SAVEPOINT {savepoint}")
                    con.execute(f"RELEASE SAVEPOINT {savepoint}")
                    failure={"episode_id":row["episode_id"],"signal_id":signal_id,
                        "recovered_at":cutoff_now.isoformat(),"action":"CRASH_RECOVERY_RETRY_REQUIRED",
                        "error_type":type(exc).__name__,"book_fetch_performed":False,
                        "network_requests_performed":False}
                    con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                        ("CRASH_RECOVERY_RETRY_REQUIRED",cutoff_now.isoformat(),
                         json.dumps(failure,sort_keys=True,separators=(",",":"))))

            con.commit()
        return result()

    def execute_first(self, episode_id: str, *, market: MarketState, quote: BookSnapshot,
                      execution: BookSnapshot | None, fee_rate: Any, fee_source: str,
                      observed_at: datetime, local_timestamp_model: bool = False) -> dict[str, Any]:
        row, version = self.episode(episode_id), self.version()
        if version["state"] != "FORWARD_TEST":
            raise ValueError("STRATEGY_NOT_FORWARD_TEST")
        if row["resolution_status"] in {"FORMALLY_RESOLVED", "VOID"}:
            raise ValueError("EPISODE_ALREADY_RESOLVED")
        if row["paper_status"] != "OBSERVED":
            return {"status": row["paper_status"], "reason": row["rejection_reason"], "duplicate": True}
        # A crash after ledger commit must never consume a newer order book.
        ledger = self.ledger(row["wallet"])
        idempotency_key = f"{self.strategy_version}:{row['first_signal_id']}"
        with self._connect() as con:
            prior = con.execute("SELECT status,reason,evidence_json FROM strict_decisions WHERE idempotency_key=?",
                                (idempotency_key,)).fetchone()
        if prior is not None:
            evidence = json.loads(prior["evidence_json"])
            with self._connect() as con:
                order = con.execute("SELECT order_id,status FROM strict_orders WHERE idempotency_key=?", (idempotency_key,)).fetchone()
                fill = con.execute("SELECT fill_id FROM strict_fills WHERE order_id=?", (order["order_id"],)).fetchone() if order else None
            if prior["status"] != "REJECTED" and fill is None:
                return {"status": "RECOVERY_REQUIRED", "reason": "EXECUTION_COMMIT_INCOMPLETE", "duplicate": True}
            quote_evidence = evidence.get("quote") or {}
            quote_levels = quote_evidence.get("asks") or []
            quote_price = quote_levels[0][0] if quote_levels else None
            leader_price = _decimal(row["leader_price"]) if row["leader_price"] else None
            execution_price = evidence.get("vwap")
            delta = str(_decimal(execution_price)-leader_price) if execution_price is not None and leader_price is not None else None
            with self._connect() as con:
                con.execute("""UPDATE wallet_v2_episodes SET paper_status=?,rejection_reason=?,execution_eligible=?,quote_price=?,execution_price=?,price_delta=?,requested_notional=?,filled_notional=?,filled_quantity=?,entry_fee=?,paper_order_id=? WHERE episode_id=? AND paper_status='OBSERVED'""",
                    (prior["status"],prior["reason"],int(prior["status"] != "REJECTED"),quote_price,execution_price,delta,
                     evidence.get("requested_notional"),evidence.get("filled_notional"),evidence.get("filled_quantity"),evidence.get("total_fee"),
                     order["order_id"] if order else None,episode_id))
            return {"status": prior["status"], "reason": prior["reason"], "duplicate": True, "recovered": True}
        config = StrategyConfig.from_evidence(json.loads(version["config_json"]))
        identity = MarketIdentity(row["condition_id"], row["first_token_id"], row["first_outcome"])
        intent = OrderIntent(row["first_signal_id"], idempotency_key, identity, "BUY", config.fixed_notional,
                             allow_partial=True, leader_trade_timestamp=datetime.fromisoformat(row["first_leader_at"]),
                             edge_detected_timestamp=datetime.fromisoformat(row["first_detected_at"]))
        decision = execute_order(intent, market, quote, execution, config.engine_rules(self.strategy_version, local_timestamp_model=local_timestamp_model),
                                 fee_rate=fee_rate, fee_source=fee_source, observed_at=_utc(observed_at))
        execution_eligible = decision.status != "REJECTED"
        if ledger.book_account() is None:
            try:
                ledger.create_account(config.initial_cash_per_wallet, created_at=_utc(observed_at).isoformat())
            except ValueError as exc:
                if str(exc) != "ACCOUNT_ALREADY_EXISTS":
                    raise
        account = ledger.account()
        if decision.status != "REJECTED" and _decimal(account["available_cash"]) < decision.total_cost + decision.total_fee:
            status, reason = "REJECTED", "INSUFFICIENT_PAPER_CASH"
            decision = replace(decision, status="REJECTED", reason=reason,
                filled_quantity=Decimal("0"), vwap=None, total_cost=Decimal("0"), total_fee=Decimal("0"),
                fills=(), filled_notional=Decimal("0"), unfilled_notional=config.fixed_notional,
                projected_net_profit_if_win=None, projected_net_roi_if_win=None)
            ledger.record_decision(decision, intent, created_at=_utc(observed_at).isoformat())
        elif decision.status == "REJECTED":
            status, reason = "REJECTED", decision.reason
            ledger.record_decision(decision, intent, created_at=_utc(observed_at).isoformat())
        else:
            order_id = hashlib.sha256(f"order|{idempotency_key}".encode()).hexdigest()
            reserve = (config.fixed_notional + (config.fixed_notional * _decimal(fee_rate)).quantize(MONEY_QUANTUM, rounding=ROUND_UP)).quantize(MONEY_QUANTUM)
            if reserve > _decimal(account["available_cash"]):
                reserve = decision.total_cost + decision.total_fee
            try:
                ledger.submit_order(order_id=order_id, idempotency_key=idempotency_key, signal_id=intent.signal_id,
                    identity=identity, side="BUY", target_quantity=0, reserve_cash=reserve,
                    requested_notional=config.fixed_notional, engine_version=decision.engine_version,
                    rule_version=decision.rule_version, evidence=decision.to_evidence(intent),
                    created_at=_utc(observed_at).isoformat())
            except ValueError as exc:
                if str(exc) != 'INSUFFICIENT_AVAILABLE_CASH':
                    raise
                # Another order can reserve shared cash after the balance read.
                # The transaction remains authoritative; retain a named no-fill.
                status, reason = 'REJECTED', 'INSUFFICIENT_PAPER_CASH'
                decision = replace(decision, status=status, reason=reason,
                    filled_quantity=Decimal('0'), vwap=None, total_cost=Decimal('0'), total_fee=Decimal('0'),
                    fills=(), filled_notional=Decimal('0'), unfilled_notional=config.fixed_notional,
                    projected_net_profit_if_win=None, projected_net_roi_if_win=None)
                ledger.record_decision(decision, intent, created_at=_utc(observed_at).isoformat())
            else:
                ledger.apply_execution(fill_id=hashlib.sha256(f"fill|{idempotency_key}".encode()).hexdigest(),
                    order_id=order_id, decision=decision, intent=intent, created_at=_utc(observed_at).isoformat())
                status, reason = decision.status, decision.reason
        quote_price = quote.asks[0].price if quote.asks else None
        leader_price = _decimal(row["leader_price"]) if row["leader_price"] else None
        delta = (decision.vwap - leader_price) if decision.vwap is not None and leader_price is not None else None
        with self._connect() as con:
            con.execute("""UPDATE wallet_v2_episodes SET paper_status=?,rejection_reason=?,execution_eligible=?,quote_price=?,execution_price=?,price_delta=?,requested_notional=?,filled_notional=?,filled_quantity=?,entry_fee=?,paper_order_id=? WHERE episode_id=? AND paper_status='OBSERVED'""",
                (status,reason,int(execution_eligible),str(quote_price) if quote_price else None,str(decision.vwap) if decision.vwap else None,
                 str(delta) if delta is not None else None,str(config.fixed_notional),str(decision.filled_notional),
                 str(decision.filled_quantity),str(decision.total_fee),order_id if decision.status != "REJECTED" and reason != "INSUFFICIENT_PAPER_CASH" else None,episode_id))
        return {"status": status, "reason": reason, "duplicate": False,
                "decision": decision.to_evidence(intent)}

    def reconcile_void(self, episode_id: str, *, observed_at: datetime,
                       authoritative_source: str, evidence: dict[str, Any]) -> bool:
        """Explicit historical correction; retain original settlement and episode evidence."""
        return self.record_resolution(episode_id, status="VOID", observed_at=observed_at,
            authoritative_source=authoritative_source, payout_per_share="0.5",
            evidence=evidence, reconcile_void=True)

    def record_resolution(self, episode_id: str, *, status: str, observed_at: datetime,
                          authoritative_source: str | None = None,
                          winning_token_id: str | None = None,
                          payout_per_share: Any | None = None,
                          evidence: dict[str, Any] | None = None,
                          reconcile_void: bool = False) -> bool:
        if status not in {"MARKET_CLOSED", "RESULT_PENDING", "FORMALLY_RESOLVED", "VOID", "API_FAILURE"}:
            raise ValueError("INVALID_RESOLUTION_STATUS")
        row = self.episode(episode_id)
        ledger = self.ledger(row["wallet"])
        when = _utc(observed_at).isoformat()
        # Financial effects, episode update, and correction audit commit together.
        with ledger._tx() as con:
            row = dict(con.execute("SELECT * FROM wallet_v2_episodes WHERE episode_id=?", (episode_id,)).fetchone())
            identity = MarketIdentity(row["condition_id"], row["first_token_id"], row["first_outcome"])
            payout = None
            if status == "FORMALLY_RESOLVED":
                if not authoritative_source or not winning_token_id or payout_per_share is None:
                    raise ValueError("MISSING_AUTHORITATIVE_RESOLUTION")
                payout = _decimal(payout_per_share)
                if payout not in (Decimal("0"), Decimal("1")) or payout != int(row["first_token_id"] == winning_token_id):
                    raise ValueError("INCONSISTENT_FORMAL_PAYOUT")
            elif status == "VOID":
                if winning_token_id is not None:
                    raise ValueError("VOID_HAS_NO_DIRECTIONAL_WINNER")
                payout = validate_void_resolution(identity, authoritative_source, payout_per_share, evidence or {})
            elif payout_per_share is not None or winning_token_id is not None:
                raise ValueError("NONFINAL_RESOLUTION_HAS_RESULT")
            if reconcile_void and (status != "VOID" or row["resolution_status"] != "VOID"):
                raise ValueError("NOT_A_HISTORICAL_VOID")
            terminal = status in {"FORMALLY_RESOLVED", "VOID"}
            correction = reconcile_void and row["payout_per_share"] is None
            if row["resolution_status"] in {"FORMALLY_RESOLVED", "VOID"} and not correction:
                if (row["resolution_status"] == status and row["winning_token_id"] == winning_token_id
                        and row["payout_per_share"] is not None and _decimal(row["payout_per_share"]) == payout):
                    return False
                raise ValueError("RESOLUTION_ALREADY_FINAL")
            details = dict(evidence or {})
            if correction:
                details["correction_of"] = {"episode_id":episode_id,
                    "original_resolution_evidence_json":row["resolution_evidence_json"],
                    "original_settled_at":row["settled_at"],
                    "original_settlement_id":hashlib.sha256(f"settle|{episode_id}|VOID".encode()).hexdigest()}
            if row["paper_order_id"]:
                key = (f"settle|{episode_id}|{status}" if terminal else f"settle|{episode_id}|{status}|{when}")
                if status == "VOID":
                    key += "|financial-void-v1"
                settlement_id = hashlib.sha256(key.encode()).hexdigest()
                existing = con.execute("SELECT * FROM strict_settlements WHERE settlement_id=? AND account_id=?",
                    (settlement_id,ledger.account_id)).fetchone()
                if existing:
                    if (existing["condition_id"],existing["token_id"],existing["outcome"],existing["status"],
                            existing["authoritative_source"],existing["payout_per_share"]) != (
                            identity.condition_id,identity.token_id,identity.outcome,status,authoritative_source,
                            str(payout) if payout is not None else None):
                        raise ValueError("SETTLEMENT_IDEMPOTENCY_CONFLICT")
                    when = existing["observed_at"]
                    details = json.loads(existing["details_json"])
                else:
                    ledger.record_settlement(settlement_id=settlement_id,identity=identity,status=status,
                        observed_at=when,authoritative_source=authoritative_source,payout_per_share=payout,
                        details=details,connection=con)
            serialized = json.dumps(details,sort_keys=True,separators=(",", ":"),default=str)
            con.execute("""UPDATE wallet_v2_episodes SET resolution_status=?,winning_token_id=?,direction_correct=?,payout_per_share=?,authoritative_source=?,settled_at=?,resolution_evidence_json=? WHERE episode_id=?""",
                (status,winning_token_id,int(row["first_token_id"] == winning_token_id) if status == "FORMALLY_RESOLVED" else None,
                 str(payout) if payout is not None else None,authoritative_source,when if terminal else None,serialized,episode_id))
            exit_table=con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wallet_v2_exit_positions'").fetchone()
            if terminal and exit_table:
                exit_state=con.execute("SELECT state,exit_reason FROM wallet_v2_exit_positions WHERE episode_id=?",(episode_id,)).fetchone()
                if exit_state and exit_state["state"]=="ACTIVE":
                    con.execute("UPDATE wallet_v2_exit_positions SET state='FORMALLY_RESOLVED',exit_reason='FORMAL_RESOLUTION',lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=?",
                                (when,episode_id))
                    append_exit_event(con,episode_id,"FORMAL_RESOLUTION",when,
                        {"resolution_status":status,"authoritative_source":authoritative_source,
                         "payout_per_share":str(payout) if payout is not None else None,
                         "winning_token_id":winning_token_id,"direction_correct":None if status=='VOID' else int(row["first_token_id"]==winning_token_id),
                         "resolution_evidence":details,"financial_settlement_recorded":bool(row["paper_order_id"])},
                        event_key=hashlib.sha256(f"{episode_id}|{status}|{when}".encode()).hexdigest())
            if correction:
                con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                    ("VOID_FINANCIAL_RECONCILIATION",when,serialized))
        return True

    def wallet_metrics(self, wallet: str) -> dict[str, Any]:
        version = self.version()
        with self._connect() as con:
            episodes = [dict(x) for x in con.execute("SELECT * FROM wallet_v2_episodes WHERE strategy_version=? AND wallet=? ORDER BY first_detected_at",
                                                   (self.strategy_version,wallet.lower()))]
            events = [dict(x) for x in con.execute("SELECT e.* FROM wallet_v2_events e JOIN wallet_v2_episodes p ON p.episode_id=e.episode_id WHERE p.strategy_version=? AND p.wallet=?",
                                                 (self.strategy_version,wallet.lower()))]
        resolved = [x for x in episodes if x["resolution_status"] == "FORMALLY_RESOLVED"]
        filled = [x for x in episodes if x["paper_status"] in {"FILLED", "PARTIAL"}]
        correct = sum(x["direction_correct"] for x in resolved)
        ledger = self.ledger(wallet)
        account = ledger.account()
        snap = ledger.account_snapshot() if account else {"positions": [], "fills": []}
        pnl = sum((_decimal(x["realized_pnl"]) for x in snap["positions"]), Decimal("0"))
        invested = sum((_decimal(x["filled_notional"]) + _decimal(x["entry_fee"])
                        for x in filled if x["resolution_status"] == "FORMALLY_RESOLVED" or (x["resolution_status"] == "VOID" and x["payout_per_share"] is not None)), Decimal("0"))
        reasons: dict[str, int] = {}
        for x in episodes:
            if x["paper_status"] == "REJECTED":
                reasons[x["rejection_reason"]] = reasons.get(x["rejection_reason"], 0) + 1
        def mean(values: list[Decimal]) -> str | None:
            return str(sum(values) / len(values)) if values else None
        holding = [Decimal(str((datetime.fromisoformat(x["settled_at"])-datetime.fromisoformat(x["first_detected_at"])).total_seconds()))
                   for x in resolved if x["settled_at"]]
        deltas = [_decimal(x["price_delta"]) for x in filled if x["price_delta"] is not None]
        return {"strategy_version":self.strategy_version,"wallet":wallet.lower(),
                "observed_episode_count":len(episodes),"resolved_directional_episode_count":len(resolved),
                "directional_accuracy":str(Decimal(correct)/len(resolved)) if resolved else None,
                "copyable_signal_rate":str(Decimal(sum(x["execution_eligible"] == 1 for x in episodes))/len(episodes)) if episodes else None,
                "paper_fill_rate":str(Decimal(len(filled))/len(episodes)) if episodes else None,
                "realized_paper_net_roi":str(pnl/invested) if invested else None,
                "realized_pnl":str(pnl),"leader_to_edge_price_delta_mean":mean(deltas),
                "detection_delay_seconds_mean":mean([_decimal(x["detection_delay_seconds"]) for x in episodes]),
                "holding_duration_seconds_mean":mean(holding),
                "add_on_count":sum(x["event_type"]=="ADD_ON" for x in events),
                "reversal_count":sum(x["event_type"]=="REVERSAL" for x in events),
                "no_fill_reasons":reasons,
                "review_eligible":len(resolved)>=json.loads(version["config_json"])["min_resolved_for_review"],
                "category_results":self._group(episodes,"category"),
                "entry_price_band_results":self._group(episodes,"entry_price_band"),
                "time_to_expected_end_band_results":self._group(episodes,"time_band")}

    @staticmethod
    def _group(episodes: list[dict[str, Any]], field: str) -> dict[str, dict[str, int]]:
        result: dict[str, dict[str, int]] = {}
        for x in episodes:
            if field == "category":
                key = x["category"] or "UNKNOWN"
            elif field == "entry_price_band":
                price = x["execution_price"]
                key = "UNKNOWN" if price is None else "LOW" if _decimal(price)<Decimal("0.25") else "MID" if _decimal(price)<Decimal("0.75") else "HIGH"
            else:
                seconds = x["time_to_expected_end_seconds"]
                key = "UNKNOWN" if seconds is None else "PAST_EXPECTED_END" if _decimal(seconds)<0 else "UNDER_1H" if _decimal(seconds)<3600 else "1H_TO_1D" if _decimal(seconds)<86400 else "OVER_1D"
            row = result.setdefault(key, {"episodes":0,"resolved":0,"correct":0,"paper_fills":0})
            row["episodes"] += 1
            row["resolved"] += x["resolution_status"] == "FORMALLY_RESOLVED"
            row["correct"] += x["direction_correct"] == 1
            row["paper_fills"] += x["paper_status"] in {"FILLED","PARTIAL"}
        return result
