"""Opt-in isolated paper account and append-only local audit ledger.

Only ``StrictPaperLedger.initialize(path)`` creates additive ``strict_*``
tables. It does not call the legacy Database.init() and never reads or writes
legacy trade, signal, experiment, wallet, or research tables.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from contextlib import contextmanager, nullcontext
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_UP
from pathlib import Path
from typing import Any

from .strict_paper import MONEY_QUANTUM, QTY_QUANTUM, BookSnapshot, ExecutionDecision, MarketIdentity, executable_level
from .shared_pool import pool_for, cash_owner, observe_capital, reconcile_pool

LEDGER_VERSION = "strict-paper-ledger-v1"


def validate_void_resolution(identity: MarketIdentity, source: str | None, payout: Any,
                             evidence: dict[str, Any]) -> Decimal:
    """Fail closed: only an exact, source-backed Polymarket half payout is VOID."""
    if not isinstance(source, str) or not source.strip():
        raise ValueError("MISSING_AUTHORITATIVE_RESOLUTION")
    if (evidence.get("resolved") is not True or evidence.get("resolution_is_void") is not True
            or evidence.get("condition_id") != identity.condition_id
            or evidence.get("token_id") != identity.token_id or evidence.get("outcome") != identity.outcome
            or evidence.get("authoritative_source") != source):
        raise ValueError("INVALID_VOID_RESOLUTION_EVIDENCE")
    value = _d(payout, "void_payout")
    if value != Decimal("0.5") or _d(evidence.get("settlement_price"), "void_source_payout") != value:
        raise ValueError("INVALID_VOID_PAYOUT")
    return value


def _d(value: Any, name: str, *, rounding=ROUND_DOWN) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(f"INVALID_{name.upper()}") from None
    if not result.is_finite():
        raise ValueError(f"INVALID_{name.upper()}")
    return result


def _money(value: Any, name: str, *, rounding=ROUND_DOWN) -> Decimal:
    return _d(value, name).quantize(MONEY_QUANTUM, rounding=rounding)


def _qty(value: Any, name: str, *, rounding=ROUND_DOWN) -> Decimal:
    return _d(value, name).quantize(QTY_QUANTUM, rounding=rounding)


def _validate_execution_evidence(evidence: dict[str, Any], order: sqlite3.Row,
                                 quantity: Decimal, vwap: Decimal, fee: Decimal,
                                 gross: Decimal) -> None:
    """Refuse ledger fills without internally consistent, two-snapshot evidence."""
    try:
        quote, execution = evidence["quote"], evidence["execution"]
        identity = evidence["identity"]
        cfg = evidence["rule_config"]
        expected = {"condition_id":order["condition_id"],"token_id":order["token_id"],"outcome":order["outcome"]}
        if (identity != expected or quote["identity"] != expected or execution["identity"] != expected
                or evidence["side"] != order["side"] or evidence["status"] not in {"FILLED","PARTIAL"}
                or evidence["rule_version"] != order["rule_version"] or evidence["engine_version"] != order["engine_version"]
                or evidence["signal_id"] != order["signal_id"] or evidence["idempotency_key"] != order["idempotency_key"]
                or _qty(evidence["target_quantity"],"target_quantity") != _qty(order["target_quantity"],"target_quantity")):
            raise ValueError
        market_state=evidence["market_state"]
        local_model=order["engine_version"]=="strict-paper-engine-v4"
        v3=order["engine_version"] in {"strict-paper-engine-v3","strict-paper-engine-v4"}
        if local_model and (cfg.get("timestamp_model")!="LOCAL_CAUSAL_OBSERVATION_V1"
                or cfg.get("book_freshness_basis")!="LOCAL_RESPONSE_RECEIVED_AT"
                or cfg.get("upstream_timestamp_role")!="PROVENANCE_ONLY"
                or cfg.get("quote_causality_basis")!="LOCAL_REQUEST_AFTER_EDGE_DETECTION"
                or cfg.get("execution_newness_basis")!="DISTINCT_REQUEST_AFTER_FROZEN_LATENCY"):
            raise ValueError
        if market_state["closed"] or market_state["resolved"] or (v3 and market_state.get("accepting_orders") is not True): raise ValueError
        if (not quote["snapshot_id"] or not execution["snapshot_id"] or not quote["request_id"] or not execution["request_id"]
                or quote["snapshot_id"] == execution["snapshot_id"] or quote["request_id"] == execution["request_id"]):
            raise ValueError
        parse=lambda raw: datetime.fromisoformat(raw.replace("Z","+00:00"))
        qt,qr,qrecv=map(parse,(quote["source_timestamp"],quote["request_timestamp"],quote["received_timestamp"]))
        et,er,erecv=map(parse,(execution["source_timestamp"],execution["request_timestamp"],execution["received_timestamp"]))
        observed=parse(evidence["observed_at"])
        state_observed=parse(market_state["observed_at"])
        if any(x.tzinfo is None or x.utcoffset() is None for x in (qt,qr,qrecv,et,er,erecv,observed)):
            raise ValueError
        if state_observed.tzinfo is None or state_observed.utcoffset() is None: raise ValueError
        # Gamma's source updatedAt is provenance only. A newly received
        # Gamma response is established by EDGE's request/receive timestamps;
        # the source record itself may legitimately have been updated hours ago.
        state_source_raw=market_state.get("source_timestamp")
        state_request_raw=market_state.get("request_timestamp")
        state_received_raw=market_state.get("received_timestamp")
        if v3 and (state_request_raw is None or state_received_raw is None): raise ValueError
        if state_request_raw is not None or state_received_raw is not None:
            if state_request_raw is None or state_received_raw is None: raise ValueError
            state_request,state_received=map(parse,(state_request_raw,state_received_raw))
            if (state_request.tzinfo is None or state_received.tzinfo is None
                    or state_request.utcoffset() is None or state_received.utcoffset() is None
                    or state_request>state_received or state_received!=state_observed):
                raise ValueError
        if state_source_raw is not None:
            state_source=parse(state_source_raw)
            if state_source.tzinfo is None or state_source.utcoffset() is None:
                raise ValueError
        fee_times=[market_state.get("fee_request_timestamp"),market_state.get("fee_received_timestamp")]
        if any(value is not None for value in fee_times):
            if any(value is None for value in fee_times) or not market_state.get("fee_source"): raise ValueError
            fee_requested,fee_received=map(parse,fee_times)
            if (fee_requested.tzinfo is None or fee_received.tzinfo is None or fee_requested>fee_received
                    or fee_received>observed or market_state.get("fee_rate") is None
                    or _d(market_state["fee_rate"],"market_fee_rate")!=_d(evidence["fee_rate"],"fee_rate")
                    or market_state["fee_source"]!=evidence["fee_source"]):
                raise ValueError
        latency=int(evidence["execution_latency_ms"])
        if ((not local_model and (qt>qrecv or et<=qt or et>erecv)) or qr>qrecv or er>erecv or qrecv>observed or qr>observed
                or er<qrecv or (er-qrecv).total_seconds()*1000<latency or erecv>observed):
            raise ValueError
        if latency != int(cfg["execution_latency_ms"]): raise ValueError
        max_age=int(cfg["max_book_age_ms"])
        if ((not local_model and ((qrecv-qt).total_seconds()*1000>max_age or (erecv-et).total_seconds()*1000>max_age))
                or (local_model and (observed-qrecv).total_seconds()*1000>max_age)
                or (v3 and (observed-erecv).total_seconds()*1000>max_age)
                or state_observed>observed or (observed-state_observed).total_seconds()*1000>max_age):
            raise ValueError
        if not quote.get("source") or not execution.get("source") or not market_state.get("source"): raise ValueError
        edge_time=evidence.get("edge_detected_timestamp")
        if edge_time is not None:
            edge_detected=parse(edge_time)
            if edge_detected.tzinfo is None or edge_detected.utcoffset() is None or qr<edge_detected or (not local_model and qt<edge_detected):
                raise ValueError
        levels=evidence["fills"]
        if not levels: raise ValueError
        visible={}
        book_side=execution["asks"] if order["side"]=="BUY" else execution["bids"]
        quote_side=quote["asks"] if order["side"]=="BUY" else quote["bids"]
        if not book_side or not quote_side: raise ValueError
        for raw_price,raw_qty in book_side:
            p,q=_d(raw_price,"book_price"),_qty(raw_qty,"book_quantity")
            visible[p]=visible.get(p,Decimal("0"))+q
        sorted_prices=sorted(visible,reverse=(order["side"]=="SELL"))
        if list(visible)!=sorted_prices: raise ValueError
        quote_best=_d(quote_side[0][0],"quote_price")
        execution_best=_d(book_side[0][0],"execution_price")
        if not v3:
            threshold=_d(cfg["near_certainty_threshold"],"near_threshold")
            state_probability=market_state.get("token_probability")
            if ((state_probability is not None and (_d(state_probability,"state_probability")>=threshold or _d(state_probability,"state_probability")<=1-threshold))
                    or execution_best>=threshold or execution_best<=1-threshold):
                raise ValueError
        adverse=(execution_best-quote_best) if order["side"]=="BUY" else (quote_best-execution_best)
        if not v3 and adverse>_d(cfg["max_adverse_move"],"max_adverse_move"): raise ValueError
        fraction=_d(cfg["max_visible_depth_fraction"],"depth_fraction")
        if fraction<=0 or fraction>1: raise ValueError
        if evidence.get("status")=="PARTIAL" and (not cfg["allow_partial_fills"] or not evidence.get("allow_partial_requested")):
            raise ValueError
        level_qty=Decimal("0"); level_gross=Decimal("0"); level_fees=Decimal("0")
        fee_rate=_d(evidence["fee_rate"],"fee_rate")
        consumed={}
        fill_prices=[_d(raw_price,"price") for raw_price,_ in levels]
        if fill_prices!=sorted(fill_prices,reverse=(order["side"]=="SELL")):
            raise ValueError
        for raw_price,raw_qty in levels:
            p,q=_d(raw_price,"price"),_qty(raw_qty,"quantity")
            if p<=0 or p>=1 or q<=0: raise ValueError
            if not executable_level(p,q,_qty(cfg["min_quantity"],"min_quantity")):
                raise ValueError
            level_qty+=q; level_gross+=_money(p*q,"level_gross")
            consumed[p]=consumed.get(p,Decimal("0"))+q
            if p not in visible or consumed[p]>(visible[p]*fraction).quantize(QTY_QUANTUM,rounding=ROUND_DOWN):
                raise ValueError
            level_fees+=(q*fee_rate*p*(Decimal("1")-p)).quantize(MONEY_QUANTUM,rounding=ROUND_UP)
        if v3 and order["side"] == "BUY":
            eligible_prices = [p for p in sorted_prices
                               if executable_level(p, (visible[p]*fraction).quantize(QTY_QUANTUM,rounding=ROUND_DOWN),
                                                   _qty(cfg["min_quantity"],"min_quantity"))]
            if not eligible_prices or fill_prices[0] != eligible_prices[0]:
                raise ValueError
            for cheaper, dearer in zip(eligible_prices, eligible_prices[1:]):
                if dearer in fill_prices and consumed.get(cheaper,Decimal("0")) != (visible[cheaper]*fraction).quantize(QTY_QUANTUM,rounding=ROUND_DOWN):
                    raise ValueError
        raw_amount=sum((p*q for p,q in visible.items()),Decimal("0"))
        strict_amount=sum((p*q*fraction for p,q in visible.items()),Decimal("0"))
        level_vwap=(level_gross/level_qty).quantize(MONEY_QUANTUM,rounding=ROUND_DOWN)
        if (level_qty!=quantity or level_gross!=gross or level_vwap!=vwap
                or _money(evidence["total_fee"],"evidence_fee")!=fee or _money(evidence["total_cost"],"evidence_cost")!=gross
                or _money(level_fees,"recomputed_fee",rounding=ROUND_UP)!=fee or not evidence.get("fee_source")
                or _d(evidence["raw_visible_executable_amount"],"raw_depth")!=raw_amount
                or _d(evidence["strict_allowed_executable_amount"],"strict_depth")!=strict_amount):
            raise ValueError
        intent_amount=_d(evidence["intent_amount"],"intent_amount")
        target=_qty(evidence["target_quantity"],"target_quantity")
        v2_buy=order["side"]=="BUY" and order["engine_version"] in {"strict-paper-engine-v2","strict-paper-engine-v3","strict-paper-engine-v4"}
        expected_target=(Decimal("0") if v2_buy else
                         _qty(intent_amount/quote_best,"target_quantity") if order["side"]=="BUY" else intent_amount.quantize(QTY_QUANTUM))
        if target!=expected_target or (order["side"]=="BUY" and gross>_money(intent_amount,"intent_amount")):
            raise ValueError
        if v2_buy:
            requested=_money(evidence["requested_notional"],"requested_notional")
            filled=_money(evidence["filled_notional"],"filled_notional")
            unfilled=_money(evidence["unfilled_notional"],"unfilled_notional")
            if (evidence.get("buy_budget_definition")!="GROSS_NOTIONAL_EXCLUDING_FEES"
                    or requested!=_money(order["requested_notional"],"order_notional")
                    or requested!=_money(intent_amount,"intent_amount") or filled!=gross
                    or filled+unfilled!=requested or unfilled<0
                    or (evidence["status"]=="PARTIAL")!=(unfilled>MONEY_QUANTUM)
                    or _qty(evidence["unfilled_quantity"],"unfilled_quantity")!=0):
                raise ValueError
        if v3:
            if cfg.get("execution_policy")!="WALLET_FOLLOW_V2" or cfg.get("adverse_price_gate")!="OBSERVE_ONLY" or cfg.get("near_certainty_gate")!="DISABLED":
                raise ValueError
            if order["side"]=="BUY":
                floor=_d(cfg["min_net_roi_if_win"],"min_roi")
                capital=gross+fee
                profit=(quantity-capital).quantize(MONEY_QUANTUM,rounding=ROUND_DOWN)
                roi=((quantity-capital)/capital).quantize(Decimal("0.00000001"),rounding=ROUND_DOWN)
                if (floor<0 or (quantity-capital)/capital<floor
                        or _d(evidence["min_net_roi_if_win"],"min_roi")!=floor
                        or _money(evidence["projected_net_profit_if_win"],"projected_profit")!=profit
                        or _d(evidence["projected_net_roi_if_win"],"projected_roi")!=roi):
                    raise ValueError
    except (KeyError, TypeError, ValueError, InvalidOperation, AttributeError):
        raise ValueError("INVALID_EXECUTION_EVIDENCE") from None


class StrictPaperLedger:
    def __init__(self, path: str | Path, account_id: str = "strict-paper-v1"):
        self.path = str(path)
        self.account_id = account_id

    @contextmanager
    def _tx(self):
        con = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=5000")
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("BEGIN IMMEDIATE")
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    @staticmethod
    def initialize(path: str | Path) -> None:
        """Create only absent strict-paper tables and triggers (additive)."""
        p = str(path)
        Path(p).parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(p, timeout=30)
        try:
            con.execute("PRAGMA foreign_keys=ON")
            con.executescript("""
            CREATE TABLE IF NOT EXISTS strict_accounts (
                account_id TEXT PRIMARY KEY, ledger_version TEXT NOT NULL,
                initial_cash TEXT NOT NULL CHECK(CAST(initial_cash AS REAL) >= 0),
                available_cash TEXT NOT NULL CHECK(CAST(available_cash AS REAL) >= 0),
                reserved_cash TEXT NOT NULL CHECK(CAST(reserved_cash AS REAL) >= 0),
                realized_cash_flows TEXT NOT NULL, fees_total TEXT NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_rule_versions (
                rule_version TEXT PRIMARY KEY, engine_version TEXT NOT NULL,
                config_json TEXT NOT NULL, frozen_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_decisions (
                decision_id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                idempotency_key TEXT NOT NULL UNIQUE, signal_id TEXT NOT NULL,
                condition_id TEXT NOT NULL, token_id TEXT NOT NULL, outcome TEXT NOT NULL,
                side TEXT NOT NULL CHECK(side IN ('BUY','SELL')), status TEXT NOT NULL,
                reason TEXT NOT NULL, engine_version TEXT NOT NULL, rule_version TEXT NOT NULL,
                evidence_json TEXT NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_orders (
                order_id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                idempotency_key TEXT NOT NULL UNIQUE, signal_id TEXT NOT NULL,
                condition_id TEXT NOT NULL, token_id TEXT NOT NULL, outcome TEXT NOT NULL,
                side TEXT NOT NULL CHECK(side IN ('BUY','SELL')), status TEXT NOT NULL,
                target_quantity TEXT NOT NULL, remaining_quantity TEXT NOT NULL,
                reserve_cash_remaining TEXT NOT NULL, reserved_quantity_remaining TEXT NOT NULL,
                engine_version TEXT NOT NULL, rule_version TEXT NOT NULL,
                evidence_json TEXT NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_fills (
                fill_id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES strict_orders(order_id),
                account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                condition_id TEXT NOT NULL, token_id TEXT NOT NULL, outcome TEXT NOT NULL,
                side TEXT NOT NULL, quantity TEXT NOT NULL, vwap TEXT NOT NULL,
                gross_amount TEXT NOT NULL, fee TEXT NOT NULL, created_at TEXT NOT NULL,
                evidence_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_positions (
                account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                condition_id TEXT NOT NULL, token_id TEXT NOT NULL, outcome TEXT NOT NULL,
                quantity TEXT NOT NULL, reserved_quantity TEXT NOT NULL,
                cost_basis TEXT NOT NULL, realized_pnl TEXT NOT NULL,
                mark_price TEXT, mark_source TEXT, marked_at TEXT,
                unrealized_pnl TEXT, mark_evidence_json TEXT,
                PRIMARY KEY(account_id,condition_id,token_id,outcome)
            );
            CREATE TABLE IF NOT EXISTS strict_marks (
                mark_id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                condition_id TEXT NOT NULL, token_id TEXT NOT NULL, outcome TEXT NOT NULL,
                mark_price TEXT NOT NULL, source TEXT NOT NULL, observed_at TEXT NOT NULL,
                unrealized_pnl TEXT NOT NULL, evidence_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_cash_ledger (
                entry_id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                order_id TEXT, fill_id TEXT, entry_type TEXT NOT NULL,
                cash_flow TEXT NOT NULL, fee TEXT NOT NULL, created_at TEXT NOT NULL,
                details_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_settlements (
                settlement_id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                condition_id TEXT NOT NULL, token_id TEXT NOT NULL, outcome TEXT NOT NULL,
                status TEXT NOT NULL, authoritative_source TEXT, payout_per_share TEXT,
                quantity TEXT NOT NULL, cash_flow TEXT NOT NULL, observed_at TEXT NOT NULL,
                details_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS strict_audit_events (
                seq INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT NOT NULL UNIQUE,
                account_id TEXT NOT NULL REFERENCES strict_accounts(account_id),
                event_type TEXT NOT NULL, created_at TEXT NOT NULL, payload_json TEXT NOT NULL,
                prev_hash TEXT NOT NULL, event_hash TEXT NOT NULL
            );
            CREATE TRIGGER IF NOT EXISTS strict_audit_no_update
            BEFORE UPDATE ON strict_audit_events BEGIN SELECT RAISE(ABORT,'append-only audit'); END;
            CREATE TRIGGER IF NOT EXISTS strict_audit_no_delete
            BEFORE DELETE ON strict_audit_events BEGIN SELECT RAISE(ABORT,'append-only audit'); END;
            CREATE TRIGGER IF NOT EXISTS strict_fills_no_update
            BEFORE UPDATE ON strict_fills BEGIN SELECT RAISE(ABORT,'append-only fills'); END;
            CREATE TRIGGER IF NOT EXISTS strict_fills_no_delete
            BEFORE DELETE ON strict_fills BEGIN SELECT RAISE(ABORT,'append-only fills'); END;
            CREATE TRIGGER IF NOT EXISTS strict_cash_no_update
            BEFORE UPDATE ON strict_cash_ledger BEGIN SELECT RAISE(ABORT,'append-only cash ledger'); END;
            CREATE TRIGGER IF NOT EXISTS strict_cash_no_delete
            BEFORE DELETE ON strict_cash_ledger BEGIN SELECT RAISE(ABORT,'append-only cash ledger'); END;
            CREATE TRIGGER IF NOT EXISTS strict_settlements_no_update
            BEFORE UPDATE ON strict_settlements BEGIN SELECT RAISE(ABORT,'append-only settlements'); END;
            CREATE TRIGGER IF NOT EXISTS strict_settlements_no_delete
            BEFORE DELETE ON strict_settlements BEGIN SELECT RAISE(ABORT,'append-only settlements'); END;
            CREATE TRIGGER IF NOT EXISTS strict_decisions_no_update
            BEFORE UPDATE ON strict_decisions BEGIN SELECT RAISE(ABORT,'append-only decisions'); END;
            CREATE TRIGGER IF NOT EXISTS strict_decisions_no_delete
            BEFORE DELETE ON strict_decisions BEGIN SELECT RAISE(ABORT,'append-only decisions'); END;
            CREATE TRIGGER IF NOT EXISTS strict_marks_no_update
            BEFORE UPDATE ON strict_marks BEGIN SELECT RAISE(ABORT,'append-only marks'); END;
            CREATE TRIGGER IF NOT EXISTS strict_marks_no_delete
            BEFORE DELETE ON strict_marks BEGIN SELECT RAISE(ABORT,'append-only marks'); END;
            CREATE INDEX IF NOT EXISTS strict_fills_order_idx ON strict_fills(order_id);
            CREATE INDEX IF NOT EXISTS strict_cash_account_idx ON strict_cash_ledger(account_id);
            """)
            # Existing isolated v1 accounts are retained. New v2 budget fields are additive.
            columns={row[1] for row in con.execute("PRAGMA table_info(strict_orders)")}
            for name in ("requested_notional", "remaining_notional"):
                if name not in columns:
                    con.execute(f"ALTER TABLE strict_orders ADD COLUMN {name} TEXT")
            con.commit()
        finally:
            con.close()

    def _audit(self, con: sqlite3.Connection, event_type: str, payload: dict[str, Any], created_at: str) -> None:
        previous = con.execute("SELECT event_hash FROM strict_audit_events ORDER BY seq DESC LIMIT 1").fetchone()
        prev_hash = previous[0] if previous else "0" * 64
        body = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        event_id = str(uuid.uuid4())
        canonical = json.dumps({"event_id": event_id, "account_id": self.account_id,
            "event_type": event_type, "created_at": created_at, "payload_json": body,
            "prev_hash": prev_hash}, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        con.execute("INSERT INTO strict_audit_events(event_id,account_id,event_type,created_at,payload_json,prev_hash,event_hash) VALUES(?,?,?,?,?,?,?)",
                    (event_id, self.account_id, event_type, created_at, body, prev_hash, digest))

    def create_account(self, initial_cash: Decimal | str | int, *, created_at: str) -> dict[str, str]:
        cash = _money(initial_cash, "initial_cash")
        if cash <= 0 or not created_at:
            raise ValueError("INVALID_INITIAL_CASH")
        with self._tx() as con:
            pool = pool_for(con, self.account_id)
            if pool:
                # A new wallet opens an attribution book, never new capital.
                cash = Decimal('0.000000')
            if con.execute("SELECT 1 FROM strict_accounts WHERE account_id=?", (self.account_id,)).fetchone():
                raise ValueError("ACCOUNT_ALREADY_EXISTS")
            con.execute("INSERT INTO strict_accounts VALUES(?,?,?,?,?,?,?,?)",
                        (self.account_id, LEDGER_VERSION, str(cash), str(cash), "0.000000", "0.000000", "0.000000", created_at))
            if not pool:
                con.execute("INSERT INTO strict_cash_ledger VALUES(?,?,?,?,?,?,?,?,?)",
                            (str(uuid.uuid4()), self.account_id, None, None, "INITIAL_CASH", str(cash), "0.000000", created_at, "{}"))
            self._audit(con, "ACCOUNT_CREATED", {"initial_cash": str(cash), "ledger_version": LEDGER_VERSION,
                **({"cash_account_id":pool['cash_account_id'],"funding_version":pool['funding_version']} if pool else {})}, created_at)
        return self.account()

    def account(self) -> dict[str, str] | None:
        with sqlite3.connect(self.path) as con:
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM strict_accounts WHERE account_id=?", (cash_owner(con, self.account_id),)).fetchone()
            return dict(row) if row else None

    def book_account(self) -> dict[str, str] | None:
        with sqlite3.connect(self.path) as con:
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM strict_accounts WHERE account_id=?", (self.account_id,)).fetchone()
            return dict(row) if row else None

    def record_decision(self, decision: ExecutionDecision, intent: Any, *, created_at: str) -> bool:
        """Persist both accepted and rejected decisions without creating a fill."""
        evidence=decision.to_evidence(intent)
        if (decision.idempotency_key!=intent.idempotency_key or decision.signal_id!=intent.signal_id
                or decision.identity!=intent.identity or decision.side!=intent.side):
            raise ValueError("DECISION_INTENT_MISMATCH")
        evidence_json=json.dumps(evidence,sort_keys=True,separators=(",",":"))
        config_json=json.dumps(evidence["rule_config"],sort_keys=True,separators=(",",":"))
        with self._tx() as con:
            existing=con.execute("SELECT evidence_json FROM strict_decisions WHERE idempotency_key=?",(decision.idempotency_key,)).fetchone()
            if existing:
                if existing[0]==evidence_json:return False
                raise ValueError("DECISION_IDEMPOTENCY_CONFLICT")
            if not con.execute("SELECT 1 FROM strict_accounts WHERE account_id=?",(self.account_id,)).fetchone():
                raise ValueError("ACCOUNT_NOT_FOUND")
            frozen=con.execute("SELECT engine_version,config_json FROM strict_rule_versions WHERE rule_version=?",(decision.rule_version,)).fetchone()
            if frozen and tuple(frozen)!=(decision.engine_version,config_json):
                raise ValueError("FROZEN_RULE_VERSION_CONFLICT")
            if not frozen:
                con.execute("INSERT INTO strict_rule_versions VALUES(?,?,?,?)",(decision.rule_version,decision.engine_version,config_json,created_at))
            con.execute("INSERT INTO strict_decisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (decision.idempotency_key,self.account_id,decision.idempotency_key,decision.signal_id,
                 decision.identity.condition_id,decision.identity.token_id,decision.identity.outcome,decision.side,
                 decision.status,decision.reason,decision.engine_version,decision.rule_version,evidence_json,created_at))
            self._audit(con,"DECISION_RECORDED",{"decision_id":decision.idempotency_key,"signal_id":decision.signal_id,
                "identity":decision.identity.key(),"side":decision.side,"status":decision.status,"reason":decision.reason,
                "engine_version":decision.engine_version,"rule_version":decision.rule_version},created_at)
        return True

    def submit_order(self, *, order_id: str, idempotency_key: str, signal_id: str,
                     identity: MarketIdentity, side: str, target_quantity: Any,
                     reserve_cash: Any = "0", engine_version: str, rule_version: str,
                      evidence: dict[str, Any], created_at: str,
                      requested_notional: Any | None = None) -> bool:
        qty, cash = _qty(target_quantity, "target_quantity"), _money(reserve_cash, "reserve_cash")
        v2_buy=side == "BUY" and engine_version in {"strict-paper-engine-v2","strict-paper-engine-v3","strict-paper-engine-v4"}
        budget = (_money(requested_notional if requested_notional is not None else evidence.get("requested_notional", evidence.get("intent_amount")), "requested_notional")
                  if v2_buy else None)
        if (side not in ("BUY", "SELL") or (qty < 0 if v2_buy else qty <= 0)
                or (v2_buy and (qty != 0 or budget is None or budget <= 0))
                or not all((order_id, idempotency_key, signal_id, created_at))):
            raise ValueError("INVALID_ORDER")
        if (side == "BUY" and cash <= 0) or (side == "SELL" and cash != 0):
            raise ValueError("INVALID_ORDER_RESERVATION")
        with self._tx() as con:
            order_evidence=dict(evidence)
            order_evidence["_ledger_order"]={"reserve_cash":str(cash),"target_quantity":str(qty),"side":side,
                "requested_notional":str(budget) if budget is not None else None,
                "identity":identity.key(),"signal_id":signal_id,"engine_version":engine_version,"rule_version":rule_version}
            funding=pool_for(con,self.account_id)
            if funding:
                order_evidence['_ledger_order']['funding_policy']={
                    'funding_version':funding['funding_version'],'cash_account_id':funding['cash_account_id'],
                    'fixed_initial_cash':funding['fixed_initial_cash']}
            evidence_json=json.dumps(order_evidence,sort_keys=True,separators=(",",":"))
            existing = con.execute("SELECT order_id,signal_id,condition_id,token_id,outcome,side,target_quantity,engine_version,rule_version,evidence_json,requested_notional FROM strict_orders WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            expected = (order_id, signal_id, identity.condition_id, identity.token_id, identity.outcome, side, str(qty), engine_version, rule_version, evidence_json, str(budget) if budget is not None else None)
            if existing:
                if tuple(existing) == expected:
                    return False
                raise ValueError("IDEMPOTENCY_CONFLICT")
            cash_id = cash_owner(con, self.account_id)
            acct = con.execute("SELECT * FROM strict_accounts WHERE account_id=?", (cash_id,)).fetchone()
            if not acct:
                raise ValueError("ACCOUNT_NOT_FOUND")
            rule_config=evidence.get("rule_config") or {"engine_version":engine_version,"rule_version":rule_version}
            config_json=json.dumps(rule_config,sort_keys=True,separators=(",",":"))
            frozen=con.execute("SELECT engine_version,config_json FROM strict_rule_versions WHERE rule_version=?",(rule_version,)).fetchone()
            if frozen and tuple(frozen)!=(engine_version,config_json):
                raise ValueError("FROZEN_RULE_VERSION_CONFLICT")
            if not frozen:
                con.execute("INSERT INTO strict_rule_versions VALUES(?,?,?,?)",(rule_version,engine_version,config_json,created_at))
            reserved_qty = Decimal("0")
            if side == "BUY":
                available = _money(acct["available_cash"], "available_cash")
                if cash > available:
                    raise ValueError("INSUFFICIENT_AVAILABLE_CASH")
                con.execute("UPDATE strict_accounts SET available_cash=?,reserved_cash=? WHERE account_id=?",
                            (str(available-cash), str(_money(acct["reserved_cash"], "reserved_cash")+cash), cash_id))
            else:
                pos = con.execute("SELECT quantity,reserved_quantity FROM strict_positions WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                                  (self.account_id, identity.condition_id, identity.token_id, identity.outcome)).fetchone()
                if not pos or qty > _qty(pos["quantity"], "position_quantity") - _qty(pos["reserved_quantity"], "reserved_quantity"):
                    raise ValueError("INSUFFICIENT_POSITION")
                reserved_qty = qty
                con.execute("UPDATE strict_positions SET reserved_quantity=? WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                            (str(_qty(pos["reserved_quantity"], "reserved_quantity")+qty), self.account_id, identity.condition_id, identity.token_id, identity.outcome))
            con.execute("INSERT INTO strict_orders(order_id,account_id,idempotency_key,signal_id,condition_id,token_id,outcome,side,status,target_quantity,remaining_quantity,reserve_cash_remaining,reserved_quantity_remaining,engine_version,rule_version,evidence_json,created_at,requested_notional,remaining_notional) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (order_id,self.account_id,idempotency_key,signal_id,identity.condition_id,identity.token_id,identity.outcome,
                 side,"OPEN",str(qty),str(qty),str(cash),str(reserved_qty),engine_version,rule_version,
                  evidence_json,created_at,str(budget) if budget is not None else None,str(budget) if budget is not None else None))
            self._audit(con,"ORDER_SUBMITTED",{"order_id":order_id,"signal_id":signal_id,"identity":identity.key(),"side":side,
                "target_quantity":str(qty),"reserve_cash":str(cash),"reserved_quantity":str(reserved_qty)},created_at)
            observe_capital(con, self.account_id, 'submit:'+order_id, 'RESERVATION', created_at)
        return True

    def apply_execution(self, *, fill_id: str, order_id: str, decision: ExecutionDecision,
                        intent: Any, created_at: str) -> bool:
        """Apply exactly the engine's aggregate fill and retain full evidence."""
        if decision.status not in ("FILLED", "PARTIAL") or decision.filled_quantity <= 0 or decision.vwap is None:
            raise ValueError("EXECUTION_HAS_NO_FILL")
        self.record_decision(decision,intent,created_at=created_at)
        if decision.identity != intent.identity or decision.side != intent.side:
            raise ValueError("EXECUTION_INTENT_MISMATCH")
        decision_evidence=decision.to_evidence(intent)
        with sqlite3.connect(self.path) as con:
            con.row_factory=sqlite3.Row
            order=con.execute("SELECT target_quantity,condition_id,token_id,outcome,side,engine_version,rule_version,idempotency_key,signal_id FROM strict_orders WHERE order_id=? AND account_id=?",(order_id,self.account_id)).fetchone()
            frozen=con.execute("SELECT engine_version,config_json FROM strict_rule_versions WHERE rule_version=?",(decision.rule_version,)).fetchone()
        if not order or (order["condition_id"],order["token_id"],order["outcome"],order["side"],_qty(order["target_quantity"],"target_quantity"),order["engine_version"],order["rule_version"],order["idempotency_key"],order["signal_id"]) != (
            decision.identity.condition_id,decision.identity.token_id,decision.identity.outcome,decision.side,_qty(decision.target_quantity,"target_quantity"),decision.engine_version,decision.rule_version,decision.idempotency_key,decision.signal_id):
            raise ValueError("EXECUTION_ORDER_MISMATCH")
        if not frozen or frozen["engine_version"]!=decision.engine_version or frozen["config_json"]!=json.dumps(decision_evidence["rule_config"],sort_keys=True,separators=(",",":")):
            raise ValueError("FROZEN_RULE_VERSION_CONFLICT")
        level_cost=sum((_money(_d(p,"fill_price")*_qty(q,"fill_quantity"),"level_cost") for p,q in decision.fills),Decimal("0"))
        if level_cost != _money(decision.total_cost,"execution_cost"):
            raise ValueError("EXECUTION_COST_EVIDENCE_MISMATCH")
        return self._apply_fill(fill_id=fill_id, order_id=order_id,
            quantity=decision.filled_quantity, vwap=decision.vwap,
            fee=decision.total_fee, created_at=created_at, gross_amount=decision.total_cost,
            evidence=decision_evidence)

    def _apply_fill(self, *, fill_id: str, order_id: str, quantity: Any, vwap: Any,
                   fee: Any, created_at: str, evidence: dict[str, Any], gross_amount: Any | None = None) -> bool:
        qty, price, fees = _qty(quantity,"fill_quantity"), _money(vwap,"vwap"), _money(fee,"fee",rounding=ROUND_UP)
        if qty <= 0 or price <= 0 or price >= 1 or fees < 0 or not fill_id:
            raise ValueError("INVALID_FILL")
        with self._tx() as con:
            evidence_json=json.dumps(evidence,sort_keys=True,separators=(",",":"))
            duplicate = con.execute("SELECT order_id,quantity,vwap,fee,created_at,evidence_json FROM strict_fills WHERE fill_id=?",(fill_id,)).fetchone()
            if duplicate:
                if tuple(duplicate)==(order_id,str(qty),str(price),str(fees),created_at,evidence_json):
                    return False
                raise ValueError("FILL_IDEMPOTENCY_CONFLICT")
            # One execution decision represents one observed execution snapshot.
            # A retry with a different caller-generated fill ID must not consume
            # the same visible book depth a second time on an open partial order.
            prior_decision_fill=con.execute(
                "SELECT fill_id FROM strict_fills WHERE order_id=? AND evidence_json=? LIMIT 1",
                (order_id,evidence_json)).fetchone()
            if prior_decision_fill:
                return False
            order = con.execute("SELECT * FROM strict_orders WHERE order_id=? AND account_id=?",(order_id,self.account_id)).fetchone()
            if not order or order["status"] != "OPEN":
                raise ValueError("ORDER_NOT_OPEN")
            frozen=con.execute("SELECT engine_version,config_json FROM strict_rule_versions WHERE rule_version=?",(order["rule_version"],)).fetchone()
            if (not frozen or frozen["engine_version"]!=order["engine_version"]
                    or frozen["config_json"]!=json.dumps(evidence.get("rule_config"),sort_keys=True,separators=(",",":"))):
                raise ValueError("FROZEN_RULE_VERSION_CONFLICT")
            remaining = _qty(order["remaining_quantity"],"remaining_quantity")
            v2=order["engine_version"] in {"strict-paper-engine-v2","strict-paper-engine-v3","strict-paper-engine-v4"}
            if (not v2 or order["side"]=="SELL") and qty > remaining:
                raise ValueError("FILL_EXCEEDS_ORDER")
            gross = _money(gross_amount if gross_amount is not None else qty*price,"gross_amount")
            _validate_execution_evidence(evidence,order,qty,price,fees,gross)
            ident = MarketIdentity(order["condition_id"],order["token_id"],order["outcome"])
            posrow = con.execute("SELECT * FROM strict_positions WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                                  (self.account_id,ident.condition_id,ident.token_id,ident.outcome)).fetchone()
            old_q = _qty(posrow["quantity"],"position_quantity") if posrow else Decimal("0")
            old_rq = _qty(posrow["reserved_quantity"],"reserved_quantity") if posrow else Decimal("0")
            old_basis = _money(posrow["cost_basis"],"cost_basis") if posrow else Decimal("0")
            old_realized = _money(posrow["realized_pnl"],"realized_pnl") if posrow else Decimal("0")
            old_mark = _d(posrow["mark_price"],"mark_price") if posrow and posrow["mark_price"] is not None else None
            old_mark_source = posrow["mark_source"] if posrow else None
            old_marked_at = posrow["marked_at"] if posrow else None
            old_mark_evidence = posrow["mark_evidence_json"] if posrow else None
            cashflow = -gross if order["side"] == "BUY" else gross
            cash_id = cash_owner(con, self.account_id)
            if order["side"] == "BUY":
                debit = gross + fees
                reserve_remaining = _money(order["reserve_cash_remaining"],"reserve_cash_remaining")
                if debit > reserve_remaining:
                    raise ValueError("FILL_EXCEEDS_CASH_RESERVATION")
                acct=con.execute("SELECT * FROM strict_accounts WHERE account_id=?",(cash_id,)).fetchone()
                con.execute("UPDATE strict_accounts SET reserved_cash=?,realized_cash_flows=?,fees_total=? WHERE account_id=?",
                    (str(_money(acct["reserved_cash"],"reserved_cash")-debit),str(_money(acct["realized_cash_flows"],"cash_flows")-gross),
                     str(_money(acct["fees_total"],"fees_total")+fees),cash_id))
                new_q, new_basis, realized = old_q+qty, old_basis+gross+fees, old_realized
            else:
                if qty > old_q or qty > old_rq:
                    raise ValueError("SELL_EXCEEDS_HELD_OR_RESERVED_SHARES")
                basis_out = (old_basis*qty/old_q).quantize(MONEY_QUANTUM,rounding=ROUND_DOWN) if old_q else Decimal("0")
                realized = old_realized + gross - fees - basis_out
                new_q, new_basis = old_q-qty, old_basis-basis_out
                acct=con.execute("SELECT * FROM strict_accounts WHERE account_id=?",(cash_id,)).fetchone()
                con.execute("UPDATE strict_accounts SET available_cash=?,realized_cash_flows=?,fees_total=? WHERE account_id=?",
                    (str(_money(acct["available_cash"],"available_cash")+gross-fees),str(_money(acct["realized_cash_flows"],"cash_flows")+gross),
                     str(_money(acct["fees_total"],"fees_total")+fees),cash_id))
                old_rq -= qty
                if v2:
                    # One-shot SELL: release this order's unfilled shares now.
                    old_rq -= _qty(order["reserved_quantity_remaining"],"reserved_quantity_remaining")-qty
            if new_q == 0: new_basis = Decimal("0")
            unrealized=(_money(old_mark*new_q,"unrealized_value")-new_basis) if old_mark is not None and new_q else Decimal("0") if old_mark is not None else None
            con.execute("INSERT INTO strict_positions(account_id,condition_id,token_id,outcome,quantity,reserved_quantity,cost_basis,realized_pnl,mark_price,mark_source,marked_at,unrealized_pnl,mark_evidence_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(account_id,condition_id,token_id,outcome) DO UPDATE SET quantity=excluded.quantity,reserved_quantity=excluded.reserved_quantity,cost_basis=excluded.cost_basis,realized_pnl=excluded.realized_pnl,mark_price=excluded.mark_price,mark_source=excluded.mark_source,marked_at=excluded.marked_at,unrealized_pnl=excluded.unrealized_pnl,mark_evidence_json=excluded.mark_evidence_json",
                (self.account_id,ident.condition_id,ident.token_id,ident.outcome,str(new_q),str(old_rq),str(new_basis),str(realized),
                 str(old_mark) if old_mark is not None else None,old_mark_source,old_marked_at,str(unrealized) if unrealized is not None else None,old_mark_evidence))
            if order["side"]=="SELL" or not v2:
                remaining -= qty
            reserve_cash_left = _money(order["reserve_cash_remaining"],"reserve_cash_remaining") - (gross+fees if order["side"]=="BUY" else Decimal("0"))
            status = ("PARTIALLY_FILLED" if evidence["status"]=="PARTIAL" else "FILLED") if v2 else "FILLED" if remaining == 0 else "OPEN"
            released_cash=reserve_cash_left if status != "OPEN" and order["side"] == "BUY" else Decimal("0")
            if released_cash:
                acct=con.execute("SELECT available_cash,reserved_cash FROM strict_accounts WHERE account_id=?",(cash_id,)).fetchone()
                con.execute("UPDATE strict_accounts SET available_cash=?,reserved_cash=? WHERE account_id=?",
                    (str(_money(acct["available_cash"],"available_cash")+reserve_cash_left),str(_money(acct["reserved_cash"],"reserved_cash")-reserve_cash_left),cash_id))
                reserve_cash_left=Decimal("0").quantize(MONEY_QUANTUM)
            if status == "FILLED" and order["side"] == "SELL" and old_rq and not v2:
                old_rq=Decimal("0")
            unfilled_notional=(_money(evidence["unfilled_notional"],"unfilled_notional") if v2 and order["side"]=="BUY" else None)
            con.execute("UPDATE strict_orders SET status=?,remaining_quantity=?,reserve_cash_remaining=?,reserved_quantity_remaining=?,remaining_notional=? WHERE order_id=?",
                        (status,str(remaining),str(reserve_cash_left),
                         str(Decimal("0")) if v2 and order["side"]=="SELL" else str(old_rq),
                         str(unfilled_notional) if unfilled_notional is not None else order["remaining_notional"],order_id))
            con.execute("INSERT INTO strict_fills VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (fill_id,order_id,self.account_id,ident.condition_id,ident.token_id,ident.outcome,order["side"],str(qty),str(price),str(gross),str(fees),created_at,
                 evidence_json))
            con.execute("INSERT INTO strict_cash_ledger VALUES(?,?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4()),cash_id,order_id,fill_id,"FILL",str(cashflow),str(fees),created_at,json.dumps({"quantity":str(qty),"price":str(price),**({"wallet_book_account_id":self.account_id} if cash_id!=self.account_id else {})},sort_keys=True)))
            self._audit(con,"FILL_APPLIED",{"fill_id":fill_id,"order_id":order_id,"identity":ident.key(),"side":order["side"],
                "quantity":str(qty),"vwap":str(price),"gross":str(gross),"fee":str(fees),
                "status":status,"released_cash":str(released_cash),
                "unfilled_notional":str(unfilled_notional) if unfilled_notional is not None else None},created_at)
            observe_capital(con, self.account_id, 'fill:'+fill_id, order['side']+'_FILL', created_at)
        return True

    def cancel_order_in_transaction(self, con: sqlite3.Connection, order_id: str, *,
                                    created_at: str, force: bool = False,
                                    reason: str = "CANCELLED") -> bool:
        """Cancel an order using a caller-owned transaction.

        Recovery uses this inside the transaction that synchronizes its V2
        episode, so released reservations and the recovery decision commit
        together. ``force`` is reserved for a no-fill recovery where the
        order's terminal label itself contradicts the absence of any fill.
        """
        order=con.execute("SELECT * FROM strict_orders WHERE order_id=? AND account_id=?",
                          (order_id,self.account_id)).fetchone()
        if not order:
            return False
        reserve_cash=_money(order["reserve_cash_remaining"],"reserve_cash_remaining")
        reserve_shares=_qty(order["reserved_quantity_remaining"],"reserved_quantity_remaining")
        already_clean=(order["status"]=="CANCELLED" and reserve_cash==0 and reserve_shares==0)
        if already_clean:
            return False
        if order["status"]!="OPEN" and not force:
            return False
        cash_id = cash_owner(con, self.account_id)
        acct=con.execute("SELECT available_cash,reserved_cash FROM strict_accounts WHERE account_id=?",
                         (cash_id,)).fetchone()
        if not acct:
            raise ValueError("ACCOUNT_NOT_FOUND")
        available=_money(acct["available_cash"],"available_cash")
        reserved=_money(acct["reserved_cash"],"reserved_cash")
        if reserve_cash > reserved:
            raise ValueError("CASH_RESERVATION_MISMATCH")
        if order["side"]=="SELL" and reserve_shares:
            ident=(self.account_id,order["condition_id"],order["token_id"],order["outcome"])
            pos=con.execute("SELECT reserved_quantity FROM strict_positions WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",ident).fetchone()
            if not pos or reserve_shares > _qty(pos["reserved_quantity"],"position_reserved_quantity"):
                raise ValueError("SHARE_RESERVATION_MISMATCH")
            con.execute("UPDATE strict_positions SET reserved_quantity=? WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                (str(_qty(pos["reserved_quantity"],"position_reserved_quantity")-reserve_shares),*ident))
        if reserve_cash:
            con.execute("UPDATE strict_accounts SET available_cash=?,reserved_cash=? WHERE account_id=?",
                (str(_money(available+reserve_cash,"available_cash")),
                 str(_money(reserved-reserve_cash,"reserved_cash")),cash_id))
        previous_status=order["status"]
        con.execute("UPDATE strict_orders SET status='CANCELLED',reserve_cash_remaining='0.000000',reserved_quantity_remaining='0.000000' WHERE order_id=? AND account_id=?",
                    (order_id,self.account_id))
        self._audit(con,"ORDER_CANCELLED",{"order_id":order_id,"previous_status":previous_status,
            "released_cash":str(reserve_cash),"released_shares":str(reserve_shares),"reason":reason},created_at)
        observe_capital(con, self.account_id, 'cancel:'+order_id, 'CANCELLATION', created_at)
        return True

    def cancel_order(self, order_id: str, *, created_at: str) -> bool:
        with self._tx() as con:
            return self.cancel_order_in_transaction(con,order_id,created_at=created_at)

    def record_settlement(self, *, settlement_id: str, identity: MarketIdentity, status: str,
                          observed_at: str, authoritative_source: str | None = None,
                          payout_per_share: Any | None = None, details: dict[str, Any] | None = None,
                          connection: sqlite3.Connection | None = None) -> bool:
        allowed={"MARKET_CLOSED","RESULT_PENDING","FORMALLY_RESOLVED","VOID","API_FAILURE"}
        if status not in allowed: raise ValueError("INVALID_SETTLEMENT_STATUS")
        payout=None
        if status=="FORMALLY_RESOLVED":
            if not authoritative_source: raise ValueError("MISSING_AUTHORITATIVE_RESOLUTION")
            payout=_d(payout_per_share,"payout_per_share")
            if payout<0 or payout>1: raise ValueError("INVALID_SETTLEMENT_PAYOUT")
        elif status == "VOID" and payout_per_share is not None:
            payout=validate_void_resolution(identity,authoritative_source,payout_per_share,details or {})
        elif payout_per_share is not None:
            raise ValueError("NONFINAL_SETTLEMENT_CANNOT_HAVE_PAYOUT")
        financial_final=status=="FORMALLY_RESOLVED" or (status=="VOID" and payout is not None)
        with (nullcontext(connection) if connection is not None else self._tx()) as con:
            cash_id = cash_owner(con, self.account_id)
            details_json=json.dumps(details or {},sort_keys=True,separators=(",",":"))
            existing=con.execute("SELECT condition_id,token_id,outcome,status,authoritative_source,payout_per_share,details_json FROM strict_settlements WHERE settlement_id=?",(settlement_id,)).fetchone()
            expected=(identity.condition_id,identity.token_id,identity.outcome,status,authoritative_source,str(payout) if payout is not None else None,details_json)
            if existing:
                if tuple(existing)==expected:return False
                raise ValueError("SETTLEMENT_IDEMPOTENCY_CONFLICT")
            pos=con.execute("SELECT * FROM strict_positions WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                (self.account_id,identity.condition_id,identity.token_id,identity.outcome)).fetchone()
            qty=_qty(pos["quantity"],"position_quantity") if pos else Decimal("0")
            flow=Decimal("0")
            released_reserve=Decimal("0")
            if financial_final and qty:
                flow=_money(qty*payout,"settlement_cash_flow")
                acct=con.execute("SELECT * FROM strict_accounts WHERE account_id=?",(cash_id,)).fetchone()
                con.execute("UPDATE strict_accounts SET available_cash=?,realized_cash_flows=? WHERE account_id=?",
                    (str(_money(acct["available_cash"],"available_cash")+flow),str(_money(acct["realized_cash_flows"],"cash_flows")+flow),cash_id))
                settlement_pnl=flow-_money(pos["cost_basis"],"cost_basis")
                settlement_evidence=json.dumps({"settlement_id":settlement_id,"source":authoritative_source,"payout_per_share":str(payout),"details":details or {}},sort_keys=True,separators=(",",":"))
                con.execute("UPDATE strict_positions SET quantity='0.000000',cost_basis='0.000000',reserved_quantity='0.000000',realized_pnl=?,mark_price=?,mark_source=?,marked_at=?,unrealized_pnl='0.000000',mark_evidence_json=? WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                    (str(_money(pos["realized_pnl"],"realized_pnl")+settlement_pnl),str(payout),authoritative_source,observed_at,settlement_evidence,self.account_id,identity.condition_id,identity.token_id,identity.outcome))
                con.execute("INSERT INTO strict_marks VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (f"settlement:{settlement_id}",self.account_id,identity.condition_id,identity.token_id,identity.outcome,str(payout),authoritative_source,observed_at,"0.000000",settlement_evidence))
                con.execute("INSERT INTO strict_cash_ledger VALUES(?,?,?,?,?,?,?,?,?)",
                    (str(uuid.uuid4()),cash_id,None,settlement_id,"FORMAL_SETTLEMENT",str(flow),"0.000000",observed_at,json.dumps({"payout_per_share":str(payout),**({"wallet_book_account_id":self.account_id} if cash_id!=self.account_id else {})},sort_keys=True)))
            if financial_final:
                open_orders=con.execute("SELECT order_id,side,reserve_cash_remaining FROM strict_orders WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=? AND status='OPEN'",
                    (self.account_id,identity.condition_id,identity.token_id,identity.outcome)).fetchall()
                released_reserve=sum((_money(row["reserve_cash_remaining"],"reserve_cash_remaining") for row in open_orders if row["side"]=="BUY"),Decimal("0"))
                if released_reserve:
                    acct=con.execute("SELECT available_cash,reserved_cash FROM strict_accounts WHERE account_id=?",(cash_id,)).fetchone()
                    con.execute("UPDATE strict_accounts SET available_cash=?,reserved_cash=? WHERE account_id=?",
                        (str(_money(acct["available_cash"],"available_cash")+released_reserve),str(_money(acct["reserved_cash"],"reserved_cash")-released_reserve),cash_id))
                con.execute("UPDATE strict_orders SET status='CANCELLED',reserve_cash_remaining='0.000000',reserved_quantity_remaining='0.000000' WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=? AND status='OPEN'",
                    (self.account_id,identity.condition_id,identity.token_id,identity.outcome))
                if pos:
                    con.execute("UPDATE strict_positions SET reserved_quantity='0.000000' WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                        (self.account_id,identity.condition_id,identity.token_id,identity.outcome))
            con.execute("INSERT INTO strict_settlements VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (settlement_id,self.account_id,identity.condition_id,identity.token_id,identity.outcome,status,authoritative_source,
                 str(payout) if payout is not None else None,str(qty),str(flow),observed_at,details_json))
            self._audit(con,"SETTLEMENT_RECORDED",{"settlement_id":settlement_id,"identity":identity.key(),"status":status,
                "source":authoritative_source,"payout_per_share":str(payout) if payout is not None else None,"quantity":str(qty),"cash_flow":str(flow),
                "released_buy_reserve":str(released_reserve)},observed_at)
            if financial_final and (qty or released_reserve):
                observe_capital(con, self.account_id, 'settle:'+settlement_id,
                    'SETTLEMENT' if qty else 'CANCELLATION', observed_at)
        return True

    def account_snapshot(self) -> dict[str, Any]:
        with sqlite3.connect(self.path) as con:
            con.row_factory=sqlite3.Row
            account=con.execute("SELECT * FROM strict_accounts WHERE account_id=?",(cash_owner(con, self.account_id),)).fetchone()
            positions=[dict(x) for x in con.execute("SELECT * FROM strict_positions WHERE account_id=? ORDER BY condition_id,token_id,outcome",(self.account_id,))]
            orders=[dict(x) for x in con.execute("SELECT * FROM strict_orders WHERE account_id=? ORDER BY created_at,order_id",(self.account_id,))]
            fills=[dict(x) for x in con.execute("SELECT * FROM strict_fills WHERE account_id=? ORDER BY created_at,fill_id",(self.account_id,))]
            decisions=[dict(x) for x in con.execute("SELECT * FROM strict_decisions WHERE account_id=? ORDER BY created_at,decision_id",(self.account_id,))]
            marks=[dict(x) for x in con.execute("SELECT * FROM strict_marks WHERE account_id=? ORDER BY rowid",(self.account_id,))]
        return {"account":dict(account) if account else None,"positions":positions,"orders":orders,"fills":fills,"decisions":decisions,"marks":marks}

    def mark_position(self, identity: MarketIdentity, book: BookSnapshot, *, observed_at: datetime,
                      max_age_ms: int = 3000) -> bool:
        """Mark a long outcome using an observed, fresh best bid; never infer missing depth."""
        if identity!=book.identity:
            raise ValueError("MARKET_IDENTITY_MISMATCH")
        if observed_at.tzinfo is None or observed_at.utcoffset() is None or max_age_ms<0:
            raise ValueError("INVALID_MARK_TIMESTAMP")
        now=observed_at.astimezone(timezone.utc)
        if (book.source_timestamp>book.received_timestamp or book.request_timestamp>book.received_timestamp
                or book.received_timestamp>now or (book.received_timestamp-book.source_timestamp).total_seconds()*1000>max_age_ms):
            raise ValueError("STALE_MARK_DATA")
        if not book.bids:
            return False
        mark=book.bids[0].price
        evidence=json.dumps({"book":book.to_evidence(),"mark_side":"best_bid"},sort_keys=True,separators=(",",":"))
        mark_id=hashlib.sha256(f"{self.account_id}|{identity.key()}|{book.snapshot_id}".encode()).hexdigest()
        timestamp=now.isoformat()
        with self._tx() as con:
            existing=con.execute("SELECT evidence_json,mark_price FROM strict_marks WHERE mark_id=?",(mark_id,)).fetchone()
            if existing:
                if tuple(existing)==(evidence,str(mark)):return False
                raise ValueError("MARK_IDEMPOTENCY_CONFLICT")
            pos=con.execute("SELECT quantity,cost_basis FROM strict_positions WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                (self.account_id,identity.condition_id,identity.token_id,identity.outcome)).fetchone()
            if not pos or _qty(pos["quantity"],"position_quantity")<=0:
                return False
            qty=_qty(pos["quantity"],"position_quantity")
            basis=_money(pos["cost_basis"],"cost_basis")
            unrealized=_money(mark*qty,"mark_value")-basis
            con.execute("UPDATE strict_positions SET mark_price=?,mark_source=?,marked_at=?,unrealized_pnl=?,mark_evidence_json=? WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                (str(mark),book.source,timestamp,str(unrealized),evidence,self.account_id,identity.condition_id,identity.token_id,identity.outcome))
            con.execute("INSERT INTO strict_marks VALUES(?,?,?,?,?,?,?,?,?,?)",
                (mark_id,self.account_id,identity.condition_id,identity.token_id,identity.outcome,str(mark),book.source,timestamp,str(unrealized),evidence))
            self._audit(con,"POSITION_MARKED",{"mark_id":mark_id,"identity":identity.key(),"price":str(mark),"source":book.source,
                "quantity":str(qty),"cost_basis":str(basis),"unrealized_pnl":str(unrealized),"snapshot_id":book.snapshot_id},timestamp)
        return True

    def verify_audit_chain(self) -> dict[str, Any]:
        with sqlite3.connect(self.path) as con:
            rows=con.execute("SELECT seq,event_id,account_id,event_type,created_at,payload_json,prev_hash,event_hash FROM strict_audit_events ORDER BY seq").fetchall()
        prev="0"*64
        for index,row in enumerate(rows,1):
            seq,event_id,account_id,event_type,created_at,payload_json,stored_prev,stored_hash=row
            canonical=json.dumps({"event_id":event_id,"account_id":account_id,"event_type":event_type,"created_at":created_at,
                "payload_json":payload_json,"prev_hash":prev},sort_keys=True,separators=(",",":"),ensure_ascii=False)
            digest=hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            if seq!=index or stored_prev!=prev or stored_hash!=digest:
                return {"ok":False,"events_checked":index-1,"failed_seq":seq}
            prev=stored_hash
        return {"ok":True,"events_checked":len(rows),"last_hash":prev}

    def reconcile(self) -> dict[str, Any]:
        """Independently rebuild positions and cash totals from fills/settlements."""
        snap=self.account_snapshot(); acct=snap["account"]
        if acct is None:return {"ok":False,"reason":"ACCOUNT_NOT_FOUND"}
        qtys:dict[tuple[str,str,str],Decimal]={}; bases:dict[tuple[str,str,str],Decimal]={}; realized_by_key:dict[tuple[str,str,str],Decimal]={}
        flows=fees=Decimal("0")
        for fill in snap["fills"]:
            key=(fill["condition_id"],fill["token_id"],fill["outcome"])
            q,p,g,f=(_qty(fill["quantity"],"quantity"),_d(fill["vwap"],"vwap"),_money(fill["gross_amount"],"gross"),_money(fill["fee"],"fee"))
            fees+=f
            if fill["side"]=="BUY": qtys[key]=qtys.get(key,Decimal("0"))+q; bases[key]=bases.get(key,Decimal("0"))+g+f; flows-=g
            else:
                old=qtys.get(key,Decimal("0")); basis=bases.get(key,Decimal("0"))
                out=(basis*q/old).quantize(MONEY_QUANTUM,rounding=ROUND_DOWN) if old else Decimal("0")
                qtys[key]=old-q; bases[key]=basis-out; flows+=g
                realized_by_key[key]=realized_by_key.get(key,Decimal("0"))+g-f-out
        with sqlite3.connect(self.path) as con:
            settlements=con.execute("SELECT condition_id,token_id,outcome,status,payout_per_share,quantity,cash_flow FROM strict_settlements WHERE account_id=? AND (status='FORMALLY_RESOLVED' OR (status='VOID' AND payout_per_share IS NOT NULL)) ORDER BY rowid",(self.account_id,)).fetchall()
            cash_events=con.execute("SELECT entry_type,cash_flow,fee FROM strict_cash_ledger WHERE account_id=?",(self.account_id,)).fetchall()
        for c,t,o,status,payout,q,flow in settlements:
            k=(c,t,o); flow_value=_money(flow,"settlement_flow")
            realized_by_key[k]=realized_by_key.get(k,Decimal("0"))+flow_value-bases.get(k,Decimal("0"))
            qtys[k]=Decimal("0"); bases[k]=Decimal("0"); flows+=flow_value
        # Cash ledger provides an independent total (includes initial cash).
        ledger_cash=sum((_money(row[1],"cash_flow")-_money(row[2],"fee") for row in cash_events),Decimal("0"))
        ledger_fees=sum((_money(row[2],"fee") for row in cash_events),Decimal("0"))
        reconstructed=(_money(acct["initial_cash"],"initial_cash")+flows-fees).quantize(MONEY_QUANTUM)
        right=_money(acct["available_cash"],"available_cash")+_money(acct["reserved_cash"],"reserved_cash")
        account_flows_ok=_money(acct["realized_cash_flows"],"account_cash_flows")==flows
        account_fees_ok=_money(acct["fees_total"],"account_fees")==fees
        stored_positions={(p["condition_id"],p["token_id"],p["outcome"]):(_qty(p["quantity"],"quantity"),_money(p["cost_basis"],"cost_basis"),_money(p["realized_pnl"],"realized_pnl")) for p in snap["positions"]}
        expected_positions={k:(qtys.get(k,Decimal("0")),bases.get(k,Decimal("0")),realized_by_key.get(k,Decimal("0"))) for k in set(qtys)|set(bases)|set(realized_by_key)}
        position_ok=all(stored_positions.get(k,(Decimal("0"),Decimal("0"),Decimal("0")))==v for k,v in expected_positions.items()) and all(v==(Decimal("0"),Decimal("0"),Decimal("0")) for k,v in stored_positions.items() if k not in expected_positions)
        latest_marks={}
        for mark in snap["marks"]: latest_marks[(mark["condition_id"],mark["token_id"],mark["outcome"])]=mark
        marks_ok=True
        for pos in snap["positions"]:
            key=(pos["condition_id"],pos["token_id"],pos["outcome"])
            latest=latest_marks.get(key)
            if latest:
                mark_price=_d(latest["mark_price"],"mark_price")
                expected_unrealized=_money(mark_price*_qty(pos["quantity"],"quantity"),"mark_value")-_money(pos["cost_basis"],"cost_basis")
                marks_ok &= (pos["mark_price"]==latest["mark_price"] and pos["mark_source"]==latest["source"]
                    and pos["marked_at"]==latest["observed_at"] and _money(pos["unrealized_pnl"],"unrealized_pnl")==expected_unrealized)
            else:
                marks_ok &= pos["mark_price"] is None and pos["unrealized_pnl"] is None
        expected_reserved_cash=sum((_money(o["reserve_cash_remaining"],"reserve_cash") for o in snap["orders"] if o["side"]=="BUY" and o["status"]=="OPEN"),Decimal("0"))
        reserved_shares_ok=True
        for pos in snap["positions"]:
            key=(pos["condition_id"],pos["token_id"],pos["outcome"])
            expected_reserved=sum((_qty(o["reserved_quantity_remaining"],"reserved_quantity") for o in snap["orders"]
                if o["side"]=="SELL" and o["status"]=="OPEN" and (o["condition_id"],o["token_id"],o["outcome"])==key),Decimal("0"))
            reserved_shares_ok &= expected_reserved==_qty(pos["reserved_quantity"],"reserved_quantity")
        remaining_ok=True
        fills_by_order:dict[str,Decimal]={}
        for fill in snap["fills"]: fills_by_order[fill["order_id"]]=fills_by_order.get(fill["order_id"],Decimal("0"))+_qty(fill["quantity"],"fill_quantity")
        for order in snap["orders"]:
            expected_remaining=(Decimal("0") if order["side"]=="BUY" and order["engine_version"] in {"strict-paper-engine-v2","strict-paper-engine-v3","strict-paper-engine-v4"} else
                max(Decimal("0"),_qty(order["target_quantity"],"target_quantity")-fills_by_order.get(order["order_id"],Decimal("0"))))
            remaining_ok &= expected_remaining==_qty(order["remaining_quantity"],"remaining_quantity")
            if order["side"]=="BUY" and order["engine_version"] in {"strict-paper-engine-v2","strict-paper-engine-v3","strict-paper-engine-v4"}:
                filled_gross=sum((_money(f["gross_amount"],"gross_amount") for f in snap["fills"] if f["order_id"]==order["order_id"]),Decimal("0"))
                remaining_ok &= (_money(order["requested_notional"],"requested_notional")-filled_gross
                    ==_money(order["remaining_notional"],"remaining_notional"))
        reservation_ok=expected_reserved_cash==_money(acct["reserved_cash"],"reserved_cash") and reserved_shares_ok
        with sqlite3.connect(self.path) as con:
            con.row_factory=sqlite3.Row
            con.execute('BEGIN')
            pool=pool_for(con,self.account_id)
            if pool:
                financial=reconcile_pool(con,pool)
                return {**financial,'pooled':True,
                    'ok':financial['ok'] and position_ok and reserved_shares_ok and remaining_ok and marks_ok,
                    'positions_match':position_ok,'reservations_match':financial['reservations_match'] and reserved_shares_ok,
                    'order_quantities_match':remaining_ok,'marks_match':marks_ok}
        return {"ok":reconstructed==right and ledger_cash==right and ledger_fees==fees and position_ok and reservation_ok and remaining_ok and account_flows_ok and account_fees_ok and marks_ok,
            "cash_reconstructed":str(reconstructed),"cash_accounted":str(right),"cash_ledger_total":str(ledger_cash),
            "fees_reconstructed":str(fees),"fees_cash_ledger":str(ledger_fees),"positions_match":position_ok,
            "reservations_match":reservation_ok,"order_quantities_match":remaining_ok,
            "account_cash_flows_match":account_flows_ok,"account_fees_match":account_fees_ok,"marks_match":marks_ok}


__all__=["StrictPaperLedger","LEDGER_VERSION"]
