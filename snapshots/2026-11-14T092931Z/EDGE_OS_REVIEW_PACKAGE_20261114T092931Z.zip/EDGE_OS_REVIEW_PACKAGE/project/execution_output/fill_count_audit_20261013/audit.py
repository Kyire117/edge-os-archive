"""Reproducible read-only paper-count and old/new lineage audit."""
from pathlib import Path
import collections
import csv
import hashlib
import json
import sqlite3
import sys
from datetime import datetime, timezone, timedelta
from decimal import Decimal

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
from app.strict_ledger import StrictPaperLedger

pointer = json.loads((OUT / 'snapshot_pointer.json').read_text(encoding='utf-8'))
snapshot = Path(pointer['path'])
con = sqlite3.connect(snapshot.as_uri() + '?mode=ro', uri=True)
con.row_factory = sqlite3.Row
con.execute('PRAGMA query_only=ON')
con.execute('BEGIN')
old = sqlite3.connect((ROOT / 'data/edge_mvp.db').as_uri() + '?mode=ro', uri=True)
old.row_factory = sqlite3.Row
old.execute('PRAGMA query_only=ON')
old.execute('BEGIN')

def rows(table, connection=con):
    return [dict(x) for x in connection.execute('SELECT * FROM "'+table+'"')]

def amount(values, field):
    return sum((Decimal(x[field] or '0') for x in values), Decimal(0))

def dt(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))

run = json.loads((ROOT / 'data/active_experiment.json').read_text(encoding='utf-8'))
activation = dt(run['started_at'])
episodes = rows('wallet_v2_episodes')
fills = rows('strict_fills')
orders = {x['order_id']:x for x in rows('strict_orders')}
accounts = rows('strict_accounts')
positions = rows('strict_positions')
events = {x['episode_id']:x for x in rows('wallet_v2_events') if x['event_type']=='FIRST'}
buy_fills = [x for x in fills if x['side']=='BUY']
sell_fills = [x for x in fills if x['side']=='SELL']
settlements = [x for x in rows('strict_settlements')
               if x['status'] in ('FORMALLY_RESOLVED','VOID') and Decimal(x['cash_flow'])!=0]
by_order = collections.defaultdict(list)
for fill in buy_fills:
    by_order[fill['order_id']].append(fill)
filled_episodes = [x for x in episodes if x['paper_status'] in ('FILLED','PARTIAL')]
closed = [x for x in filled_episodes if x['resolution_status']=='FORMALLY_RESOLVED']
pending = [x for x in filled_episodes if x['resolution_status'] not in ('FORMALLY_RESOLVED','VOID')]
initial = amount(accounts, 'initial_cash')
available = amount(accounts, 'available_cash')
reserved = amount(accounts, 'reserved_cash')
gross = amount(buy_fills, 'gross_amount')
fees = amount(buy_fills, 'fee')
payout = amount(settlements, 'cash_flow')
realized = amount(positions, 'realized_pnl')
open_cost = amount([x for x in positions if Decimal(x['quantity'])>0], 'cost_basis')
sell_net = amount(sell_fills,'gross_amount')-amount(sell_fills,'fee')
financial = {
    'account_count':len(accounts), 'initial_virtual_cash':str(initial),
    'available_cash':str(available),'reserved_cash':str(reserved),
    'cumulative_buy_gross':str(gross),'entry_fees':str(fees),
    'cumulative_buy_debit':str(gross+fees),'formal_payout_cash':str(payout),
    'sell_net':str(sell_net),'open_cost_basis':str(open_cost),'realized_pnl':str(realized),
    'cash_equation_matches':initial-gross-fees+payout+sell_net==available+reserved,
    'cost_basis_equation_matches':available+reserved+open_cost==initial+realized,
    'cash_is_virtual':True,
}
integrity = {'pre_activation_episodes':0,'pre_activation_fills':0,
             'duplicate_buy_orders_per_wallet_market':0,'multiple_buy_fills_per_order':0,
             'filled_episode_without_fill':0,'episode_financial_mismatch':0,
             'fill_without_episode':0,'over_25_gross_fills':0,
             'quote_execution_timing_failures':0,'identity_mismatches':0}
integrity['pre_activation_episodes']=sum(dt(x['first_leader_at'])<activation or dt(x['first_detected_at'])<activation for x in episodes)
integrity['pre_activation_fills']=sum(dt(x['created_at'])<activation for x in buy_fills)
groups=collections.Counter((x['account_id'],x['condition_id']) for x in buy_fills)
integrity['duplicate_buy_orders_per_wallet_market']=sum(n>1 for n in groups.values())
integrity['multiple_buy_fills_per_order']=sum(len(x)>1 for x in by_order.values())
integrity['over_25_gross_fills']=sum(Decimal(x['gross_amount'])>25 for x in buy_fills)
filled_ids={x['paper_order_id'] for x in filled_episodes}
integrity['fill_without_episode']=sum(x['order_id'] not in filled_ids for x in buy_fills)
for episode in filled_episodes:
    fs=by_order.get(episode['paper_order_id'],[])
    if not fs:
        integrity['filled_episode_without_fill']+=1
        continue
    if (amount(fs,'gross_amount')!=Decimal(episode['filled_notional'])
        or amount(fs,'quantity')!=Decimal(episode['filled_quantity'])
        or amount(fs,'fee')!=Decimal(episode['entry_fee'])):
        integrity['episode_financial_mismatch']+=1

first_morning=dt('2026-10-12T23:43:28.760881+00:00')
timing=[]
delay_groups=collections.Counter()
source_groups=collections.Counter()
for episode in filled_episodes:
    fill=by_order[episode['paper_order_id']][0]
    ev=json.loads(fill['evidence_json'])
    leader=dt(episode['first_leader_at']);detected=dt(episode['first_detected_at'])
    delay=(detected-leader).total_seconds()
    band='<=60s' if delay<=60 else '1-5min' if delay<=300 else '5-30min' if delay<=1800 else '>30min'
    delay_groups[band]+=1
    first=json.loads(events[episode['episode_id']]['evidence_json'])
    trade=first.get('trade') or {};raw=trade.get('raw') or {}
    source=(raw.get('_edge_ingest') or {}).get('source') or first.get('source') or 'UNKNOWN'
    source_groups[source]+=1
    q=ev['quote'];ex=ev['execution']
    timing_ok=(dt(q['request_timestamp'])>=detected
               and (dt(ex['request_timestamp'])-dt(q['received_timestamp'])).total_seconds()>=0.5
               and dt(ex['received_timestamp'])<=dt(ev['observed_at']))
    if not timing_ok:integrity['quote_execution_timing_failures']+=1
    identity=ev['identity']
    if (identity.get('condition_id'),str(identity.get('token_id')),identity.get('outcome'))!=(fill['condition_id'],fill['token_id'],fill['outcome']):
        integrity['identity_mismatches']+=1
    timing.append({'episode_id':episode['episode_id'],'fill_id':fill['fill_id'],'wallet':episode['wallet'],
        'leader_at_shanghai':leader.astimezone(timezone(timedelta(hours=8))).isoformat(),
        'detected_at_shanghai':detected.astimezone(timezone(timedelta(hours=8))).isoformat(),
        'filled_at_shanghai':dt(fill['created_at']).astimezone(timezone(timedelta(hours=8))).isoformat(),
        'detection_delay_seconds':delay,'source':source,'gross':fill['gross_amount'],'fee':fill['fee'],
        'status':episode['paper_status'],'resolution_status':episode['resolution_status']})

old_fills=rows('strict_fills',old);old_episodes=rows('wallet_v2_episodes',old)
old_fill_ids={x['fill_id'] for x in old_fills}
old_signals={x['first_signal_id'] for x in old_episodes}
overlap={'old_fill_count':len(old_fills),'old_episode_count':len(old_episodes),
         'shared_fill_ids':sum(x['fill_id'] in old_fill_ids for x in buy_fills),
         'shared_first_signal_ids':sum(x['first_signal_id'] in old_signals for x in episodes),
         'old_financial_results_used_in_new_dashboard':False,
         'strategy_name_still_v2':all(x['strategy_version']=='wallet-follow-v2.0' for x in episodes),
         'engine_versions':sorted({json.loads(x['evidence_json'])['engine_version'] for x in buy_fills})}
old_baseline=json.loads((ROOT/'execution_output/polygon_fast_path/continuous_start_20261012T073309Z/before_start.json').read_text(encoding='utf-8'))
overlap['archive_all_tables_unchanged']=True
for table,baseline in old_baseline['tables'].items():
    data=sorted(json.dumps(tuple(r),ensure_ascii=False,separators=(',',':'),default=str)
                for r in old.execute('SELECT * FROM "'+table.replace('"','""')+'"'))
    overlap['archive_all_tables_unchanged'] &= len(data)==baseline['count'] and hashlib.sha256('\n'.join(data).encode()).hexdigest()==baseline['sha256']

count_summary={'episodes':len(episodes),'full':sum(x['paper_status']=='FILLED' for x in episodes),
              'partial':sum(x['paper_status']=='PARTIAL' for x in episodes),'actual_buy_fills':len(buy_fills),
              'rejected':sum(x['paper_status']=='REJECTED' for x in episodes),
              'observed_unfinished':sum(x['paper_status']=='OBSERVED' for x in episodes),
              'settled_filled_episodes':len(closed),'pending_filled_episodes':len(pending),
              'closed_wins':sum(x['direction_correct']==1 for x in closed),
              'closed_losses':sum(x['direction_correct']==0 for x in closed),
              'filled_before_morning_restart':sum(dt(x['created_at'])<first_morning for x in buy_fills),
              'filled_after_morning_restart':sum(dt(x['created_at'])>=first_morning for x in buy_fills)}
cancelled=con.execute("SELECT COUNT(*) FROM strict_orders WHERE status='CANCELLED'").fetchone()[0]
wallets=rows('wallets')
monitor_errors=collections.Counter()
for wallet in wallets:
    error=wallet.get('last_error')
    if error:monitor_errors[error.split(':',2)[0]+':'+error.split(':',2)[1] if ':' in error else 'OTHER']+=1
con.rollback();con.close();old.rollback();old.close()
reconciliation={x['account_id']:{'ledger':StrictPaperLedger(snapshot,x['account_id']).reconcile(),
               'audit':StrictPaperLedger(snapshot,x['account_id']).verify_audit_chain()} for x in accounts}
report={'snapshot':pointer,'run_id':run['run_id'],'activation':run['started_at'],
        'counts':count_summary,'financial':financial,'integrity':integrity,'old_new_overlap':overlap,
        'fill_delay_distribution':dict(delay_groups),'fill_source_distribution':dict(source_groups),
        'largest_delay_seconds':max(x['detection_delay_seconds'] for x in timing),
        'fills_by_wallet':dict(collections.Counter(x['wallet'] for x in filled_episodes)),
        'cancelled_orders_without_replay':cancelled,'wallet_error_counts':dict(monitor_errors),
        'account_reconciliation':reconciliation,
        'all_accounts_reconcile':all(x['ledger']['ok'] and x['audit']['ok'] for x in reconciliation.values())}
(OUT/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'fill_lineage.csv').open('w',encoding='utf-8-sig',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(timing[0]));writer.writeheader();writer.writerows(timing)
print(json.dumps({k:v for k,v in report.items() if k!='account_reconciliation'},ensure_ascii=True,indent=2))
