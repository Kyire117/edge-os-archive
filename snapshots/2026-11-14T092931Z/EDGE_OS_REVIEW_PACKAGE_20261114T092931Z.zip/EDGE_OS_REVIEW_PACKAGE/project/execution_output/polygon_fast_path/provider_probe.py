"""Read-only public Polygon provider capability probe; no application DB imports."""
import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from websockets.asyncio.client import connect

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from app.polygon_fast_path import CONTRACTS, ORDERFILLED_TOPIC

URL='wss://polygon-bor-rpc.publicnode.com'
OUT=Path(__file__).resolve().parent/'forward_observation'
OUT.mkdir(exist_ok=True)

async def attempt(proxy_mode):
    result={'provider':'PublicNode Polygon Bor','endpoint':URL,'proxy_mode':proxy_mode,
            'at':datetime.now(timezone.utc).isoformat(),'ok':False}
    kwargs={'proxy':None} if proxy_mode=='direct' else {}
    try:
        async with connect(URL,open_timeout=12,ping_interval=10,ping_timeout=10,**kwargs) as socket:
            index=0
            async def rpc(method,params):
                nonlocal index
                index+=1
                await socket.send(json.dumps({'jsonrpc':'2.0','id':index,'method':method,'params':params}))
                async with asyncio.timeout(12):
                    while True:
                        msg=json.loads(await socket.recv())
                        if msg.get('id')==index:
                            if msg.get('error'): raise ValueError('PROVIDER_RPC_ERROR: '+str(msg['error'].get('code')))
                            return msg.get('result')
            result['chain_id']=int(await rpc('eth_chainId',[]),16)
            if result['chain_id']!=137:raise ValueError('WRONG_CHAIN_ID')
            result['head']=int(await rpc('eth_blockNumber',[]),16)
            result['contract_code_bytes']={a:(len(await rpc('eth_getCode',[a,'latest']))-2)//2 for a in CONTRACTS}
            result['logs_response_is_list']=isinstance(await rpc('eth_getLogs',[
                {'address':list(CONTRACTS),'topics':[ORDERFILLED_TOPIC],
                 'fromBlock':hex(result['head']-1),'toBlock':hex(result['head'])}]),list)
            subscription=await rpc('eth_subscribe',['logs',{'address':list(CONTRACTS),'topics':[ORDERFILLED_TOPIC]}])
            result['subscription_accepted']=bool(subscription)
            result['ok']=all(result['contract_code_bytes'].values()) and result['logs_response_is_list'] and bool(subscription)
            if subscription:await rpc('eth_unsubscribe',[subscription])
    except Exception as exc:
        result['error_type']=type(exc).__name__
        if isinstance(exc,ValueError):result['safe_error']=str(exc)
    return result

async def main():
    results=[]
    for proxy in ('auto','direct'):
        result=await attempt(proxy);results.append(result)
        print(json.dumps(result),flush=True)
        if result['ok']:break
    (OUT/'provider_probe.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    return 0 if any(r['ok'] for r in results) else 1

if __name__=='__main__':raise SystemExit(asyncio.run(main()))
