"""Explicit fresh forward run in a NEW file. Original experiment is never rewritten."""
import hashlib
import json
import sqlite3
import sys
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from edge_runtime import active_database, MANIFEST
from app.db import Database
from app.wallet_follow_v2 import StrategyConfig,WalletFollowV2

source=active_database()
at=datetime.now(timezone.utc)
stamp=at.strftime('%Y%m%dT%H%M%SZ')
run_id='FORWARD-'+stamp
destination=ROOT/'data'/('edge_forward_'+stamp+'.db')
assert not destination.exists() and destination!=source
src=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True);src.row_factory=sqlite3.Row
src.execute('PRAGMA query_only=ON');src.execute('BEGIN')
assert src.execute('PRAGMA quick_check').fetchone()[0]=='ok'
version=dict(src.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version='wallet-follow-v2.0'").fetchone())
config=StrategyConfig.from_evidence(json.loads(version['config_json']))
assert config.evidence()['live_orders'] is False
archive={'run_id':'ARCHIVE-'+stamp,'label':'之前的 V2 累计实验','database':str(source.relative_to(ROOT)),
    'episodes':src.execute('SELECT COUNT(*) FROM wallet_v2_episodes').fetchone()[0],
    'fills':src.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0],
    'realized_pnl':str(sum((Decimal(r[0]) for r in src.execute('SELECT realized_pnl FROM strict_positions')),Decimal('0'))),
    'preserved_read_only':True}
src.rollback();src.close()
db=Database(str(destination));db.init()
tables=['wallets','wallet_category_stats','wallet_public_profiles','trades',
        'wallet_candidates','research_identity','research_exclusions','research_ai_runs']
with sqlite3.connect(destination,uri=True) as con:
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('ATTACH DATABASE ? AS archive',(source.as_uri()+'?mode=ro',))
    existing={r[0] for r in con.execute("SELECT name FROM archive.sqlite_master WHERE type='table'")}
    for table in tables:
        if table not in existing:continue
        columns={r[1] for r in con.execute('PRAGMA archive.table_info("'+table+'")')}
        target=[r[1] for r in con.execute('PRAGMA main.table_info("'+table+'")') if r[1] in columns]
        names=','.join('"'+x.replace('"','""')+'"' for x in target)
        con.execute('INSERT INTO main."'+table+'" ('+names+') SELECT '+names+' FROM archive."'+table+'"')
    # This is only the new file's ingestion boundary, not an edit to old wallet history.
    con.execute('UPDATE wallets SET last_trade_ts=?,last_error=NULL',(int(at.timestamp()),))
WalletFollowV2.initialize(destination)
engine=WalletFollowV2(destination)
engine.create_version(config,created_at=at,evidence_cutoff=at);engine.activate(at=at)
with sqlite3.connect(destination) as con:
    con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES('CLEAN_FORWARD_RESTART',?,?)",
        (at.isoformat(),json.dumps({'run_id':run_id,'scope':'NEW_DATABASE_OLD_RECORDS_PRESERVED',
                                  'source_replay':False,'archive_database':archive['database']})))
    assert con.execute('PRAGMA quick_check').fetchone()[0]=='ok'
    assert con.execute('SELECT COUNT(*) FROM wallet_v2_episodes').fetchone()[0]==0
    assert con.execute('SELECT COUNT(*) FROM strict_fills').fetchone()[0]==0
old=json.loads(MANIFEST.read_text()) if MANIFEST.exists() else {}
manifest={'run_id':run_id,'label':'新实时前向模拟实验','started_at':at.isoformat(),
    'database':str(destination.relative_to(ROOT)),'strategy_version':'wallet-follow-v2.0','live_orders':False,
    'archives':old.get('archives',[])+[archive], 'initial_episodes':0,'initial_fills':0,
    'frozen_config':config.evidence()}
temp=MANIFEST.with_suffix('.tmp');temp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
temp.replace(MANIFEST)
out=ROOT/'execution_output/reliable_forward_restart_20261012'
(out/'new_experiment.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'run_id':run_id,'new_database':str(destination),'episodes':0,'fills':0,
                  'archive_episodes':archive['episodes'],'archive_fills':archive['fills']},ensure_ascii=True))
