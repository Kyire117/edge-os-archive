"""Synthetic fixtures only: no provider, production DB, or latency SLO evidence."""
import asyncio
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from types import SimpleNamespace

import pytest

from app import service
from app.db import Database
from app.fill_identity import strong_key
from app.polygon_fast_path import (CONTRACTS, ORDERFILLED_TOPIC, EventStore,
    PolygonProducer, ProducerConfig, TokenResolver, decode_log, integer,
    keccak256, latency_summary, normalize_event)
from app.polymarket import PolymarketClient, PolymarketError, normalize_trade

WALLET='0x'+'a'*40
COUNTERPARTY='0x'+'b'*40
CONDITION='0x'+'c'*64
TX='0x'+'d'*64
BLOCK='0x'+'e'*64
NOW=datetime(2026,10,10,tzinfo=timezone.utc)


def log(index=1, *, side=0, maker=WALLET, taker=COUNTERPARTY,
        making=2_000_000, taking=4_000_000, height=101, removed=False):
    return {'address':CONTRACTS[0], 'topics':[ORDERFILLED_TOPIC,'0x'+'1'*64,
        '0x'+'0'*24+maker[2:],'0x'+'0'*24+taker[2:]],
        'data':'0x'+''.join(format(v,'064x') for v in (side,123,making,taking,13,0,0)),
        'transactionHash':TX,'blockHash':BLOCK,'blockNumber':hex(height),
        'transactionIndex':'0x2','logIndex':hex(index),'removed':removed}


class Metadata:
    def __init__(self,fail=False): self.calls=0;self.fail=fail
    async def fast_token_metadata(self,token):
        self.calls+=1
        if self.fail: raise TimeoutError('unavailable')
        return {'token_id':token,'condition_id':CONDITION,'outcome':'YES',
                'source':'GAMMA_TOKEN_QUERY','title':'Fixture','category':'Politics'}


@pytest.fixture
def database(tmp_path):
    db=Database(str(tmp_path/'isolated.db'));db.init();db.upsert_wallet(WALLET)
    EventStore(db).initialize()
    return db


def state(db,event=None):
    with db.conn() as c:
        rows=c.execute('SELECT * FROM polygon_fast_events ORDER BY block_number,log_index').fetchall()
    if event:return next(dict(r) for r in rows if r['event_id']==event['event_id'])
    return [dict(r) for r in rows]


def producer(database, *, client=None, ingest=None, logs=None):
    calls=[]
    async def route(wallet,trade):calls.append((wallet,trade));return {'decision':'OBSERVED'}
    p=PolygonProducer(database,client or Metadata(),ingest or route,ProducerConfig())
    p.ready=True;p.refresh_wallets()
    async def rpc(method,params):
        if method=='eth_getBlockByNumber':return {'hash':BLOCK,'timestamp':hex(int(NOW.timestamp()))}
        if method=='eth_getTransactionReceipt':return {'blockHash':BLOCK,'status':'0x1','logs':logs or [log()]}
        if method=='eth_getLogs':return logs or [log()]
        raise AssertionError(method)
    p.rpc=rpc
    return p,calls


def normalized(index=1,unique=True):
    event=decode_log(log(index))
    return normalize_event(event,{'token_id':'123','condition_id':CONDITION,'outcome':'YES'},
        int(NOW.timestamp()),NOW.isoformat(),NOW.isoformat(),unique)


def polled(key='different-data-api-id', *, size='4',price='0.5'):
    return normalize_trade({'id':key,'asset':'123','conditionId':CONDITION,'outcome':'YES',
        'side':'BUY','price':price,'size':size,'transactionHash':TX,
        'timestamp':int(NOW.timestamp()),'title':'Fixture'},WALLET)


def gateway(monkeypatch,db):
    calls=[]
    monkeypatch.setattr(service,'db',db)
    async def route(wallet,trade,*args,**kwargs):calls.append(trade);return {'decision':'OBSERVED'}
    monkeypatch.setattr(service,'_process_new_trade_claimed',route)
    return calls


def test_keccak_ethereum_vectors():
    assert keccak256(b'')=='0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
    assert keccak256(b'Transfer(address,address,uint256)')=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
    assert keccak256(b'abc')=='0x4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45'


@pytest.mark.parametrize('side,making,taking,expected_side',[(0,2_000_000,4_000_000,'BUY'),(1,4_000_000,2_000_000,'SELL')])
def test_authoritative_amount_orientation_and_raw_evidence(side,making,taking,expected_side):
    raw=log(side=side,making=making,taking=taking);event=decode_log(raw)
    assert event['side']==expected_side
    assert Decimal(event['price'])==Decimal('0.5')
    assert Decimal(event['size'])==4 and Decimal(event['usd_value'])==2
    assert event['maker']==WALLET and event['taker']==COUNTERPARTY
    assert event['raw_log']==raw and event['transaction_index']==2
    assert event['fee_raw']=='13' and event['order_hash']=='0x'+'1'*64
    assert event['event_id'].endswith(':1')


def test_large_integer_amounts_never_use_float():
    event=decode_log(log(making=2**200,taking=2**201))
    with __import__('decimal').localcontext() as ctx:
        ctx.prec=100
        assert Decimal(event['usd_value'])==Decimal(2**200)/10**6
        assert Decimal(event['size'])==Decimal(2**201)/10**6


@pytest.mark.parametrize('bad',[True,1.2,-1,'0x','-2','3.5',None])
def test_chain_integer_fail_closed(bad):
    with pytest.raises((ValueError,TypeError)):integer(bad)


@pytest.mark.parametrize('change',[{'topics':[None]*4},{'data':'0x01'},
    {'address':'0x'+'0'*40},{'transactionHash':'not-a-hash'}, {'logIndex':1.5}])
def test_malformed_log_never_normalizes(change):
    raw=log();raw.update(change)
    with pytest.raises((ValueError,TypeError)):decode_log(raw)


def test_invalid_side_or_price_rejected():
    for raw in (log(side=2),log(making=5_000_000,taking=4_000_000)):
        with pytest.raises(ValueError):decode_log(raw)


def test_only_order_owner_is_tracked_and_wallet_changes_are_live(database):
    p,calls=producer(database,logs=[log()])
    p.stage(log(maker=COUNTERPARTY,taker=WALLET))
    assert state(database)==[]  # counterparty presence never creates an event
    p.stage(log());asyncio.run(p.process_pending(101))
    assert len(calls)==1 and calls[0][1]['wallet']==WALLET
    database.upsert_wallet(COUNTERPARTY);p.refresh_wallets()
    assert COUNTERPARTY in p.tracked


def test_confirmation_depth_defers_gateway(database):
    p,calls=producer(database);p.stage(log())
    asyncio.run(p.process_pending(100));assert not calls
    asyncio.run(p.process_pending(101));assert len(calls)==1


def test_metadata_fallback_cache_and_exact_mapping(database):
    client=Metadata();resolver=TokenResolver(database,client)
    first=asyncio.run(resolver.resolve('123'));second=asyncio.run(resolver.resolve('123'))
    assert first['source']=='GAMMA_TOKEN_QUERY' and second['source']=='CACHED_GAMMA'
    assert client.calls==1
    assert first['condition_id']==second['condition_id']==CONDITION


def test_local_source_mapping_precedes_network(database):
    database.insert_trade_if_new(WALLET,polled())
    client=Metadata(fail=True)
    mapped=asyncio.run(TokenResolver(database,client).resolve('123'))
    assert mapped['source']=='LOCAL_UPSTREAM_TRADE' and client.calls==0


def test_cache_is_bounded_and_wrong_identity_rejected(database):
    client=Metadata();resolver=TokenResolver(database,client,limit=2)
    for token in ('1','2','3'):asyncio.run(resolver.resolve(token))
    with database.conn() as c:assert c.execute('SELECT COUNT(*) FROM polygon_token_cache').fetchone()[0]==2
    async def wrong(token):return {'token_id':'different','condition_id':CONDITION,'outcome':'YES'}
    client.fast_token_metadata=wrong
    with pytest.raises(ValueError):asyncio.run(resolver.resolve('4'))


def test_metadata_pending_has_no_gateway_ownership_and_can_resolve_later(database):
    client=Metadata(fail=True);p,calls=producer(database,client=client);p.stage(log())
    asyncio.run(p.process_pending(101))
    assert state(database)[0]['state']=='PENDING_METADATA' and not calls
    with database.conn() as c:
        assert c.execute('SELECT COUNT(*) FROM fill_canonical').fetchone()[0]==0
        assert c.execute('SELECT COUNT(*) FROM trades WHERE is_seed=0').fetchone()[0]==0
    client.fail=False;asyncio.run(p.process_pending(101))
    assert len(calls)==1 and state(database)[0]['state']=='ROUTED'


@pytest.mark.parametrize('fast_first',[True,False])
def test_cross_source_different_ids_one_execution(database,monkeypatch,fast_first):
    calls=gateway(monkeypatch,database)
    async def run():
        if fast_first:
            await service.ingest_fast_path_trade({'address':WALLET},normalized())
            await service.process_new_trade({'address':WALLET},polled(),source='DATA_API_POLL')
        else:
            await service.process_new_trade({'address':WALLET},polled(),source='DATA_API_POLL')
            await service.ingest_fast_path_trade({'address':WALLET},normalized())
    asyncio.run(run());assert len(calls)==1
    with database.conn() as c:
        assert c.execute('SELECT COUNT(*) FROM trades WHERE is_seed=0').fetchone()[0]==1
        states=[r[0] for r in c.execute('SELECT state FROM fill_source_observations')]
    assert 'DUPLICATE_RECEIPT_EXACT_ECONOMICS' in states


@pytest.mark.parametrize('fast_first',[True,False])
@pytest.mark.parametrize('tx_hash',['',None,'not-a-hash','0x1234'])
def test_live_poll_insufficient_tx_identity_never_executes_twice(database,monkeypatch,fast_first,tx_hash):
    calls=gateway(monkeypatch,database)
    poll=polled(key='hashless-different-source-id')
    poll['tx_hash']=tx_hash
    poll['raw']['transactionHash']=tx_hash
    async def run():
        if fast_first:
            await service.ingest_fast_path_trade({'address':WALLET},normalized())
        assert await service.process_new_trade({'address':WALLET},poll,source='DATA_API_POLL') is None
        if not fast_first:
            assert not calls
            with database.conn() as c:
                assert c.execute('SELECT COUNT(*) FROM fill_canonical').fetchone()[0]==0
            await service.ingest_fast_path_trade({'address':WALLET},normalized())
        # Restart/re-observation keeps the insufficient observation non-executable.
        monkeypatch.setattr(service,'db',Database(database.path))
        assert await service.process_new_trade({'address':WALLET},poll,source='DATA_API_POLL') is None
    asyncio.run(run())
    assert len(calls)==1
    with database.conn() as c:
        assert c.execute('SELECT COUNT(*) FROM trades WHERE is_seed=0').fetchone()[0]==1
        audit=c.execute("SELECT * FROM fill_identity_audit WHERE source='DATA_API_POLL' ORDER BY id").fetchall()
        assert len(audit)==2
        assert all(r['state']=='AMBIGUOUS_INSUFFICIENT_TRANSACTION_IDENTITY' for r in audit)
        assert json.loads(audit[0]['evidence_json'])['trade']['raw']['transactionHash']==tx_hash
        observation=c.execute("SELECT * FROM fill_source_observations WHERE source='DATA_API_POLL'").fetchone()
        assert observation['canonical_id'] is None
        assert observation['state']=='AMBIGUOUS_INSUFFICIENT_TRANSACTION_IDENTITY'


def test_live_fast_gateway_missing_tx_also_fails_closed(database,monkeypatch):
    calls=gateway(monkeypatch,database)
    invalid=normalized();invalid['tx_hash']=''
    assert asyncio.run(service.ingest_fast_path_trade({'address':WALLET},invalid)) is None
    assert not calls
    with database.conn() as c:
        assert c.execute('SELECT COUNT(*) FROM fill_canonical').fetchone()[0]==0
        assert c.execute('SELECT state FROM fill_identity_audit').fetchone()[0]=='AMBIGUOUS_INSUFFICIENT_TRANSACTION_IDENTITY'


def test_non_live_direct_import_keeps_legacy_key_gate(database):
    poll=polled();poll['tx_hash']=''
    assert database.insert_trade_if_new(WALLET,poll,source='DIRECT')
    assert not database.insert_trade_if_new(WALLET,poll,source='DIRECT')


def test_exact_data_api_chain_metadata_dedupes(database,monkeypatch):
    calls=gateway(monkeypatch,database);poll=polled()
    poll['raw'].update({'chainId':137,'contractAddress':CONTRACTS[0],'logIndex':1})
    async def run():
        await service.ingest_fast_path_trade({'address':WALLET},normalized())
        await service.process_new_trade({'address':WALLET},poll,source='DATA_API_POLL')
    asyncio.run(run());assert len(calls)==1


def test_distinct_indexes_same_tx_partial_fills_remain_distinct(database,monkeypatch):
    calls=gateway(monkeypatch,database)
    async def run():
        for index in (1,2):
            await service.ingest_fast_path_trade({'address':WALLET},normalized(index,unique=False))
    asyncio.run(run());assert len(calls)==2
    assert calls[0]['raw']['order_hash']==calls[1]['raw']['order_hash']
    assert calls[0]['trade_key']!=calls[1]['trade_key']


def test_ambiguous_poll_is_recorded_not_mislabeled_duplicate(database,monkeypatch):
    calls=gateway(monkeypatch,database)
    async def run():
        for index in (1,2):await service.ingest_fast_path_trade({'address':WALLET},normalized(index,False))
        await service.process_new_trade({'address':WALLET},polled(),source='DATA_API_POLL')
    asyncio.run(run());assert len(calls)==2
    with database.conn() as c:
        row=c.execute("SELECT * FROM fill_source_observations WHERE source='DATA_API_POLL'").fetchone()
        assert row['state']=='AMBIGUOUS_CROSS_SOURCE_IDENTITY'
        assert row['canonical_id'] is None and 'different-data-api-id' in row['evidence_json']


def test_poll_first_ambiguous_receipt_never_guesses_second_fill(database,monkeypatch):
    calls=gateway(monkeypatch,database)
    async def run():
        await service.process_new_trade({'address':WALLET},polled(),source='DATA_API_POLL')
        for index in (1,2):await service.ingest_fast_path_trade({'address':WALLET},normalized(index,False))
    asyncio.run(run());assert len(calls)==1
    with database.conn() as c:
        assert c.execute("SELECT COUNT(*) FROM fill_source_observations WHERE state='AMBIGUOUS_CROSS_SOURCE_IDENTITY'").fetchone()[0]==2


def test_conflicting_same_chain_identity_fails_closed(database,monkeypatch):
    calls=gateway(monkeypatch,database);conflict=normalized();conflict['raw']['size']='8'
    async def run():
        await service.ingest_fast_path_trade({'address':WALLET},normalized())
        await service.process_new_trade({'address':WALLET},conflict,source='DATA_API_POLL')
    asyncio.run(run());assert len(calls)==1
    with database.conn() as c:
        assert c.execute("SELECT state FROM fill_source_observations WHERE source='DATA_API_POLL'").fetchone()[0]=='AMBIGUOUS_CHAIN_EVIDENCE_CONFLICT'


def test_producer_duplicate_and_ambiguous_states_are_separate(database,monkeypatch):
    calls=gateway(monkeypatch,database)
    asyncio.run(service.process_new_trade({'address':WALLET},polled(),source='DATA_API_POLL'))
    p,_=producer(database,ingest=service.ingest_fast_path_trade)
    p.stage(log());asyncio.run(p.process_pending(101))
    assert len(calls)==1 and state(database)[0]['state']=='RECONCILED_DUPLICATE'
    assert p.status()['duplicates_reconciled']==1


def test_backfill_restart_ordering_and_duplicate_safe_checkpoint(database):
    logs=[log(3,height=103),log(1,height=101),log(2,height=102)]
    p,calls=producer(database,logs=logs);p.store.checkpoint(100)
    asyncio.run(p.backfill(103))
    assert [t['raw']['log_index'] for _,t in calls]==[1,2,3]
    p2,calls2=producer(database,logs=logs)
    asyncio.run(p2.backfill(103));assert not calls2
    assert p2.store.checkpoint()==103
    for raw in logs:p2.stage(raw)
    asyncio.run(p2.process_pending(103));assert not calls2


def test_initial_boundary_no_historical_backfill_and_gap_fails_closed(database):
    p,calls=producer(database)
    async def forbidden(*args):raise AssertionError('historical request')
    p.rpc=forbidden;asyncio.run(p.backfill(100))
    assert p.store.checkpoint()==100 and not calls
    with pytest.raises(ValueError,match='BACKFILL_GAP_EXCEEDS_BOUND'):asyncio.run(p.backfill(229))
    p.store.forward_boundary(100);p.stage(log(height=100));assert state(database)==[]


@pytest.mark.parametrize('after_admission',[False,True])
def test_removed_logs_tombstone_and_post_admission_audit(database,after_admission):
    p,calls=producer(database)
    if after_admission:
        p.stage(log());asyncio.run(p.process_pending(101))
    p.stage(log(removed=True));p.stage(log())
    asyncio.run(p.process_pending(101))
    assert len(calls)==int(after_admission)
    assert state(database)[0]['state']==('REORG_AFTER_ADMISSION' if after_admission else 'REMOVED')


def test_canonical_block_mismatch_never_routes(database):
    p,calls=producer(database);p.stage(log())
    async def rpc(method,params):return {'hash':'0x'+'f'*64,'timestamp':'0x1'}
    p.rpc=rpc;asyncio.run(p.process_pending(101))
    assert not calls and state(database)[0]['state']=='REORG'


def test_receipt_mismatch_never_routes(database):
    p,calls=producer(database,logs=[log(making=1_000_000)]);p.stage(log())
    asyncio.run(p.process_pending(101))
    assert not calls and state(database)[0]['state']=='INVALID_EVIDENCE'


def test_restart_routing_crash_is_terminal_without_replay(database):
    p,calls=producer(database);event=decode_log(log());p.stage(log())
    p.store.transition(event,'ROUTING')
    EventStore(database).restart_recovery();EventStore(database).restart_recovery()
    asyncio.run(p.process_pending(101))
    assert not calls and state(database)[0]['state']=='ROUTING_INTERRUPTED'
    with database.conn() as c:
        assert c.execute("SELECT COUNT(*) FROM polygon_fast_audit WHERE action='ROUTING_INTERRUPTED'").fetchone()[0]==1


class FakeSocket:
    def __init__(self):self.incoming=asyncio.Queue();self.sent=[]
    def __aiter__(self):return self
    async def __anext__(self):return await self.incoming.get()
    async def send(self,message):self.sent.append(json.loads(message))


def test_json_rpc_reader_correlates_out_of_order_responses(database):
    async def run():
        p,_=producer(database);del p.rpc
        p.socket=FakeSocket();reader=asyncio.create_task(p.reader())
        a=asyncio.create_task(p.rpc('eth_chainId',[]));b=asyncio.create_task(p.rpc('eth_blockNumber',[]))
        await asyncio.sleep(0)
        for request in reversed(p.socket.sent):
            await p.socket.incoming.put(json.dumps({'id':request['id'],'result':request['method']}))
        assert await a=='eth_chainId' and await b=='eth_blockNumber'
        reader.cancel();await asyncio.gather(reader,return_exceptions=True)
    asyncio.run(run())


def test_provider_timeout_does_not_block_polling_gateway(database,monkeypatch):
    calls=gateway(monkeypatch,database)
    async def run():
        p,_=producer(database);del p.rpc
        p.config=ProducerConfig(rpc_timeout=.02);p.socket=FakeSocket()
        stalled=asyncio.create_task(p.rpc('eth_blockNumber',[]))
        await service.process_new_trade({'address':WALLET},polled(),source='DATA_API_POLL')
        with pytest.raises(TimeoutError):await stalled
    asyncio.run(run());assert len(calls)==1


def test_slow_poll_lane_does_not_block_wss_gateway(database,monkeypatch):
    calls=gateway(monkeypatch,database)
    async def run():
        release=asyncio.Event();poll=asyncio.create_task(release.wait())
        p,_=producer(database,ingest=service.ingest_fast_path_trade);p.stage(log())
        await asyncio.wait_for(p.process_pending(101),.5)
        assert not poll.done() and len(calls)==1
        release.set();await poll
    asyncio.run(run())


def test_reconnect_backoff_and_shutdown_never_expose_provider_secret(database):
    class Broken:
        async def __aenter__(self):raise TimeoutError('wss://provider/secret-token')
        async def __aexit__(self,*args):pass
    async def run():
        p,_=producer(database);p.config=ProducerConfig(url='wss://provider/secret-token')
        p.connect=lambda *args,**kwargs:Broken()
        task=asyncio.create_task(p.run());p.task=task
        await asyncio.sleep(.01)
        assert p.counters['reconnect_count']==1 and p.error_category=='TimeoutError'
        assert 'secret-token' not in json.dumps(p.status()) and 'secret-token' not in repr(p.config)
        await p.stop();assert task.cancelled() and not p.connected
    asyncio.run(run())


def test_wrong_chain_fails_before_subscription(database):
    p,_=producer(database)
    async def wrong(method,params):return '0x1'
    p.rpc=wrong
    with pytest.raises(ValueError,match='WRONG_CHAIN_ID'):asyncio.run(p.connection(FakeSocket()))


def test_latency_distributions_synthetic_only():
    rows=[]
    for lag in range(1,21):
        observed=NOW+timedelta(seconds=lag)
        rows.append({'block_timestamp':NOW.timestamp(),'first_observed_at':observed.isoformat(),
            'normalized_at':(observed+timedelta(seconds=2)).isoformat(),
            'strategy_started_at':(observed+timedelta(seconds=3)).isoformat()})
    summary=latency_summary(rows)
    assert summary['chain_source']=={'sample_count':20,'p50':10,'p75':15,'p90':18,'p95':19,'max':20}
    assert summary['normalization']['p95']==2 and summary['strategy']['p95']==1
    assert summary['total']['p95']==22
    assert latency_summary([])['total']['p95'] is None


def test_unconfigured_default_and_disabled_start_never_initialize_db(tmp_path):
    db=Database(str(tmp_path/'must-not-exist.db'))
    for config in (ProducerConfig(),ProducerConfig(url='wss://provider'),ProducerConfig(url='wss://provider',enabled=False)):
        p=PolygonProducer(db,Metadata(),None,config);p.start()
        assert p.task is None and not p.connected
    assert not (tmp_path/'must-not-exist.db').exists()


def test_configuration_is_literal_default_off_and_explicit_opt_in():
    assert ProducerConfig().enabled is False
    assert ProducerConfig(url='wss://provider',enabled=True).enabled is True
    env=os.environ.copy();env.pop('POLYGON_FAST_ENABLED',None)
    command=[sys.executable,'-c','from app.config import Settings; print(Settings().polygon_fast_enabled)']
    assert subprocess.check_output(command,env=env,text=True).strip()=='False'
    env['POLYGON_FAST_ENABLED']='true'
    assert subprocess.check_output(command,env=env,text=True).strip()=='True'
    example=Path(__file__).resolve().parents[1]/'.env.example'
    assert 'POLYGON_FAST_ENABLED=false' in example.read_text()


def test_contract_coverage_and_invalid_configuration_fail_closed():
    ProducerConfig(url='wss://provider').validate()
    with pytest.raises(ValueError,match='UNVERIFIED_CONTRACT'):
        ProducerConfig(url='wss://provider',contracts=('0xe3333700ca9d93003f00f0f71f8515005f6c00aa',)).validate()
    with pytest.raises(ValueError):ProducerConfig(url='http://provider').validate()
    assert strong_key({'chain_id':137,'contract_address':CONTRACTS[0],'transaction_hash':TX,'log_index':1.2}) is None


def test_additive_initialization_preserves_raw_wallet_and_canonical_rows(database):
    database.insert_trade_if_new(WALLET,polled(),source='DATA_API_POLL')
    with database.conn() as c:
        before=[tuple(r) for r in c.execute('SELECT * FROM trades ORDER BY trade_key')]
        canonical=[tuple(r) for r in c.execute('SELECT * FROM fill_canonical')]
    database.init();EventStore(database).initialize()
    with database.conn() as c:
        assert before==[tuple(r) for r in c.execute('SELECT * FROM trades ORDER BY trade_key')]
        assert canonical==[tuple(r) for r in c.execute('SELECT * FROM fill_canonical')]
        assert c.execute('SELECT tracked FROM wallets WHERE address=?',(WALLET,)).fetchone()[0]==1


def test_gamma_lookup_exact_tokens_and_ambiguity():
    async def run():
        client=PolymarketClient()
        async def get(*args,**kwargs):return [{'conditionId':CONDITION,'clobTokenIds':'["123","456"]',
            'outcomes':'["YES","NO"]','question':'Fixture'}]
        client._get=get
        result=await client.fast_token_metadata('123')
        assert result['outcome']=='YES' and result['condition_id']==CONDITION
        with pytest.raises(PolymarketError):await client.fast_token_metadata('999')
        await client.close()
    asyncio.run(run())


def test_safe_status_api_default_without_lifespan(monkeypatch):
    from app import main
    from fastapi.testclient import TestClient
    monkeypatch.setattr(main,'polygon_fast',PolygonProducer(None,None,None))
    response=TestClient(main.app).get('/api/polygon-fast-path')
    assert response.status_code==200
    data=response.json()
    assert data['configured'] is False and data['connected'] is False and data['live_orders'] is False
    assert data['latency']['total']['sample_count']==0 and 'url' not in data


def test_real_gateway_routes_verified_chain_schema_and_records_actual_start(database,monkeypatch):
    from app import wallet_follow_runtime as runtime
    seen=[]
    monkeypatch.setattr(service,'db',database)
    monkeypatch.setattr(runtime,'v2_activation_state',lambda path:runtime.V2ActivationState.ACTIVE)
    class Runtime:
        def __init__(self,*args):pass
        async def process_trade(self,wallet,trade,**kwargs):seen.append(trade);return {'decision':'FILLED'}
    monkeypatch.setattr(runtime,'WalletFollowRuntime',Runtime)
    p,_=producer(database,ingest=service.ingest_fast_path_trade);p.stage(log())
    asyncio.run(p.process_pending(101))
    row=state(database)[0]
    assert len(seen)==1 and seen[0]['price']=='0.5' and seen[0]['size']=='4'
    assert row['strategy_started_at'] is not None
    assert p.status()['latency']['total']['sample_count']==1


def test_chain_gateway_never_falls_back_to_legacy_when_v2_inactive(database,monkeypatch):
    from app import wallet_follow_runtime as runtime
    monkeypatch.setattr(service,'db',database)
    monkeypatch.setattr(runtime,'v2_activation_state',lambda path:runtime.V2ActivationState.INACTIVE)
    p,_=producer(database,ingest=service.ingest_fast_path_trade);p.stage(log())
    asyncio.run(p.process_pending(101))
    assert state(database)[0]['state']=='OBSERVED_NO_ADMISSION'
    assert p.status()['events_admitted_to_strategy']==0
    assert p.status()['latency']['total']['sample_count']==0
    with database.conn() as c:
        assert c.execute('SELECT COUNT(*) FROM signals').fetchone()[0]==0


def test_malformed_receipt_is_isolated_and_unknown_contract_blocks_weak_dedupe(database):
    bad=log(2);bad['data']='0x01'
    p,calls=producer(database,logs=[log(),bad]);p.stage(log())
    asyncio.run(p.process_pending(101))
    assert not calls and state(database)[0]['reason']=='MALFORMED_RECEIPT_LOG'
    other=Database(database.path)
    unknown=log(2);unknown['address']='0xe3333700ca9d93003f00f0f71f8515005f6c00aa'
    p,calls=producer(other,logs=[log(),unknown]);p.stage(log(3))
    # Independent fixture identity for the actual receipt event.
    event=decode_log(log());p.store.transition(event,'WAITING_CONFIRMATION')
    asyncio.run(p.process_pending(101))
    assert calls[0][1]['raw']['_receipt_unique'] is False


def test_unkeyed_repeat_and_conflicting_repeat_have_append_only_evidence(database):
    unkeyed=polled();unkeyed['raw'].pop('id')
    assert database.insert_trade_if_new(WALLET,unkeyed,source='DATA_API_POLL')
    assert not database.insert_trade_if_new(WALLET,unkeyed,source='DATA_API_POLL')
    assert unkeyed['_canonical_state']=='AMBIGUOUS_UNKEYED_REPEAT'
    unkeyed['raw']['size']='9'
    assert not database.insert_trade_if_new(WALLET,unkeyed,source='DATA_API_POLL')
    with database.conn() as c:
        states=[r[0] for r in c.execute('SELECT state FROM fill_identity_audit ORDER BY id')]
    assert states==['FIRST_SOURCE','AMBIGUOUS_UNKEYED_REPEAT','AMBIGUOUS_CHAIN_EVIDENCE_CONFLICT']


def test_actual_poll_scan_and_wss_are_independent_network_lanes(database,monkeypatch):
    from app import monitor as monitor_module
    calls=gateway(monkeypatch,database)
    async def run():
        release=asyncio.Event();entered=asyncio.Event()
        class Poll:
            async def trades_page(self,wallet,**kwargs):
                entered.set();await release.wait()
                return {'trades':[polled()], 'has_more':False,'next_cursor':None,
                    'requested_at':NOW.isoformat(),'received_at':NOW.isoformat(),
                    'elapsed_ms':1,'http_metadata':{}}
        monkeypatch.setattr(monitor_module,'db',database)
        monkeypatch.setattr(monitor_module,'pm',Poll())
        monkeypatch.setattr(monitor_module,'settings',SimpleNamespace(
            realtime_page_size=25,realtime_pages_per_slice=1,realtime_process_limit_per_slice=100,
            realtime_request_timeout_seconds=1,monitor_max_concurrency=8,research_enabled=True))
        monitor=monitor_module.WalletMonitor()
        slow=asyncio.create_task(monitor._scan_wallet({'address':WALLET,'last_trade_ts':100},asyncio.Semaphore(1)))
        await entered.wait()
        p,_=producer(database,ingest=service.ingest_fast_path_trade);p.stage(log())
        await asyncio.wait_for(p.process_pending(101),.5)
        assert not slow.done() and len(calls)==1
        release.set();result=await slow
        assert result['checkpoint_advanced'] is True and len(calls)==1
    asyncio.run(run())


def test_actual_reconnect_subscribe_then_bounded_backfill(database,monkeypatch):
    logs=[log(2,height=102),log(1,height=101)]
    async def run():
        p,calls=producer(database,logs=logs);del p.rpc
        p.config=ProducerConfig(url='wss://provider',heartbeat_seconds=.01,rpc_timeout=.1)
        p.store.checkpoint(100);p.store.forward_boundary(100)
        async def ingest(wallet,trade):
            calls.append((wallet,trade))
            if len(calls)==2:p.stop_event.set()
            return {'decision':'OBSERVED'}
        p.ingest=ingest
        class AutoSocket(FakeSocket):
            async def send(self,message):
                request=json.loads(message);self.sent.append(request)
                results={'eth_chainId':'0x89','eth_blockNumber':'0x67','eth_subscribe':'sub-1',
                    'eth_getLogs':logs,'eth_getBlockByNumber':{'hash':BLOCK,'timestamp':hex(int(NOW.timestamp()))},
                    'eth_getTransactionReceipt':{'blockHash':BLOCK,'status':'0x1','logs':logs}}
                await self.incoming.put(json.dumps({'id':request['id'],'result':results[request['method']]}))
        socket=AutoSocket();attempts=[]
        class Connection:
            async def __aenter__(self):
                attempts.append(1)
                if len(attempts)==1:raise TimeoutError('temporary outage')
                return socket
            async def __aexit__(self,*args):pass
        p.connect=lambda *args,**kwargs:Connection()
        monkeypatch.setattr('app.polygon_fast_path.random.uniform',lambda *args:0)
        await asyncio.wait_for(p.run(),3)
        assert len(attempts)==2 and p.counters['reconnect_count']==1
        assert [t['raw']['log_index'] for _,t in calls]==[1,2]
        assert p.store.checkpoint()==102
        assert next(r for r in socket.sent if r['method']=='eth_subscribe')['params'][1]['topics']==[ORDERFILLED_TOPIC]
    asyncio.run(run())


def test_status_read_failure_does_not_break_other_health_fields(database,monkeypatch):
    p,_=producer(database)
    def broken():raise RuntimeError('internal state unavailable')
    monkeypatch.setattr(database,'conn',broken)
    result=p.status()
    assert result['status_read_error']=='PRODUCER_STATE_READ_ERROR'
    assert result['live_orders'] is False and 'configured' in result
