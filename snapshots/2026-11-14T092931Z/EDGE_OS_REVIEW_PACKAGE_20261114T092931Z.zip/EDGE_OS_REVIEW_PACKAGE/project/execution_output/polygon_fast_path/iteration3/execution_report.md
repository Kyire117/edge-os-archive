[C2C_EXECUTED]
TASK_ID: c2c_polygon_orderfilled_fast_path_v1
ITERATION: 3
STATE: READY_FOR_REVIEW

# 首次决策返回结构与重连诊断修复

## 修改文件
- app/polygon_fast_path.py
- tests/test_polygon_fast_path.py
- POLYGON_FAST_PATH_V1.md

FIRST 实际返回 decision 字典；旧 set membership 引发 TypeError，金融结果已提交后 producer 留在 ROUTING，并被 run 当作连接错误重试。现在仅字符串 routing label 参与 blocked 集合判断；结构化严格证据保持原样，FIRST 成交/拒绝均落 ROUTED。原隔离观察的 4 ROUTING 记录及 1 fill 保持原样，未重放或改写。

重连追加安全审计字段：reconnect_number / error_type / phase / failed rpc_method / UTC timestamp。覆盖 CONNECT、CHAIN_ID、SUBSCRIBE、HEARTBEAT、BACKFILL、PROCESS_PENDING、TERMINAL_TRANSITION；不保存异常原文、参数、地址或密钥。诊断写入失败不能中断有界重试。

回归使用真实 WalletFollowV2.observe_buy + execute_first 的 FIRST 返回结构，经 service gateway -> producer，不用字符串 FILLED mock。覆盖首次 REJECTED/FILLED、strategy_started_at、终态、重复处理/恢复不新增 fill、ledger reconcile。验证 CONNECT / CHAIN_ID + eth_chainId timeout 诊断及秘密隔离。

## 验证
- new: 70 passed；targeted: 221 passed；full: 385 passed；全部 exit=0，唯一旧 Starlette/anyio 警告。
- compileall / git diff --check exit=0。
- 主 DB SHA256 bb9772ed841ff0352d78e415a539fca98df3dc48f19d96e8837fc8c55d216da4 前后不变；37 张表完整 count/hash 一致；quick_check=ok。
- VOID BLOCKED checkpoint 完全不变；无生产初始化/迁移/重启/部署、无真实订单、无历史重放。
- exact_iteration3.patch 是相对本轮修改前源文件的精确差异；source_before 保留本轮前的三份源文件。
- checks.py 可复跑临时库测试/只读生产快照；manifest 保存精确命令、exit、源 hash 和生产保护。

## 仍待完成
独立网页审查后，使用同一 PublicNode 做 300 秒全新隔离观察。原观察不作全局漏单率或 P95/重复率达标证明。生产 Fast Path 仍不启用。
