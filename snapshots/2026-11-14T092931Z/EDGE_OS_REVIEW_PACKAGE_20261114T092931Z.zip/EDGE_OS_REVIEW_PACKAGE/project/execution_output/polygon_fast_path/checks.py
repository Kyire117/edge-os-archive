import hashlib, json, os, sqlite3, subprocess, sys, time, urllib.request
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
FILES=['app/fill_identity.py','app/polygon_fast_path.py','app/config.py','app/db.py','app/main.py',
       'app/polymarket.py','app/service.py','requirements.txt','.env.example','POLYGON_FAST_PATH_V1.md',
       'tests/test_polygon_fast_path.py']
TEMP=ROOT.parents[1]/'execution_output'/'fp10tests'
TEMP.mkdir(parents=True, exist_ok=True)
def snapshot(name):
    path=ROOT/'data/edge_mvp.db'
    c=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True); c.execute('PRAGMA query_only=ON'); c.execute('BEGIN')
    tables={}
    for t, in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
        rows=c.execute('SELECT * FROM "'+t.replace('"','""')+'"').fetchall()
        data=sorted(json.dumps(r,sort_keys=True,default=str,separators=(',',':')) for r in rows)
        tables[t]={'count':len(rows),'sha256':hashlib.sha256('\n'.join(data).encode()).hexdigest()}
    result={'at':datetime.now(timezone.utc).isoformat(),'path':str(path),'main_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'tables':tables,'quick_check':c.execute('PRAGMA quick_check').fetchall(),
        'wss_configured':bool(os.getenv('POLYGON_WSS_URL'))}
    sample=c.execute('SELECT raw_json FROM trades WHERE is_seed=0 ORDER BY timestamp DESC LIMIT 10').fetchall()
    result['data_api_raw_field_sets']=[sorted(json.loads(r[0])) for r in sample]
    c.rollback();c.close()
    (OUT/(name+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('tables','data_api_raw_field_sets')}))
    if name=='after':
        before=json.loads((OUT/'before.json').read_text());result={'main_unchanged':result['main_sha256']==before['main_sha256'],
            'all_tables_unchanged':result['tables']==before['tables'],'table_count':len(tables)}
        (OUT/'preservation.json').write_text(json.dumps(result,indent=2));print(result)
    return
def run(name,args):
    env=os.environ.copy();env['TEMP']=str(TEMP);env['TMP']=str(TEMP)
    env['DATABASE_PATH']=str(TEMP/'default.db');env.pop('POLYGON_WSS_URL',None)
    env['PYTEST_ADDOPTS']='--basetemp="'+str(TEMP/name)+'" -p no:cacheprovider'
    hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in FILES if (ROOT/f).exists()}
    started_at=datetime.now(timezone.utc).isoformat()
    started=time.monotonic();p=subprocess.run(args,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    out=p.stdout.decode('utf-8',errors='replace');(OUT/(name+'.txt')).write_text(out,encoding='utf-8')
    r={'name':name,'command':args,'exit_code':p.returncode,'seconds':round(time.monotonic()-started,2),
       'started_at':started_at,'source_sha256':hashes,
       'source_unchanged_during_run':all(hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==v for f,v in hashes.items())}
    (OUT/(name+'.json')).write_text(json.dumps(r,indent=2));print({k:v for k,v in r.items() if k!='source_sha256'},flush=True);print(out[-3000:],flush=True)
    return p.returncode
if __name__=='__main__':
    mode=sys.argv[1]
    if mode in ('before','after'):snapshot(mode)
    elif mode=='baseline':sys.exit(run(mode,[sys.executable,'-m','pytest','tests','-q']))
    elif mode=='targeted':sys.exit(run(mode,[sys.executable,'-m','pytest','tests/test_polygon_fast_path.py','tests/test_realtime_ingestion_exit_v1.py','tests/test_wallet_follow_v2.py','tests/test_wallet_follow_v2_activation.py','tests/test_strict_paper_iteration1.py','tests/test_strict_paper_iteration2.py','tests/test_v2_timestamp_model.py','-q']))
    elif mode=='new':sys.exit(run(mode,[sys.executable,'-m','pytest','tests/test_polygon_fast_path.py','-q']))
    elif mode=='full':sys.exit(run(mode,[sys.executable,'-m','pytest','tests','-q']))
    elif mode=='compile':sys.exit(run(mode,[sys.executable,'-m','compileall','-q','app','tests']))
    elif mode=='diff':sys.exit(run(mode,['git','diff','--check']))
