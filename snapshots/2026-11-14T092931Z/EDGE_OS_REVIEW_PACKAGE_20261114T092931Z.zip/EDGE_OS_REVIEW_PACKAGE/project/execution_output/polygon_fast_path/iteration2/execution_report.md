[C2C_EXECUTED]
TASK_ID: c2c_polygon_orderfilled_fast_path_v1
ITERATION: 2
STATE: READY_FOR_REVIEW

# 第二轮修复证据

## 修改文件

- app/fill_identity.py
- app/config.py
- app/polygon_fast_path.py
- .env.example
- POLYGON_FAST_PATH_V1.md
- tests/test_polygon_fast_path.py
- tests/test_realtime_ingestion_exit_v1.py
- tests/test_wallet_follow_v2_activation.py
- tests/test_research.py

## 修复及不变量

- P1：实时 DATA_API_POLL / FAST_PATH 缺少合法 32-byte transaction hash 时，返回 False；保存完整原始观察于审计/来源证据，状态 AMBIGUOUS_INSUFFICIENT_TRANSACTION_IDENTITY，canonical_id=NULL。没有 canonical 所有权、策略调用或金融成交。不按时间或价格猜重复。
- 合法链证据晚到可执行一次；无哈希数据无论先到或后到、重启再观察，都不产生第二次执行。非实时 DIRECT/导入旧 trade-key 行为保留。没有改写历史记录。
- P2：Settings / ProducerConfig / .env.example 全部默认 enabled=false，配置地址本身不会开启；显式 true 才允许启动。
- 旧实时/V2/research 测试夹具补充合法格式的合成哈希，原断言保留；实时 ingestion fixture 加入精确合成链身份，用于已有跨源相同 key 测试。没有测试特例开关。
- ABI、金额、元数据、补漏、崩溃不重放、冻结策略、Exit V1 均保持不变。

## 验证

- Fast Path：67 passed；targeted：218 passed；full：382 passed。全部 exit=0；唯一已有 Starlette/anyio 弃用警告。
- compileall / git diff --check：exit=0。Git 提示既有 LF/CRLF 转换，无 diff 错误。
- 首次 targeted：214 passed / 4 failed，均为既有 V2 测试夹具缺交易哈希；失败输出完整保留 targeted_initial_failure.txt/json。补充夹具后通过。
- 主 DB SHA256 前后：bb9772ed841ff0352d78e415a539fca98df3dc48f19d96e8837fc8c55d216da4，相同。37 张表完整行数/内容哈希一致，quick_check=ok。
- VOID BLOCKED checkpoint 与第一轮完全一致；未生产初始化/迁移/重启/部署，未回放历史、未历史 VOID 对账。
- 原始第一轮测试记录与审查文本保留。本目录 checks.py 可重跑临时库测试及只读快照；manifest 保存精确命令/exit/source hashes。

## 未完成

- 独立网页第二轮审查待完成。WSS 未配置，真实前向延迟仍未测，不能声称达标。
- 两个已验证 Exchange 覆盖、一块确认/深重组及同步 SQLite 调度限制沿用第一轮说明。
