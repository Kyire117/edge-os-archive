"""Reproduce Iteration 2 validation with temporary DBs; snapshot production read-only."""
import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fast_path_evidence_checks', HERE.parent/'checks.py')
checks = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checks)
checks.OUT = HERE
checks.FILES.extend(['tests/test_realtime_ingestion_exit_v1.py',
                     'tests/test_wallet_follow_v2_activation.py', 'tests/test_research.py'])

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode in ('before','after'):
        checks.snapshot(mode)
    else:
        commands = {
            'new':[sys.executable,'-m','pytest','tests/test_polygon_fast_path.py','-q'],
            'targeted':[sys.executable,'-m','pytest','tests/test_polygon_fast_path.py',
                'tests/test_realtime_ingestion_exit_v1.py','tests/test_wallet_follow_v2.py',
                'tests/test_wallet_follow_v2_activation.py','tests/test_strict_paper_iteration1.py',
                'tests/test_strict_paper_iteration2.py','tests/test_v2_timestamp_model.py','-q'],
            'full':[sys.executable,'-m','pytest','tests','-q'],
            'compile':[sys.executable,'-m','compileall','-q','app','tests'],
            'diff':['git','diff','--check'],
        }
        raise SystemExit(checks.run(mode,commands[mode]))
