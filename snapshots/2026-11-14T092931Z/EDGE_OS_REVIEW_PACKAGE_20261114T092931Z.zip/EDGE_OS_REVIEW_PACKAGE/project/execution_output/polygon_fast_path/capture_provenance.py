"""Capture public official source versions, never local credentials."""
import hashlib
import json
import urllib.request
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OUT=Path(__file__).resolve().parent/'provenance'
OUT.mkdir(exist_ok=True)
def fetch(url):
    request=urllib.request.Request(url,headers={'User-Agent':'EDGE-OS-source-verification'})
    return urllib.request.urlopen(request,timeout=20).read()

commit=subprocess.check_output(['git','ls-remote','https://github.com/Polymarket/ctf-exchange-v2.git','refs/heads/main'],text=True).split()[0]
paths=['README.md','src/exchange/interfaces/ITrading.sol','src/exchange/mixins/Events.sol',
       'src/exchange/libraries/Structs.sol','src/exchange/mixins/Trading.sol',
       'src/collateral/CollateralToken.sol']
evidence={'captured_at':datetime.now(timezone.utc).isoformat(),'repository':'Polymarket/ctf-exchange-v2',
          'commit':commit,'files':[]}
for path in paths:
    url=f'https://raw.githubusercontent.com/Polymarket/ctf-exchange-v2/{commit}/{path}'
    data=fetch(url);local=OUT/path.replace('/','__');local.write_bytes(data)
    evidence['files'].append({'source_url':url,'path':str(local),'sha256':hashlib.sha256(data).hexdigest()})
(OUT/'manifest.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
print(json.dumps({'commit':commit,'source_files':len(paths)}))
