# 新版 EDGE OS 持续模拟启动

启动 UTC：2026-10-12T06:13:20.8663219Z
页面：http://127.0.0.1:8000
运行 PID：15296

- 原 Wallet Follow V2.0 FORWARD_TEST 配置、激活时间及已有模拟资金继续保留；没有清零或重建旧实验。
- 本次启动前基线：episodes=951，strict_fills=356，跟踪钱包=20。
- 已创建 SQLite 一致性备份：C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\data\backups\edge_mvp.pre-continuous-fast-path-20261012T061152Z.db
- 备份 integrity_check=ok；SHA256=8c43d7c4ab865ad3e82d8bc296777470d4ca243c33c94e4dc69e9bb8db17895e。
- Fast Path 开启，64 分块，最大补漏 gap 128；链上 RPC 等待 15 秒；本机代理用于公开 HTTP 请求；冻结入场与账本规则不变。
- 监控最近成功扫描已发生，Fast Path 当前连通并推进 checkpoint；存在短暂重连，不能称为零网络错误。
- live_orders=false；未启用真实交易。
- 原 episodes/fills/orders/wallets/trades 主键集合保留，冻结配置和激活时间不变，quick_check=ok。
- 启动后正常模拟入场和结算会更新运行数据；不要求运行中的 DB hash 保持原值。

## 前端同步建议

现有 V2 页面、档案、盈亏、立即扫描均可使用，本轮未修改前端。
应补充 Fast Path 已启用/当前连接/最近事件/补漏进度/待身份解析/重连状态。
应将“本次启动新增结果”与原 V2 累计结果明确区分；目前首页仍展示原策略累计统计。
本轮创建的 before_start.json 只是统计基线，不是独立的新策略账户。

## 运行限制

持续进程保留在后台，电脑和本机代理需保持可用。自动开机启动和跨系统重启恢复本次专用启动参数尚未配置。
没有重写 C2C/VOID checkpoint，没有删除历史数据。本轮未改产品源代码。
