# 实时数据短时前向观察（独立模拟库）

区间 UTC：2026-10-10T11:52:36.921020+00:00 — 2026-10-10T11:55:37.366574+00:00
跟踪钱包：20
原始观察次数：6751（含补漏/重复及未跟踪 maker）
唯一被跟踪 WSS / BACKFILL key：4 / 10
身份成功 / 持久事件：7 / 10
精确跨源配对：0；first-arrival：{}
方向 episodes：4；金融 fills：1
episode 状态：{'REJECTED': 3, 'FILLED': 1}
不足身份观察审计次数：0
轮询成功次数：76/76
生产保护：{'main_unchanged': True, 'all_tables_unchanged': True, 'tables': 37}

延迟完整分位数见 summary.json producer.latency / backfill_latency。
只对真实进入策略的样本计算；空样本为未知。
短时间结果不证明全市场漏单率/重复率或生产 SLA。零配对不是重复率为零。
没有启动/重启生产、没有配置生产运行环境；实时地址只作用于本脚本进程。
本次使用当前源码的正式市场/两份订单簿/手续费模拟；所有交易均 PAPER_ONLY。
数据库保留，未进行历史回放或强制结算。

## 验证关口

状态：INCOMPLETE_NOT_APPROVED_FOR_PRODUCTION。

- 重连计数为 6，终止前仍有 ConnectionError；根因未确认。
- 4 条 producer ROUTING / 3 条 WAITING_CONFIRMATION 保留原状，需要只读核对路由终态。
- 7 条已尝试解析记录均成功；另 3 条尚未开始解析，不能当成已确认的 metadata 失败。
- WSS total latency 仅 n=1：16.143031 秒；不构成可靠 P95 或达标证明。该样本 first_observed 比链时间早约 0.230235 秒，chain_source 被排除。
- 精确跨源配对 n=0，不能给实际重复率或 first-arrival 结论。
- 三个新建模拟账户 reconcile/audit 均通过；1 笔成交尚未正式结算，不产生历史/真实策略利润。
- 只有全新隔离库被初始化/激活；未加载持续生产 EDGE OS。
