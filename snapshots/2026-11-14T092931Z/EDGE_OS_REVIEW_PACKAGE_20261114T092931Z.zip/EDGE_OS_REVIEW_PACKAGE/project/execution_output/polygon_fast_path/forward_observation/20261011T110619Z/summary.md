# 实时数据短时前向观察（独立模拟库）

区间 UTC：2026-10-11T11:06:23.104706+00:00 — 2026-10-11T11:11:31.802423+00:00
跟踪钱包：20
原始观察次数：13391（含补漏/重复及未跟踪 maker）
唯一被跟踪 WSS / BACKFILL key：0 / 22
身份成功 / 持久事件：22 / 22
精确跨源配对：0；first-arrival：{}
方向 episodes：12；金融 fills：9
episode 状态：{'FILLED': 9, 'REJECTED': 3}
不足身份观察审计次数：0
轮询成功次数：138/138
轮询收到行数：0；重连次数：1
BACKFILL eth_getLogs 诊断请求：34；错误：1；chunk 配置：{'enabled': True, 'initial_chunk_size': 64, 'fallback_sizes': [64], 'max_gap_blocks': 128, 'retry_number_semantics': '0 is the initial attempt for a block range; each smaller-size fallback increments it.'}
BACKFILL 诊断写入失败：False
未完成 ROUTING：0
生产保护：{'main_unchanged': True, 'all_tables_unchanged': True, 'tables': 37}

延迟完整分位数见 summary.json producer.latency / backfill_latency。
只对真实进入策略的样本计算；空样本为未知。
短时间结果不证明全市场漏单率/重复率或生产 SLA。零配对不是重复率为零。
没有启动/重启生产、没有配置生产运行环境；实时地址只作用于本脚本进程。
本次使用当前源码的正式市场/两份订单簿/手续费模拟；所有交易均 PAPER_ONLY。
数据库保留，未进行历史回放或强制结算。
