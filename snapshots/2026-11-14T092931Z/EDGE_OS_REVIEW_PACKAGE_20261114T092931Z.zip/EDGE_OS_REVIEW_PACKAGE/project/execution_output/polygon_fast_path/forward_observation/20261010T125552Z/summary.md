# 实时数据短时前向观察（独立模拟库）

区间 UTC：2026-10-10T12:55:56.826190+00:00 — 2026-10-10T13:00:59.797146+00:00
跟踪钱包：20
原始观察次数：9758（含补漏/重复及未跟踪 maker）
唯一被跟踪 WSS / BACKFILL key：25 / 22
身份成功 / 持久事件：21 / 24
精确跨源配对：0；first-arrival：{}
方向 episodes：9；金融 fills：5
episode 状态：{'REJECTED': 4, 'FILLED': 5}
不足身份观察审计次数：0
轮询成功次数：121/121
轮询收到行数：120；重连次数：7
未完成 ROUTING：0
生产保护：{'main_unchanged': True, 'all_tables_unchanged': True, 'tables': 37}

延迟完整分位数见 summary.json producer.latency / backfill_latency。
只对真实进入策略的样本计算；空样本为未知。
短时间结果不证明全市场漏单率/重复率或生产 SLA。零配对不是重复率为零。
没有启动/重启生产、没有配置生产运行环境；实时地址只作用于本脚本进程。
本次使用当前源码的正式市场/两份订单簿/手续费模拟；所有交易均 PAPER_ONLY。
数据库保留，未进行历史回放或强制结算。

## 独立复核结论待定

- 本轮实际执行成功，质量状态 INCOMPLETE_BACKFILL_AND_CROSS_SOURCE_EVIDENCE，生产启用 BLOCKED。
- 21 条规范化事件均 ROUTED；ROUTING=0，尚有 3 条 WAITING_CONFIRMATION，不当作已经确认的身份失败或永久丢单。
- WSS total: n=21, P50=15.186903s, P90=25.547784s, P95=26.203136s, max=26.850853s。只描述此短时样本，不证明持续 SLO。
- chain_source 仅 n=4；其它负值由已有 helper 排除，可能与时钟/整秒时间粒度有关，不能归零或解释为负延迟优势。
- 7 次重连全部 BACKFILL / eth_getLogs：6 ConnectionError、1 TimeoutError。最后一次在 shutdown grace 内，是否与停机有关未确认。没有 TypeError。
- 121/121 轮询成功，120 条观察；审计显示1个 FIRST_SOURCE、119个 AMBIGUOUS_UNKEYED_REPEAT，不能当120笔独立交易或确认为119笔跨源重复。
- 精确跨源配对 n=0，真实跨源重复率和谁先到仍未知。
- 9 episodes: 5 FILLED / 4 REJECTED(STALE_MARKET_STATE)。未观察正式结算，不产生已实现策略利润。
- 3个隔离账户 reconcile/audit 全部绿色；金融规则未改。生产主SHA/37表不变。
- 原180秒观察库未更改/重放，未部署或重启生产。第三轮385测试的产品源hash仍完全一致。
- 仍需定位补漏传输异常及取得可证明的跨源对应样本。此报告不宣布数据验证通过。
