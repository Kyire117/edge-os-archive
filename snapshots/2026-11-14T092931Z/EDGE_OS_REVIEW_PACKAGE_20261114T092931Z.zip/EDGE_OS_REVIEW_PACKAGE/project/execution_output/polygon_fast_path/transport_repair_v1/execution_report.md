# Polygon 实时连接修复及隔离复测

状态：EXECUTED；本地自审通过，但保留短期观察局限。生产未启动/重启。

## 已确认根因与修复

- 原 websocket 消息上限为 1MB。只读探测 64 个区块响应 5,355,660 bytes：1MB 连接以 close code 1009 失败，16MB 接收成功。消息上限调整为可配置且严格限制在 1–16MB；默认 16MB，仍保留队列、区块 gap 和 10,000 条结果限制。
- Gamma 直连 ConnectTimeout，系统 HTTPS 代理未配置；已运行的本地代理可取得 HTTP 200 并精确匹配 token。客户端支持显式 public_http_proxy，隔离脚本只允许无凭据 loopback HTTP 地址。未改系统/VPN/生产配置。
- 扫描取消会遗留 freshness 子任务异常：增加取消/异常时子任务清理；隔离关闭先等扫描退出，再采用有界取消。
- 隔离脚本允许链上 RPC 等待 8/15/20 秒，默认仍 8；不改 CLOB 3000ms、500ms 延迟或策略规则。

## 修改文件

- app/polygon_fast_path.py
- app/polymarket.py
- app/monitor.py
- execution_output/polygon_fast_path/observe_forward.py
- tests/test_polygon_fast_path.py
- tests/test_fast_transport_repair.py

## 真实复测（每轮新独立数据库）

| 链上等待 | 补漏成功/请求 | 身份解析/事件 | episodes | fills | 重连 | 账本/审计 |
|---|---:|---:|---:|---:|---:|---|
| 8s | 33/34 | 22/22 | 12 | 9 | 1 | 通过 |
| 15s | 42/43 | 14/14 | 8 | 6 | 1 | 通过 |

## 验证及保护

- 相关测试 117 passed；最终全仓 409 passed，1 个既有依赖弃用警告，exit 0。
- 初次全仓 10 项临时备份失败；只缩短 basetemp 后全通过，未修改备份/激活产品逻辑。保留所有失败和成功输出。
- compileall、git diff --check、精确差异空白检查均 exit 0。
- 生产主 DB hash、37 张表逻辑 hash 在两轮中以及首尾均一致；strict paper / ledger 文件 hash 不变。
- 未改冻结策略、生产库/历史观察库内容、VOID checkpoint；没有启动生产服务或真实订单。

## 局限及下一步

- Two sequential five-minute windows do not prove production SLO.
- Transient provider/network errors persist; last run demonstrated reconnect and resumed processing.
- Only one exact cross-source pair across these two runs, and no WSS-first strategy latency samples: duplicate rate and Fast-first P95 remain unmeasured.
- MARKET_DATA_UNAVAILABLE still rejects some fresh attempts; no stale prices or fabricated fills used.
- Proxy was explicitly selected only for isolated processes; production startup remains a separate action.

下一步可安排更长的隔离观察验证稳定性和 Fast-first 延迟；不得把这些模拟成交当作生产或已实现策略利润。
本轮未自动部署或持续启动新版 EDGE OS。
