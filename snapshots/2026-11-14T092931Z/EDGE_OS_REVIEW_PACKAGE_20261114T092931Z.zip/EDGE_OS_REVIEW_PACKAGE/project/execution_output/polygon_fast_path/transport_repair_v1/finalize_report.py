"""Artifact-only self-review: no network, application initialization or DB writes."""
import difflib
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
files=['app/polygon_fast_path.py','app/polymarket.py','app/monitor.py',
       'execution_output/polygon_fast_path/observe_forward.py','tests/test_polygon_fast_path.py',
       'tests/test_fast_transport_repair.py']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
diff=''
for name in files:
    before=OUT/'source_before'/name
    old=before.read_text(encoding='utf-8').splitlines(True) if before.exists() else []
    diff+=''.join(difflib.unified_diff(old,(ROOT/name).read_text(encoding='utf-8').splitlines(True),
                                    fromfile='a/'+name,tofile='b/'+name))
(OUT/'exact.diff').write_text(diff,encoding='utf-8',newline='\n')
assert not any(line.startswith('+') and not line.startswith('+++') and
               line.rstrip('\r\n') != line.rstrip() for line in diff.splitlines(True))
before=json.loads((OUT/'preservation_before.json').read_text(encoding='utf-8-sig'))
preservation=[]
for item in before:
    path=Path(item['Path'])
    if path.name=='monitor.py':continue  # Authorized child-task shutdown repair.
    preservation.append({'path':str(path),'before':item['Hash'].lower(),'after':sha(path),
                         'unchanged':item['Hash'].lower()==sha(path)})
assert all(item['unchanged'] for item in preservation)
runs=[]
for stamp in ('20261011T110619Z','20261011T111236Z'):
    directory=OUT.parent/'forward_observation'/stamp
    s=json.loads((directory/'summary.json').read_text(encoding='utf-8'))
    a=s['backfill_diagnostics']
    reconciled=all(v['ledger']['ok'] and v['audit']['ok'] for v in s['reconciliations'].values())
    assert reconciled
    assert s['production_preservation']['main_unchanged'] and s['production_preservation']['all_tables_unchanged']
    runs.append({'directory':str(directory),'duration_seconds':s['duration_seconds'],
        'requests':len(a),'successful_requests':sum(r['error_type'] is None for r in a),
        'errors':dict(Counter(r['error_type'] for r in a if r['error_type'])),
        'rpc_timeout':s['backfill_diagnostic_config'].get('rpc_timeout_seconds',8),
        'metadata':s['metadata'],'episodes':s['episode_count'],'episode_status':s['episode_status'],
        'fills':s['fill_count'],'reconnect_count':s['producer']['reconnect_count'],
        'last_error':s['producer']['error_category'],'last_checkpoint':s['producer']['last_block'],
        'poll_ok_runs':s['poll_ok_runs'],'poll_runs':s['poll_runs'],
        'cross_source_exact_pairs':s['cross_source_exact_pairs'],
        'wss_strategy_latency_samples':s['producer']['latency']['total']['sample_count'],
        'ledger_and_audit_ok':reconciled,'accounts_checked':len(s['reconciliations']),
        'production_preservation':s['production_preservation'],'live_orders':s['producer']['live_orders']})
first=json.loads((OUT.parent/'forward_observation/20261011T110619Z/production_before.json').read_text())
last=json.loads((OUT.parent/'forward_observation/20261011T111236Z/production_after.json').read_text())
assert first['tables']==last['tables'] and first['main_sha256']==last['main_sha256']
manifest={'task':'polygon_fast_path_transport_repair_v1','state':'EXECUTED_LOCAL_REVIEW_WITH_LIMITATIONS',
    'captured_at_utc':datetime.now(timezone.utc).isoformat(),'changed_files':files,
    'source_sha256':{name:sha(ROOT/name) for name in files},'runs':runs,'preservation':preservation,
    'all_production_tables_unchanged_across_both_runs':True,
    'tests':{'targeted':'117 passed, 1 warning','full_final':'409 passed, 1 warning',
             'targeted_exit':0,'full_final_exit':0,'compileall_exit':0,'git_diff_check_exit':0,
             'exact_diff_whitespace_exit':0,'initial_full':'10 failed / 398 passed: temporary backup path failures; short-path rerun passed'},
    'runtime':{'production_started_or_restarted':False,'production_proxy_config_written':False,
               'historical_fills_replayed':False,'void_checkpoint_modified':False},
    'review':'Codex self-review as currently requested; no web ChatGPT review.',
    'limitations':['Two sequential five-minute windows do not prove production SLO.',
        'Transient provider/network errors persist; last run demonstrated reconnect and resumed processing.',
        'Only one exact cross-source pair across these two runs, and no WSS-first strategy latency samples: duplicate rate and Fast-first P95 remain unmeasured.',
        'MARKET_DATA_UNAVAILABLE still rejects some fresh attempts; no stale prices or fabricated fills used.',
        'Proxy was explicitly selected only for isolated processes; production startup remains a separate action.']}
lines=['# Polygon 实时连接修复及隔离复测','',
    '状态：EXECUTED；本地自审通过，但保留短期观察局限。生产未启动/重启。','',
    '## 已确认根因与修复','',
    '- 原 websocket 消息上限为 1MB。只读探测 64 个区块响应 5,355,660 bytes：1MB 连接以 close code 1009 失败，16MB 接收成功。消息上限调整为可配置且严格限制在 1–16MB；默认 16MB，仍保留队列、区块 gap 和 10,000 条结果限制。',
    '- Gamma 直连 ConnectTimeout，系统 HTTPS 代理未配置；已运行的本地代理可取得 HTTP 200 并精确匹配 token。客户端支持显式 public_http_proxy，隔离脚本只允许无凭据 loopback HTTP 地址。未改系统/VPN/生产配置。',
    '- 扫描取消会遗留 freshness 子任务异常：增加取消/异常时子任务清理；隔离关闭先等扫描退出，再采用有界取消。',
    '- 隔离脚本允许链上 RPC 等待 8/15/20 秒，默认仍 8；不改 CLOB 3000ms、500ms 延迟或策略规则。','',
    '## 修改文件','']+['- '+name for name in files]
lines+=['','## 真实复测（每轮新独立数据库）','',
    '| 链上等待 | 补漏成功/请求 | 身份解析/事件 | episodes | fills | 重连 | 账本/审计 |',
    '|---|---:|---:|---:|---:|---:|---|']
for r in runs:
    lines.append(f"| {r['rpc_timeout']}s | {r['successful_requests']}/{r['requests']} | {r['metadata']['normalized']}/{r['metadata']['tracked_persisted_events']} | {r['episodes']} | {r['fills']} | {r['reconnect_count']} | 通过 |")
lines+=['','## 验证及保护','',
    '- 相关测试 117 passed；最终全仓 409 passed，1 个既有依赖弃用警告，exit 0。',
    '- 初次全仓 10 项临时备份失败；只缩短 basetemp 后全通过，未修改备份/激活产品逻辑。保留所有失败和成功输出。',
    '- compileall、git diff --check、精确差异空白检查均 exit 0。',
    '- 生产主 DB hash、37 张表逻辑 hash 在两轮中以及首尾均一致；strict paper / ledger 文件 hash 不变。',
    '- 未改冻结策略、生产库/历史观察库内容、VOID checkpoint；没有启动生产服务或真实订单。','',
    '## 局限及下一步','']+['- '+x for x in manifest['limitations']]
lines+=['','下一步可安排更长的隔离观察验证稳定性和 Fast-first 延迟；不得把这些模拟成交当作生产或已实现策略利润。',
        '本轮未自动部署或持续启动新版 EDGE OS。']
(OUT/'execution_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
manifest['artifact_sha256']={n:sha(OUT/n) for n in ['execution_report.md','exact.diff','targeted_tests.txt','full_tests_final.txt']}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'state':manifest['state'],'runs':runs,'production_unchanged':True},ensure_ascii=False,indent=2))
