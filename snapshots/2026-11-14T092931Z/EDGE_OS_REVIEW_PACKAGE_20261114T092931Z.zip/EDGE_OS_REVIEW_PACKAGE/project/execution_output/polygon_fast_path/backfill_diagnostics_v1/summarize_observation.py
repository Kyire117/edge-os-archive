"""Summarize only this authorized three-run observation; no network or DB access."""
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / 'forward_observation'
RUNS = ['20261011T101741Z', '20261011T102245Z', '20261011T102749Z']
rows = []
for run in RUNS:
    s = json.loads((BASE / run / 'summary.json').read_text(encoding='utf-8'))
    attempts = s['backfill_diagnostics']
    durations = sorted(r['duration_ms'] for r in attempts)
    def percentile(p):
        return durations[max(0, math.ceil(len(durations)*p)-1)] if durations else None
    rows.append({
        'run': run, 'summary_path': str(BASE / run / 'summary.json'),
        'chunk_size': s['backfill_diagnostic_config']['initial_chunk_size'],
        'started_at': s['started_at'], 'finished_at': s['finished_at'],
        'duration_seconds': s['duration_seconds'], 'requests': len(attempts),
        'successes': sum(r['error_type'] is None for r in attempts),
        'errors': dict(Counter(r['error_type'] for r in attempts if r['error_type'])),
        'fallback_attempts': sum(r['retry_number'] > 0 for r in attempts),
        'actual_range_sizes': sorted(set(r['block_range_size'] for r in attempts)),
        'request_duration_ms_p50': percentile(.5), 'request_duration_ms_p95': percentile(.95),
        'reconnect_count': s['producer']['reconnect_count'],
        'last_error': s['producer']['error_category'],
        'last_confirmed_checkpoint': s['producer']['last_block'],
        'metadata': s['metadata'], 'episodes': s['episode_count'], 'fills': s['fill_count'],
        'poll_ok_runs': s['poll_ok_runs'], 'poll_runs': s['poll_runs'],
        'exact_cross_source_pairs': s['cross_source_exact_pairs'],
        'latency': s['producer']['latency'],
        'diagnostic_write_failed': s['backfill_diagnostics_persistence_failed'],
        'ledger_reconciliations': s['reconciliations'],
        'production_preservation': s['production_preservation'],
        'live_orders': s['producer']['live_orders']})
    rows[-1]['success_rate'] = rows[-1]['successes']/len(attempts) if attempts else None
before = json.loads((BASE / RUNS[0] / 'production_before.json').read_text())
after = json.loads((BASE / RUNS[-1] / 'production_after.json').read_text())
result = {'captured_at_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'OBSERVATION_COMPLETE_NOT_READY_FOR_CONTINUOUS_FAST_PATH',
    'runs': rows, 'production_preservation_across_all_runs': {
        'main_unchanged': before['main_sha256'] == after['main_sha256'],
        'all_tables_unchanged': before['tables'] == after['tables']},
    'production_started_or_restarted': False, 'source_code_modified': False,
    'limitations': ['Sequential short windows do not isolate chunk-size causality.',
        'No normalized episodes/fills: strategy latency, duplicate fill rate and permanent loss are unmeasurable.',
        'Request duration is RPC latency, not leader-to-EDGE detection latency.',
        'Metadata and subscription failures also occurred; changing chunk alone is not proven sufficient.',
        'First run logged one unhandled data_freshness request failure during shutdown.']}
(OUT / 'observation_comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
lines = ['# 三轮隔离模拟观察结果', '',
    '状态：观察完成；当前 Fast Path 数据链路不适合直接加载持续运行。', '',
    '| 初始分块 | 请求成功/总数 | 回退请求 | 重连 | 身份解析成功/暂存事件 | episodes / fills |',
    '|---|---:|---:|---:|---:|---:|']
for r in rows:
    lines.append(f"| {r['chunk_size']} | {r['successes']}/{r['requests']} | {r['fallback_attempts']} | {r['reconnect_count']} | {r['metadata']['normalized']}/{r['metadata']['tracked_persisted_events']} | {r['episodes']}/{r['fills']} |")
lines += ['', '## 当前验证', '',
    '- 每轮约 5 分钟，20 个跟踪钱包，新建独立模拟库；live_orders=false。',
    '- 三轮均出现 BACKFILL 请求错误；128 分块结束时达到 BACKFILL_GAP_EXCEEDS_BOUND，未跳过缺口。',
    '- 还有订阅超时、市场元数据等待以及轮询请求失败，不能认定只调 chunk 就可恢复。',
    '- 未产生可用策略延迟样本或模拟成交；重复跟单率、永久漏单率仍未知。',
    '- 各轮生产主库 hash/全表 hash 一致，三轮首尾比较亦见 JSON；未启动或重启生产。',
    '- 本轮未修改产品代码、账本、规则或 VOID checkpoint。', '',
    '## 下一步', '',
    '先排查/验证实时数据源的订阅与 eth_getLogs 可用性，以及市场身份资料请求失败。',
    '得到稳定数据后再跑隔离观察；本轮不据此启动新版持续运行。', '',
    '## 证据与限制', '']
for r in rows:
    lines.append('- ' + r['summary_path'])
lines += ['', '三轮时间不同，样本有限，不能证明哪种 chunk 最优或供应商永久不可用。',
    'RPC 耗时不等于 leader→EDGE 延迟。第一轮退出时记录一次未处理 data_freshness 请求失败；未在本任务扩展修复。']
(OUT / 'observation_comparison.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
