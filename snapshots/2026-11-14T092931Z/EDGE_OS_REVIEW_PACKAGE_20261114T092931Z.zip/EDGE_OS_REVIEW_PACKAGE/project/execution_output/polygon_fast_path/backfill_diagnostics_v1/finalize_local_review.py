"""Artifact-only local review finalization; no database connections or network."""
import difflib
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
FILES = ['app/polygon_fast_path.py', 'execution_output/polygon_fast_path/observe_forward.py',
         'tests/test_polygon_fast_path.py']
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

before = json.loads((OUT / 'local_review_before.json').read_text(encoding='utf-8-sig'))
preservation = []
for row in before:
    path = ROOT / row['path']
    preservation.append({'path': row['path'], 'before_sha256': row['sha256'].lower(),
                         'after_sha256': digest(path), 'before_size': row['size'],
                         'after_size': path.stat().st_size,
                         'unchanged': row['sha256'].lower() == digest(path)})
assert all(row['unchanged'] for row in preservation), preservation
diff = ''.join(''.join(difflib.unified_diff(
    (OUT / 'source_before' / name).read_text(encoding='utf-8').splitlines(True),
    (ROOT / name).read_text(encoding='utf-8').splitlines(True),
    fromfile='a/' + name, tofile='b/' + name)) for name in FILES)
(OUT / 'exact.diff').write_text(diff, encoding='utf-8', newline='\n')
assert not any(line.startswith('+') and not line.startswith('+++') and
               line.rstrip('\n\r') != line.rstrip() for line in diff.splitlines(True))
at = datetime.now(timezone.utc).isoformat()
review = {'captured_at_utc': at, 'result': 'LOCAL_REVIEW_PASS_WITH_LIMITATIONS',
          'reviewer': 'Codex self-review; no independent ChatGPT review requested in this iteration',
          'test_result': '81 passed, 1 existing warning', 'test_exit_code': 0,
          'compile_exit_code': 0, 'exact_diff_whitespace_exit_code': 0,
          'full_regression': 'not run; scoped task', 'preservation': preservation,
          'limitations': ['No live RPC observation; provider stability remains unmeasured.',
                         'Main-file hash alone does not prove committed WAL state unchanged.',
                         'Telemetry covers eth_getLogs request attempts, not downstream stage/identity errors.'],
          'production_or_historical_db_connections': False, 'observation_started': False}
(OUT / 'local_review.json').write_text(json.dumps(review, indent=2), encoding='utf-8')
tests = (OUT / 'local_review_tests.txt').read_text(encoding='utf-8-sig')
(OUT / 'test_results.txt').write_text(
    'Final scoped run: .venv/Scripts/python.exe -m pytest tests/test_polygon_fast_path.py '
    '-q -p no:cacheprovider --basetemp <output>/local_review_tests_final_20261011\n'
    'Exit code: 0\n' + tests + '\ncompileall affected files: exit 0\n'
    'exact diff whitespace: exit 0\n'
    'Initial command used system Python without pytest (exit 1); switched to project venv.\n'
    'Initial new fixture lacked WSS URL: 3 failed, 78 passed (exit 1); fixture corrected.\n'
    'Initial failed pytest output retained in local_review_tests_initial_failure.txt.\n', encoding='utf-8')
report = '''# Polygon Fast Path BACKFILL 诊断：实现与本地审查

- TASK_ID：c2c_polygon_orderfilled_fast_path_backfill_diagnostics_v1 / Iteration 1
- 状态：EXECUTED / LOCAL_REVIEW_PASS_WITH_LIMITATIONS；按用户本轮要求由 Codex 自审，不连接网页。
- 本轮读取现有实现并补充 7 个参数化/确定性测试用例；运行代码未再次改动。

## 精确范围

任务累计修改：app/polygon_fast_path.py、execution_output/polygon_fast_path/observe_forward.py、tests/test_polygon_fast_path.py。
exact.diff 以本任务修改前保存的 source_before 为基线，不包含工作区已有其他改动。

## 审查结论

- telemetry 仅包含 retry_number、phase、rpc_method、start_block、end_block、block_range_size、duration_ms、result_count、error_type、timestamp。时间为 UTC，耗时来自 monotonic；不保存异常消息、RPC 地址或环境变量。
- retry_number 从每个起始区块的首次实际请求 0 开始，缩小有效范围时递增；重连后的新请求重新计数。
- 默认配置关闭 telemetry、未设置 chunk：保留一次请求覆盖允许 gap 的行为。
- 显式 chunk 支持 256/128/64，RPC 失败或超过既有 10000 条响应上限才尝试更小范围；重复有效范围不重复请求，畸形响应停止。
- 所有 chunk 成功后才推进 checkpoint；前段已暂存事件沿用既有身份去重。诊断写入失败设置失败标志，不改变补漏结果。
- 隔离观察脚本提供参数并导出 backfill_diagnostics.json；选择 256 时仅扩大该隔离运行的 gap 上限至 256。

## 验证

- 专项测试：81 passed, 1 warning，exit 0；警告为既有 Starlette/anyio 弃用警告。
- 受影响文件 compileall：exit 0；精确差异空白检查：exit 0。
- 新测试覆盖三种配置、畸形响应、超量响应回退、后段失败保留 checkpoint、诊断持久化失败。
- 初次新增测试有 3 个 fixture 配置失败，已补合法虚构 WSS URL；失败记录保留。没有请求该 URL。
- 未运行全仓回归；未执行观察脚本、生产重启、真实订单或历史成交回放。

## 保护与局限

本轮只散列生产主 DB 文件与 ledger/strict-paper 源码，前后均一致，详见 local_review.json；未连接生产或历史观察数据库，未改 VOID checkpoint。
主库文件 hash 不是 WAL 内容不变的证明，本轮不声称完成生产逻辑全表核对。
没有新的真实网络样本，不能宣称 eth_getLogs 已稳定、测得成功率或最佳 chunk。
telemetry 衡量 RPC 请求响应，不覆盖后续事件排序、身份解析/暂存失败；error_type 为类型，不含供应商错误详情。

## 输出

execution_report.md / manifest.json / test_results.txt / exact.diff / local_review.json。
停止在本地 REVIEW，未启动下一轮观察。
'''
(OUT / 'execution_report.md').write_text(report, encoding='utf-8')
manifest = json.loads((OUT / 'manifest.json').read_text(encoding='utf-8'))
manifest['state'] = 'REVIEW'
manifest['local_review'] = review
manifest['source_sha256_after'] = {name: digest(ROOT / name) for name in FILES}
manifest['tests'].update(targeted_result='81 passed, 1 warning', targeted_exit_code=0,
                         compileall_exit_code=0, exact_diff_whitespace_exit_code=0)
manifest['exact_diff'].update(bytes=(OUT / 'exact.diff').stat().st_size,
    added_lines=sum(line.startswith('+') and not line.startswith('+++') for line in diff.splitlines()),
    removed_lines=sum(line.startswith('-') and not line.startswith('---') for line in diff.splitlines()))
manifest['artifact_sha256'] = {name: digest(OUT / name) for name in
    ['execution_report.md', 'test_results.txt', 'exact.diff', 'before_state.json', 'local_review.json']}
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'state': 'REVIEW', 'review': review['result'],
                  'preservation': preservation, 'exact_diff': manifest['exact_diff']}, indent=2))
