"""Confirmed Polygon V2 OrderFilled producer. Never signs or submits transactions."""
from __future__ import annotations

import asyncio
import json
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from urllib.parse import urlsplit

from .fill_identity import ADDRESS, HEX32, economics, strong_key

ABI_COMMIT = 'ccc0596074f4dfd62c944fbca4de252893b82b4b'
PROVENANCE = 'https://github.com/Polymarket/ctf-exchange-v2/tree/'+ABI_COMMIT
DEPLOYMENT_SOURCE = 'https://docs.polymarket.com/resources/contracts'
CONTRACTS = ('0xe111180000d2663c0091e4f400237545b87b996b',
             '0xe2222d279d744050d28e00520010520000310f59')
EVENT_SIGNATURE = 'OrderFilled(bytes32,address,address,uint8,uint256,uint256,uint256,uint256,bytes32,bytes32)'

def keccak256(data: bytes) -> str:
    """Ethereum Keccak-256 (not FIPS SHA3); fixed event topic without a new SDK."""
    rotations = (0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14)
    constants = (1,0x8082,0x800000000000808a,0x8000000080008000,0x808b,0x80000001,
        0x8000000080008081,0x8000000000008009,0x8a,0x88,0x80008009,0x8000000a,
        0x8000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,
        0x8000000000008002,0x8000000000000080,0x800a,0x800000008000000a,
        0x8000000080008081,0x8000000000008080,0x80000001,0x8000000080008008)
    mask = (1 << 64)-1
    def rotate(v, n): return ((v << n) | (v >> (64-n))) & mask if n else v
    padded = bytearray(data); padding=136-len(padded)%136
    if padding==1:padded.append(129)
    else:
        padded.append(1);padded.extend(b'\0'*(padding-2));padded.append(128)
    a = [0]*25
    for start in range(0,len(padded),136):
        for i in range(17): a[i] ^= int.from_bytes(padded[start+8*i:start+8*i+8],'little')
        for rc in constants:
            c = [a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20] for x in range(5)]
            d = [c[(x-1)%5]^rotate(c[(x+1)%5],1) for x in range(5)]
            for i in range(25): a[i] ^= d[i%5]
            b = [0]*25
            for x in range(5):
                for y in range(5): b[y+5*((2*x+3*y)%5)] = rotate(a[x+5*y],rotations[x+5*y])
            for x in range(5):
                for y in range(5): a[x+5*y] = b[x+5*y] ^ ((~b[(x+1)%5+5*y]) & b[(x+2)%5+5*y])
            a[0] ^= rc
    return '0x'+b''.join(v.to_bytes(8,'little') for v in a)[:32].hex()

ORDERFILLED_TOPIC = keccak256(EVENT_SIGNATURE.encode())

def utc(): return datetime.now(timezone.utc).isoformat()

def integer(value):
    if isinstance(value,bool) or not isinstance(value,(str,int)):
        raise ValueError('INVALID_CHAIN_INTEGER')
    if isinstance(value,str) and not (value.isdecimal() or
            (value.startswith('0x') and value[2:] and all(c in '0123456789abcdefABCDEF' for c in value[2:]))):
        raise ValueError('INVALID_CHAIN_INTEGER')
    result = int(value,16) if isinstance(value,str) and value.startswith('0x') else int(value)
    if result < 0: raise ValueError('INVALID_CHAIN_INTEGER')
    return result

def decode_log(raw, contracts=CONTRACTS):
    address = str(raw.get('address','')).lower()
    topics = raw.get('topics')
    data = raw.get('data')
    if address not in contracts or not isinstance(topics,list) or len(topics)!=4:
        raise ValueError('INVALID_ORDERFILLED_IDENTITY')
    if any(not isinstance(t,str) or not HEX32.fullmatch(t) for t in topics):
        raise ValueError('MALFORMED_ORDERFILLED_TOPICS')
    if topics[0].lower()!=ORDERFILLED_TOPIC: raise ValueError('INVALID_ORDERFILLED_IDENTITY')
    if any(int(t[2:26],16) for t in topics[2:]): raise ValueError('MALFORMED_ADDRESS_PADDING')
    if not isinstance(data,str) or len(data)!=450 or not data.startswith('0x'):
        raise ValueError('MALFORMED_ORDERFILLED_DATA')
    try: words = [int(data[i:i+64],16) for i in range(2,450,64)]
    except ValueError: raise ValueError('MALFORMED_ORDERFILLED_DATA') from None
    side,token,making,taking,fee,builder,metadata = words
    if side not in (0,1) or min(token,making,taking)<=0: raise ValueError('INVALID_ORDERFILLED_AMOUNTS')
    tx = str(raw.get('transactionHash','')).lower(); block_hash = str(raw.get('blockHash','')).lower()
    if not HEX32.fullmatch(tx) or not HEX32.fullmatch(block_hash): raise ValueError('MISSING_CHAIN_IDENTITY')
    # Trading._deriveAssetIds: BUY gives collateral, receives tokens. SELL reverses.
    with localcontext() as ctx:
        ctx.prec = 100
        shares = Decimal(taking if side==0 else making)/Decimal(10**6)
        gross = Decimal(making if side==0 else taking)/Decimal(10**6)
        price = gross/shares
    if not 0 < price <= 1: raise ValueError('INVALID_CHAIN_PRICE')
    result = {'chain_id':137,'contract_address':address,'transaction_hash':tx,
        'block_number':integer(raw['blockNumber']),'block_hash':block_hash,
        'log_index':integer(raw['logIndex']),'transaction_index':integer(raw['transactionIndex']) if raw.get('transactionIndex') is not None else None,
        'order_hash':topics[1].lower(),'maker':'0x'+topics[2][-40:].lower(),
        'taker':'0x'+topics[3][-40:].lower(),'token_id':str(token),'side':'BUY' if side==0 else 'SELL',
        'size':str(shares),'usd_value':str(gross),'price':str(price),'fee_raw':str(fee),
        'maker_amount_raw':str(making),'taker_amount_raw':str(taking),
        'builder':'0x'+format(builder,'064x'),'metadata':'0x'+format(metadata,'064x'),
        'removed':raw.get('removed') is True,'abi_source':PROVENANCE,'raw_log':raw}
    result['event_id'] = strong_key(result)
    return result

def identity_valid(item, token):
    return (isinstance(item,dict) and str(item.get('token_id'))==str(token) and
            HEX32.fullmatch(str(item.get('condition_id',''))) and
            isinstance(item.get('outcome'),str) and bool(item['outcome'].strip()))

SCHEMA = """
CREATE TABLE IF NOT EXISTS polygon_fast_events (
 event_id TEXT NOT NULL, block_hash TEXT NOT NULL, block_number INTEGER NOT NULL,
 log_index INTEGER NOT NULL, wallet TEXT NOT NULL, state TEXT NOT NULL,
 first_observed_at TEXT NOT NULL, received_at TEXT NOT NULL, block_timestamp INTEGER,
 normalized_at TEXT, strategy_started_at TEXT, evidence_json TEXT NOT NULL,
 normalized_json TEXT, reason TEXT, PRIMARY KEY(event_id,block_hash));
CREATE INDEX IF NOT EXISTS idx_polygon_fast_pending ON polygon_fast_events(state,block_number,log_index);
CREATE TABLE IF NOT EXISTS polygon_fast_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT,block_hash TEXT,at TEXT NOT NULL,
 action TEXT NOT NULL,evidence_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS polygon_fast_state (key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS polygon_token_cache (
 token_id TEXT PRIMARY KEY,condition_id TEXT NOT NULL,outcome TEXT NOT NULL,
 checked_at REAL NOT NULL,evidence_json TEXT NOT NULL);
"""

class EventStore:
    def __init__(self,database): self.db=database
    def initialize(self):
        with self.db.conn() as c: c.executescript(SCHEMA)
    def audit(self,c,event,action,evidence):
        c.execute('INSERT INTO polygon_fast_audit(event_id,block_hash,at,action,evidence_json) VALUES(?,?,?,?,?)',
            (event['event_id'],event['block_hash'],utc(),action,json.dumps(evidence,sort_keys=True,default=str)))
    def stage(self,event,observed,received,tracked):
        with self.db.conn() as c:
            old=c.execute('SELECT state FROM polygon_fast_events WHERE event_id=? AND block_hash=?',
                (event['event_id'],event['block_hash'])).fetchone()
            if event['removed']:
                state='REORG_AFTER_ADMISSION' if old and old[0] in ('ROUTED','ROUTING') else 'REMOVED'
                if not old:
                    c.execute('INSERT INTO polygon_fast_events(event_id,block_hash,block_number,log_index,wallet,state,first_observed_at,received_at,evidence_json) VALUES(?,?,?,?,?,?,?,?,?)',
                        (event['event_id'],event['block_hash'],event['block_number'],event['log_index'],event['maker'],state,observed,received,json.dumps(event,sort_keys=True)))
                c.execute('UPDATE polygon_fast_events SET state=?,reason=? WHERE event_id=? AND block_hash=?',
                          (state,'REMOVED_CHAIN_LOG',event['event_id'],event['block_hash']))
                self.audit(c,event,state,event); return False
            if old: return False
            state='WAITING_CONFIRMATION' if tracked else 'UNTRACKED'
            c.execute('INSERT INTO polygon_fast_events(event_id,block_hash,block_number,log_index,wallet,state,first_observed_at,received_at,evidence_json) VALUES(?,?,?,?,?,?,?,?,?)',
                (event['event_id'],event['block_hash'],event['block_number'],event['log_index'],event['maker'],state,observed,received,json.dumps(event,sort_keys=True)))
            self.audit(c,event,state,{'tracked':tracked}); return True
    def transition(self,event,state,reason=None,trade=None,block_timestamp=None,started=None):
        with self.db.conn() as c:
            c.execute('UPDATE polygon_fast_events SET state=?,reason=?,block_timestamp=COALESCE(?,block_timestamp),normalized_at=COALESCE(?,normalized_at),normalized_json=COALESCE(?,normalized_json),strategy_started_at=COALESCE(?,strategy_started_at) WHERE event_id=? AND block_hash=?',
                (state,reason,block_timestamp,trade['raw']['normalized_ready_at'] if trade else None,json.dumps(trade,sort_keys=True,default=str) if trade else None,started,event['event_id'],event['block_hash']))
            self.audit(c,event,state,{'reason':reason})
    def pending(self,confirmed,limit=100):
        with self.db.conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM polygon_fast_events WHERE state IN ('WAITING_CONFIRMATION','PENDING_METADATA') AND block_number<=? ORDER BY block_number,log_index LIMIT ?",(confirmed,limit))]
    def checkpoint(self,height=None):
        with self.db.conn() as c:
            if height is not None: c.execute("INSERT INTO polygon_fast_state VALUES('confirmed_block',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(str(height),))
            row=c.execute("SELECT value FROM polygon_fast_state WHERE key='confirmed_block'").fetchone()
            return int(row[0]) if row else None
    def forward_boundary(self,height=None):
        with self.db.conn() as c:
            if height is not None:
                c.execute("INSERT OR IGNORE INTO polygon_fast_state VALUES('forward_boundary',?)",(str(height),))
            row=c.execute("SELECT value FROM polygon_fast_state WHERE key='forward_boundary'").fetchone()
            return int(row[0]) if row else None
    def restart_recovery(self):
        # A routing crash must never repeat an execution against later order books.
        with self.db.conn() as c:
            rows=c.execute("SELECT evidence_json FROM polygon_fast_events WHERE state='ROUTING'").fetchall()
            for row in rows:
                event=json.loads(row[0])
                c.execute("UPDATE polygon_fast_events SET state='ROUTING_INTERRUPTED',reason='NO_EXECUTION_REPLAY' WHERE event_id=? AND block_hash=? AND state='ROUTING'",(event['event_id'],event['block_hash']))
                self.audit(c,event,'ROUTING_INTERRUPTED',{'reason':'NO_EXECUTION_REPLAY'})

class TokenResolver:
    def __init__(self,database,client,limit=2048,ttl=3600):
        self.db=database; self.client=client; self.limit=limit; self.ttl=ttl
    async def resolve(self,token):
        # Local mapping is only usable when raw upstream identity agrees exactly.
        with self.db.conn() as c:
            rows=c.execute('SELECT condition_id,outcome,raw_json FROM trades WHERE token_id=? ORDER BY timestamp DESC LIMIT 20',(token,)).fetchall()
            found={}
            for row in rows:
                raw=json.loads(row['raw_json']); asset=str(raw.get('asset') or raw.get('token_id') or raw.get('tokenId') or raw.get('asset_id') or '')
                condition=raw.get('conditionId') or raw.get('condition_id'); outcome=raw.get('outcome')
                item={'token_id':asset,'condition_id':condition,'outcome':outcome,'source':'LOCAL_UPSTREAM_TRADE','raw':raw}
                if identity_valid(item,token) and (condition,outcome)==(row['condition_id'],row['outcome']): found[(condition,outcome)]=item
            if len(found)==1: return next(iter(found.values()))
            if len(found)>1: raise ValueError('CONFLICTING_TOKEN_METADATA')
            cached=c.execute('SELECT * FROM polygon_token_cache WHERE token_id=? AND checked_at>?',(token,time.time()-self.ttl)).fetchone()
            if cached: return {'token_id':token,'condition_id':cached['condition_id'],'outcome':cached['outcome'],'source':'CACHED_GAMMA','raw':json.loads(cached['evidence_json'])}
        market=await asyncio.wait_for(self.client.fast_token_metadata(token),timeout=8)
        if not identity_valid(market,token): raise ValueError('UNVERIFIED_TOKEN_METADATA')
        with self.db.conn() as c:
            c.execute('INSERT INTO polygon_token_cache VALUES(?,?,?,?,?) ON CONFLICT(token_id) DO UPDATE SET condition_id=excluded.condition_id,outcome=excluded.outcome,checked_at=excluded.checked_at,evidence_json=excluded.evidence_json',
                (token,market['condition_id'],market['outcome'],time.time(),json.dumps(market,sort_keys=True,default=str)))
            c.execute('DELETE FROM polygon_token_cache WHERE token_id NOT IN (SELECT token_id FROM polygon_token_cache ORDER BY checked_at DESC,token_id LIMIT ?)',(self.limit,))
        return market

def normalize_event(event,identity,block_timestamp,observed,ready,receipt_unique):
    if not identity_valid(identity,event['token_id']): raise ValueError('UNVERIFIED_TOKEN_METADATA')
    raw={**event,'_chain_fill':{k:event[k] for k in ('chain_id','contract_address','transaction_hash','log_index')},
        '_receipt_unique':receipt_unique,'source_observed_at':observed,'normalized_ready_at':ready,
        'token_identity_evidence':identity,'price':event['price'],'size':event['size'],'usd_value':event['usd_value']}
    return {'trade_key':event['event_id'],'wallet':event['maker'],'token_id':event['token_id'],
        'condition_id':identity['condition_id'],'outcome':identity['outcome'],'side':event['side'],
        'price':event['price'],'size':event['size'],'usd_value':event['usd_value'],'timestamp':block_timestamp,
        'tx_hash':event['transaction_hash'],'title':identity.get('title') or identity.get('question') or 'Unknown market',
        'category':identity.get('category') or identity.get('market_category') or 'Unknown','raw':raw}

def latency_summary(rows):
    names=('chain_source','normalization','strategy','total')
    series={name:[] for name in names}
    for row in rows:
        try:
            chain=float(row['block_timestamp']);observed=datetime.fromisoformat(row['first_observed_at']).timestamp()
            ready=datetime.fromisoformat(row['normalized_at']).timestamp();started=datetime.fromisoformat(row['strategy_started_at']).timestamp()
            for name,v in zip(names,(observed-chain,ready-observed,started-ready,started-chain)):
                if v>=0: series[name].append(v)
        except (ValueError,TypeError,KeyError): continue
    def summary(values):
        values=sorted(values);n=len(values)
        if not n:return {'sample_count':0,'p50':None,'p75':None,'p90':None,'p95':None,'max':None}
        return {'sample_count':n,**{'p'+str(p):values[max(0,(n*p+99)//100-1)] for p in (50,75,90,95)},'max':values[-1]}
    return {name:summary(values) for name,values in series.items()}

@dataclass(frozen=True)
class ProducerConfig:
    url: str = field(default='',repr=False)
    enabled: bool = False
    contracts: tuple[str,...] = CONTRACTS
    confirmation_depth: int = 1
    backfill_blocks: int = 128
    rpc_timeout: float = 8
    heartbeat_seconds: float = 5
    queue_size: int = 2048
    def validate(self):
        parsed=urlsplit(self.url)
        if parsed.scheme!='wss' or not parsed.hostname or parsed.fragment: raise ValueError('INVALID_WSS_CONFIGURATION')
        if not self.contracts or any(c.lower() not in CONTRACTS for c in self.contracts):
            raise ValueError('UNVERIFIED_CONTRACT_OR_ABI_CONFIGURATION')
        if not 1<=self.confirmation_depth<=32 or not 1<=self.backfill_blocks<=1024 or self.rpc_timeout<=0 or self.heartbeat_seconds<=0 or not 1<=self.queue_size<=10000:
            raise ValueError('INVALID_PRODUCER_LIMIT')

class PolygonProducer:
    def __init__(self,database,client,ingest,config=None,connect=None):
        self.db=database;self.client=client;self.ingest=ingest;self.config=config or ProducerConfig()
        self.store=EventStore(database);self.resolver=TokenResolver(database,client)
        self.connect=connect;self.task=None;self.stop_event=asyncio.Event();self.socket=None
        self.pending_rpc={};self.request_id=0;self.send_lock=asyncio.Lock()
        self.queue=asyncio.Queue(maxsize=self.config.queue_size);self.connected=False
        self.counters={'raw_events_seen':0,'tracked_events_seen':0,'normalized_events':0,'events_admitted_to_strategy':0,'duplicates_reconciled':0,'reconnect_count':0}
        self.last_event_at=None;self.last_block=None;self.error_category=None
        self.phase='IDLE';self.failed_rpc_method=None;self.last_reconnect=None
        self.tracked={};self.ready=False
    def start(self):
        if not self.config.enabled or not self.config.url: return
        try: self.config.validate()
        except ValueError as exc: self.error_category=str(exc);return
        try:
            self.store.initialize();self.store.restart_recovery();self.ready=True
        except Exception:
            self.error_category='PRODUCER_STATE_INIT_ERROR';return
        if not self.task or self.task.done():
            self.stop_event.clear();self.task=asyncio.create_task(self.run(),name='polygon-orderfilled')
    async def stop(self):
        self.stop_event.set()
        if self.task:
            self.task.cancel()
            try: await self.task
            except asyncio.CancelledError: pass
        self.connected=False
    async def rpc(self,method,params):
        self.request_id+=1;rid=self.request_id
        future=asyncio.get_running_loop().create_future();self.pending_rpc[rid]=future
        try:
            async with self.send_lock:
                await self.socket.send(json.dumps({'jsonrpc':'2.0','id':rid,'method':method,'params':params}))
            return await asyncio.wait_for(future,self.config.rpc_timeout)
        except Exception:
            self.failed_rpc_method=method
            raise
        finally: self.pending_rpc.pop(rid,None)
    async def reader(self):
        try:
            async for message in self.socket:
                payload=json.loads(message)
                if 'id' in payload:
                    future=self.pending_rpc.get(payload['id'])
                    if future and not future.done():
                        if 'error' in payload:future.set_exception(ValueError('PROVIDER_RPC_ERROR'))
                        else:future.set_result(payload.get('result'))
                elif payload.get('method')=='eth_subscription':
                    value=payload.get('params',{}).get('result')
                    if isinstance(value,dict) and 'topics' in value:
                        self.queue.put_nowait((value,utc()))
        finally:
            for future in list(self.pending_rpc.values()):
                if not future.done():future.set_exception(ConnectionError('WSS_DISCONNECTED'))
    def refresh_wallets(self):
        self.tracked={w['address'].lower():w for w in self.db.tracked_wallets()}
    def stage(self,raw,received=None,transport='WSS'):
        self.counters['raw_events_seen']+=1
        try:event=decode_log(raw,tuple(c.lower() for c in self.config.contracts))
        except (ValueError,TypeError,KeyError):
            self.error_category='INVALID_CHAIN_LOG'
            # Invalid log evidence remains auditable without fabricating an identity.
            with self.db.conn() as c:
                c.execute('INSERT INTO polygon_fast_audit(at,action,evidence_json) VALUES(?,?,?)',
                    (utc(),'INVALID_CHAIN_LOG',json.dumps(raw,sort_keys=True,default=str)))
            return
        tracked=event['maker'] in self.tracked
        event['observation_transport']=transport
        if tracked:self.counters['tracked_events_seen']+=1
        self.last_event_at=received or utc()
        if not tracked: return  # bounded local filter: do not persist the whole exchange firehose
        boundary=self.store.forward_boundary()
        if boundary is not None and event['block_number']<=boundary and not event['removed']:return
        self.store.stage(event,self.last_event_at,self.last_event_at,tracked)
    async def process_pending(self,confirmed):
        for row in self.store.pending(confirmed):
            self.phase='PROCESS_PENDING'
            event=json.loads(row['evidence_json']);wallet=self.tracked.get(event['maker'])
            if not wallet:self.store.transition(event,'UNTRACKED','WALLET_NO_LONGER_TRACKED');continue
            block=await self.rpc('eth_getBlockByNumber',[hex(event['block_number']),False])
            if not isinstance(block,dict) or str(block.get('hash','')).lower()!=event['block_hash']:
                self.store.transition(event,'REORG','CANONICAL_BLOCK_MISMATCH');continue
            stamp=integer(block['timestamp'])
            receipt=await self.rpc('eth_getTransactionReceipt',[event['transaction_hash']])
            if not isinstance(receipt,dict) or str(receipt.get('blockHash','')).lower()!=event['block_hash'] or integer(receipt.get('status','0x0'))!=1:
                self.store.transition(event,'REORG','UNVERIFIED_RECEIPT');continue
            supported=[]
            unknown_topic=False
            try:
                for raw in receipt.get('logs',[]):
                    if (raw.get('topics') or [None])[0]!=ORDERFILLED_TOPIC:continue
                    if str(raw.get('address','')).lower() in self.config.contracts:
                        supported.append(decode_log(raw,self.config.contracts))
                    else:unknown_topic=True
            except (ValueError,TypeError,KeyError):
                self.store.transition(event,'INVALID_EVIDENCE','MALFORMED_RECEIPT_LOG');continue
            compare=('event_id','block_hash','order_hash','maker','taker','token_id','side','maker_amount_raw','taker_amount_raw','fee_raw','builder','metadata')
            exact=[v for v in supported if all(v[k]==event[k] for k in compare)]
            if len(exact)!=1:self.store.transition(event,'INVALID_EVIDENCE','RECEIPT_LOG_MISMATCH');continue
            peers=[v for v in supported if (v['maker'],v['token_id'],v['side'],v['size'],v['usd_value'])==(event['maker'],event['token_id'],event['side'],event['size'],event['usd_value'])]
            try:identity=await self.resolver.resolve(event['token_id'])
            except Exception:
                self.store.transition(event,'PENDING_METADATA','METADATA_UNAVAILABLE',block_timestamp=stamp);continue
            trade=normalize_event(event,identity,stamp,row['first_observed_at'],utc(),len(peers)==1 and not unknown_topic)
            trade['raw']['wss_received_at']=row['received_at']
            trade['raw']['receipt_evidence']={'block_hash':receipt['blockHash'],'supported_log_count':len(supported),'economic_peer_count':len(peers)}
            self.counters['normalized_events']+=1
            self.store.transition(event,'ROUTING',trade=trade,block_timestamp=stamp)
            try:result=await self.ingest(wallet,trade)
            except Exception:
                self.store.transition(event,'ROUTING_INTERRUPTED','NO_EXECUTION_REPLAY');continue
            self.phase='TERMINAL_TRANSITION'
            if result is None:
                with self.db.conn() as c:
                    observation=c.execute('SELECT state FROM fill_identity_audit WHERE wallet=? AND source=? AND source_id=? ORDER BY id DESC LIMIT 1',
                        (event['maker'],'FAST_PATH',event['event_id'])).fetchone()
                state=observation[0] if observation else 'NO_STRATEGY_SIGNAL'
                if state.startswith('DUPLICATE'):
                    self.counters['duplicates_reconciled']+=1
                    self.store.transition(event,'RECONCILED_DUPLICATE',state)
                elif state.startswith('AMBIGUOUS'):
                    self.store.transition(event,'AMBIGUOUS',state)
                else:self.store.transition(event,'NO_STRATEGY_SIGNAL',state)
            else:
                started=result.get('_fast_path_processing_started_at') if isinstance(result,dict) else None
                # FIRST returns structured strict decision evidence; ADD_ON and
                # routing guards return string labels. Never hash the evidence dict.
                route_label=result.get('decision') if isinstance(result,dict) else None
                blocked=isinstance(route_label,str) and route_label in {
                    'FAST_PATH_V2_INACTIVE','V2_RUNTIME_LOCKED','V2_ROUTING_STATE_ERROR',
                    'V2_NON_BUY_IGNORED','V2_PRE_RESTART_TRADE_IGNORED'}
                if blocked:self.store.transition(event,'OBSERVED_NO_ADMISSION',result['decision'])
                else:
                    self.counters['events_admitted_to_strategy']+=1
                    self.store.transition(event,'ROUTED',started=started)
    async def backfill(self,confirmed):
        self.phase='BACKFILL'
        checkpoint=self.store.checkpoint()
        if checkpoint is None:
            # First enable is a forward boundary, not a historical replay request.
            self.store.checkpoint(confirmed);self.last_block=confirmed;return
        if confirmed < checkpoint:raise ValueError('CHAIN_HEAD_REGRESSION')
        if confirmed-checkpoint>self.config.backfill_blocks:raise ValueError('BACKFILL_GAP_EXCEEDS_BOUND')
        if confirmed>checkpoint:
            logs=await self.rpc('eth_getLogs',[{'address':list(self.config.contracts),'topics':[ORDERFILLED_TOPIC],
                'fromBlock':hex(checkpoint+1),'toBlock':hex(confirmed)}])
            if not isinstance(logs,list):raise ValueError('INVALID_BACKFILL_RESPONSE')
            if len(logs)>10000:raise ValueError('BACKFILL_RESPONSE_EXCEEDS_BOUND')
            for raw in sorted(logs,key=lambda r:(integer(r['blockNumber']),integer(r['logIndex']))):self.stage(raw,transport='BACKFILL')
            self.store.checkpoint(confirmed);self.last_block=confirmed
        await self.process_pending(confirmed)
    async def connection(self,socket):
        self.socket=socket
        reader=asyncio.create_task(self.reader())
        try:
            self.phase='CHAIN_ID'
            if integer(await self.rpc('eth_chainId',[]))!=137:raise ValueError('WRONG_CHAIN_ID')
            self.phase='HEARTBEAT'
            initial_head=integer(await self.rpc('eth_blockNumber',[]))
            self.store.forward_boundary(initial_head)
            if self.store.checkpoint() is None:
                self.store.checkpoint(max(0,initial_head-self.config.confirmation_depth))
            self.phase='SUBSCRIBE'
            await self.rpc('eth_subscribe',['logs',{'address':list(self.config.contracts),'topics':[ORDERFILLED_TOPIC]}])
            self.connected=True;self.error_category=None
            while not self.stop_event.is_set():
                if reader.done():await reader;raise ConnectionError('WSS_DISCONNECTED')
                self.refresh_wallets()
                # RPC heartbeat proves the provider is responding even when no tracked fill occurs.
                self.phase='HEARTBEAT'
                head=integer(await self.rpc('eth_blockNumber',[]))
                while not self.queue.empty():
                    raw,received=self.queue.get_nowait();self.stage(raw,received)
                await self.backfill(max(0,head-self.config.confirmation_depth))
                await asyncio.sleep(self.config.heartbeat_seconds)
        finally:
            self.connected=False;reader.cancel()
            await asyncio.gather(reader,return_exceptions=True)
            self.socket=None
    async def run(self):
        if self.connect is None:
            from websockets.asyncio.client import connect
            self.connect=connect
        failures=0
        while not self.stop_event.is_set():
            try:
                self.phase='CONNECT';self.failed_rpc_method=None
                async with self.connect(self.config.url,open_timeout=self.config.rpc_timeout,
                    ping_interval=10,ping_timeout=10,max_size=2**20,max_queue=32) as socket:
                    await self.connection(socket)
                    failures=0
            except asyncio.CancelledError:raise
            except Exception as exc:
                self.connected=False;self.counters['reconnect_count']+=1;failures+=1
                # Never persist or return provider exception strings (they may contain credentials).
                self.error_category=str(exc) if isinstance(exc,ValueError) and str(exc) in {
                    'WRONG_CHAIN_ID','BACKFILL_GAP_EXCEEDS_BOUND','CHAIN_HEAD_REGRESSION','PROVIDER_RPC_ERROR'} else type(exc).__name__
                self.last_reconnect={'reconnect_number':self.counters['reconnect_count'],
                    'error_type':type(exc).__name__,'phase':self.phase,
                    'rpc_method':self.failed_rpc_method,'timestamp':utc()}
                try:
                    with self.db.conn() as c:
                        c.execute('INSERT INTO polygon_fast_audit(at,action,evidence_json) VALUES(?,?,?)',
                            (self.last_reconnect['timestamp'],'RECONNECT_DIAGNOSTIC',json.dumps(self.last_reconnect,sort_keys=True)))
                except Exception:
                    # Diagnostics must not prevent a bounded transport retry.
                    self.last_reconnect['persistence_failed']=True
                try:await asyncio.wait_for(self.stop_event.wait(),min(60,2**min(failures,6))+random.uniform(0,1))
                except asyncio.TimeoutError:pass
    def status(self):
        result={'enabled':self.config.enabled,'configured':bool(self.config.url),'connected':self.connected,
            'last_event_at':self.last_event_at,'last_block':self.last_block,'error_category':self.error_category,
            'tracked_wallet_count':len(self.tracked),'confirmation_depth':self.config.confirmation_depth,
            'contract_addresses':list(self.config.contracts),'abi_provenance':PROVENANCE,
            'deployment_provenance':DEPLOYMENT_SOURCE,'counter_scope':'CURRENT_PROCESS',**self.counters,
            'phase':self.phase,'last_reconnect':self.last_reconnect,
            'pending_metadata':0,'latency':latency_summary([]),'backfill_latency':latency_summary([]),'live_orders':False}
        if self.ready:
            try:
                with self.db.conn() as c:
                    result['pending_metadata']=c.execute("SELECT COUNT(*) FROM polygon_fast_events WHERE state='PENDING_METADATA'").fetchone()[0]
                    rows=[dict(r) for r in c.execute("SELECT block_timestamp,first_observed_at,normalized_at,strategy_started_at,evidence_json FROM polygon_fast_events WHERE strategy_started_at IS NOT NULL ORDER BY block_number DESC,log_index DESC LIMIT 1000")]
                    result['latency']=latency_summary([r for r in rows if json.loads(r['evidence_json']).get('observation_transport')=='WSS'])
                    result['backfill_latency']=latency_summary([r for r in rows if json.loads(r['evidence_json']).get('observation_transport')=='BACKFILL'])
            except Exception:result['status_read_error']='PRODUCER_STATE_READ_ERROR'
        return result
