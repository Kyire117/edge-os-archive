# 三轮隔离模拟观察结果

状态：观察完成；当前 Fast Path 数据链路不适合直接加载持续运行。

| 初始分块 | 请求成功/总数 | 回退请求 | 重连 | 身份解析成功/暂存事件 | episodes / fills |
|---|---:|---:|---:|---:|---:|
| 256 | 1/14 | 5 | 8 | 0/3 | 0/0 |
| 128 | 4/12 | 2 | 8 | 0/3 | 0/0 |
| 64 | 2/7 | 0 | 8 | 0/1 | 0/0 |

## 当前验证

- 每轮约 5 分钟，20 个跟踪钱包，新建独立模拟库；live_orders=false。
- 三轮均出现 BACKFILL 请求错误；128 分块结束时达到 BACKFILL_GAP_EXCEEDS_BOUND，未跳过缺口。
- 还有订阅超时、市场元数据等待以及轮询请求失败，不能认定只调 chunk 就可恢复。
- 未产生可用策略延迟样本或模拟成交；重复跟单率、永久漏单率仍未知。
- 各轮生产主库 hash/全表 hash 一致，三轮首尾比较亦见 JSON；未启动或重启生产。
- 本轮未修改产品代码、账本、规则或 VOID checkpoint。

## 下一步

先排查/验证实时数据源的订阅与 eth_getLogs 可用性，以及市场身份资料请求失败。
得到稳定数据后再跑隔离观察；本轮不据此启动新版持续运行。

## 证据与限制

- C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\execution_output\polygon_fast_path\forward_observation\20261011T101741Z\summary.json
- C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\execution_output\polygon_fast_path\forward_observation\20261011T102245Z\summary.json
- C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\execution_output\polygon_fast_path\forward_observation\20261011T102749Z\summary.json

三轮时间不同，样本有限，不能证明哪种 chunk 最优或供应商永久不可用。
RPC 耗时不等于 leader→EDGE 延迟。第一轮退出时记录一次未处理 data_freshness 请求失败；未在本任务扩展修复。
