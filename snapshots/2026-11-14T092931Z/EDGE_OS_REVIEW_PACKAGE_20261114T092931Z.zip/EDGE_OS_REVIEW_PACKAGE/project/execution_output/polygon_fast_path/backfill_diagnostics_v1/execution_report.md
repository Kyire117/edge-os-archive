# Polygon Fast Path BACKFILL 诊断：实现与本地审查

- TASK_ID：c2c_polygon_orderfilled_fast_path_backfill_diagnostics_v1 / Iteration 1
- 状态：EXECUTED / LOCAL_REVIEW_PASS_WITH_LIMITATIONS；按用户本轮要求由 Codex 自审，不连接网页。
- 本轮读取现有实现并补充 7 个参数化/确定性测试用例；运行代码未再次改动。

## 精确范围

任务累计修改：app/polygon_fast_path.py、execution_output/polygon_fast_path/observe_forward.py、tests/test_polygon_fast_path.py。
exact.diff 以本任务修改前保存的 source_before 为基线，不包含工作区已有其他改动。

## 审查结论

- telemetry 仅包含 retry_number、phase、rpc_method、start_block、end_block、block_range_size、duration_ms、result_count、error_type、timestamp。时间为 UTC，耗时来自 monotonic；不保存异常消息、RPC 地址或环境变量。
- retry_number 从每个起始区块的首次实际请求 0 开始，缩小有效范围时递增；重连后的新请求重新计数。
- 默认配置关闭 telemetry、未设置 chunk：保留一次请求覆盖允许 gap 的行为。
- 显式 chunk 支持 256/128/64，RPC 失败或超过既有 10000 条响应上限才尝试更小范围；重复有效范围不重复请求，畸形响应停止。
- 所有 chunk 成功后才推进 checkpoint；前段已暂存事件沿用既有身份去重。诊断写入失败设置失败标志，不改变补漏结果。
- 隔离观察脚本提供参数并导出 backfill_diagnostics.json；选择 256 时仅扩大该隔离运行的 gap 上限至 256。

## 验证

- 专项测试：81 passed, 1 warning，exit 0；警告为既有 Starlette/anyio 弃用警告。
- 受影响文件 compileall：exit 0；精确差异空白检查：exit 0。
- 新测试覆盖三种配置、畸形响应、超量响应回退、后段失败保留 checkpoint、诊断持久化失败。
- 初次新增测试有 3 个 fixture 配置失败，已补合法虚构 WSS URL；失败记录保留。没有请求该 URL。
- 未运行全仓回归；未执行观察脚本、生产重启、真实订单或历史成交回放。

## 保护与局限

本轮只散列生产主 DB 文件与 ledger/strict-paper 源码，前后均一致，详见 local_review.json；未连接生产或历史观察数据库，未改 VOID checkpoint。
主库文件 hash 不是 WAL 内容不变的证明，本轮不声称完成生产逻辑全表核对。
没有新的真实网络样本，不能宣称 eth_getLogs 已稳定、测得成功率或最佳 chunk。
telemetry 衡量 RPC 请求响应，不覆盖后续事件排序、身份解析/暂存失败；error_type 为类型，不含供应商错误详情。

## 输出

execution_report.md / manifest.json / test_results.txt / exact.diff / local_review.json。
停止在本地 REVIEW，未启动下一轮观察。
