"""Read-only public endpoint probe; never emits proxy URLs, bodies or credentials."""
import asyncio
import json
import sqlite3
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
import httpx
from websockets.asyncio.client import connect

OUT = Path(__file__).resolve().parent
DB = OUT.parent / 'forward_observation/20261011T101741Z/isolated_forward.db'
c = sqlite3.connect(DB.resolve().as_uri()+'?mode=ro', uri=True)
c.execute('PRAGMA query_only=ON')
token = json.loads(c.execute('SELECT evidence_json FROM polygon_fast_events LIMIT 1').fetchone()[0])['token_id']
c.close()
CONTRACTS=['0xe111180000d2663c0091e4f400237545b87b996b','0xe2222d279d744050d28e00520010520000310f59']
async def http_probe(route):
    started=time.monotonic()
    result={'transport':'HTTPS_GAMMA','route':route}
    try:
        proxy=urllib.request.getproxies().get('https') if route=='system' else None
        async with httpx.AsyncClient(proxy=proxy, trust_env=False, timeout=12) as client:
            response=await client.get('https://gamma-api.polymarket.com/markets', params={'clob_token_ids':token,'limit':5})
            result['http_status']=response.status_code
            if response.status_code==200:
                data=response.json()
                result['market_count']=len(data) if isinstance(data,list) else None
                result['exact_token_matches']=sum(token in json.loads(m.get('clobTokenIds') or '[]') for m in data) if isinstance(data,list) else None
    except Exception as exc:result['error_type']=type(exc).__name__
    result['duration_ms']=round((time.monotonic()-started)*1000,2)
    return result
async def ws_probe(route, max_size):
    started=time.monotonic()
    result={'transport':'WSS_PUBLICNODE','route':route,'max_size':max_size}
    method=None
    try:
        async with connect('wss://polygon-bor-rpc.publicnode.com',proxy=True if route=='auto' else None,
                           open_timeout=12,ping_interval=10,ping_timeout=10,max_size=max_size,close_timeout=2) as ws:
            async def rpc(method,params,rid):
                await ws.send(json.dumps({'jsonrpc':'2.0','id':rid,'method':method,'params':params}))
                raw=await asyncio.wait_for(ws.recv(),12)
                payload=json.loads(raw)
                if 'error' in payload:
                    result['rpc_error_code']=payload['error'].get('code')
                    raise ValueError('RPC_ERROR')
                return payload.get('result'), len(raw)
            method='eth_chainId'; chain,_=await rpc(method,[],1); result['chain_id']=int(chain,16)
            method='eth_blockNumber'; head,_=await rpc(method,[],2); head=int(head,16)-1
            method='eth_getLogs'; logs,size=await rpc(method,[{'address':CONTRACTS,'fromBlock':hex(head-3),'toBlock':hex(head)}],3)
            result.update(result_count=len(logs),response_bytes=size,blocks=4)
    except Exception as exc:
        result.update(error_type=type(exc).__name__,method=method)
        for field in ('rcvd','sent'):
            frame=getattr(exc,field,None)
            if frame:result[field+'_close_code']=frame.code
    result['duration_ms']=round((time.monotonic()-started)*1000,2)
    return result
async def main():
    rows=await asyncio.gather(http_probe('system'),http_probe('direct'),
        ws_probe('auto',2**20),ws_probe('auto',16*2**20),ws_probe('direct',16*2**20))
    output={'captured_at':datetime.now(timezone.utc).isoformat(),'system_https_proxy_present':bool(urllib.request.getproxies().get('https')),'probes':rows}
    (OUT/'transport_probe.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps(output,indent=2))
if __name__=='__main__':asyncio.run(main())
