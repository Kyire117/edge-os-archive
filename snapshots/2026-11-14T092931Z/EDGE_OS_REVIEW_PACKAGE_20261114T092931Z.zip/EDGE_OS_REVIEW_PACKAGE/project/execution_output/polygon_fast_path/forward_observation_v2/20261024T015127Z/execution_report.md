# EDGE OS isolated 300-second observation — executed

TASK_ID: c2c_polygon_fast_path_forward_observation_v2
ITERATION: 1
STATE: EXECUTED; independent review pending

## Command and identity

- Actual command: `.venv\Scripts\python.exe execution_output\polygon_fast_path\observe_forward.py`; process exit code: 0.
- Process UTC: 2026-10-24T01:52:17.4904129Z to 2026-10-24T01:57:35.1766109Z.
- Observation/cleanup UTC: 2026-10-24T01:52:24.556473+00:00 to 2026-10-24T01:57:32.813922+00:00.
- Requested observation: 300 seconds (ten 30-second samples); observation plus bounded drain: 308.257449 seconds.
- Existing script SHA-256 before/after: `ef200a736cd771c9c53d75743c6b690108d6d84d4d572343291c744fac3952fb`. No code change or rerun.
- Actual workspace_info via original ChatGPT conversation: 47fec7b8248c / EDGE OS 101. Read-back: workspace_info_readback.txt. Only EDGE OS tools were used.
- New output directory: `C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\execution_output\polygon_fast_path\forward_observation\20261024T015217Z`.
- New isolated database: `C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\execution_output\polygon_fast_path\forward_observation\20261024T015217Z\isolated_forward.db`.

## Observed results

| Metric | Actual |
|---|---:|
| Tracked wallets | 20 |
| Raw received observations (including untracked/repeated logs) | 11243 |
| Unique tracked WSS / confirmed backfill keys | 117 / 117 |
| Normalized / persisted tracked events | 117 / 117 |
| ROUTED / unfinished ROUTING | 117 / 0 |
| Episodes | 42 |
| FILLED / REJECTED | 40 / 2 |
| Financial fills / orders | 40 / 40 |
| Open orders / reserved cash | 0 / 0.000000 |
| Reconnects / RPC failures | 0 / 0 |
| eth_getLogs requests / errors | 13 / 0 |
| Poll scans reporting ok / all scans | 146 / 146 |
| Poll rows / exact cross-source pairs | 0 / 0 |
| Strict accounts with reconcile and audit-chain success | 2 / 2 |
| Settlements | 0 |

Both rejection reasons are INSUFFICIENT_PAPER_CASH. One isolated wallet used 39 fills and exhausted its own 1000 USD allocation; another used one fill. This is the existing isolated harness's funding model, not injection into or expenditure from the production shared pool. No settled PnL is claimed.

All tracked confirmed backfill keys were seen on WSS before stop within this bounded window. This is not a global loss-rate estimate. All 117 FIRST_SOURCE decisions concern the observed chain events; zero Data API rows means cross-source matching/deduplication is untested here, not perfect.

## Latency and timestamp limits

Existing helper's `total` means block timestamp to strategy start, not completed fill. n=117: P50 35.413387s; P90 51.142637s; P95 54.469833s; max 57.194519s. Normalization n=117: P50 36.897381s; P95 54.959379s. Strategy handoff n=117: P95 0.041123s (not complete order-book/financial execution latency).

All 117 first-observed minus block-timestamp deltas are negative (-2.350108s to -0.216258s). Thus chain_source sample count=0 after the existing negative-value exclusion. Clock/source timestamp alignment has not been established; these are raw source-based metrics, not proof of P95 <60s or a production SLO.

The script constructed ProducerConfig with independent_lanes=False. It loads the repaired modules but does not exercise the new concurrent lane mode, resolver shutdown path under independent lanes, or coalesced RPC behavior. There were no natural reorg events. This observation cannot replace the prior deterministic boundary tests or prove those paths live.

## Production protection (active DB independently checked)

Active DB resolved from data/active_experiment.json: `C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\data\edge_forward_20261012T073343Z.db`.
Run: FORWARD-20261012T073343Z. Main DB SHA-256: `c955c919c15a94489b1fe0f7810cc6e567765ded81eeaf70eee0e8d60932e632`.

active_production_before.json vs active_production_after.json: all comparisons true; main/WAL/SHM existence, size and hashes identical; active manifest/hash, all table counts, frozen wallet_v2_versions/strict_rule_versions/strict_accounts and tracked-address set identical; query_only read-only quick_check=ok. Production shared funding remains 7000 USD, live_orders=false. Snapshot queries used mode=ro + query_only + transaction rollback; no production application DB class was instantiated.

The script separately checked the old archive data/edge_mvp.db: main hash and all 52 table counts/hashes unchanged. Those archive checks are supplemental and do not substitute for the active DB checks above. No old observation DB was opened by this command; the script's timestamped output directory and DB were new.

Source hash comparison: all 25 app/script files match the recorded pre-completion read-only hashes; the observation script's hash also matches its actual pre-execution baseline. No strategy/config/environment dump or credentials were recorded. No production start/restart/deploy, live order, historical replay or forced settlement occurred. Historical c2c_fix_p1_execution_void remains BLOCKED; no session/checkpoint write is performed by this task.

## Artifacts

All eleven requested script artifacts exist; paths, sizes and SHA-256 are in observation_artifacts.json:
summary.json, summary.md, production_before.json, production_after.json, reconnect_diagnostics.json, backfill_diagnostics.json, chain_observations.json, source_pairs.json, polygon_events.json, episodes.json, strict_fills.json.

Additional evidence here: console.log (raw complete stdout/stderr), execution.json (process command/time/exit), active_production_before.json, active_production_after.json, financial_audit.json (full account reconcile/audit and source-time diagnostics), error_evidence.json (no Polygon error audit/runtime events), lineage_checks.json (one fill per order and episode/order links), source_preservation.json. The script's poll_runs.json is also retained. No error log was deleted or overwritten.

Next gate: actual independent review in the same conversation. No production activation or next observation is automatically approved.

## Final actual independent review

Original Connection verification report conversation returned OBSERVATION_REVIEW_PASS_WITH_LIMITATIONS after reading outputs 139/140 and original artifacts. Full actual read-back: web_review_final.txt; screenshot: web_review_pass.png. This approves the bounded observation evidence only, not production enablement or a next run. The transient webpage error/CAPTCHA was resolved by the user in the same tab; no connector deletion, new chat or observation rerun occurred.

Additional read-only evidence: forward_boundary_checks.json confirms all first observations and episode detection/leader times follow activation; event blocks exceed the fresh boundary. poll_scan_audit.json confirms 2920 page requests with zero rows and zero reported scan/wallet errors; the cause is not established. active_final_physical_check.json independently reconfirms the active DB/WAL/SHM hashes after all snapshot queries.
