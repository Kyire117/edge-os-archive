"""Assemble review evidence; source DB snapshots are generated read-only elsewhere."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from checks import FILES, OUT, ROOT

def load(name):return json.loads((OUT/(name+'.json')).read_text(encoding='utf-8-sig'))
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True,stderr=subprocess.DEVNULL).strip()
checks={name:load(name) for name in ('baseline','new','targeted','full','compile','diff')}
before=load('before');after=load('after');preservation=load('preservation')
manifest={'task_id':'c2c_polygon_orderfilled_fast_path_v1','iteration':1,
    'generated_at':datetime.now(timezone.utc).isoformat(), 'workspace':str(ROOT),
    'git':{'commit':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),
           'dirty':bool(git('status','--porcelain','--untracked-files=normal'))},
    'changed_product_files':FILES,'checks':checks,'production_preservation':preservation,
    'production_main_sha256_before':before['main_sha256'],'production_main_sha256_after':after['main_sha256'],
    'production_tables':after['tables'],'wss_provider_configured':after['wss_configured'],
    'live_validation':'BLOCKED_BY_WSS_PROVIDER_CONFIGURATION','production_restart':False,
    'production_migration':False,'historical_void_reconciliation':False,
    'independent_review':'PENDING',
    'source_sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in FILES},
    'abi_provenance':json.loads((OUT/'provenance/manifest.json').read_text()),
    'preserved_checkpoint':load('checkpoint_before')['checkpoint']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
patch=subprocess.check_output(['git','diff','--',*FILES],cwd=ROOT,stderr=subprocess.DEVNULL)
(OUT/'selected_current_worktree.patch').write_bytes(patch)
lines=['[C2C_EXECUTED]','TASK_ID: c2c_polygon_orderfilled_fast_path_v1','ITERATION: 1',
       'STATE: READY_FOR_REVIEW','','# 执行报告','',
       f"记录时间 UTC：{manifest['generated_at']}",f"工作区：{ROOT}",
       f"Git：{manifest['git']['branch']} / {manifest['git']['commit']} / dirty。",'',
       '## 本轮修改文件','']
lines += ['- '+f for f in FILES]
lines += ['', '新增执行辅助文件：checks.py / capture_provenance.py / report.py（仅在 execution_output 下）。',
    'selected_current_worktree.patch 是所选文件相对 HEAD 的当前差异，包含已有未提交修改；不是纯本轮 diff。',
    '新建模块/测试/文档可直接读取；manifest 保存所有本轮文件 SHA256。未清理 Git。','',
    '## 结构、规则与来源','',
    '- polygon_fast_path.py：两个经过官方部署和固定 ABI 提交验证的 Exchange；独立 WSS JSON-RPC 读链任务。',
    '- BUY shares=takerAmountFilled/1e6，gross=makerAmountFilled/1e6；SELL 两者反向；price=gross/shares；整数/Decimal，无金融 float 推导。',
    '- 按 maker/order-owner 归属，保留 taker、订单/交易/块/log 身份和原始金额。未知身份保持 PENDING_METADATA，不抢占网关。',
    '- 本地精确映射 -> 2048 行 TTL 缓存 -> 有界 Gamma token 查询；未知、冲突、错误不伪造 identity。',
    '- fill_identity.py：精确链身份 + 完整 receipt 唯一精确经济量跨来源匹配；不同来源 ID 只执行一次；不同 log_index 不合并。',
    '- 不足以证明身份时保存 AMBIGUOUS 状态和追加审计；保守拒绝可能漏执行，绝不假装精确去重。',
    '- 独立 heartbeat、RPC timeout、指数重连+jitter；一个后继块确认；初次保存 forward boundary；重启有界 128-block/10000-log backfill。',
    '- removed/reorg 留证，不改金融历史；ROUTING crash 不回放。超过补漏范围失败关闭，需后续处理。',
    '- /api/polygon-fast-path 和 /api/health.polygon_fast_path 返回安全状态、当前进程计数与持久延迟。WSS 与 BACKFILL 分开统计。',
    '- 新增七张表，未来正常启动时增量创建；没有在生产初始化或迁移。固定策略、严格引擎、Exit V1 未修改。',
    '- 显式依赖 websockets==17.1，原虚拟环境已安装。未重装软件。',
    '- 官方 ABI 固定提交：ccc0596074f4dfd62c944fbca4de252893b82b4b；六份源文件及哈希见 provenance/manifest.json。',
    '- 官方另列 e333...00Aa；未验证其 ABI，本轮不启用。不能声称所有 Exchange 已覆盖。','',
    '## 自动验证','']
for name,check in checks.items():
    text=(OUT/(name+'.txt')).read_text()
    summary=next((line for line in reversed(text.splitlines()) if 'passed' in line or 'failed' in line),'完成')
    lines.append(f"- {name}: exit={check['exit_code']}，{summary.strip()}，{check['seconds']} 秒；完整输出 {name}.txt，命令/环境证据 {name}.json。")
lines += ['', '所有 pytest 使用临时数据库、短临时目录及无 POLYGON_WSS_URL 环境。唯一测试警告为既有 Starlette/anyio 弃用提示。',
    'new/targeted/full 采用确定性 fixture；任何 fixture 分位数不属于真实前向表现。','',
    '## 生产保留与当前阻塞','',
    f"- 主文件 SHA256 前后：{before['main_sha256']}（相同）。",
    f"- {preservation['table_count']} 张表的全量 row count / deterministic row hash 前后完全相同。",
    '- 前后 quick_check=ok；只用 SQLite mode=ro、query_only=ON、BEGIN/rollback，未实例化生产应用 Database。',
    '- 未写生产表、未启动/重启应用、未部署；没有新增生产 Fast Path/strict 状态。',
    '- c2c_fix_p1_execution_void 仍是 iteration 1 / BLOCKED；没有历史 VOID 对账，没有历史重放。',
    '- POLYGON_WSS_URL 未配置：BLOCKED_BY_WSS_PROVIDER_CONFIGURATION。没有真实推送样本，没有测量/宣称真实延迟或 SLO。',
    '- 其他边界：一块确认不保证无深重组；SQLite 同步锁仍可能影响调度；待元数据积压按每次 100 条处理；补漏超过上限不会自动跨过缺口。',
    '- 本轮代码尚未生产启用。独立 ChatGPT 审查必须实际读取这些证据后给出结果。','',
    '## 可复核证据','',
    '- manifest.json：命令、exit code、源文件哈希、生产 preservation、ABI 固定源证据。',
    '- checks.py：可重跑测试、只读 SQLite 快照和 count/hash 计算方法。',
    '- before.json / after.json / preservation.json：完整生产表比较。',
    '- baseline/new/targeted/full/compile/diff .txt/.json：完整自动检查证据。',
    '- POLYGON_FAST_PATH_V1.md：API、表、生命周期、去重边界及配置说明。']
(OUT/'execution_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({'report':str(OUT/'execution_report.md'),'preservation':preservation,'files':len(FILES)}))
