"""Bounded real-data PAPER_ONLY observation in a fresh isolated database.

Does not import app.main, start a server, alter production, or seed history.
"""
import asyncio
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Bounded isolated Polygon forward observation')
parser.add_argument('--backfill-chunk-size',type=int,choices=(256,128,64),default=None,
    help='Diagnostic initial eth_getLogs chunk size; falls back to smaller supported chunks on RPC/range errors.')
def local_proxy(value):
    try:
        parsed=urlsplit(value)
        valid=(parsed.scheme=='http' and parsed.hostname in ('127.0.0.1','localhost','::1')
               and parsed.port is not None and not parsed.username and not parsed.password
               and not parsed.query and not parsed.fragment and parsed.path in ('','/'))
    except ValueError:valid=False
    if not valid:raise argparse.ArgumentTypeError('A credential-free local HTTP proxy is required.')
    return value
parser.add_argument('--public-http-proxy',type=local_proxy,default=None,
    help='Optional verified loopback proxy for public market/data requests in this isolated process.')
parser.add_argument('--rpc-timeout',type=int,choices=(8,15,20),default=8,
    help='Isolated chain RPC timeout in seconds; does not change CLOB book freshness or execution rules.')
ARGS=parser.parse_args()
STAMP=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT=BASE/'forward_observation'/STAMP
OUT.mkdir(parents=True)
ISOLATED=(OUT/'isolated_forward.db').resolve()
SOURCE=(ROOT/'data/edge_mvp.db').resolve()
DURATION=int(os.getenv('EDGE_FORWARD_OBSERVATION_SECONDS','300'))
if not 30<=DURATION<=600 or DURATION%30:raise ValueError('INVALID_BOUNDED_OBSERVATION_DURATION')
assert ISOLATED!=SOURCE and SOURCE not in ISOLATED.parents
os.environ['DATABASE_PATH']=str(ISOLATED)
os.environ['POLYGON_FAST_ENABLED']='true'
os.environ['POLYGON_WSS_URL']='wss://polygon-bor-rpc.publicnode.com'
os.environ['DISCOVERY_ENABLED']='false'
sys.path.insert(0,str(ROOT))
from app.db import Database
from app import service
import app.monitor as monitor_module
from app.polymarket import PolymarketClient
from app.polygon_fast_path import PolygonProducer, ProducerConfig, decode_log
from app.wallet_follow_runtime import V2_CONFIG, WalletFollowRuntime
from app.wallet_follow_v2 import WalletFollowV2

def utc():return datetime.now(timezone.utc)
def dump(name,data):
    (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def snapshot():
    c=sqlite3.connect(SOURCE.as_uri()+'?mode=ro',uri=True)
    c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
    tables={}
    for table, in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
        data=sorted(json.dumps(tuple(r),separators=(',',':'),default=str) for r in
            c.execute('SELECT * FROM "'+table.replace('"','""')+'"'))
        tables[table]={'count':len(data),'sha256':hashlib.sha256('\n'.join(data).encode()).hexdigest()}
    wallets=[r[0] for r in c.execute('SELECT address FROM wallets WHERE tracked=1 ORDER BY address')]
    result={'at':utc().isoformat(),'main_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'tables':tables,'quick_check':c.execute('PRAGMA quick_check').fetchall(),
            'tracked_addresses':wallets}
    c.rollback();c.close();return result

def summary(db,producer,before,after,observations,poll_runs,started,finished):
    with db.conn() as c:
        episodes=[dict(r) for r in c.execute('SELECT * FROM wallet_v2_episodes')]
        events=[dict(r) for r in c.execute('SELECT * FROM polygon_fast_events')]
        aliases=[dict(r) for r in c.execute('SELECT * FROM fill_source_observations')]
        audits=[dict(r) for r in c.execute('SELECT * FROM fill_identity_audit')]
        fills=[dict(r) for r in c.execute('SELECT * FROM strict_fills')]
        accounts=[r[0] for r in c.execute('SELECT account_id FROM strict_accounts')]
        version=dict(c.execute('SELECT * FROM wallet_v2_versions').fetchone())
        reconnects=[json.loads(r[0]) for r in c.execute("SELECT evidence_json FROM polygon_fast_audit WHERE action='RECONNECT_DIAGNOSTIC' ORDER BY id")]
        backfill_diagnostics=[json.loads(r[0]) for r in c.execute("SELECT evidence_json FROM polygon_fast_audit WHERE action='BACKFILL_RPC_DIAGNOSTIC' ORDER BY id")]
    typed={kind:{r['event_id'] for r in observations if r['transport']==kind}
           for kind in ('WSS','BACKFILL')}
    # Backfill is a confirmed-log reference only for these contracts and this window.
    reference=typed['BACKFILL']; missing=reference-typed['WSS']
    paired=defaultdict(list)
    for row in aliases:
        if row['canonical_id']:paired[row['canonical_id']].append(row)
    arrival=Counter()
    pairs=[]
    for identity,rows in paired.items():
        if {'FAST_PATH','DATA_API_POLL'} <= {r['source'] for r in rows}:
            first=min(rows,key=lambda r:r['observed_at'])
            arrival[first['source']]+=1
            pairs.append({'canonical_id':identity,'first_source':first['source'],
                          'observations':[{k:r[k] for k in ('source','source_id','state','observed_at')} for r in rows]})
    from app.strict_ledger import StrictPaperLedger
    reconciliations={a:{'ledger':StrictPaperLedger(ISOLATED,account_id=a).reconcile(),
                       'audit':StrictPaperLedger(ISOLATED,account_id=a).verify_audit_chain()} for a in accounts}
    normalized=sum(r['normalized_json'] is not None for r in events)
    result={'mode':'PAPER_ONLY_ISOLATED_FORWARD','started_at':started,'finished_at':finished,
       'duration_seconds':(datetime.fromisoformat(finished)-datetime.fromisoformat(started)).total_seconds(),
       'requested_observation_seconds':DURATION,
       'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       'isolated_db':str(ISOLATED),'production_service_restart':False,'production_config_changed':False,
       'provider':'PublicNode Polygon Bor','provider_scope':'this isolated process only',
       'tracked_wallet_count':len(before['tracked_addresses']),'frozen_config':V2_CONFIG.evidence(),
       'version':version,'producer':producer.status(),'observed_chain_keys':{
           k:len(v) for k,v in typed.items()},
       'confirmed_reference_count':len(reference),'not_seen_on_wss_before_stop':len(missing),
       'confirmed_window_wss_missing_fraction':len(missing)/len(reference) if reference else None,
       'metadata':{'tracked_persisted_events':len(events),'normalized':normalized,
           'normalized_fraction':normalized/len(events) if events else None,
           'states':dict(Counter(r['state'] for r in events))},
       'reconnect_diagnostics':reconnects,
       'backfill_diagnostics':backfill_diagnostics,
       'backfill_diagnostics_persistence_failed':producer.backfill_diagnostics_persistence_failed,
       'backfill_diagnostic_config':{'enabled':True,
           'rpc_timeout_seconds':producer.config.rpc_timeout,
           'max_message_bytes':producer.config.max_message_bytes,
           'public_http_proxy_enabled':ARGS.public_http_proxy is not None,
           'initial_chunk_size':ARGS.backfill_chunk_size,
           'fallback_sizes':([ARGS.backfill_chunk_size//(2**n) for n in range(3)
               if ARGS.backfill_chunk_size//(2**n)>=64] if ARGS.backfill_chunk_size else None),
           'max_gap_blocks':max(128,ARGS.backfill_chunk_size or 128),
           'retry_number_semantics':'0 is the initial attempt for a block range; each smaller-size fallback increments it.'},
       'uncompleted_routing_count':sum(r['state']=='ROUTING' for r in events),
       'cross_source_exact_pairs':len(pairs),'first_arrival':dict(arrival),
       'canonical_decisions':dict(Counter(r['state'] for r in audits)),
       'insufficient_identity_count':sum(r['state']=='AMBIGUOUS_INSUFFICIENT_TRANSACTION_IDENTITY' for r in audits),
       'episode_count':len(episodes),'episode_status':dict(Counter(r['paper_status'] for r in episodes)),
       'fill_count':len(fills),'poll_runs':len(poll_runs),'poll_ok_runs':sum(r.get('ok') is True for r in poll_runs),
       'poll_rows_seen':sum(r.get('trades_seen',0) for r in poll_runs),
       'reconciliations':reconciliations,'production_preservation':{
           'main_unchanged':before['main_sha256']==after['main_sha256'],
           'all_tables_unchanged':before['tables']==after['tables'],'tables':len(before['tables'])},
       'limitations':['Short window and only two verified contracts; no global coverage or production SLO claim.',
           'Confirmed backfill comparison measures not-yet-seen WSS keys at stop, not permanent global loss.',
           'Zero exact cross-source pairs means duplicate/first-arrival rate is unmeasurable, not zero.',
           'No synthetic signals, historical replay, or manufactured fills; missing data stays missing.']}
    dump('summary.json',result);dump('source_pairs.json',pairs)
    dump('chain_observations.json',observations);dump('poll_runs.json',poll_runs)
    dump('episodes.json',episodes);dump('strict_fills.json',fills)
    dump('polygon_events.json',events);dump('reconnect_diagnostics.json',reconnects)
    dump('backfill_diagnostics.json',backfill_diagnostics)
    (OUT/'summary.md').write_text('\n'.join([
        '# 实时数据短时前向观察（独立模拟库）','',
        f'区间 UTC：{started} — {finished}',f'跟踪钱包：{result["tracked_wallet_count"]}',
        f'原始观察次数：{result["producer"]["raw_events_seen"]}（含补漏/重复及未跟踪 maker）',
        f'唯一被跟踪 WSS / BACKFILL key：{len(typed["WSS"])} / {len(reference)}',
        f'身份成功 / 持久事件：{normalized} / {len(events)}',
        f'精确跨源配对：{len(pairs)}；first-arrival：{dict(arrival)}',
        f'方向 episodes：{len(episodes)}；金融 fills：{len(fills)}',
        f'episode 状态：{result["episode_status"]}',
        f'不足身份观察审计次数：{result["insufficient_identity_count"]}',
        f'轮询成功次数：{result["poll_ok_runs"]}/{len(poll_runs)}',
        f'轮询收到行数：{result["poll_rows_seen"]}；重连次数：{len(reconnects)}',
        f'BACKFILL eth_getLogs 诊断请求：{len(backfill_diagnostics)}；错误：{sum(r["error_type"] is not None for r in backfill_diagnostics)}；chunk 配置：{result["backfill_diagnostic_config"]}',
        f'BACKFILL 诊断写入失败：{result["backfill_diagnostics_persistence_failed"]}',
        f'未完成 ROUTING：{result["uncompleted_routing_count"]}',
        f'生产保护：{result["production_preservation"]}',
        '', '延迟完整分位数见 summary.json producer.latency / backfill_latency。',
        '只对真实进入策略的样本计算；空样本为未知。',
        '短时间结果不证明全市场漏单率/重复率或生产 SLA。零配对不是重复率为零。',
        '没有启动/重启生产、没有配置生产运行环境；实时地址只作用于本脚本进程。',
        '本次使用当前源码的正式市场/两份订单簿/手续费模拟；所有交易均 PAPER_ONLY。',
        '数据库保留，未进行历史回放或强制结算。'] )+'\n',encoding='utf-8')
    return result

async def main():
    before=snapshot();dump('production_before.json',before)
    db=Database(str(ISOLATED));db.init()
    at=utc()
    for wallet in before['tracked_addresses']:
        db.upsert_wallet(wallet)
        with db.conn() as c:c.execute('UPDATE wallets SET last_trade_ts=? WHERE address=?',(int(at.timestamp()),wallet))
    WalletFollowV2.initialize(ISOLATED)
    engine=WalletFollowV2(ISOLATED)
    engine.create_version(V2_CONFIG,created_at=at,evidence_cutoff=at)
    engine.activate(at=at)
    # Explicit fresh sandbox cutoff: no prior signal may become a forward episode.
    with db.conn() as c:
        c.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES('CLEAN_FORWARD_RESTART',?,?)",
                  (at.isoformat(),json.dumps({'scope':'NEW_ISOLATED_VALIDATION_DB','episodes_before':0,'source_replay':False})))
    client=PolymarketClient(public_http_proxy=ARGS.public_http_proxy)
    original_client=service.pm
    service.db=db;service.pm=client
    monitor_module.db=db;monitor_module.pm=client
    monitor=monitor_module.WalletMonitor()
    chunk_size=ARGS.backfill_chunk_size
    producer=PolygonProducer(db,client,service.ingest_fast_path_trade,
        ProducerConfig(url=os.environ['POLYGON_WSS_URL'],enabled=True,
            backfill_blocks=max(128,chunk_size or 128),backfill_diagnostics=True,
            rpc_timeout=ARGS.rpc_timeout,
            diagnostic_backfill_chunk_size=chunk_size))
    observations=[];poll_runs=[];stop=asyncio.Event()
    stage=producer.stage
    def observe_stage(raw,received=None,transport='WSS'):
        try:
            event=decode_log(raw)
            if event['maker'] in producer.tracked:
                observations.append({'event_id':event['event_id'],'block':event['block_number'],
                    'block_hash':event['block_hash'],'removed':event['removed'],'transport':transport,
                    'received_at':received or utc().isoformat()})
        except (ValueError,TypeError,KeyError):pass
        return stage(raw,received,transport)
    producer.stage=observe_stage
    async def poll():
        while not stop.is_set():
            t=time.monotonic()
            try:poll_runs.append(await monitor.scan_once(require_v2=True))
            except Exception as exc:poll_runs.append({'ok':False,'error_type':type(exc).__name__})
            await asyncio.sleep(max(.2,2-(time.monotonic()-t)))
    # Stopping admission first lets the scan drain its own freshness task.
    # Only cancel if the bounded cleanup deadline is exceeded.
    producer.start();poll_task=asyncio.create_task(poll())
    started=utc().isoformat()
    print(json.dumps({'state':'STARTED','out':str(OUT),'tracked_wallets':len(before['tracked_addresses']),
                      'duration_seconds':DURATION,'production_started':False}),flush=True)
    try:
        for _ in range(DURATION//30):
            await asyncio.sleep(30)
            status=producer.status()
            print(json.dumps({'state':'OBSERVING','connected':status['connected'],
                  'raw_events_seen':status['raw_events_seen'],'tracked_events_seen':status['tracked_events_seen'],
                  'normalized_events':status['normalized_events'],'error_category':status['error_category'],
                  'phase':status.get('phase'),'last_reconnect':status.get('last_reconnect')}),flush=True)
    finally:
        stop.set()
        try:await asyncio.wait_for(asyncio.shield(poll_task),20)
        except TimeoutError:
            poll_task.cancel();await asyncio.gather(poll_task,return_exceptions=True)
        # Allow the current decision to finish, without starting another heartbeat.
        producer.stop_event.set()
        if producer.task:
            try:await asyncio.wait_for(asyncio.shield(producer.task),20)
            except (TimeoutError,Exception):pass
        await producer.stop();await client.close()
        await original_client.close()
    finished=utc().isoformat();after=snapshot();dump('production_after.json',after)
    result=summary(db,producer,before,after,observations,poll_runs,started,finished)
    print(json.dumps({'state':'COMPLETE','out':str(OUT),'episode_count':result['episode_count'],
          'fill_count':result['fill_count'],'production_preservation':result['production_preservation']}),flush=True)
    if not all(v for k,v in result['production_preservation'].items() if k!='tables'):raise RuntimeError('PRODUCTION_DRIFT')

if __name__=='__main__':asyncio.run(main())
