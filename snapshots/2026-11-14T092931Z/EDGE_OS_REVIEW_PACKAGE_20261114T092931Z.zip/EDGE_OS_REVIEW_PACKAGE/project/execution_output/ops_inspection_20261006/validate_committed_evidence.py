import collections
from decimal import Decimal as D, ROUND_DOWN, ROUND_UP
import json
from pathlib import Path
import sqlite3
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT))
from app.strict_ledger import _validate_execution_evidence
from app.strict_paper import MONEY_QUANTUM,QTY_QUANTUM
con=sqlite3.connect((OUT/'inspection_snapshot.db').resolve().as_uri()+'?mode=ro',uri=True)
con.row_factory=sqlite3.Row
con.execute('PRAGMA query_only=ON')
result=[]
for row in con.execute("SELECT e.episode_id,e.first_detected_at,e.first_signal_id,d.evidence_json FROM wallet_v2_episodes e JOIN strict_decisions d ON d.signal_id=e.first_signal_id WHERE e.rejection_reason='EXECUTION_COMMIT_INCOMPLETE' ORDER BY e.first_detected_at"):
    order=con.execute('SELECT * FROM strict_orders WHERE signal_id=?',(row['first_signal_id'],)).fetchone()
    evidence=json.loads(row['evidence_json'])
    raised=[]
    def trace(frame,event,arg):
        if frame.f_code.co_name=='_validate_execution_evidence' and event=='exception' and isinstance(arg[1],ValueError):
            raised.append(frame.f_lineno)
        return trace
    sys.settrace(trace)
    try:
        _validate_execution_evidence(evidence,order,D(evidence['filled_quantity']),D(evidence['vwap']),D(evidence['total_fee']),D(evidence['total_cost']))
        status='VALID_IN_CURRENT_VALIDATOR'
    except Exception as exc:
        status=type(exc).__name__+': '+str(exc)
    finally:
        sys.settrace(None)
    fills=evidence['fills']
    recomputed_gross=sum(((D(p)*D(q)).quantize(MONEY_QUANTUM,rounding=ROUND_DOWN) for p,q in fills),D(0))
    qty=sum((D(q) for p,q in fills),D(0))
    recomputed_fee=sum(((D(q)*D(evidence['fee_rate'])*D(p)*(1-D(p))).quantize(MONEY_QUANTUM,rounding=ROUND_UP) for p,q in fills),D(0))
    visible={};consumed={}
    for p,q in evidence['execution']['asks']:
        p=D(p);visible[p]=visible.get(p,D(0))+D(q).quantize(QTY_QUANTUM,rounding=ROUND_DOWN)
    for p,q in fills:
        p=D(p);consumed[p]=consumed.get(p,D(0))+D(q)
    fraction=D(evidence['rule_config']['max_visible_depth_fraction'])
    eligible=[p for p in sorted(visible) if (visible[p]*fraction).quantize(QTY_QUANTUM,rounding=ROUND_DOWN)>=D(evidence['rule_config']['min_quantity']).quantize(QTY_QUANTUM,rounding=ROUND_DOWN)]
    mismatch=[{'cheaper_price':str(a),'dearer_price':str(b),'allowed_cheaper_qty':str((visible[a]*fraction).quantize(QTY_QUANTUM,rounding=ROUND_DOWN)),'consumed_cheaper_qty':str(consumed.get(a,D(0))),'shortfall':str((visible[a]*fraction).quantize(QTY_QUANTUM,rounding=ROUND_DOWN)-consumed.get(a,D(0)))} for a,b in zip(eligible,eligible[1:]) if b in consumed and consumed.get(a,D(0))!=(visible[a]*fraction).quantize(QTY_QUANTUM,rounding=ROUND_DOWN)]
    for m in mismatch:
        m['consumed_dearer_qty']=str(consumed[D(m['dearer_price'])])
    result.append({'episode_id':row['episode_id'],'detected_at':row['first_detected_at'],'order_id':order['order_id'] if order else None,'order_status':order['status'] if order else None,'validation_result':status,'first_exception_line':raised[0] if raised else None,'price_priority_mismatches':mismatch,'total_cost':evidence['total_cost'],'recomputed_level_gross':str(recomputed_gross),'vwap':evidence['vwap'],'recomputed_vwap':str((recomputed_gross/qty).quantize(MONEY_QUANTUM,rounding=ROUND_DOWN)),'total_fee':evidence['total_fee'],'recomputed_fee':str(recomputed_fee),'levels':len(fills)})
con.close()
summary={'mode':'Existing immutable evidence only; pure validator; no fills or network; snapshot mode=ro/query_only','total':len(result),'first_failure_line_counts':dict(collections.Counter(r['first_exception_line'] for r in result)),'rows':result}
(OUT/'execution_evidence_diagnosis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({**summary,'rows':result[:2]+result[-2:]},indent=2))
