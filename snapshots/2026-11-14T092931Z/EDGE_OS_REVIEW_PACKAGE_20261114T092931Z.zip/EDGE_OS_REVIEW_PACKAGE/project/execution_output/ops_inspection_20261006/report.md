# EDGE OS 101 只读运维巡检

记录时间（UTC）：2026-10-06T11:49:17.380340+00:00
实际仓库：`C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp`
任务：c2c_edge_os_ops_inspection / Iteration 1

## 检查命令与退出码

| 检查 | 退出码 | 结果 |
|---|---:|---|
| python -m pytest tests -q（短临时路径） | 0 | 277 passed, 1 warning |
| python -m compileall -q app tests | 0 | 通过 |
| git diff --check | 0 | 无空白错误；LF/CRLF警告 |
| node --check app/static/app.js | 0 | 通过 |
| node tests/ui_v1_static.test.js | 0 | 通过 |
| python -m pip check | 0 | No broken requirements found |
| SQLite只读检查与对账 | 0 | quick_check=ok，9个账户对账通过 |

Python 使用仓库 .venv/Scripts/python.exe（3.13.15）。测试 DATABASE_PATH 指向专用临时数据库。初次pytest exit4是 PYTEST_ADDOPTS 空格路径未引用；修正后长临时路径 exit1（267 passed / 10 BACKUP_FAILED）；短临时路径原命令 exit0（277 passed）。三次均保留输出。run_checks.py 包装器因保留历史失败返回1；最终pytest子命令实际exit0，以 checks.json 对应条目为准。

## 当前生产快照

- strategy=wallet-follow-v2.0，FORWARD_TEST；冻结$25、5% ROI、10%深度、500ms延迟、3000ms盘口年龄、120秒恢复宽限；live_orders=false。
- episodes=634：FILLED 280、PARTIAL 11、REJECTED 343、OBSERVED 0。
- orders=365：FILLED 280、PARTIALLY_FILLED 11、CANCELLED 74、OPEN 0；fills=291。
- positions=291；正数量持仓36，其中正常待结算34、VOID后仍正数量2。directional pending=96。
- strict_settlements=620：FORMALLY_RESOLVED 255、API_FAILURE 226、RESULT_PENDING 137、VOID 2。episode正式结果535、VOID3。
- 9个账户available_cash总计7647.306675，reserved_cash=0.000000；无负现金、无终止订单残留预留；已提交fill/order/episode金额未见分歧。
- strict审计链1861项通过。审计链是本地一致性证据，并不证明数据不可伪造。
- V3和V4均已注册；V3 decisions37，V4 decisions465，全部291个金融fill为V4。V4已经开始过；当前没有可确认的运行后端，不能宣称当前process仍是V3/V4。
- tracked_wallets=20；没有持久化monitor:错误；4条旧profile/volume/pnl错误均属于未跟踪钱包。运行期scan/backoff状态主要在内存，当前不可核验。
- journal_mode=wal；主DB WAL288432 bytes、SHM32768 bytes；quick_check=ok，foreign_key_check空。
- GET /api/health 和 GET /api/wallet-follow-v2 未执行：8000未监听；没有启动或重启服务。

## 分级发现

- **P0**：本次范围内未发现已确认的资金/数据破坏；并不等于完整安全审计通过。
- **P1**：8000 未监听，检查结束时未发现 python/pythonw/uvicorn 后端进程；运行状态及两个 GET 接口无法在线核验。若服务预期常驻，则监控与结算当前暂停。未启动或重启服务。
- **P1**：74 个 V4 执行尝试被 INVALID_EXECUTION_EVIDENCE 拒绝；原始决策为 FILLED，但提交失败后订单 CANCELLED、episode REJECTED、无金融 fill、无残留预留。对全部74份既有证据再次调用纯校验函数均在 strict_ledger.py:169 拒绝。执行引擎可跳过成本量化为0的便宜档位后消费更贵档位，而账本要求便宜档位耗尽，存在规则一致性缺陷。
  证据源码：app/strict_paper.py:463, app/strict_ledger.py:162, app/wallet_follow_v2.py:654
  下一步：在独立修复任务中对微小剩余预算与价格优先级统一语义并加真实证据夹具；保留历史拒绝，不能重放为成交。
- **P1**：2 个已标为 VOID 的模拟成交仍持有数量与成本（总成本 51.065198 USD），却被结算刷新排除，API pending_paper_positions 也不包含它们。账本对账通过不代表 VOID 生命周期已完成。
  证据源码：app/wallet_follow_runtime.py:658, app/strict_ledger.py:674, app/wallet_follow_runtime.py:278
  下一步：明确正式 VOID 赔付证据/待处理状态；不得猜测退款或$0/$1结果，修复前保留持仓。
- **P2**：长临时路径回归出现10个 BACKUP_FAILED 相关失败；短临时路径同一277项全部通过。备份生成路径超过Windows传统路径上限，原始异常被 BACKUP_FAILED 隐去，影响诊断。
  证据源码：app/wallet_follow_runtime.py:146, app/wallet_follow_runtime.py:161
  下一步：检查长路径能力与备份目标长度，并保留安全的异常类型；本轮没有修改代码。
- **P2**：结算异常记录的二次写失败被 except Exception: pass 吞掉；当前无 API_FAILURE episode，历史226条 API_FAILURE结算记录说明曾成功持久化，但无法证明每次失败均已记录。服务未运行，无法排除尚未持久化的失败。
  证据源码：app/wallet_follow_runtime.py:719
  下一步：独立修复任务中增加持久化失败诊断和临时库回归；本轮不调用写入方法。
- **P2**：工作树已有大量未提交实现；7个 .tm* 根目录、21个 .pytest* 根目录、9个备份及16个数据 WAL/SHM 文件。23个路径不可枚举；大小与文件数是可读部分下界。部分历史 .backup-wal/.backup-shm 和 .tm2full 出现在 Git untracked 列表。
  下一步：后续独立维护任务检查备份可恢复性、权限与忽略规则；本轮没有删除或 Git 编辑。
- **P3**：全量回归有1项 Starlette/AnyIO BlockingPortal 弃用警告；git diff --check exit0，只有现有LF/CRLF警告。

## 保全与局限

- 本轮检查前后生产主文件SHA256：`93a02e17e77eaae18eb51ae313e35d3bc177a46548b161c0ad9fcae0abc925db` / `93a02e17e77eaae18eb51ae313e35d3bc177a46548b161c0ad9fcae0abc925db`。
- 全表完整行哈希/count比较：changes=0；production_unchanged=True。
- 原有源码Git diff哈希保持一致：True。没有产品源码、策略或数据库写入，也没有部署、清理、重启。
- 仅新增execution_output内的诊断脚本、日志、JSON和一致性检查副本，以及忽略的临时测试文件。源码支持V4与生产证据表明V4曾运行，具体启动审批过程不在本轮验证范围。
- 临时检查副本采用SQLite backup包含已提交WAL；只对副本使用账本SELECT方法，未初始化生产类。
- 不通过真实网络请求猜测市场是否已结算；本轮不能判断正常PENDING的上游结果或未启动服务的原因。

## 可读取证据

`checks.json`，`pytest.txt`，`pytest_retry.txt`，`pytest_short_temp.txt`，`compileall.txt`，`diff_check.txt`，`frontend_syntax.txt`，`frontend_tests.txt`，`pip_check.txt`，`production_inspection.json`，`inspection_details.json`，`execution_evidence_diagnosis.json`，`temporary_path_probe.json`，`process_state.json`，`final_preservation.json`，`summary.json`。
