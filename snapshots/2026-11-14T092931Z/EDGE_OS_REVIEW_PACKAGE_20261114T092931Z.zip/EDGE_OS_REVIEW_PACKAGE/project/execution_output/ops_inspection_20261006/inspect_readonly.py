import collections
import datetime as dt
import decimal
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import sqlite3
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / os.environ.get('DATABASE_PATH', 'data/edge_mvp.db')
D = decimal.Decimal
NOW = dt.datetime.now(dt.timezone.utc)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None

def safe(value):
    if isinstance(value, dict):
        return {k: ('[REDACTED]' if re.search(r'api.?key|secret|token$|password|cookie|authorization|pairingcode', k, re.I) and not k.endswith('token_id') else safe(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [safe(v) for v in value]
    if isinstance(value, str):
        return re.sub(r'(Bearer\s+)\S+', r'\1[REDACTED]', value)
    return value

def ro(path):
    con = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA query_only=ON')
    return con

def fingerprint(con):
    result = {}
    for row in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
        name = row[0]
        rows = [tuple(r) for r in con.execute('SELECT * FROM "' + name.replace('"', '""') + '"')]
        encoded = sorted(json.dumps(r, ensure_ascii=False, default=lambda x: {'blob_hex': x.hex()}, separators=(',', ':')) for r in rows)
        result[name] = {'count': len(rows), 'sha256': hashlib.sha256('\n'.join(encoded).encode()).hexdigest()}
    return result

def capture(path):
    with ro(path) as con:
        con.execute('BEGIN')
        result = {'main_sha256': sha(path), 'tables': fingerprint(con)}
        con.rollback()
        return result

def timestamp(raw):
    return dt.datetime.fromisoformat(raw.replace('Z', '+00:00')).astimezone(dt.timezone.utc)

report = {'captured_at': NOW.isoformat(), 'repository_root': str(ROOT), 'production_db': str(SOURCE.resolve()), 'access': 'mode=ro; query_only=ON; read transaction; rollback; no production application classes'}
if not SOURCE.is_file():
    raise SystemExit('Configured production database does not exist; inspection aborted')
before = capture(SOURCE)
report['before'] = before
with ro(SOURCE) as src:
    src.execute('BEGIN')
    report['quick_check'] = [r[0] for r in src.execute('PRAGMA quick_check')]
    report['journal_mode'] = src.execute('PRAGMA journal_mode').fetchone()[0]
    report['foreign_key_check'] = [tuple(r) for r in src.execute('PRAGMA foreign_key_check')]
    report['sidecars'] = {suffix: {'exists': Path(str(SOURCE) + suffix).exists(), 'size': Path(str(SOURCE) + suffix).stat().st_size if Path(str(SOURCE) + suffix).exists() else 0} for suffix in ('-wal', '-shm')}
    with sqlite3.connect(OUT / 'inspection_snapshot.db') as dst:
        src.backup(dst)
    src.rollback()

with ro(OUT / 'inspection_snapshot.db') as con:
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    def rows(name):
        return [dict(r) for r in con.execute('SELECT * FROM "' + name + '"')] if name in tables else []
    def group(values, key):
        return dict(collections.Counter(r.get(key) for r in values))
    episodes = rows('wallet_v2_episodes')
    orders = rows('strict_orders')
    fills = rows('strict_fills')
    positions = rows('strict_positions')
    settlements = rows('strict_settlements')
    decisions = rows('strict_decisions')
    versions = rows('wallet_v2_versions')
    rules = rows('strict_rule_versions')
    accounts = rows('strict_accounts')
    report['strategy_versions'] = versions
    report['strict_rule_versions'] = rules
    report['episodes'] = {'total': len(episodes), 'paper_status': group(episodes, 'paper_status'), 'resolution_status': group(episodes, 'resolution_status'), 'rejections': group([e for e in episodes if e['paper_status']=='REJECTED'], 'rejection_reason'), 'first_detected_at': min((e['first_detected_at'] for e in episodes), default=None), 'latest_detected_at': max((e['first_detected_at'] for e in episodes), default=None)}
    report['ledger_counts'] = {'orders': len(orders), 'order_statuses': group(orders, 'status'), 'fills': len(fills), 'positions': len(positions), 'positive_quantity_positions': sum(D(p['quantity'])>0 for p in positions), 'settlements': len(settlements), 'settlement_statuses': group(settlements, 'status'), 'decision_statuses': group(decisions, 'status'), 'decision_engine_versions': group(decisions, 'engine_version'), 'fill_engine_versions': dict(collections.Counter(json.loads(f['evidence_json']).get('engine_version') for f in fills))}
    grace = {v['strategy_version']: json.loads(v['config_json']).get('observed_recovery_grace_seconds',120) for v in versions}
    report['stale_observed'] = [{'episode_id': e['episode_id'], 'age_seconds': (NOW-timestamp(e['first_detected_at'])).total_seconds(), 'grace_seconds': grace.get(e['strategy_version'],120)} for e in episodes if e['paper_status']=='OBSERVED' and (NOW-timestamp(e['first_detected_at'])).total_seconds()>grace.get(e['strategy_version'],120)]
    pending = [e for e in episodes if e['resolution_status'] not in ('FORMALLY_RESOLVED','VOID')]
    report['pending_settlements'] = {'directional_episodes':len(pending), 'paper_episodes':sum(e['paper_status'] in ('FILLED','PARTIAL') for e in pending), 'api_failure_episodes':[{'episode_id':e['episode_id'],'paper_status':e['paper_status'],'paper_order_id':e['paper_order_id'],'resolution_evidence':json.loads(e['resolution_evidence_json'] or '{}')} for e in pending if e['resolution_status']=='API_FAILURE']}
    runtime = rows('wallet_v2_runtime_events')
    report['runtime_events'] = {'total':len(runtime), 'reason_counts':group(runtime,'reason'), 'latest':[{'signal_id':r['signal_id'],'episode_id':r['episode_id'],'reason':r['reason'],'event_type':r['event_type'],'occurred_at':r['occurred_at'],'error_type':json.loads(r['evidence_json']).get('error_type')} for r in sorted(runtime,key=lambda x:x['occurred_at'],reverse=True)[:20]]}
    wallets=rows('wallets')
    report['wallet_monitor_persisted'] = {'wallets':len(wallets),'tracked':sum(bool(w['tracked']) for w in wallets),'errors':[{'address':w['address'],'tracked':w['tracked'],'last_error':w['last_error'],'updated_at':w['updated_at'],'last_trade_ts':w['last_trade_ts']} for w in wallets if w.get('last_error')], 'latest_trade_timestamp':max((w['last_trade_ts'] or 0 for w in wallets),default=0)}
    report['reservations'] = [{'account_id':a['account_id'],'available_cash':a['available_cash'],'reserved_cash':a['reserved_cash'],'open_order_cash':str(sum((D(o['reserve_cash_remaining']) for o in orders if o['account_id']==a['account_id'] and o['status']=='OPEN' and o['side']=='BUY'),D(0)))} for a in accounts]
    divergence=[]
    order_ids={o['order_id']:o for o in orders}
    for e in episodes:
        ef=[f for f in fills if f['order_id']==e['paper_order_id']]
        if e['paper_status'] in ('FILLED','PARTIAL'):
            if not e['paper_order_id'] or e['paper_order_id'] not in order_ids or not ef:
                divergence.append({'episode_id':e['episode_id'],'reason':'FILLED_EPISODE_MISSING_COMMITTED_ORDER_FILL'})
            elif any(D(e[field] or 0)!=sum((D(f[ff]) for f in ef),D(0)) for field,ff in [('filled_quantity','quantity'),('filled_notional','gross_amount'),('entry_fee','fee')]):
                divergence.append({'episode_id':e['episode_id'],'reason':'EPISODE_FILL_AMOUNT_MISMATCH'})
        elif ef:
            divergence.append({'episode_id':e['episode_id'],'reason':'FINANCIAL_FILL_WITH_NONFILLED_EPISODE'})
    for f in fills:
        if f['order_id'] not in order_ids:
            divergence.append({'fill_id':f['fill_id'],'reason':'ORPHAN_FILL'})
        if not any(e['paper_order_id']==f['order_id'] for e in episodes):
            divergence.append({'fill_id':f['fill_id'],'reason':'FILL_WITHOUT_EPISODE'})
    report['divergence']=divergence
    report['terminal_order_reservation_anomalies']=[o['order_id'] for o in orders if o['status']!='OPEN' and (D(o['reserve_cash_remaining'])!=0 or D(o['reserved_quantity_remaining'])!=0)]
    report['v4']={'registered':any(r['engine_version']=='strict-paper-engine-v4' for r in rules),'decisions':sum(d['engine_version']=='strict-paper-engine-v4' for d in decisions),'fills':sum(json.loads(f['evidence_json']).get('engine_version')=='strict-paper-engine-v4' for f in fills),'latest_decisions':[{'created_at':d['created_at'],'engine_version':d['engine_version'],'status':d['status'],'reason':d['reason']} for d in sorted(decisions,key=lambda x:x['created_at'],reverse=True)[:5]]}

# Reuse SELECT-only reconciliation against the consistent COPY, never production.
sys.path.insert(0,str(ROOT))
from app.strict_ledger import StrictPaperLedger
original_connect=sqlite3.connect
snapshot=(OUT/'inspection_snapshot.db').resolve()
def restricted_connect(path,*args,**kwargs):
    if Path(str(path)).resolve()!=snapshot:
        raise RuntimeError('Reconciliation attempted unexpected database access')
    kwargs['uri']=True
    con=original_connect(snapshot.as_uri()+'?mode=ro',*args,**kwargs)
    con.execute('PRAGMA query_only=ON')
    return con
sqlite3.connect=restricted_connect
try:
    report['reconciliation']={a['account_id']:StrictPaperLedger(snapshot,account_id=a['account_id']).reconcile() for a in accounts}
    report['audit_chain']=StrictPaperLedger(snapshot).verify_audit_chain()
finally:
    sqlite3.connect=original_connect

api={}
with socket.socket() as s:
    s.settimeout(1)
    running=s.connect_ex(('127.0.0.1',8000))==0
report['localhost_8000_listening']=running
if running:
    for endpoint in ('/api/health','/api/wallet-follow-v2'):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8000'+endpoint,timeout=15) as res:
                api[endpoint]={'http_status':res.status,'body':safe(json.load(res))}
        except Exception as exc:
            api[endpoint]={'error_type':type(exc).__name__,'error':str(exc)}
report['http']=api
report['after']=capture(SOURCE)
report['preservation']={'main_sha256_equal':before['main_sha256']==report['after']['main_sha256'],'table_changes':{t:{'before':before['tables'].get(t),'after':report['after']['tables'].get(t)} for t in set(before['tables'])|set(report['after']['tables']) if before['tables'].get(t)!=report['after']['tables'].get(t)},'task_used_production_readonly_connections_only':True}
output=OUT/'production_inspection.json'
output.write_text(json.dumps(safe(report),ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['captured_at','quick_check','journal_mode','sidecars','episodes','ledger_counts','stale_observed','v4','audit_chain','localhost_8000_listening','preservation']},ensure_ascii=False,indent=2))
print('JSON evidence: '+str(output))
