import json
from pathlib import Path
import subprocess
import sys
sys.stdout.reconfigure(encoding='utf-8')

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
CLI=Path.home()/'codex-with-chatgpt'/'bin'/'c2c.js'
checks=json.loads((OUT/'checks.json').read_text(encoding='utf-8'))['results']
records=[]
for r in checks:
    cmd=['node',str(CLI),'record','-w',str(ROOT),'--task','c2c_edge_os_ops_inspection','--iteration','1','--changed-files','0','--tests','277 passed, 1 warning; full regression final exit 0; earlier environment failures preserved','--exit-status','ok' if r['exit_code']==0 else 'failed','--command',r['command'],'--output-file',r['output_file'],'--exit-code',str(r['exit_code']),'--notes','Read-only inspection; tests use isolated DATABASE_PATH; no production writes or source edits. See execution_output/ops_inspection_20261006/checks.json for environment and chronological results.']
    p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
    records.append({'command':r['command'],'record_exit':p.returncode,'result':p.stdout,'error':p.stderr})
    print(p.stdout,flush=True)
    if p.returncode:raise SystemExit(p.stderr)
p=subprocess.run(['node',str(CLI),'record','-w',str(ROOT),'--task','c2c_edge_os_ops_inspection','--iteration','1','--changed-files','0','--tests','277 passed, 1 warning; compileall/diff/frontend/pip/readonly DB checks exit 0','--exit-status','ok','--command','Read-only production inspection, ledger reconciliation, process checks and preservation comparison','--output-file',str(OUT/'report.md'),'--exit-code','0','--notes','Findings P1: runtime offline, 74 cancelled V4 execution evidence mismatches, 2 VOID holdings outside pending settlement. Full JSON evidence: execution_output/ops_inspection_20261006/summary.json. No restart, deployment or production/code mutation.'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
records.append({'command':'read-only report','record_exit':p.returncode,'result':p.stdout,'error':p.stderr})
print(p.stdout,flush=True)
(OUT/'c2c_records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
raise SystemExit(p.returncode)
