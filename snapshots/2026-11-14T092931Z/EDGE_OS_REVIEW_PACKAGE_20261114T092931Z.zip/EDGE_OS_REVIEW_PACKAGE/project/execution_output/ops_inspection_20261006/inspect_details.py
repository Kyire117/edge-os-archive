import collections
import datetime as dt
from decimal import Decimal as D
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
con=sqlite3.connect((OUT/'inspection_snapshot.db').resolve().as_uri()+'?mode=ro',uri=True)
con.row_factory=sqlite3.Row
con.execute('PRAGMA query_only=ON')
def rows(sql,*args):return [dict(r) for r in con.execute(sql,args)]
failed=rows("SELECT e.episode_id,e.first_detected_at,e.paper_status,e.rejection_reason,o.order_id,o.status order_status,o.reserve_cash_remaining,d.status decision_status,d.reason decision_reason,d.engine_version,r.reason runtime_reason,r.evidence_json runtime_evidence FROM wallet_v2_episodes e LEFT JOIN strict_orders o ON o.order_id=e.paper_order_id LEFT JOIN strict_decisions d ON d.signal_id=e.first_signal_id LEFT JOIN wallet_v2_runtime_events r ON r.episode_id=e.episode_id WHERE e.rejection_reason='EXECUTION_COMMIT_INCOMPLETE' ORDER BY e.first_detected_at")
for r in failed:
    evidence=json.loads(r.pop('runtime_evidence') or '{}')
    r['error_type']=evidence.get('error_type')
    r['error_detail']=evidence.get('error_detail')
pending=rows("SELECT e.episode_id,e.paper_status,e.resolution_status,e.first_detected_at,e.settled_at,p.quantity,p.cost_basis FROM wallet_v2_episodes e JOIN strict_positions p ON p.account_id=e.strategy_version||':'||lower(e.wallet) AND p.condition_id=e.condition_id AND p.token_id=e.first_token_id AND p.outcome=e.first_outcome WHERE CAST(p.quantity AS REAL)>0 ORDER BY e.first_detected_at")
api_failures=rows("SELECT e.episode_id,e.paper_status,e.resolution_status,COUNT(s.settlement_id) persisted_api_failures,MAX(s.observed_at) latest_api_failure FROM wallet_v2_episodes e JOIN strict_settlements s ON s.account_id=e.strategy_version||':'||lower(e.wallet) AND s.condition_id=e.condition_id AND s.token_id=e.first_token_id WHERE s.status='API_FAILURE' GROUP BY e.episode_id ORDER BY latest_api_failure DESC")
latest_runtime=rows('SELECT occurred_at,reason,evidence_json FROM wallet_v2_runtime_events ORDER BY occurred_at DESC LIMIT 30')
for r in latest_runtime:
    e=json.loads(r.pop('evidence_json'))
    r['error_type']=e.get('error_type');r['error_detail']=e.get('error_detail')
table_names={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
latest_discovery=rows('SELECT * FROM discovery_runs ORDER BY rowid DESC LIMIT 3') if 'discovery_runs' in table_names else []
audit_actions=rows('SELECT action,COUNT(*) count,MAX(occurred_at) latest FROM wallet_v2_audit GROUP BY action')
con.close()

errors=[]
inventory=[]
def scan(path):
    count=size=0
    def onerror(exc):errors.append({'path':str(exc.filename),'error_type':type(exc).__name__})
    for root,dirs,files in os.walk(path,onerror=onerror):
        for name in files:
            count+=1
            try:size+=(Path(root)/name).stat().st_size
            except OSError as exc:onerror(exc)
    return count,size
for p in ROOT.iterdir():
    if p.name.startswith(('.tm','.pytest')):
        count,size=scan(p) if p.is_dir() else (1,p.stat().st_size)
        inventory.append({'name':p.name,'files_readable':count,'bytes_readable':size})
data_sidecars=[];backups=[]
for root,dirs,files in os.walk(ROOT/'data'):
    for name in files:
        p=Path(root)/name
        item={'path':str(p.relative_to(ROOT)),'size':p.stat().st_size}
        if name.endswith(('-wal','-shm')):data_sidecars.append(item)
        elif 'backup' in name or 'backups' in p.parts:backups.append(item)
git_status=subprocess.run(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,capture_output=True,text=True)
git_diff=subprocess.run(['git','diff','HEAD','--binary'],cwd=ROOT,capture_output=True)
result={'execution_commit_incomplete':{'count':len(failed),'error_counts':dict(collections.Counter((r['error_detail'] or r['runtime_reason'] or 'UNAVAILABLE') for r in failed)),'first':failed[:2],'last':failed[-3:]},'open_positions':pending,'api_failure_history':api_failures,'latest_runtime_errors':latest_runtime,'audit_actions':audit_actions,'discovery_runs':latest_discovery,'artifact_inventory':{'tm_roots':sum(p['name'].startswith('.tm') for p in inventory),'pytest_roots':sum(p['name'].startswith('.pytest') for p in inventory),'roots':inventory,'inaccessible_paths':errors,'data_sidecars':data_sidecars,'backups':backups,'backup_count':len(backups),'wal_shm_count':len(data_sidecars)},'git':{'tracked_status':git_status.stdout,'status_exit':git_status.returncode,'diff_sha256':hashlib.sha256(git_diff.stdout).hexdigest(),'diff_exit':git_diff.returncode}}
(OUT/'inspection_details.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:result[k] for k in ['execution_commit_incomplete','open_positions','latest_runtime_errors']},ensure_ascii=False,indent=2))
print('Artifact roots:',len(inventory),'Backups:',len(backups),'WAL/SHM:',len(data_sidecars),'Inaccessible:',len(errors))
