import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
env=os.environ.copy()
env['PATH']=str(Path(sys.executable).parent)+os.pathsep+env.get('PATH','')
temp=(ROOT.parents[1]/'execution_output'/'ops6tests') if '--short-temp' in sys.argv else OUT/'temporary_test_environment'
temp.mkdir(parents=True,exist_ok=True)
env['TEMP']=str(temp)
env['TMP']=str(temp)
env['DATABASE_PATH']=str(temp/'isolated_test_default.db')
env['PYTEST_ADDOPTS']='--basetemp="'+str(temp/'pytest')+'" -p no:cacheprovider'
commands=[('pytest',['python','-m','pytest','tests','-q']),('compileall',['python','-m','compileall','-q','app','tests']),('diff_check',['git','diff','--check']),('frontend_syntax',['node','--check','app/static/app.js']),('frontend_tests',['node','tests/ui_v1_static.test.js']),('pip_check',['python','-m','pip','check'])]
results=[]
if '--pytest-only' in sys.argv:
    commands=commands[:1]
    results=json.loads((OUT/'checks.json').read_text(encoding='utf-8'))['results']
for name,args in commands:
    started=time.monotonic()
    actual=([sys.executable]+args[1:]) if args[0]=='python' else args
    p=subprocess.run(actual,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    content=p.stdout.decode('utf-8',errors='replace')
    log_name=name+('_short_temp' if '--short-temp' in sys.argv else '_retry' if '--pytest-only' in sys.argv else '')
    (OUT/(log_name+'.txt')).write_text(content,encoding='utf-8')
    result={'name':log_name,'command':' '.join(args),'executable':actual[0],'exit_code':p.returncode,'duration_seconds':round(time.monotonic()-started,3),'output_file':str(OUT/(log_name+'.txt'))}
    results.append(result)
    (OUT/'checks.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(ROOT),'temporary_database':env['DATABASE_PATH'],'pytest_options':env['PYTEST_ADDOPTS'],'results':results},indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)
    print(content[-3000:],flush=True)
sys.exit(0 if all(r['exit_code']==0 for r in results) else 1)
