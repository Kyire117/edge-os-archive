"""Live-only adapter, explicit activation and read-only status for Wallet Follow V2."""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import sqlite3
import time
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from .strict_paper import (BookSnapshot, BookLevel, MarketIdentity, MarketState,
                           LocalObservationEngineRules, OrderIntent, execute_order)
from .polymarket import public_profile_view, verified_market_url
from .wallet_follow_v2 import STRATEGY_VERSION, StrategyConfig, WalletFollowV2
from .exit_v1 import (EXIT_RULE_VERSION, append_exit_event, ensure_exit_v1_active,
                      exit_levels, exit_v1_status, quote_transition)
from .shared_pool import capital_metrics

log=logging.getLogger("edge.wallet_follow_v2")
V2_CONFIG = StrategyConfig(max_visible_depth_fraction=Decimal("0.10"))


class V2ActivationState(str, Enum):
    NOT_CONFIGURED = "NOT_CONFIGURED"
    INACTIVE = "INACTIVE"
    ACTIVE = "ACTIVE"
    LOCKED = "LOCKED"
    READ_ERROR = "READ_ERROR"


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _as_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("NAIVE_TIMESTAMP")
        return value.astimezone(timezone.utc)
    if isinstance(value, bool) or value is None:
        raise ValueError("MISSING_TIMESTAMP")
    if isinstance(value, (int, float, Decimal)):
        raw = Decimal(str(value))
        if not raw.is_finite() or raw <= 0:
            raise ValueError("INVALID_TIMESTAMP")
        if raw > Decimal("10000000000"):
            raw /= Decimal("1000")
        return datetime.fromtimestamp(float(raw), timezone.utc)
    raw = str(value).strip()
    if not raw:
        raise ValueError("MISSING_TIMESTAMP")
    try:
        stamp = Decimal(raw)
        if stamp.is_finite() and stamp > 0:
            if stamp > Decimal("10000000000"):
                stamp /= Decimal("1000")
            return datetime.fromtimestamp(float(stamp), timezone.utc)
    except (InvalidOperation, ValueError, OverflowError):
        pass
    parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("NAIVE_TIMESTAMP")
    return parsed.astimezone(timezone.utc)


def _finite_decimal(value: Any, reason: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(reason) from None
    if not result.is_finite():
        raise ValueError(reason)
    return result


def _optional_datetime(value: Any) -> tuple[datetime | None, str | None]:
    if value is None:
        return None, None
    try:
        return _as_datetime(value), None
    except (ValueError, TypeError, OverflowError):
        return None, "INVALID_SOURCE_TIMESTAMP"


def _readonly_uri(path: str | Path) -> str:
    # Do not use immutable=1: it ignores an active SQLite WAL and would expose
    # stale activation/settlement state while the app is running.
    return f"file:{Path(path).resolve().as_posix()}?mode=ro"


def v2_activation_state(path: str | Path) -> V2ActivationState:
    target = Path(path)
    if not target.exists():
        return V2ActivationState.NOT_CONFIGURED
    try:
        uri = _readonly_uri(target)
        with sqlite3.connect(uri, uri=True) as con:
            con.row_factory = sqlite3.Row
            exists = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wallet_v2_versions'").fetchone()
            if not exists:
                return V2ActivationState.NOT_CONFIGURED
            row = con.execute("SELECT state,activated_at FROM wallet_v2_versions WHERE strategy_version=?", (STRATEGY_VERSION,)).fetchone()
            if row is None:
                return V2ActivationState.NOT_CONFIGURED
            if row["state"] == "FORWARD_TEST":
                return V2ActivationState.ACTIVE
            # Once a production version has ever been activated, retiring or
            # completing it must not silently hand runtime back to legacy V0.x.
            return V2ActivationState.LOCKED if row["activated_at"] is not None else V2ActivationState.INACTIVE
    except sqlite3.Error:
        return V2ActivationState.READ_ERROR


def has_active_v2(path: str | Path) -> bool:
    """Compatibility helper that never converts a database read error to inactive."""
    state=v2_activation_state(path)
    if state is V2ActivationState.READ_ERROR:
        raise RuntimeError("V2_ACTIVATION_STATE_READ_ERROR")
    return state is V2ActivationState.ACTIVE


def _forward_cutoff(con: sqlite3.Connection, activated_at: str | None) -> datetime | None:
    if not activated_at:
        return None
    row = con.execute("SELECT occurred_at FROM wallet_v2_audit "
                      "WHERE action='CLEAN_FORWARD_RESTART' ORDER BY audit_id DESC LIMIT 1").fetchone()
    return _as_datetime(row[0] if row else activated_at)


def forward_cutoff_v2(path: str | Path) -> datetime | None:
    """Return the clean-restart cutoff, if one was explicitly recorded."""
    with sqlite3.connect(_readonly_uri(path), uri=True) as con:
        con.execute("PRAGMA query_only=ON")
        row = con.execute("SELECT occurred_at FROM wallet_v2_audit "
                          "WHERE action='CLEAN_FORWARD_RESTART' ORDER BY audit_id DESC LIMIT 1").fetchone()
        return _as_datetime(row[0]) if row else None


def create_activation_backup(path: str | Path) -> Path:
    source = Path(path)
    if not source.is_file():
        raise RuntimeError("SOURCE_DATABASE_MISSING")
    stamp = _utcnow().strftime("%Y%m%dT%H%M%S%fZ")
    destination = source.with_name(f"{source.name}.wallet-follow-v2-before-activation-{stamp}-{uuid.uuid4().hex[:8]}.backup")
    source_uri = f"file:{source.resolve().as_posix()}?mode=ro"
    try:
        with sqlite3.connect(source_uri, uri=True, timeout=30) as src, sqlite3.connect(destination, timeout=30) as dst:
            src.backup(dst)
            check = dst.execute("PRAGMA quick_check").fetchone()
            if not check or check[0] != "ok":
                raise RuntimeError("BACKUP_INTEGRITY_CHECK_FAILED")
        if not destination.is_file() or destination.stat().st_size == 0:
            raise RuntimeError("BACKUP_NOT_CREATED")
    except Exception as exc:
        # A failed backup is never permission to activate. A partial backup is
        # intentionally left in place as evidence rather than deleting data.
        if isinstance(exc, RuntimeError):
            raise
        raise RuntimeError("BACKUP_FAILED") from None
    return destination


def activate_v2(database: Any, *, now: datetime | None = None,
                backup_fn: Callable[[str | Path], Path] = create_activation_backup) -> dict[str, Any]:
    """Explicit, one-time activation. Never called from application startup."""
    path = Path(database.path)
    if now is not None and (now.tzinfo is None or now.utcoffset() is None):
        raise ValueError("INVALID_ACTIVATION_TIMESTAMP")
    at = (now or _utcnow()).astimezone(timezone.utc)
    # A retry after a committed activation verifies the original backup and
    # does not create a second version or a new timestamp.
    if path.exists():
        uri = _readonly_uri(path)
        with sqlite3.connect(uri, uri=True) as con:
            con.row_factory = sqlite3.Row
            tables = {x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "wallet_v2_versions" in tables:
                existing = con.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version=?", (STRATEGY_VERSION,)).fetchone()
                if existing and existing["state"] == "FORWARD_TEST":
                    audit = con.execute("SELECT evidence_json FROM wallet_v2_audit WHERE action='V2_ACTIVATED' ORDER BY audit_id DESC LIMIT 1").fetchone()
                    backup_name = json.loads(audit[0]).get("backup_file") if audit else None
                    backup_path = path.with_name(backup_name) if backup_name else None
                    if not backup_path or not backup_path.is_file() or backup_path.stat().st_size == 0:
                        raise RuntimeError("ACTIVATION_BACKUP_MISSING")
                    if existing["config_json"] != json.dumps(V2_CONFIG.evidence(), sort_keys=True, separators=(",", ":")):
                        raise RuntimeError("FROZEN_V2_CONFIG_CONFLICT")
                    return {"activated": False, "already_active": True,
                            "strategy_version": STRATEGY_VERSION, "activated_at": existing["activated_at"],
                            "backup_file": backup_name}

    backup = backup_fn(path)
    if not Path(backup).is_file() or Path(backup).stat().st_size == 0:
        raise RuntimeError("BACKUP_NOT_CREATED")
    # Initialization only creates additive strict_*/wallet_v2_* structures.
    WalletFollowV2.initialize(path)
    config_json = json.dumps(V2_CONFIG.evidence(), sort_keys=True, separators=(",", ":"))
    created_at = at.isoformat()
    with sqlite3.connect(path, timeout=30, isolation_level=None) as con:
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("BEGIN IMMEDIATE")
        try:
            # Older production databases can contain experiment tables before
            # the event table was initialized by the normal app startup path.
            # Keep this additive DDL in the activation transaction so closing
            # the legacy run and recording its supersession stay atomic.
            con.execute("""CREATE TABLE IF NOT EXISTS research_experiment_events(
                event_id TEXT PRIMARY KEY, experiment_id TEXT NOT NULL, event_type TEXT NOT NULL,
                created_ts REAL NOT NULL, details_json TEXT NOT NULL,
                FOREIGN KEY(experiment_id) REFERENCES research_experiments(id))""")
            con.execute("CREATE INDEX IF NOT EXISTS research_experiment_events_lookup ON research_experiment_events(experiment_id,event_type,created_ts)")
            existing = con.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version=?", (STRATEGY_VERSION,)).fetchone()
            if existing:
                raise RuntimeError("WALLET_V2_VERSION_CONFLICT")
            legacy = con.execute("SELECT * FROM research_experiments WHERE status IN ('RUNNING','ENTRY_CLOSED') ORDER BY started_at DESC").fetchall()
            running = [x for x in legacy if x["status"] == "RUNNING"]
            if len(running) > 1:
                raise RuntimeError("MULTIPLE_RUNNING_LEGACY_EXPERIMENTS")
            if running:
                old = running[0]
                con.execute("UPDATE research_experiments SET status='ENTRY_CLOSED' WHERE id=? AND status='RUNNING'", (old["id"],))
                details = json.dumps({"strategy_version": STRATEGY_VERSION, "previous_status": "RUNNING"}, sort_keys=True, separators=(",", ":"))
                con.execute("INSERT INTO research_experiment_events(event_id,experiment_id,event_type,created_ts,details_json) VALUES(?,?,?,?,?)",
                            (uuid.uuid4().hex, old["id"], "SUPERSEDED_BY_WALLET_FOLLOW_V2", at.timestamp(), details))
                con.execute("INSERT INTO research_audit(created_ts,action,data_json) VALUES(?,?,?)",
                            (at.timestamp(), "SUPERSEDED_BY_WALLET_FOLLOW_V2", json.dumps({"experiment_id":old["id"], "strategy_version":STRATEGY_VERSION}, sort_keys=True)))
            con.execute("""INSERT INTO wallet_v2_versions
                (strategy_version,parent_version,created_at,config_json,evidence_cutoff,state,activated_at)
                VALUES(?,NULL,?,?,?,'FORWARD_TEST',?)""",
                (STRATEGY_VERSION, created_at, config_json, created_at, created_at))
            evidence = json.dumps({"strategy_version":STRATEGY_VERSION, "created_at":created_at,
                "evidence_cutoff":created_at, "activated_at":created_at, "state":"FORWARD_TEST",
                "config":V2_CONFIG.evidence(), "backup_file":Path(backup).name}, sort_keys=True, separators=(",", ":"))
            con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES('V2_ACTIVATED',?,?)", (created_at, evidence))
            con.commit()
        except Exception:
            con.rollback()
            raise
    return {"activated": True, "already_active": False, "strategy_version":STRATEGY_VERSION,
            "activated_at":created_at, "backup_file":Path(backup).name,
            "frozen_config":V2_CONFIG.evidence()}


def status_v2(path: str | Path, *, limit: int = 20) -> dict[str, Any]:
    target = Path(path)
    if not target.exists():
        return {"configured":False,"state":"NOT_CONFIGURED","strategy_version":STRATEGY_VERSION}
    uri = _readonly_uri(target)
    with sqlite3.connect(uri, uri=True) as con:
        con.row_factory = sqlite3.Row
        con.execute('PRAGMA query_only=ON')
        con.execute('BEGIN')
        tables = {x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "wallet_v2_versions" not in tables:
            return {"configured":False,"state":"NOT_CONFIGURED","strategy_version":STRATEGY_VERSION}
        version = con.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version=?", (STRATEGY_VERSION,)).fetchone()
        if not version:
            return {"configured":False,"state":"NOT_CONFIGURED","strategy_version":STRATEGY_VERSION}
        episodes = [dict(x) for x in con.execute("SELECT * FROM wallet_v2_episodes WHERE strategy_version=? ORDER BY first_detected_at", (STRATEGY_VERSION,))]
        events = {x["episode_id"]:dict(x) for x in con.execute("SELECT episode_id,evidence_json FROM wallet_v2_events WHERE event_type='FIRST'")}
        runtime_reasons = dict(con.execute("SELECT reason,COUNT(*) FROM wallet_v2_runtime_events WHERE episode_id IS NULL GROUP BY reason"))
        accounts = [dict(x) for x in con.execute("SELECT available_cash,reserved_cash FROM strict_accounts WHERE account_id LIKE ?", (f"{STRATEGY_VERSION}:%",))] if "strict_accounts" in tables else []
        positions = [dict(x) for x in con.execute("SELECT * FROM strict_positions WHERE account_id LIKE ?", (f"{STRATEGY_VERSION}:%",))] if "strict_positions" in tables else []
        decisions = [dict(x) for x in con.execute("SELECT idempotency_key,evidence_json FROM strict_decisions WHERE idempotency_key LIKE ?", (f"{STRATEGY_VERSION}:%",))] if "strict_decisions" in tables else []
        cutoff = _forward_cutoff(con, version["activated_at"])
        tracked_wallets = con.execute("SELECT COUNT(*) FROM wallets WHERE tracked=1").fetchone()[0] if "wallets" in tables else 0
        observed_trades = observed_buys = 0
        if cutoff is not None and "trades" in tables:
            row = con.execute("""SELECT COUNT(*), COALESCE(SUM(CASE WHEN side='BUY' THEN 1 ELSE 0 END),0)
                FROM trades WHERE is_seed=0 AND timestamp>=?
                AND julianday(discovered_at)>=julianday(?)""",
                (cutoff.timestamp(), cutoff.isoformat())).fetchone()
            observed_trades, observed_buys = row[0], row[1]
        pool_metrics = capital_metrics(con, STRATEGY_VERSION)
    observed=len(episodes)
    resolved=[x for x in episodes if x["resolution_status"]=="FORMALLY_RESOLVED"]
    resolved_paper=[x for x in resolved if x["paper_status"] in {"FILLED","PARTIAL"}]
    paper_wins=sum(x["direction_correct"]==1 for x in resolved_paper)
    paper_losses=sum(x["direction_correct"]==0 for x in resolved_paper)
    paper_total=paper_wins+paper_losses
    filled=[x for x in episodes if x["paper_status"]=="FILLED"]
    partial=[x for x in episodes if x["paper_status"]=="PARTIAL"]
    rejected=[x for x in episodes if x["paper_status"]=="REJECTED"]
    pending=[x for x in episodes if x["resolution_status"] not in {"FORMALLY_RESOLVED","VOID"}]
    realized=sum((Decimal(x["realized_pnl"]) for x in positions),Decimal("0"))
    unrealized=sum((Decimal(x["unrealized_pnl"] or "0") for x in positions),Decimal("0"))
    missing_marks=sum(Decimal(x['quantity'])>0 and x['unrealized_pnl'] is None for x in positions)
    available_cash=sum((Decimal(x["available_cash"]) for x in accounts),Decimal("0"))
    reserved_cash=sum((Decimal(x["reserved_cash"]) for x in accounts),Decimal("0"))
    invested=sum((Decimal(x["filled_notional"] or "0")+Decimal(x["entry_fee"] or "0") for x in episodes if (x["resolution_status"]=="FORMALLY_RESOLVED" or (x["resolution_status"]=="VOID" and x["payout_per_share"] is not None)) and x["paper_status"] in {"FILLED","PARTIAL"}),Decimal("0"))
    no_fill: dict[str,int]={}
    for item in rejected:
        reason=item["rejection_reason"] or "UNKNOWN"
        no_fill[reason]=no_fill.get(reason,0)+1
    for key,value in runtime_reasons.items():
        no_fill[key]=no_fill.get(key,0)+int(value)
    wallet_results: dict[str, dict[str, int]] = {}
    for item in episodes:
        result = wallet_results.setdefault(item["wallet"], {"episodes":0,"fills":0,"rejected":0,
            "pending_paper_settlements":0,"realized_pnl":"0","unrealized_pnl":"0"})
        result["episodes"] += 1
        if item["paper_status"] in {"FILLED","PARTIAL"}:
            result["fills"] += 1
            if item["resolution_status"] not in {"FORMALLY_RESOLVED","VOID"}:
                result["pending_paper_settlements"] += 1
        elif item["paper_status"] == "REJECTED":
            result["rejected"] += 1
    for position in positions:
        wallet = position["account_id"].removeprefix(f"{STRATEGY_VERSION}:")
        result = wallet_results.setdefault(wallet, {"episodes":0,"fills":0,"rejected":0,
            "pending_paper_settlements":0,"realized_pnl":"0","unrealized_pnl":"0"})
        result["realized_pnl"] = str(Decimal(result["realized_pnl"]) + Decimal(position["realized_pnl"] or "0"))
        result["unrealized_pnl"] = str(Decimal(result["unrealized_pnl"]) + Decimal(position["unrealized_pnl"] or "0"))
        if Decimal(position['quantity'])>0 and position['unrealized_pnl'] is None:
            result['missing_marks']=result.get('missing_marks',0)+1
    for result in wallet_results.values():
        if result.get('missing_marks'):result['unrealized_pnl']=None
    decision_evidence={}
    for item in decisions:
        try: decision_evidence[item["idempotency_key"].rsplit(":",1)[-1]]=json.loads(item["evidence_json"])
        except (TypeError,ValueError): pass
    recent=[]
    for item in reversed(episodes[-max(1,min(int(limit),100)):]):
        evidence=json.loads(events.get(item["episode_id"],{}).get("evidence_json") or "{}")
        trade=evidence.get("trade") if isinstance(evidence.get("trade"),dict) else {}
        decision=decision_evidence.get(item["first_signal_id"],{})
        recent.append({"wallet":item["wallet"],"market_title":trade.get("title"),"condition_id":item["condition_id"],
            "token_id":item["first_token_id"],"outcome":item["first_outcome"],"direction":item["first_outcome"],
            "leader_price":item["leader_price"],"edge_execution_price":item["execution_price"],
            "paper_status":item["paper_status"],"paper_reason":item["rejection_reason"],
            "projected_net_roi_if_win":decision.get("projected_net_roi_if_win"),"resolution_status":item["resolution_status"],
            "direction_correct":item["direction_correct"],"detected_at":item["first_detected_at"]})
    config=json.loads(version["config_json"])
    status={"configured":True,"strategy_version":version["strategy_version"],"state":version["state"],
        "created_at":version["created_at"],"evidence_cutoff":version["evidence_cutoff"],
        "activated_at":version["activated_at"],"frozen_config":config,
        "resolved_paper_outcomes":{"wins":paper_wins,"losses":paper_losses,
            "total":paper_total,"rate":paper_wins/paper_total if paper_total else None,
            "unscored":len(resolved_paper)-paper_total},
        "counts":{"observed_episodes":observed,"resolved_episodes":len(resolved),"filled":len(filled),
            "partial":len(partial),"rejected_no_fill":len(rejected),"pending_resolution":len(pending)},
        "performance":{"directional_accuracy":(sum(int(x["direction_correct"] or 0) for x in resolved)/len(resolved) if resolved else None),
            "realized_paper_pnl":str(realized),"unrealized_paper_pnl":None if missing_marks else str(unrealized),
            "missing_mark_positions":missing_marks,
            "realized_paper_net_roi":str(realized/invested) if invested else None,
            "no_fill_reason_distribution":no_fill,"available_cash":str(available_cash),
            "reserved_cash":str(reserved_cash)},
        "observation":{"forward_started_at":cutoff.isoformat() if cutoff else None,
            "tracked_wallets":tracked_wallets,"observed_trades":observed_trades,
            "observed_buy_trades":observed_buys,"participating_wallets":len(wallet_results)},
        "settlement":{"pending_paper_positions":sum(x["pending_paper_settlements"] for x in wallet_results.values())},
        "wallet_results":wallet_results,"recent_episodes":recent,"capital_pool":pool_metrics}
    status["exit_v1"]=exit_v1_status(target)
    return status


def _episode_display(con: sqlite3.Connection, item: sqlite3.Row) -> dict[str, Any]:
    entry = dict(item)
    first = con.execute("SELECT evidence_json FROM wallet_v2_events "
                        "WHERE episode_id=? AND event_type='FIRST' LIMIT 1", (entry["episode_id"],)).fetchone()
    try:
        evidence = json.loads(first[0]) if first else {}
    except (TypeError, ValueError):
        evidence = {}
    trade = evidence.get("trade") if isinstance(evidence, dict) else None
    trade = trade if isinstance(trade, dict) else {}
    profile = con.execute("SELECT address,proxy_wallet,username,avatar_url,source,refreshed_at "
                          "FROM wallet_public_profiles WHERE address=?", (entry["wallet"],)).fetchone()
    entry["market_title"] = trade.get("title")
    entry["market_url"] = verified_market_url(evidence)
    entry["leader_identity"] = public_profile_view(dict(profile) if profile else None, entry["wallet"])
    return entry


def v2_episode_list(path: str | Path, *, offset: int = 0, limit: int = 50,
                    status: str = "") -> dict[str, Any]:
    if status not in {"", "OBSERVED", "FILLED", "PARTIAL", "REJECTED", "FORMALLY_RESOLVED"}:
        raise ValueError("INVALID_EPISODE_STATUS")
    with sqlite3.connect(_readonly_uri(path), uri=True) as con:
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA query_only=ON")
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wallet_v2_episodes'").fetchone():
            return {"total": 0, "entries": []}
        clause = "strategy_version=?"
        args: list[Any] = [STRATEGY_VERSION]
        if status:
            clause += " AND " + ("resolution_status" if status == "FORMALLY_RESOLVED" else "paper_status") + "=?"
            args.append(status)
        total = con.execute(f"SELECT COUNT(*) FROM wallet_v2_episodes WHERE {clause}", args).fetchone()[0]
        items = con.execute(f"SELECT * FROM wallet_v2_episodes WHERE {clause} "
                            "ORDER BY first_detected_at DESC,episode_id DESC LIMIT ? OFFSET ?",
                            [*args, limit, offset]).fetchall()
        return {"total": total, "entries": [_episode_display(con, item) for item in items]}


def v2_episode_detail(path: str | Path, episode_id: str) -> dict[str, Any] | None:
    with sqlite3.connect(_readonly_uri(path), uri=True) as con:
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA query_only=ON")
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wallet_v2_episodes'").fetchone():
            return None
        item = con.execute("SELECT * FROM wallet_v2_episodes WHERE episode_id=? AND strategy_version=?",
                           (episode_id, STRATEGY_VERSION)).fetchone()
        if item is None:
            return None
        entry = _episode_display(con, item)
        account_id = f"{STRATEGY_VERSION}:{entry['wallet'].lower()}"
        entry["events"] = [dict(row) for row in con.execute(
            "SELECT * FROM wallet_v2_events WHERE episode_id=? ORDER BY detected_at,event_id", (episode_id,))]
        entry["runtime_events"] = [dict(row) for row in con.execute(
            "SELECT * FROM wallet_v2_runtime_events WHERE episode_id=? ORDER BY occurred_at", (episode_id,))]
        entry["strict_decisions"] = [dict(row) for row in con.execute(
            "SELECT * FROM strict_decisions WHERE account_id=? AND signal_id=?",
            (account_id, entry["first_signal_id"]))]
        entry["strict_orders"] = [dict(row) for row in con.execute(
            "SELECT * FROM strict_orders WHERE account_id=? AND signal_id=?",
            (account_id, entry["first_signal_id"]))]
        entry["strict_fills"] = [dict(row) for row in con.execute(
            "SELECT f.* FROM strict_fills f JOIN strict_orders o ON o.order_id=f.order_id "
            "WHERE o.account_id=? AND o.signal_id=?", (account_id, entry["first_signal_id"]))]
        entry["strict_settlements"] = [dict(row) for row in con.execute(
            "SELECT * FROM strict_settlements WHERE account_id=? AND condition_id=? AND token_id=?",
            (account_id, entry["condition_id"], entry["first_token_id"]))]
        return entry


class WalletFollowRuntime:
    """Uses one quote and one delayed, independently fetched execution book."""

    def __init__(self, path: str | Path, client: Any, *, clock: Callable[[], datetime] = _utcnow,
                 sleep: Callable[[float], Any] = asyncio.sleep):
        self.engine = WalletFollowV2(path)
        self.client = client
        self.clock = clock
        self.sleep = sleep

    def _now(self) -> datetime:
        return _as_datetime(self.clock())

    async def process_trade(self, wallet: str, trade: dict[str, Any], *, detected_at: datetime) -> dict[str, Any] | None:
        self.engine.recover_stale_observed(now=self._now())
        if str(trade.get("side") or "").upper() != "BUY":
            return {"decision":"V2_NON_BUY_IGNORED","signal_id":trade.get("trade_key")}
        signal_id=str(trade.get("trade_key") or "")
        if not signal_id:
            return None
        detected=_as_datetime(detected_at)
        identity_values=(trade.get("condition_id"),trade.get("token_id"),trade.get("outcome"))
        try:
            identity=MarketIdentity(*(str(x).strip() if x is not None else "" for x in identity_values))
            leader_at=_as_datetime(trade.get("timestamp"))
            if detected < leader_at:
                raise ValueError("INVALID_SIGNAL_TIMESTAMP")
            cutoff=forward_cutoff_v2(self.engine.path)
            if cutoff is not None and (leader_at < cutoff or detected < cutoff):
                # The raw trade is already stored by the monitor. An old trade
                # first discovered after the clean restart is not a new V2
                # prediction and must never request market or book data.
                return {"decision":"V2_PRE_RESTART_TRADE_IGNORED","signal_id":signal_id,
                        "forward_started_at":cutoff.isoformat()}
            result=self.engine.observe_buy(signal_id=signal_id,wallet=wallet,identity=identity,
                leader_at=leader_at,detected_at=detected,leader_price=trade.get("price"),
                category=trade.get("category"),source_mode="LIVE_OBSERVATION",
                evidence={"source":"LIVE_WALLET_MONITOR","trade":trade})
        except Exception as exc:
            reason=str(exc) if str(exc).isupper() and len(str(exc))<80 else type(exc).__name__.upper()
            self.engine.record_runtime_failure(signal_id=signal_id,wallet=wallet,condition_id=identity_values[0],
                reason=reason,occurred_at=detected,evidence={"phase":"OBSERVATION","error_type":type(exc).__name__,"trade_key":signal_id})
            return {"decision":"REJECTED","reason":reason,"signal_id":signal_id}
        if result["duplicate"] or result["event_type"] != "FIRST":
            return {"decision":result["event_type"],**result}
        episode_id=result["episode_id"]
        return await self._execute_episode(episode_id, signal_id, wallet, trade, identity, detected)

    async def _book_snapshot(self, identity: MarketIdentity, *, phase: str = "QUOTE",
                             evidence: dict[str, Any] | None = None,
                             previous: BookSnapshot | None = None) -> BookSnapshot:
        request_at=self._now(); request_id=uuid.uuid4().hex; start=time.monotonic()
        book_evidence: dict[str,Any]={
            "phase":phase,"quote_or_execution":phase,"request_id":request_id,
            "identity":{"condition_id":identity.condition_id,"token_id":identity.token_id,"outcome":identity.outcome},
            "request_timestamp":request_at.isoformat(),"received_timestamp":None,"elapsed_ms":None,
            "raw_source_timestamp":None,"raw_timestamp_type":None,"raw_timestamp_repr":None,
            "normalized_source_timestamp":None,"source_timestamp_parse_status":"NOT_AVAILABLE",
            "source_timestamp_parse_error":None,"upstream_hash":None,"raw_book":None,
            "bids":None,"asks":None,"bid_level_count":None,"ask_level_count":None,
            "best_bid":None,"best_ask":None,
            "http_date":None,"http_age":None,"http_cache_control":None,"http_status":None,
            "http_response_received_timestamp":None,"http_response_attempt":None,
            "source_timestamp_role":"UPSTREAM_BOOK_STATE_PROVENANCE",
            "received_timestamp_role":"EDGE_LOCAL_OBSERVATION_TIME",
            "source_minus_request_ms":None,"source_minus_received_ms":None,
            "response_age_at_decision_ms":None,"source_equal_previous":None,"hash_equal_previous":None}
        if evidence is not None:
            evidence.setdefault("books",[]).append(book_evidence)
        try:
            payload=await asyncio.wait_for(self.client.orderbook(identity.token_id),timeout=10)
            received_at=self._now()
            book_evidence.update(received_timestamp=received_at.isoformat(),elapsed_ms=(time.monotonic()-start)*1000)
            raw=payload.get("raw") if isinstance(payload,dict) else None
            metadata=payload.get("http_metadata") if isinstance(payload,dict) else None
            if isinstance(metadata,dict):
                book_evidence.update({k:metadata.get(k) for k in ("http_date","http_age","http_cache_control","http_status")})
                book_evidence.update(http_response_received_timestamp=metadata.get("response_received_timestamp"),
                                     http_response_attempt=metadata.get("response_attempt"))
            book_evidence["raw_book"]=raw
            stamp=raw.get("timestamp") if isinstance(raw,dict) and "timestamp" in raw else payload.get("timestamp") if isinstance(payload,dict) else None
            book_evidence.update(raw_source_timestamp=stamp,raw_timestamp_type=type(stamp).__name__ if stamp is not None else None,
                raw_timestamp_repr=repr(stamp) if stamp is not None else None,
                upstream_hash=raw.get("hash") if isinstance(raw,dict) else None)
            if request_at>received_at:
                raise ValueError(f"INVALID_{phase}_LOCAL_TIMESTAMPS")
            if not isinstance(payload,dict) or not isinstance(raw,dict):
                raise ValueError("MALFORMED_ORDER_BOOK")
            if (raw.get("asset_id") is not None and str(raw["asset_id"])!=identity.token_id
                    or raw.get("market") is not None and raw["market"]!=identity.condition_id):
                raise ValueError("MARKET_IDENTITY_MISMATCH")
            try:
                source_stamp=_as_datetime(stamp)
            except (ValueError,TypeError,OverflowError,OSError) as exc:
                reason="MISSING_TIMESTAMP" if stamp is None or stamp=="" else "INVALID_TIMESTAMP"
                book_evidence.update(source_timestamp_parse_status="INVALID",source_timestamp_parse_error=str(exc))
                raise ValueError(reason) from exc
            book_evidence.update(source_timestamp_parse_status="PARSED",normalized_source_timestamp=source_stamp.isoformat(),
                source_minus_request_ms=(source_stamp-request_at).total_seconds()*1000,
                source_minus_received_ms=(source_stamp-received_at).total_seconds()*1000,
                source_equal_previous=source_stamp==previous.source_timestamp if previous else None)
            if previous and previous.observation_evidence_json:
                old_hash=json.loads(previous.observation_evidence_json).get("upstream_hash")
                if old_hash is not None and book_evidence["upstream_hash"] is not None:
                    book_evidence["hash_equal_previous"]=old_hash==book_evidence["upstream_hash"]
            for key in ("bids","asks"):
                source_levels=raw.get(key);normalized=payload.get(key)
                if not isinstance(source_levels,list) or not isinstance(normalized,list) or len(source_levels)!=len(normalized):
                    raise ValueError("MALFORMED_ORDER_BOOK")
            # Parse exact raw prices/sizes, not lossy floating-point normalization.
            snapshot=BookSnapshot.from_raw(snapshot_id=uuid.uuid4().hex,request_id=request_id,identity=identity,
                source="Polymarket CLOB /book",source_timestamp=source_stamp,request_timestamp=request_at,
                received_timestamp=received_at,bids=raw["bids"],asks=raw["asks"],observation_evidence=book_evidence)
            book_evidence.update(snapshot.to_evidence())
            return snapshot
        except Exception as exc:
            # This dictionary is carried into the atomic terminal runtime event,
            # even when construction/transport fails before a snapshot exists.
            metadata=getattr(exc,"response_metadata",None)
            if isinstance(metadata,dict):
                book_evidence.update({k:metadata.get(k) for k in ("http_date","http_age","http_cache_control","http_status")})
                # Capture at the HTTP boundary, before status/JSON validation.
                # Never replace a transport failure with the later error time.
                response_received=metadata.get("response_received_timestamp")
                book_evidence.update(http_response_received_timestamp=response_received,
                                     http_response_attempt=metadata.get("response_attempt"))
                if response_received is not None:
                    book_evidence["received_timestamp"]=_as_datetime(response_received).isoformat()
                raw=metadata.get("raw_response");book_evidence["raw_book"]=raw
                if isinstance(raw,dict):
                    stamp=raw.get("timestamp")
                    book_evidence.update(raw_source_timestamp=stamp,raw_timestamp_type=type(stamp).__name__ if stamp is not None else None,
                        raw_timestamp_repr=repr(stamp) if stamp is not None else None,upstream_hash=raw.get("hash"))
            book_evidence["elapsed_ms"]=(time.monotonic()-start)*1000
            book_evidence["validation_reason"]=str(exc) if isinstance(exc,ValueError) else "ORDER_BOOK_RESPONSE_UNAVAILABLE"
            book_evidence["error_type"]=type(exc).__name__
            raise

    async def _execute_episode(self, episode_id: str, signal_id: str, wallet: str,
                               trade: dict[str, Any], identity: MarketIdentity,
                               detected: datetime) -> dict[str, Any]:
        evidence: dict[str,Any]={"phase":"EXECUTION_ADAPTER","signal_id":signal_id,
                                 "identity":{"condition_id":identity.condition_id,"token_id":identity.token_id,"outcome":identity.outcome}}
        try:
            market_request=self._now()
            market_data=await asyncio.wait_for(self.client.market_state(identity.token_id),timeout=15)
            market_received=self._now()
            if not isinstance(market_data,dict):
                raise ValueError("MALFORMED_MARKET_STATE")
            if (market_data.get("condition_id") != identity.condition_id or market_data.get("token_id") != identity.token_id
                    or market_data.get("outcome") != identity.outcome):
                raise ValueError("MARKET_IDENTITY_MISMATCH")
            if market_data.get("accepting_orders") is not True or market_data.get("closed") is True or market_data.get("resolved") is True:
                raise ValueError("MARKET_NOT_TRADABLE")
            minimum=_finite_decimal(market_data.get("minimum_order_size"),"MINIMUM_ORDER_EVIDENCE_UNAVAILABLE")
            if minimum<0:
                raise ValueError("INVALID_MINIMUM_ORDER_EVIDENCE")
            minimum_source=market_data.get("minimum_order_source")
            if not isinstance(minimum_source,str) or not minimum_source.strip():
                raise ValueError("MINIMUM_ORDER_SOURCE_UNAVAILABLE")
            if market_received < market_request:
                raise ValueError("INVALID_MARKET_REQUEST_TIMESTAMPS")
            # Gamma updatedAt describes the upstream record, not when EDGE
            # queried it. Keep it as provenance only; the local request/receive
            # pair proves a live market-state read while CLOB books retain the
            # strict three-second local-observation freshness checks in V4.
            market_source_timestamp,source_timestamp_error=_optional_datetime(market_data.get("market_source_timestamp"))
            state=MarketState(identity=identity,closed=bool(market_data.get("closed")),resolved=bool(market_data.get("resolved")),
                token_probability=_finite_decimal(market_data["current_price"],"INVALID_MARKET_PRICE") if market_data.get("current_price") is not None else None,
                state_source="Polymarket Gamma /markets",observed_at=market_received,
                accepting_orders=True,minimum_order_size=minimum,minimum_order_source=minimum_source,
                source_timestamp=market_source_timestamp,request_timestamp=market_request,received_timestamp=market_received)
            evidence["market_state"]={**market_data,"request_timestamp":market_request.isoformat(),
                "received_timestamp":market_received.isoformat(),
                "source_timestamp_normalized":market_source_timestamp.isoformat() if market_source_timestamp else None,
                "source_timestamp_parse_error":source_timestamp_error}
            fee_request=self._now()
            fee=await asyncio.wait_for(self.client.research_fee(identity.condition_id,market_data),timeout=12)
            fee_received=self._now()
            if not isinstance(fee,dict) or not fee.get("source"):
                raise ValueError("FEE_EVIDENCE_UNAVAILABLE")
            fee_rate=_finite_decimal(fee.get("rate"),"INVALID_FEE_EVIDENCE")
            if not 0<=fee_rate<=1 or fee.get("exponent")!=1:
                raise ValueError("INVALID_FEE_EVIDENCE")
            state=MarketState(**{**state.__dict__,"fee_rate":fee_rate,"fee_source":str(fee["source"]),
                "fee_request_timestamp":fee_request,"fee_received_timestamp":fee_received})
            evidence["fee"]={"rate":str(fee_rate),"source":fee["source"],"exponent":fee["exponent"],
                "request_timestamp":fee_request.isoformat(),"received_timestamp":fee_received.isoformat()}
            quote=await self._book_snapshot(identity,phase="QUOTE",evidence=evidence)
            config=StrategyConfig.from_evidence(json.loads(self.engine.version()["config_json"]))
            eligible_at=quote.received_timestamp+timedelta(milliseconds=config.execution_latency_ms)
            remaining=(eligible_at-self._now()).total_seconds()
            if remaining>0:
                await self.sleep(remaining)
            execution=await self._book_snapshot(identity,phase="EXECUTION",evidence=evidence,previous=quote)
            observed=self._now()
            evidence["quote_snapshot_id"]=quote.snapshot_id
            evidence["execution_snapshot_id"]=execution.snapshot_id
            evidence["edge_detected_timestamp"]=detected.isoformat()
            evidence["books"]=[quote.to_evidence(observed_at=observed),execution.to_evidence(observed_at=observed,previous=quote)]
            # Persist available evidence before any financial execution. If this
            # write fails, no order/fill may be submitted; recovery remains no-fill.
            with self.engine._connect() as con:
                con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                    ("EXECUTION_ATTEMPT",observed.isoformat(),json.dumps({"episode_id":episode_id,
                     "signal_id":signal_id,"quote_snapshot_id":quote.snapshot_id,
                     "execution_snapshot_id":execution.snapshot_id,"adapter_evidence":evidence},sort_keys=True,separators=(",",":"),default=str)))
            result=self.engine.execute_first(episode_id,market=state,quote=quote,execution=execution,
                fee_rate=fee_rate,fee_source=str(fee["source"]),observed_at=observed,local_timestamp_model=True)
            return {"episode_id":episode_id,**result}
        except Exception as exc:
            raw_reason=str(exc)
            known={"MARKET_IDENTITY_MISMATCH","MARKET_NOT_TRADABLE","MINIMUM_ORDER_EVIDENCE_UNAVAILABLE",
                "INVALID_MINIMUM_ORDER_EVIDENCE","MINIMUM_ORDER_SOURCE_UNAVAILABLE","STALE_MARKET_STATE",
                "INVALID_MARKET_REQUEST_TIMESTAMPS",
                "INVALID_MARKET_PRICE","FEE_EVIDENCE_UNAVAILABLE","INVALID_FEE_EVIDENCE",
                "MALFORMED_ORDER_BOOK","MISSING_TIMESTAMP","INVALID_BOOK_LEVEL","CROSSED_BOOK",
                "MALFORMED_BOOK","INVALID_PRICE","INVALID_QUANTITY",
                "INVALID_QUOTE_LOCAL_TIMESTAMPS","INVALID_EXECUTION_LOCAL_TIMESTAMPS",
                "INVALID_TIMESTAMP","NAIVE_TIMESTAMP","EXECUTION_BEFORE_FROZEN_LATENCY"}
            books=evidence.get("books") or []
            if books and books[-1].get("validation_reason")=="ORDER_BOOK_RESPONSE_UNAVAILABLE":
                raw_reason="ORDER_BOOK_RESPONSE_UNAVAILABLE"
                known.add(raw_reason)
            if books and "validation_reason" in books[-1]:
                evidence["book_failure"]=books[-1]
            reason=raw_reason if raw_reason in known else "MARKET_DATA_UNAVAILABLE"
            evidence.update({"reason":reason,"error_type":type(exc).__name__,"error_detail":raw_reason[:120]})
            log.warning("V2 first-entry rejected for %s (%s)",signal_id,reason)
            self.engine.record_runtime_failure(signal_id=signal_id,wallet=wallet,condition_id=identity.condition_id,
                reason=reason,occurred_at=self._now(),episode_id=episode_id,evidence=evidence)
            episode=self.engine.episode(episode_id)
            if episode["paper_status"]=="OBSERVED":
                return {"episode_id":episode_id,"status":"RECOVERY_REQUIRED",
                        "reason":"EXECUTION_COMMIT_SYNC_REQUIRED","duplicate":False}
            return {"episode_id":episode_id,"status":episode["paper_status"],
                    "reason":episode["rejection_reason"],"duplicate":False}

    def _ensure_exit_v1(self) -> bool:
        if not ensure_exit_v1_active(self.engine.path,activated_at=self._now()):
            return False
        now=self._now().isoformat()
        with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
            con.row_factory=sqlite3.Row;con.execute("PRAGMA foreign_keys=ON");con.execute("BEGIN IMMEDIATE")
            try:
                rows=con.execute("SELECT * FROM wallet_v2_episodes WHERE strategy_version=? AND paper_status IN ('FILLED','PARTIAL') AND resolution_status NOT IN ('FORMALLY_RESOLVED','VOID') AND execution_price IS NOT NULL",
                    (self.engine.strategy_version,)).fetchall()
                enrolled=0
                for row in rows:
                    try: levels=exit_levels(row["execution_price"])
                    except ValueError: continue
                    account_id=f"{self.engine.strategy_version}:{row['wallet'].lower()}"
                    position=con.execute("SELECT quantity,reserved_quantity FROM strict_positions WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                        (account_id,row["condition_id"],row["first_token_id"],row["first_outcome"])).fetchone()
                    if not position or Decimal(position["quantity"] or "0")<=0:
                        continue
                    exists=con.execute("SELECT 1 FROM wallet_v2_exit_positions WHERE episode_id=?",(row["episode_id"],)).fetchone()
                    if exists: continue
                    con.execute("INSERT INTO wallet_v2_exit_positions(episode_id,rule_version,wallet,condition_id,token_id,outcome,entry_price,initial_stop,protection_trigger,active_exit_floor,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,'ACTIVE',?,?)",
                        (row["episode_id"],EXIT_RULE_VERSION,row["wallet"],row["condition_id"],row["first_token_id"],row["first_outcome"],
                         str(levels["entry_price"]),str(levels["initial_stop"]),str(levels["profit_protection_trigger"]),str(levels["active_exit_floor"]),now,now))
                    append_exit_event(con,row["episode_id"],"POSITION_ENROLLED",now,
                        {"entry_price_source":"wallet_v2_episodes.execution_price","entry_price":str(levels["entry_price"]),
                         "initial_stop":str(levels["initial_stop"]),"profit_protection_trigger":str(levels["profit_protection_trigger"]),
                         "position_quantity":position["quantity"],"reserved_quantity":position["reserved_quantity"],
                         "activation_basis":"CURRENT_OPEN_POSITION_FIRST_FORWARD_OBSERVATION"},event_key="enrolled")
                    enrolled+=1
                con.commit();return True
            except Exception:
                con.rollback();raise

    def _exit_lease(self, episode_id: str) -> str | None:
        lease=uuid.uuid4().hex;now=time.time()
        with sqlite3.connect(self.engine.path,timeout=30) as con:
            cur=con.execute("UPDATE wallet_v2_exit_positions SET lease_id=?,lease_until=?,updated_at=? WHERE episode_id=? AND state='ACTIVE' AND (lease_until IS NULL OR lease_until<?)",
                (lease,now+120,self._now().isoformat(),episode_id,now))
            return lease if cur.rowcount else None

    def _recover_exit_attempt(self, row: dict[str,Any], lease: str) -> bool:
        """Reconcile an interrupted exit locally before any new market request."""
        order_id=row.get("last_order_id");idem=row.get("last_idempotency_key")
        if not order_id and not idem:return False
        ledger=self.engine.ledger(row["wallet"]);account_id=ledger.account_id
        with sqlite3.connect(self.engine.path) as con:
            con.row_factory=sqlite3.Row
            order=con.execute("SELECT * FROM strict_orders WHERE order_id=? AND account_id=?",(order_id,account_id)).fetchone() if order_id else None
            decision=con.execute("SELECT * FROM strict_decisions WHERE idempotency_key=? AND account_id=?",(idem,account_id)).fetchone() if idem else None
            fills=con.execute("SELECT * FROM strict_fills WHERE order_id=? AND account_id=? ORDER BY created_at,fill_id",(order_id,account_id)).fetchall() if order else []
        at=self._now().isoformat();event_key=idem or order_id or row["episode_id"]
        if fills:
            if any(x["side"]!="SELL" or x["condition_id"]!=row["condition_id"] or x["token_id"]!=row["token_id"] or x["outcome"]!=row["outcome"] for x in fills):
                outcome="BLOCKED";event_type="EXIT_RECOVERY_IDENTITY_MISMATCH"
            else:
                snap=ledger.account_snapshot()
                pos=next((x for x in snap["positions"] if (x["condition_id"],x["token_id"],x["outcome"])==(row["condition_id"],row["token_id"],row["outcome"])),None)
                remaining=Decimal(pos["quantity"] if pos else "0")
                latest=fills[-1];evidence=json.loads(latest["evidence_json"] or "{}")
                order_evidence=json.loads(order["evidence_json"] or "{}") if order else {}
                exit_meta=order_evidence.get("exit_v1") if isinstance(order_evidence.get("exit_v1"),dict) else {}
                vwap=latest["vwap"]
                reference=_finite_decimal(exit_meta.get("quote_reference"),"INVALID_EXIT_REFERENCE") if exit_meta.get("quote_reference") is not None else None
                slippage=reference-Decimal(vwap) if reference is not None else None
                exit_reason=exit_meta.get("reason") or row.get("exit_reason")
                outcome="EXITED" if remaining<=0 else "ACTIVE"
                event_type="EXIT_FILL_RECOVERED"
                details={"order_id":order_id,"fill_ids":[x["fill_id"] for x in fills],"remaining_quantity":str(remaining),
                    "actual_execution_price":vwap,"fee":latest["fee"],"position_realized_pnl":pos["realized_pnl"] if pos else None,
                    "exit_reason":exit_reason,"adverse_slippage_quote_minus_execution":str(slippage) if slippage is not None else None,
                    "book_evidence":evidence,"network_requests_performed":False}
                with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
                    con.row_factory=sqlite3.Row;con.execute("BEGIN IMMEDIATE")
                    con.execute("UPDATE wallet_v2_exit_positions SET state=?,exit_reason=COALESCE(?,exit_reason),last_exit_price=?,last_exit_slippage=?,last_exit_fee=?,realized_exit_pnl=?,last_order_id=NULL,last_idempotency_key=NULL,last_execution_snapshot_id=NULL,lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                        (outcome,exit_reason,vwap,str(slippage) if slippage is not None else None,latest["fee"],pos["realized_pnl"] if pos else None,at,row["episode_id"],lease))
                    append_exit_event(con,row["episode_id"],event_type,at,details,event_key=event_key)
                    con.commit()
                return True
            with ledger._tx() as con:
                if order and order["status"]=="OPEN":ledger.cancel_order_in_transaction(con,order_id,created_at=at,reason="EXIT_RECOVERY_IDENTITY_MISMATCH")
                con.execute("UPDATE wallet_v2_exit_positions SET state='BLOCKED',exit_reason='EXECUTION_COMMIT_INCOMPLETE',last_order_id=NULL,last_idempotency_key=NULL,last_execution_snapshot_id=NULL,lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                    (at,row["episode_id"],lease))
                append_exit_event(con,row["episode_id"],event_type,at,{"order_id":order_id,"network_requests_performed":False},event_key=event_key)
            return True
        if decision and decision["status"] in {"FILLED","PARTIAL"}:
            # A decision without its immutable fill commit cannot be repaired by
            # fetching another book or synthesizing financial state.
            with ledger._tx() as con:
                if order and order["status"]=="OPEN":ledger.cancel_order_in_transaction(con,order_id,created_at=at,reason="EXIT_EXECUTION_COMMIT_INCOMPLETE")
                con.execute("UPDATE wallet_v2_exit_positions SET state='BLOCKED',exit_reason='EXECUTION_COMMIT_INCOMPLETE',last_order_id=NULL,last_idempotency_key=NULL,last_execution_snapshot_id=NULL,lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                    (at,row["episode_id"],lease))
                append_exit_event(con,row["episode_id"],"EXECUTION_COMMIT_INCOMPLETE",at,
                    {"order_id":order_id,"decision_id":decision["decision_id"],"network_requests_performed":False},event_key=event_key)
            return True
        if order and order["status"]=="OPEN":
            ledger.cancel_order(order_id,created_at=at)
            event_type="EXIT_ABANDONED_ORDER_CANCELLED"
        elif decision and decision["status"]=="REJECTED":
            event_type="EXIT_REJECTION_RECOVERED"
        elif order:
            event_type="EXIT_TERMINAL_NO_FILL_RECOVERED"
        else:
            # Crash occurred before the decision/order transaction. Clear the
            # prepared intent; the next work uses fresh evidence.
            event_type="EXIT_PREPARED_INTENT_CLEARED"
        with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
            con.row_factory=sqlite3.Row;con.execute("BEGIN IMMEDIATE")
            con.execute("UPDATE wallet_v2_exit_positions SET last_order_id=NULL,last_idempotency_key=NULL,last_execution_snapshot_id=NULL,lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                (at,row["episode_id"],lease))
            append_exit_event(con,row["episode_id"],event_type,at,{"order_id":order_id,"decision_id":decision["decision_id"] if decision else None,
                "network_requests_performed":False},event_key=event_key)
            con.commit()
        return True

    async def refresh_exit_v1(self, *, limit: int = 20) -> dict[str,int]:
        """Forward-only V1 exits; each attempt uses distinct fresh quote/fill books."""
        activation=v2_activation_state(self.engine.path)
        if activation is V2ActivationState.READ_ERROR:return {"checked":0,"exited":0,"protected":0,"errors":1}
        if activation is not V2ActivationState.ACTIVE:return {"checked":0,"exited":0,"protected":0,"errors":0}
        if not self._ensure_exit_v1():return {"checked":0,"exited":0,"protected":0,"errors":0}
        with sqlite3.connect(self.engine.path) as con:
            con.row_factory=sqlite3.Row
            rows=[dict(x) for x in con.execute("SELECT * FROM wallet_v2_exit_positions WHERE rule_version=? AND state='ACTIVE' ORDER BY updated_at LIMIT ?",
                (EXIT_RULE_VERSION,max(1,min(int(limit),100))))]
        totals={"checked":0,"exited":0,"protected":0,"errors":0}
        semaphore=asyncio.Semaphore(5)
        async def process(row:dict[str,Any])->None:
            lease=self._exit_lease(row["episode_id"])
            if not lease:return
            try:
                if self._recover_exit_attempt(row,lease):return
                row=self._read_exit_position(row["episode_id"])
                if not row or row["state"]!="ACTIVE":return
                async with semaphore:
                    totals["checked"]+=1
                    result=await self._evaluate_exit_position(row,lease)
                    if result=="EXITED":totals["exited"]+=1
                    elif result=="PROTECTED":totals["protected"]+=1
                    elif result=="ERROR":totals["errors"]+=1
            except Exception as exc:
                totals["errors"]+=1
                log.warning("Exit V1 isolated failure for %s (%s)",row.get("episode_id"),type(exc).__name__)
                self._exit_release_lease(row["episode_id"],lease)
            finally:
                self._exit_release_lease(row["episode_id"],lease)
        await asyncio.gather(*(process(row) for row in rows))
        return totals

    def _read_exit_position(self, episode_id: str) -> dict[str,Any] | None:
        with sqlite3.connect(self.engine.path) as con:
            con.row_factory=sqlite3.Row
            row=con.execute("SELECT * FROM wallet_v2_exit_positions WHERE episode_id=?",(episode_id,)).fetchone()
        return dict(row) if row else None

    def _exit_release_lease(self, episode_id: str, lease: str) -> None:
        with sqlite3.connect(self.engine.path) as con:
            con.execute("UPDATE wallet_v2_exit_positions SET lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                (self._now().isoformat(),episode_id,lease))

    async def _evaluate_exit_position(self, row:dict[str,Any], lease:str) -> str:
        episode_id=row["episode_id"];identity=MarketIdentity(row["condition_id"],row["token_id"],row["outcome"])
        evidence={"exit_rule_version":EXIT_RULE_VERSION,"episode_id":episode_id,
            "entry_price":row["entry_price"],"initial_stop":row["initial_stop"],
            "protection_trigger":row["protection_trigger"],"protection_active":bool(row["protection_active"]),
            "hard_stop_active":bool(row.get("hard_stop_active")),
            "active_exit_floor":row["active_exit_floor"],"live_orders":False}
        market_request=self._now()
        try:
            market_data=await asyncio.wait_for(self.client.market_state(identity.token_id),timeout=15)
            market_received=self._now()
            if not isinstance(market_data,dict) or (market_data.get("condition_id"),market_data.get("token_id"),market_data.get("outcome"))!=(identity.condition_id,identity.token_id,identity.outcome):
                raise ValueError("MARKET_IDENTITY_MISMATCH")
            if market_received<market_request:raise ValueError("INVALID_MARKET_REQUEST_TIMESTAMPS")
            if market_data.get("accepting_orders") is not True or market_data.get("closed") is True or market_data.get("resolved") is True:
                return "HOLD"
            minimum=_finite_decimal(market_data.get("minimum_order_size"),"MINIMUM_ORDER_EVIDENCE_UNAVAILABLE")
            minimum_source=market_data.get("minimum_order_source")
            if minimum<0 or not isinstance(minimum_source,str) or not minimum_source.strip():
                raise ValueError("INVALID_MINIMUM_ORDER_EVIDENCE")
            market_source,source_error=_optional_datetime(market_data.get("market_source_timestamp"))
            market=MarketState(identity=identity,closed=False,resolved=False,
                token_probability=_finite_decimal(market_data["current_price"],"INVALID_MARKET_PRICE") if market_data.get("current_price") is not None else None,
                state_source="Polymarket Gamma /markets",observed_at=market_received,accepting_orders=True,
                minimum_order_size=minimum,minimum_order_source=minimum_source,source_timestamp=market_source,
                request_timestamp=market_request,received_timestamp=market_received)
            fee_request=self._now();fee=await asyncio.wait_for(self.client.research_fee(identity.condition_id,market_data),timeout=12);fee_received=self._now()
            if not isinstance(fee,dict) or not fee.get("source"):raise ValueError("FEE_EVIDENCE_UNAVAILABLE")
            fee_rate=_finite_decimal(fee.get("rate"),"INVALID_FEE_EVIDENCE")
            if not 0<=fee_rate<=1 or fee.get("exponent")!=1:raise ValueError("INVALID_FEE_EVIDENCE")
            market=MarketState(**{**market.__dict__,"fee_rate":fee_rate,"fee_source":str(fee["source"]),
                "fee_request_timestamp":fee_request,"fee_received_timestamp":fee_received})
            evidence["market"]={**market_data,"request_timestamp":market_request.isoformat(),"received_timestamp":market_received.isoformat(),
                "source_timestamp_normalized":market_source.isoformat() if market_source else None,"source_timestamp_parse_error":source_error}
            evidence["fee"]={"rate":str(fee_rate),"source":fee["source"],"exponent":fee["exponent"],
                "request_timestamp":fee_request.isoformat(),"received_timestamp":fee_received.isoformat()}
            quote=await self._book_snapshot(identity,phase="EXIT_QUOTE",evidence=evidence)
            now=self._now()
            if quote.request_timestamp>quote.received_timestamp or quote.received_timestamp>now or (now-quote.received_timestamp).total_seconds()*1000>3000:
                raise ValueError("STALE_EXIT_QUOTE")
            if not quote.bids:return "HOLD"
            best_bid=quote.bids[0].price
            rule_config=json.loads(sqlite3.connect(self.engine.path).execute("SELECT config_json FROM wallet_v2_exit_rules WHERE rule_version=?",(EXIT_RULE_VERSION,)).fetchone()[0])
            depth=Decimal(rule_config["max_visible_depth_fraction"])
            qty_quantum=Decimal("0.000001")
            action=quote_transition(entry_price=row["entry_price"],initial_stop=row["initial_stop"],
                protection_trigger=row["protection_trigger"],protection_active=bool(row["protection_active"]),
                hard_stop_active=bool(row.get("hard_stop_active")),best_bid=best_bid)
            if action=="ACTIVATE_PROFIT_PROTECTION":
                capacity=sum(((level.quantity*depth).quantize(qty_quantum,rounding=ROUND_DOWN)
                    for level in quote.bids if level.price>=Decimal(row["protection_trigger"])),Decimal("0"))
                if capacity>=minimum: 
                    at=now.isoformat()
                    with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
                        con.row_factory=sqlite3.Row;con.execute("BEGIN IMMEDIATE")
                        con.execute("UPDATE wallet_v2_exit_positions SET protection_active=1,protection_activated_at=?,active_exit_floor=entry_price,updated_at=?,lease_id=NULL,lease_until=NULL WHERE episode_id=? AND state='ACTIVE' AND lease_id=? AND protection_active=0",
                            (at,at,episode_id,lease))
                        append_exit_event(con,episode_id,"PROFIT_PROTECTION_ACTIVATED",at,
                            {"trigger":row["protection_trigger"],"active_exit_floor":row["entry_price"],"best_bid":str(best_bid),
                             "quote_book":quote.to_evidence(observed_at=now),"minimum_executable_depth":str(capacity),"venue_minimum":str(minimum),
                             "latched":True,"no_take_profit":True},event_key=quote.snapshot_id)
                        con.commit()
                    return "PROTECTED"
                return "HOLD"
            if action=="HOLD_TO_FORMAL_RESOLUTION":return "HOLD"
            threshold=Decimal(row["initial_stop"] if action=="DYNAMIC_HARD_STOP" else row["active_exit_floor"])
            eligible_depth=sum(((level.quantity*depth).quantize(qty_quantum,rounding=ROUND_DOWN)
                for level in quote.bids if level.price<=threshold),Decimal("0"))
            if eligible_depth<minimum:return "HOLD"
            at=now.isoformat()
            trigger_evidence={"reason":action,"threshold":str(threshold),"best_bid":str(best_bid),
                "quote_book":quote.to_evidence(observed_at=now),"market":evidence["market"],"fee":evidence["fee"],
                "eligible_depth":str(eligible_depth),"venue_minimum":str(minimum),"execution_latency_ms":500}
            with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
                con.row_factory=sqlite3.Row;con.execute("BEGIN IMMEDIATE")
                if action=="DYNAMIC_HARD_STOP":
                    con.execute("UPDATE wallet_v2_exit_positions SET hard_stop_active=1,hard_stop_triggered_at=COALESCE(hard_stop_triggered_at,?),active_exit_floor=initial_stop,exit_reason=?,updated_at=? WHERE episode_id=? AND state='ACTIVE' AND lease_id=?",
                        (at,action,at,episode_id,lease))
                else:
                    con.execute("UPDATE wallet_v2_exit_positions SET exit_reason=?,updated_at=? WHERE episode_id=? AND state='ACTIVE' AND lease_id=?",
                        (action,at,episode_id,lease))
                append_exit_event(con,episode_id,"EXIT_TRIGGERED",at,trigger_evidence,event_key=quote.snapshot_id)
                con.commit()
            await self.sleep(max(0,(quote.received_timestamp+timedelta(milliseconds=500)-self._now()).total_seconds()))
            execution=await self._book_snapshot(identity,phase="EXIT_EXECUTION",evidence=evidence,previous=quote)
            observed=self._now();evidence["execution_timestamp"]=observed.isoformat()
            ledger=self.engine.ledger(row["wallet"])
            with sqlite3.connect(self.engine.path) as con:
                pos=con.execute("SELECT quantity,reserved_quantity,realized_pnl FROM strict_positions WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=?",
                    (ledger.account_id,identity.condition_id,identity.token_id,identity.outcome)).fetchone()
            if not pos:return "HOLD"
            quantity=(Decimal(pos[0])-Decimal(pos[1])).quantize(qty_quantum,rounding=ROUND_DOWN)
            if quantity<=0:return "HOLD"
            idem=f"{EXIT_RULE_VERSION}:{episode_id}:{execution.snapshot_id}"
            intent=OrderIntent(signal_id=f"exit:{episode_id}:{action}",idempotency_key=idem,identity=identity,
                side="SELL",amount=quantity,allow_partial=True,edge_detected_timestamp=quote.received_timestamp)
            rules=LocalObservationEngineRules(rule_version=f"strict-paper-rules-v4-{EXIT_RULE_VERSION}",
                execution_latency_ms=500,max_book_age_ms=3000,max_visible_depth_fraction=depth,
                allow_partial_fills=True,min_quantity=qty_quantum)
            decision=execute_order(intent,market,quote,execution,rules,fee_rate=fee_rate,fee_source=str(fee["source"]),observed_at=observed)
            decision_evidence=decision.to_evidence(intent)
            order_id=hashlib.sha256(f"order|{idem}".encode()).hexdigest();fill_id=hashlib.sha256(f"fill|{idem}".encode()).hexdigest()
            with sqlite3.connect(self.engine.path,timeout=30) as con:
                con.execute("UPDATE wallet_v2_exit_positions SET last_order_id=?,last_idempotency_key=?,last_execution_snapshot_id=?,updated_at=? WHERE episode_id=? AND lease_id=?",
                    (order_id,idem,execution.snapshot_id,observed.isoformat(),episode_id,lease))
            if decision.status=="REJECTED":
                ledger.record_decision(decision,intent,created_at=observed.isoformat())
                with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
                    con.row_factory=sqlite3.Row;con.execute("BEGIN IMMEDIATE")
                    con.execute("UPDATE wallet_v2_exit_positions SET last_order_id=NULL,last_idempotency_key=NULL,last_execution_snapshot_id=NULL,lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                        (observed.isoformat(),episode_id,lease))
                    append_exit_event(con,episode_id,"EXIT_REJECTED",observed.isoformat(),
                        {"reason":decision.reason,"decision":decision_evidence,"quote":quote.to_evidence(observed_at=observed),
                         "execution":execution.to_evidence(observed_at=observed,previous=quote)},event_key=execution.snapshot_id)
                    con.commit()
                return "REJECTED"
            ledger.submit_order(order_id=order_id,idempotency_key=idem,signal_id=intent.signal_id,identity=identity,side="SELL",
                target_quantity=quantity,reserve_cash="0",engine_version=decision.engine_version,rule_version=decision.rule_version,
                evidence={**decision_evidence,"exit_v1":{"rule_version":EXIT_RULE_VERSION,"reason":action,
                    "entry_price":row["entry_price"],"trigger_floor":str(threshold),"quote_reference":str(best_bid),
                    "quote_snapshot_id":quote.snapshot_id,"execution_snapshot_id":execution.snapshot_id}},created_at=observed.isoformat())
            ledger.apply_execution(fill_id=fill_id,order_id=order_id,decision=decision,intent=intent,created_at=observed.isoformat())
            snap=ledger.account_snapshot();position=next((x for x in snap["positions"] if (x["condition_id"],x["token_id"],x["outcome"])==(identity.condition_id,identity.token_id,identity.outcome)),None)
            remaining=Decimal(position["quantity"] if position else "0")
            actual=decision.vwap
            adverse_slippage=(best_bid-actual) if actual is not None else None
            status="EXITED" if remaining<=0 else "ACTIVE"
            with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
                con.row_factory=sqlite3.Row;con.execute("BEGIN IMMEDIATE")
                con.execute("UPDATE wallet_v2_exit_positions SET state=?,exit_reason=?,last_exit_price=?,last_exit_slippage=?,last_exit_fee=?,realized_exit_pnl=?,last_order_id=NULL,last_idempotency_key=NULL,last_execution_snapshot_id=NULL,lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                    (status,action,str(actual) if actual is not None else None,str(adverse_slippage) if adverse_slippage is not None else None,
                     str(decision.total_fee),position["realized_pnl"] if position else None,observed.isoformat(),episode_id,lease))
                append_exit_event(con,episode_id,"EXIT_PARTIAL" if decision.status=="PARTIAL" else "EXIT_FILLED",observed.isoformat(),
                    {"reason":action,"threshold":str(threshold),"entry_price":row["entry_price"],"quote_reference_best_bid":str(best_bid),
                     "actual_execution_price":str(actual),"adverse_slippage_quote_minus_execution":str(adverse_slippage),
                     "quantity":str(decision.filled_quantity),"remaining_quantity":str(remaining),"fee":str(decision.total_fee),
                     "position_realized_pnl_after_exit":position["realized_pnl"] if position else None,
                     "decision":decision_evidence,"execution_order_id":order_id,"fill_id":fill_id,
                     "strict_ledger_reconciles":ledger.reconcile().get("ok")},event_key=execution.snapshot_id)
                con.commit()
            return "EXITED" if status=="EXITED" else "PARTIAL"
        except Exception as exc:
            failure={"error_type":type(exc).__name__,"reason":str(exc)[:240],"network_requests_performed":True,
                "evidence":evidence}
            try:
                with sqlite3.connect(self.engine.path,timeout=30,isolation_level=None) as con:
                    con.row_factory=sqlite3.Row;con.execute("BEGIN IMMEDIATE")
                    append_exit_event(con,episode_id,"EXIT_DATA_FAILURE",self._now().isoformat(),failure,
                        event_key=hashlib.sha256(json.dumps(failure,sort_keys=True,default=str).encode()).hexdigest())
                    con.execute("UPDATE wallet_v2_exit_positions SET lease_id=NULL,lease_until=NULL,updated_at=? WHERE episode_id=? AND lease_id=?",
                        (self._now().isoformat(),episode_id,lease));con.commit()
            except Exception:pass
            log.warning("Exit V1 data/execution failed for %s: %s",episode_id,type(exc).__name__)
            return "ERROR"
        finally:
            self._exit_release_lease(episode_id,lease)

    async def refresh_settlements(self, *, limit: int = 100) -> dict[str, int]:
        activation=v2_activation_state(self.engine.path)
        if activation is V2ActivationState.READ_ERROR:
            return {"checked":0,"settled":0,"errors":1}
        if activation not in {V2ActivationState.ACTIVE, V2ActivationState.LOCKED}:
            return {"checked":0,"settled":0,"errors":0}
        _, recovered_episode_ids=self.engine.recover_stale_observed(
            now=self._now(),include_episode_ids=True)
        with self.engine._connect() as con:
            rows=[dict(x) for x in con.execute("""WITH checks AS (
                SELECT json_extract(evidence_json,'$.episode_id') AS episode_id,
                    MAX(occurred_at) AS checked_at FROM wallet_v2_audit
                WHERE action='SETTLEMENT_CHECK' AND json_valid(evidence_json)
                GROUP BY json_extract(evidence_json,'$.episode_id'))
                SELECT p.* FROM wallet_v2_episodes p LEFT JOIN checks c ON c.episode_id=p.episode_id
                WHERE p.strategy_version=? AND p.resolution_status NOT IN ('FORMALLY_RESOLVED','VOID')
                ORDER BY COALESCE(c.checked_at,p.first_detected_at),(c.checked_at IS NOT NULL),p.episode_id LIMIT ?""",
                (self.engine.strategy_version,max(1,min(int(limit),500))))]
        totals={"checked":0,"settled":0,"errors":0}
        semaphore=asyncio.Semaphore(2)
        async def refresh(row: dict[str,Any]) -> None:
            # A just-recovered episode waits for the next settlement cycle.
            # This keeps crash recovery itself strictly local and network-free.
            if row["episode_id"] in recovered_episode_ids:
                return
            async with semaphore:
                totals["checked"]+=1
                ident=MarketIdentity(row["condition_id"],row["first_token_id"],row["first_outcome"])
                requested=self._now()
                diagnostic={"episode_id":row["episode_id"],"condition_id":ident.condition_id,
                    "token_id":ident.token_id,"request_timestamp":requested.isoformat(),
                    "source":"Polymarket Gamma /markets","result":"FAILED"}
                try:
                    market=await asyncio.wait_for(self.client.market_state(ident.token_id),timeout=15)
                    received=self._now()
                    if (market.get("condition_id")!=ident.condition_id or market.get("token_id")!=ident.token_id
                            or market.get("outcome")!=ident.outcome):
                        raise ValueError("MARKET_IDENTITY_MISMATCH")
                    if received < requested:
                        raise ValueError("INVALID_MARKET_REQUEST_TIMESTAMPS")
                    diagnostic.update(received_timestamp=received.isoformat(),result="SUCCESS")
                    source_time,source_timestamp_error=_optional_datetime(market.get("market_source_timestamp"))
                    base={"source":"Polymarket Gamma /markets","request_timestamp":requested.isoformat(),
                          "received_timestamp":received.isoformat(),
                          "source_timestamp":source_time.isoformat() if source_time else None,
                          "source_timestamp_raw":market.get("market_source_timestamp_raw",market.get("market_source_timestamp")),
                          "source_timestamp_parse_error":source_timestamp_error,
                          "resolution_status":market.get("resolution_status"),"closed":market.get("closed"),
                          "resolved":market.get("resolved"),"resolution_source":market.get("resolution_source"),
                          "resolution_is_void":market.get("resolution_is_void"),
                          "condition_id":market.get("condition_id"),"token_id":market.get("token_id"),
                          "outcome":market.get("outcome"),"settlement_price":market.get("settlement_price"),
                          "authoritative_source":market.get("authoritative_source") or market.get("resolution_source")}
                    current=row["resolution_status"]
                    if market.get("resolved") is True:
                        source=market.get("authoritative_source") or market.get("resolution_source")
                        if not isinstance(source,str) or not source.strip():
                            status="RESULT_PENDING"; source=None; winning=None; payout=None
                        elif market.get("resolution_is_void") is True:
                            status="VOID"; winning=None; payout=market.get("settlement_price")
                        else:
                            winning=market.get("winning_token_id")
                            payout=Decimal("1") if winning==ident.token_id else Decimal("0")
                            if not winning:
                                status="RESULT_PENDING"; source=None; winning=None; payout=None
                            else:
                                status="FORMALLY_RESOLVED"
                        if current!=status:
                            changed=self.engine.record_resolution(row["episode_id"],status=status,observed_at=received,
                                authoritative_source=source,winning_token_id=winning,payout_per_share=payout,
                                evidence={**base,"winning_token_id":winning,"payout_per_share":str(payout) if payout is not None else None})
                            totals["settled"]+=int(changed and status in {"FORMALLY_RESOLVED","VOID"})
                    else:
                        if market.get("closed"):
                            status="RESULT_PENDING" if market.get("resolution_status") else "MARKET_CLOSED"
                        elif current=="API_FAILURE":
                            status="RESULT_PENDING"
                        else:
                            status=current
                        if current!=status:
                            self.engine.record_resolution(row["episode_id"],status=status,observed_at=received,evidence=base)
                except Exception as exc:
                    totals["errors"]+=1
                    metadata=getattr(exc,"response_metadata",None)
                    metadata=metadata if isinstance(metadata,dict) else {}
                    diagnostic.update(result="FAILED",error_type=type(exc).__name__,
                        upstream_error_type=metadata.get("last_error_type"),http_status=metadata.get("http_status"))
                    current=row["resolution_status"]
                    if current!="API_FAILURE":
                        try:
                            self.engine.record_resolution(row["episode_id"],status="API_FAILURE",observed_at=self._now(),
                                evidence={"source":"Polymarket Gamma /markets","request_timestamp":requested.isoformat(),
                                          "error_type":type(exc).__name__,"reason":str(exc)[:100],
                                          "upstream_error_type":metadata.get("last_error_type"),
                                          "http_status":metadata.get("http_status")})
                        except Exception as persistence_error:
                            totals["persistence_errors"]=totals.get("persistence_errors",0)+1
                            log.error("Settlement failure state could not persist for %s: %s",
                                      row["episode_id"],type(persistence_error).__name__)
                finally:
                    # Repeated failures stay auditable without replacing the
                    # original failure evidence or writing another cash flow.
                    try:
                        with self.engine._connect() as audit:
                            audit.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                                ("SETTLEMENT_CHECK",self._now().isoformat(),json.dumps(diagnostic,sort_keys=True)))
                    except Exception as persistence_error:
                        totals["persistence_errors"]=totals.get("persistence_errors",0)+1
                        log.error("Settlement check audit could not persist for %s: %s",
                                  row["episode_id"],type(persistence_error).__name__)
        await asyncio.gather(*(refresh(row) for row in rows))
        return totals
