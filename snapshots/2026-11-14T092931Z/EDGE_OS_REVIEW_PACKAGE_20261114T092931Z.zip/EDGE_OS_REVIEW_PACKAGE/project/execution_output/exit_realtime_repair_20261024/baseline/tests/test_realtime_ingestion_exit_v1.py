import asyncio
import hashlib
import json
import sqlite3
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from types import SimpleNamespace

import pytest

from app.db import Database
from app import service, monitor as monitor_module
from app.exit_v1 import exit_levels, quote_transition, EXIT_RULE_VERSION
from app.monitor import WalletMonitor, _ingest_error
from app.polymarket import PolymarketError
from app.wallet_follow_runtime import V2_CONFIG, WalletFollowRuntime
from app.wallet_follow_v2 import WalletFollowV2

WALLET="0x"+"a"*40
T0=datetime(2026,10,1,tzinfo=timezone.utc)


@pytest.fixture
def database(tmp_path):
    db=Database(str(tmp_path/"temporary.db"));db.init();db.upsert_wallet(WALLET)
    with db.conn() as con:
        con.execute("UPDATE wallets SET last_trade_ts=100 WHERE address=?",(WALLET,))
    return db


def trade(key, timestamp=200):
    tx = '0x'+hashlib.sha256(key.encode()).hexdigest()
    return {"trade_key":key,"wallet":WALLET,"token_id":"token","condition_id":"condition",
        "event_id":"event","side":"BUY","price":0.7,"size":3,"usd_value":2.1,
        "timestamp":timestamp,"title":"fixture","outcome":"YES","category":"Politics",
        "tx_hash":tx,"raw":{"id":key,"_chain_fill":{"chain_id":137,
            "contract_address":"0xe111180000d2663c0091e4f400237545b87b996b",
            "transaction_hash":tx,"log_index":0}}}


def configure_ingest(monkeypatch, database, client, *, page_budget=3, process_limit=100):
    monkeypatch.setattr(monitor_module,"db",database)
    monkeypatch.setattr(monitor_module,"pm",client)
    monkeypatch.setattr(monitor_module,"settings",SimpleNamespace(
        realtime_page_size=25,realtime_pages_per_slice=page_budget,
        realtime_process_limit_per_slice=process_limit,realtime_request_timeout_seconds=1,
        monitor_max_concurrency=8,research_enabled=True))
    monkeypatch.setattr(service,"db",database)
    async def route(_wallet,_trade,_scan_started_at=None,_detected_at=None,**_kwargs):
        return {"decision":"OBSERVED"}
    monkeypatch.setattr(service,"_process_new_trade_claimed",route)
    return WalletMonitor()


class PageClient:
    def __init__(self,pages):self.pages=pages;self.calls=[]
    async def trades_page(self,wallet,*,start,cursor,limit):
        self.calls.append((wallet,start,cursor,limit))
        value=self.pages[cursor]
        if isinstance(value,Exception):raise value
        return value


def page(rows, cursor=None, more=False):
    return {"trades":rows,"next_cursor":cursor,"has_more":more,
        "requested_at":T0.isoformat(),"received_at":T0.isoformat(),"elapsed_ms":1,
        "http_metadata":{"request_attempts":1,"retry_count":0,"retry_backoff_seconds":0}}


def test_successful_backlog_page_clears_previous_monitor_error(database,monkeypatch):
    database.set_wallet_error(WALLET,'monitor: TRANSPORT_ERROR: fixture')
    client=PageClient({None:page([trade('fresh',timestamp=200)],'next-page',True)})
    monitor=configure_ingest(monkeypatch,database,client,page_budget=1)
    result=asyncio.run(monitor._scan_wallet({'address':WALLET,'last_trade_ts':100},asyncio.Semaphore(1)))
    assert result['pages_requested']==1 and result['ingest_state']=='FETCHING'
    assert database.get_wallet(WALLET)['last_error'] is None
    assert database.ingest_poll_state(WALLET)['checkpoint_timestamp']==100


def test_realtime_pagination_drains_more_than_25_same_timestamp_trades(database,monkeypatch):
    rows=[trade(f"trade-{i:03d}",timestamp=200) for i in range(40)]
    client=PageClient({None:page(rows[:25],"cursor-2",True),"cursor-2":page(rows[25:])})
    monitor=configure_ingest(monkeypatch,database,client,page_budget=2)
    result=asyncio.run(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},asyncio.Semaphore(1)))
    with database.conn() as con:
        raw=con.execute("SELECT COUNT(*) FROM trades WHERE wallet=? AND is_seed=0",(WALLET,)).fetchone()[0]
        state=dict(con.execute("SELECT * FROM wallet_ingest_state WHERE wallet=?",(WALLET,)).fetchone())
        events=con.execute("SELECT COUNT(*) FROM wallet_ingest_events WHERE state='COMPLETE'").fetchone()[0]
    assert raw==events==40
    assert result["pages_requested"]==2 and result["checkpoint_advanced"] is True
    assert state["checkpoint_timestamp"]==200 and state["checkpoint_trade_key"]=="trade-039"
    assert state["state"]=="IDLE" and result["backlog_remaining"]==0


def test_page_n_503_keeps_checkpoint_and_recovers_without_skipping(database,monkeypatch):
    first=[trade(f"before-{i:02d}",timestamp=201) for i in range(25)]
    last=[trade(f"after-{i:02d}",timestamp=202) for i in range(10)]
    failure=PolymarketError("HTTP 503: busy");failure.response_metadata={"http_status":503,"request_attempts":2,"retry_count":1,"retry_backoff_seconds":2}
    client=PageClient({None:page(first,"page-2",True),"page-2":failure})
    monitor=configure_ingest(monkeypatch,database,client,page_budget=3)
    failed=asyncio.run(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},asyncio.Semaphore(1)))
    state=database.ingest_poll_state(WALLET)
    assert state["checkpoint_timestamp"]==100
    assert state["state"]=="FETCHING" and state["next_cursor"]=="page-2"
    assert state["last_error_category"]=="HTTP_503"
    assert failed["backlog_remaining"]==0 and len(database.pending_ingest_trades(WALLET,100))==0
    with database.conn() as con:
        con.execute("UPDATE wallet_ingest_state SET next_retry_at=0 WHERE wallet=?",(WALLET,))
    # Simulate a new monitor process after the persisted retry delay has elapsed.
    monitor._next_scan_at.pop(WALLET,None)
    client.pages["page-2"]=page(last)
    recovered=asyncio.run(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},asyncio.Semaphore(1)))
    state=database.ingest_poll_state(WALLET)
    assert recovered["checkpoint_advanced"] is True
    assert state["checkpoint_timestamp"]==202 and state["state"]=="IDLE"
    with database.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM trades WHERE is_seed=0").fetchone()[0]==35
        attempt=con.execute("SELECT error_category,retry_count,backoff_seconds FROM wallet_ingest_attempts WHERE outcome='ERROR'").fetchone()
    # Persisted total combines the upstream retry delay and local per-wallet retry delay.
    assert tuple(attempt)==("HTTP_503",1,pytest.approx(4.0))


def test_cursor_backlog_progresses_in_fair_slices(database,monkeypatch):
    first=[trade(f"fair-{i:02d}",timestamp=210) for i in range(25)]
    second=[trade(f"fair-{i:02d}",timestamp=210) for i in range(25,50)]
    client=PageClient({None:page(first,"next",True),"next":page(second,"last",True),"last":page([])})
    monitor=configure_ingest(monkeypatch,database,client,page_budget=1,process_limit=25)
    r1=asyncio.run(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},asyncio.Semaphore(1)))
    assert r1["ingest_state"]=="FETCHING" and r1["cursor_present"]
    assert r1["new_trades"]==25
    r2=asyncio.run(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},asyncio.Semaphore(1)))
    assert r2["ingest_state"]=="FETCHING" and r2["new_trades"]==25
    r3=asyncio.run(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},asyncio.Semaphore(1)))
    assert r3["checkpoint_advanced"] is True
    with database.conn() as con:
        assert con.execute("SELECT COUNT(*) FROM trades WHERE is_seed=0").fetchone()[0]==50


def test_slow_wallet_does_not_block_an_independent_wallet(database,monkeypatch):
    fast_wallet="0x"+"b"*40;database.upsert_wallet(fast_wallet)
    with database.conn() as con:con.execute("UPDATE wallets SET last_trade_ts=100 WHERE address=?",(fast_wallet,))
    release=asyncio.Event()
    class Client:
        async def trades_page(self,wallet,*,start,cursor,limit):
            if wallet==WALLET:await release.wait()
            return page([])
    monitor=configure_ingest(monkeypatch,database,Client())
    async def run_pair():
        sem=asyncio.Semaphore(2)
        slow=asyncio.create_task(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},sem))
        await asyncio.sleep(0)
        fast=await asyncio.wait_for(monitor._scan_wallet({"address":fast_wallet,"last_trade_ts":100},sem),.5)
        release.set();await slow
        return fast
    result=asyncio.run(run_pair())
    assert result["checkpoint_advanced"] is True


def test_fast_path_is_independent_and_late_poll_duplicate_is_not_routed_twice(database,monkeypatch):
    release=asyncio.Event();route_calls=[];same=trade("same-signal",timestamp=220)
    class Client:
        async def trades_page(self,wallet,*,start,cursor,limit):
            await release.wait()
            return page([same])
    monitor=configure_ingest(monkeypatch,database,Client())
    async def route(_wallet,item,_scan_started_at=None,_detected_at=None,**_kwargs):
        route_calls.append(item["trade_key"]);return {"decision":"FILLED"}
    monkeypatch.setattr(service,"_process_new_trade_claimed",route)
    async def scenario():
        poll=asyncio.create_task(monitor._scan_wallet({"address":WALLET,"last_trade_ts":100},asyncio.Semaphore(1)))
        await asyncio.sleep(0)
        fast=await asyncio.wait_for(service.ingest_fast_path_trade({"address":WALLET},same),.5)
        release.set();await poll
        return fast
    fast=asyncio.run(scenario())
    assert fast["decision"]=="FILLED" and route_calls==["same-signal"]
    with database.conn() as con:
        sources=[tuple(x) for x in con.execute("SELECT source,first_source FROM wallet_ingest_sources WHERE trade_key='same-signal' ORDER BY source")]
        event=con.execute("SELECT first_source,state FROM wallet_ingest_events WHERE trade_key='same-signal'").fetchone()
    assert sources==[("DATA_API_POLL",0),("FAST_PATH",1)]
    assert tuple(event)==("FAST_PATH","COMPLETE")


@pytest.mark.parametrize("status,expected",[(429,"HTTP_429"),(503,"HTTP_503"),(502,"HTTP_FAILURE")])
def test_ingest_http_failures_have_explicit_categories(status,expected):
    error=PolymarketError(f"HTTP {status}");error.response_metadata={"http_status":status,"request_attempts":2,"retry_count":1}
    assert _ingest_error(error)[0]==expected


def test_ingest_timeout_transport_and_invalid_response_categories():
    connect=PolymarketError("offline");connect.response_metadata={"last_error_type":"ConnectTimeout"}
    read=PolymarketError("offline");read.response_metadata={"last_error_type":"ReadTimeout"}
    invalid=PolymarketError("INVALID_REALTIME_PAGINATION")
    assert _ingest_error(connect)[0]=="CONNECT_TIMEOUT"
    assert _ingest_error(read)[0]=="READ_TIMEOUT"
    assert _ingest_error(invalid)[0]=="INVALID_RESPONSE"


class FakeClock:
    def __init__(self):self.value=T0
    def now(self):return self.value
    async def sleep(self,seconds):self.value+=timedelta(seconds=seconds)


class ExitClient:
    def __init__(self,clock):
        self.clock=clock;self.bid_sequence=[];self.ask="0.70";self.depth=1000;self.formal=False;self.book_calls=0
    def set_bids(self,*values):self.bid_sequence=list(values)
    async def market_state(self,token):
        return {"condition_id":"condition","token_id":token,"outcome":"YES","closed":self.formal,
            "resolved":self.formal,"accepting_orders":not self.formal,"minimum_order_size":"1",
            "minimum_order_source":"Gamma.market.orderMinSize","market_source_timestamp":int((self.clock.now()-timedelta(hours=6)).timestamp()*1000),
            "current_price":"0.70","resolution_status":"resolved" if self.formal else None,
            "authoritative_source":"Gamma official resolution" if self.formal else None,
            "resolution_source":"Gamma official resolution" if self.formal else None,
            "resolution_is_void":False,"winning_token_id":"token" if self.formal else None}
    async def research_fee(self,condition,market):return {"rate":"0","source":"GAMMA_FEES_DISABLED","exponent":1}
    async def orderbook(self,token):
        self.book_calls+=1
        bid=self.bid_sequence.pop(0) if self.bid_sequence else "0.65"
        if Decimal(str(bid)) >= Decimal(str(self.ask)):
            bid=str(Decimal(str(self.ask))-Decimal("0.05"))
        stamp=int(self.clock.now().timestamp()*1000)
        raw={"timestamp":stamp,"asset_id":token,"market":"condition",
            "bids":[{"price":str(bid),"size":str(self.depth)}],"asks":[{"price":self.ask,"size":str(self.depth)}]}
        return {"timestamp":stamp,"bids":[{"price":float(bid),"size":self.depth}],
            "asks":[{"price":float(self.ask),"size":self.depth}],"raw":raw}


def make_runtime(tmp_path):
    path=tmp_path/"exit.db";WalletFollowV2.initialize(path);engine=WalletFollowV2(path)
    engine.create_version(V2_CONFIG,created_at=T0,evidence_cutoff=T0);engine.activate(at=T0)
    clock=FakeClock();client=ExitClient(clock);runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    entry={"trade_key":"entry-signal","condition_id":"condition","token_id":"token","outcome":"YES",
        "side":"BUY","timestamp":(T0-timedelta(seconds=60)).timestamp(),"price":.70,"size":10,
        "category":"Politics","raw":{"id":"entry-signal"}}
    result=asyncio.run(runtime.process_trade(WALLET,entry,detected_at=T0))
    assert result["status"]=="FILLED"
    return path,engine,clock,client,runtime,result


@pytest.mark.parametrize("entry,stop,trigger",[("0.60","0.400","0.680"),("0.70","0.550","0.760"),("0.80","0.700","0.840")])
def test_exit_v1_decimal_thresholds(entry,stop,trigger):
    values=exit_levels(entry)
    assert values["initial_stop"]==Decimal(stop)
    assert values["profit_protection_trigger"]==Decimal(trigger)
    assert values["active_exit_floor"]==Decimal(entry)


def test_exit_v1_rejects_entries_outside_authorized_band():
    for entry in ("0.599999","0.800001"):
        with pytest.raises(ValueError,match="ENTRY_OUTSIDE_EXIT_V1_RANGE"):exit_levels(entry)


def test_dynamic_hard_stop_uses_fresh_executable_books_and_real_fill(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    client.set_bids("0.54","0.53")
    outcome=asyncio.run(runtime.refresh_exit_v1())
    with sqlite3.connect(path) as con:
        state=dict(zip([x[1] for x in con.execute("PRAGMA table_info(wallet_v2_exit_positions)")],con.execute("SELECT * FROM wallet_v2_exit_positions WHERE episode_id=?",(result["episode_id"],)).fetchone()))
        events=[x[0] for x in con.execute("SELECT event_type FROM wallet_v2_exit_events WHERE episode_id=?",(result["episode_id"],))]
    snap=engine.ledger(WALLET).account_snapshot()
    assert outcome["exited"]==1 and state["state"]=="EXITED"
    assert state["exit_reason"]=="DYNAMIC_HARD_STOP" and state["hard_stop_active"]==1
    assert any("EXIT_FILLED"==x for x in events)
    assert len(snap["fills"])==2 and snap["fills"][-1]["side"]=="SELL"
    assert Decimal(snap["fills"][-1]["vwap"])==Decimal("0.529999")
    assert engine.ledger(WALLET).reconcile()["ok"]


def test_profit_protection_latches_across_restart_then_exits_at_break_even_floor(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    client.ask="0.80"
    client.set_bids("0.76")
    protected=asyncio.run(runtime.refresh_exit_v1())
    with sqlite3.connect(path) as con:
        row=con.execute("SELECT protection_active,active_exit_floor,protection_activated_at,state FROM wallet_v2_exit_positions WHERE episode_id=?",(result["episode_id"],)).fetchone()
        assert con.execute("SELECT COUNT(*) FROM strict_fills WHERE side='SELL'").fetchone()[0]==0
    assert protected["protected"]==1 and tuple(row)==(1,"0.699999",clock.now().isoformat(),"ACTIVE")
    restarted=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    client.set_bids("0.699999","0.69")
    outcome=asyncio.run(restarted.refresh_exit_v1())
    snap=engine.ledger(WALLET).account_snapshot()
    with sqlite3.connect(path) as con:
        final=con.execute("SELECT state,protection_active,exit_reason,last_exit_price,last_exit_fee FROM wallet_v2_exit_positions WHERE episode_id=?",(result["episode_id"],)).fetchone()
    assert outcome["exited"]==1 and len([x for x in snap["fills"] if x["side"]=="SELL"])==1
    assert final[0:3]==("EXITED",1,"PROFIT_PROTECTION")
    assert final[3]=="0.689999" and Decimal(final[4])==0
    assert engine.ledger(WALLET).reconcile()["ok"]


def test_hard_stop_partial_is_latched_and_retried_with_a_new_snapshot(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    client.depth=100
    client.set_bids("0.54","0.53")
    first=asyncio.run(runtime.refresh_exit_v1())
    with sqlite3.connect(path) as con:
        row=con.execute("SELECT hard_stop_active,state FROM wallet_v2_exit_positions WHERE episode_id=?",(result["episode_id"],)).fetchone()
        first_order=con.execute("SELECT order_id,status FROM strict_orders WHERE side='SELL'").fetchone()
    assert first["errors"]==0 and tuple(row)==(1,"ACTIVE")
    assert first_order[1]=="PARTIALLY_FILLED"
    client.depth=1000;client.set_bids("0.54","0.53")
    second=asyncio.run(WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep).refresh_exit_v1())
    with sqlite3.connect(path) as con:
        orders=con.execute("SELECT COUNT(*) FROM strict_orders WHERE side='SELL'").fetchone()[0]
        row=con.execute("SELECT state,hard_stop_active,exit_reason FROM wallet_v2_exit_positions WHERE episode_id=?",(result["episode_id"],)).fetchone()
    assert second["exited"]==1 and orders==2
    assert tuple(row)==("EXITED",1,"DYNAMIC_HARD_STOP")
    assert engine.ledger(WALLET).reconcile()["ok"]


def test_eligible_open_position_held_until_formal_resolution(tmp_path):
    path,engine,clock,client,runtime,result=make_runtime(tmp_path)
    client.set_bids("0.65")
    asyncio.run(runtime.refresh_exit_v1())
    client.formal=True
    settled=asyncio.run(runtime.refresh_settlements())
    with sqlite3.connect(path) as con:
        row=con.execute("SELECT state,exit_reason FROM wallet_v2_exit_positions WHERE episode_id=?",(result["episode_id"],)).fetchone()
        events=[x[0] for x in con.execute("SELECT event_type FROM wallet_v2_exit_events WHERE episode_id=?",(result["episode_id"],))]
    assert settled["settled"]==1 and tuple(row)==("FORMALLY_RESOLVED","FORMAL_RESOLUTION")
    assert "FORMAL_RESOLUTION" in events
    assert engine.ledger(WALLET).reconcile()["ok"]


def test_exit_v1_does_not_enroll_entry_below_band(tmp_path):
    path=tmp_path/"out-of-band.db";WalletFollowV2.initialize(path);engine=WalletFollowV2(path)
    engine.create_version(V2_CONFIG,created_at=T0,evidence_cutoff=T0);engine.activate(at=T0)
    clock=FakeClock();client=ExitClient(clock);client.ask="0.40"
    runtime=WalletFollowRuntime(path,client,clock=clock.now,sleep=clock.sleep)
    entry={"trade_key":"low-entry","condition_id":"condition","token_id":"token","outcome":"YES","side":"BUY",
        "timestamp":(T0-timedelta(seconds=60)).timestamp(),"price":.4,"size":10,"raw":{"id":"low-entry"}}
    result=asyncio.run(runtime.process_trade(WALLET,entry,detected_at=T0));assert result["status"]=="FILLED"
    asyncio.run(runtime.refresh_exit_v1())
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT COUNT(*) FROM wallet_v2_exit_positions").fetchone()[0]==0
