const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const nodes = new Map();
const document = {
  getElementById(id) { if (!nodes.has(id)) { const node = {innerHTML: '', textContent: ''}; Object.defineProperty(node, 'outerHTML', {get() { return this.innerHTML; }, set(value) { this.innerHTML = value; }}); nodes.set(id, node); } return nodes.get(id); },
  addEventListener() {}
};
const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[character]));
const context = {document, URL, esc, $: document.getElementById.bind(document),
  short: value => `${value.slice(0, 8)}…`, money: value => value == null ? '—' : `$${Number(value).toFixed(2)}`,
  stamp: value => value || '—',
  tag: value => `<span>${esc(value)}</span>`, button: (action, id, label) => `<button data-action="${esc(action)}" data-id="${esc(id)}">${esc(label)}</button>`,
  empty: value => esc(value), navigator: {clipboard: {writeText() {}}}};
vm.createContext(context);
const appSource = fs.readFileSync(path.join(__dirname, '..', 'app', 'static', 'app.js'), 'utf8');
const v2Source = appSource.slice(appSource.indexOf('function resolvedPaperOutcome'), appSource.indexOf('function drawCandidates'));
context.table = (headers, body) => `<table><thead>${headers.map(esc).join('|')}</thead><tbody>${body}</tbody></table>`;
vm.runInContext(v2Source + '\nthis.drawV2Test = drawV2; this.outcomeTest = {resolvedPaperOutcome, summarizeResolvedPaperOutcomes, outcomeChartHtml, fetchAllFormallyResolvedEpisodes, loadV2OutcomeChart, paperEntryPrice, paperSettlementPrice, paperRealizedPnl, signedMoney};', context);
const runtimeSource = appSource.slice(appSource.indexOf('function fastPathStatusHtml'), appSource.indexOf('function drawWallets'));
vm.runInContext(runtimeSource + '\nthis.runtimeTest = {fastPathStatusHtml, drawOverview};', context);
vm.runInContext('this.capitalTest = {capitalDashboardHtml, realizedReturnChart, capitalPercent, holdingTime};', context);
const poolFixture = {enabled:true, fixed_initial_cash:'7000', available_cash:'5400',reserved_cash:'0',
  open_cost_basis:'1600',current_utilization:'0.2285714286',average_utilization:'0.2',
  average_utilization_since:'2026-10-13T03:00:00Z',buy_turnover:'0.41',average_holding_seconds:'7200',
  closed_position_samples:54,reconciliation:{ok:true},return_curve:[
    {at:'2026-10-13T03:00:00Z',return:'-0.005'},
    {at:'2026-10-13T04:00:00Z',return:'0.01'}]};
const poolHtml=context.capitalTest.capitalDashboardHtml(poolFixture);
for(const text of ['当前资金占用率','平均资金占用率','本金周转次数','平均持仓时长','已实现收益 / 初始本金','22.86%','20.00%','0.41 次','2.0 小时','新钱包不增资','资金核对通过']) assert.ok(poolHtml.includes(text),text);
assert.ok(poolHtml.includes('<polyline') && poolHtml.includes('时间（上海）'));
assert.ok(poolHtml.includes('1.00%'));
assert.equal((poolHtml.match(/<circle /g)||[]).length,2);
assert.equal(context.capitalTest.capitalPercent(null),'—');
assert.equal(context.capitalTest.capitalPercent('NaN'),'—');
assert.equal(context.capitalTest.holdingTime(null),'—');
assert.ok(context.capitalTest.capitalDashboardHtml({enabled:false}).includes('尚未启用'));
assert.ok(!context.capitalTest.realizedReturnChart({return_curve:[{at:'bad',return:'<script>'}]}).includes('<script>'));
assert.ok(context.capitalTest.realizedReturnChart({return_curve:[{at:'2026-10-13T03:00:00Z',return:'-0.01'}]}).includes('承接损益起点'));
const fallbackHtml = context.runtimeTest.fastPathStatusHtml({enabled:true,configured:true,connected:false,
  last_data_success_at:new Date().toISOString(),read_transport:'HTTPS',catchup_remaining_blocks:12});
assert.ok(fallbackHtml.includes('HTTP 补漏正在运行'));
assert.ok(fallbackHtml.includes('12 个区块'));
context.runtimeTest.drawOverview({versions:[],exclusions:[],ai:{calls_today:0,daily_call_limit:24}},
  {monitor_running:true,ai:{},experiment:{run_id:'FORWARD-NEW',label:'新实验',archives:[{run_id:'ARCHIVE-OLD',episodes:2023,fills:385,realized_pnl:'-569'}]}},
  {counts:{resolved_episodes:0},performance:{realized_paper_pnl:'0',unrealized_paper_pnl:null,missing_mark_positions:3}});
assert.ok(nodes.get('experiment-banner').innerHTML.includes('FORWARD-NEW'));
assert.ok(nodes.get('experiment-banner').innerHTML.includes('2023'));
assert.ok(!nodes.get('metrics').innerHTML.includes('2023'));
assert.ok(nodes.get('metrics').innerHTML.includes('缺少有效估值'));
context.drawV2Test({configured: true, strategy_version: 'wallet-follow-v2.0', state: 'FORWARD_TEST',
  frozen_config: {fixed_notional: '25', min_net_roi_if_win: '0.05', max_visible_depth_fraction: '0.10', execution_latency_ms: 500, max_book_age_ms: 3000, live_orders: false, min_resolved_for_review: 20},
  counts: {observed_episodes: 0, filled: 0, partial: 0, rejected_no_fill: 0, pending_resolution: 0},
  performance: {no_fill_reason_distribution: {'<bad>': 2}}, observation: {tracked_wallets: 20, observed_trades: 0}, settlement: {pending_paper_positions: 0}});
assert.ok(nodes.get('v2-state').innerHTML.includes('wallet-follow-v2.0'));
assert.ok(nodes.get('v2-state').innerHTML.includes('&lt;bad&gt;'));
assert.ok(!nodes.get('v2-state').innerHTML.includes('<td><bad></td>'));
const outcomeSamples = [
  {resolution_status: 'FORMALLY_RESOLVED', paper_status: 'FILLED', direction_correct: 1},
  {resolution_status: 'FORMALLY_RESOLVED', paper_status: 'PARTIAL', direction_correct: 0},
  {resolution_status: 'FORMALLY_RESOLVED', paper_status: 'REJECTED', direction_correct: 1},
  {resolution_status: 'PENDING', paper_status: 'FILLED', direction_correct: 1},
  {resolution_status: 'FORMALLY_RESOLVED', paper_status: 'FILLED', direction_correct: null},
  {resolution_status: 'VOID', paper_status: 'FILLED', direction_correct: 0}
];
assert.deepEqual(JSON.parse(JSON.stringify(context.outcomeTest.summarizeResolvedPaperOutcomes(outcomeSamples))), {wins: 1, losses: 1, total: 2, rate: 0.5});
const renderedOutcomes = context.outcomeTest.outcomeChartHtml({wins: 2, losses: 1, total: 3, rate: 2 / 3});
assert.ok(renderedOutcomes.includes('总计 <strong>3</strong>'));
assert.ok(renderedOutcomes.includes('预测成功 <strong>2</strong>'));
assert.ok(renderedOutcomes.includes('预测失败 <strong>1</strong>'));
assert.ok(renderedOutcomes.includes('66.7%'));
assert.ok(context.outcomeTest.outcomeChartHtml({wins: 0, losses: 0, total: 0, rate: null}).includes('暂无已正式判定且完成模拟成交的样本。'));
assert.ok(appSource.includes('status=FORMALLY_RESOLVED&offset=${offset}&limit=200'));
assert.ok(appSource.includes('} while (offset < expectedTotal);'));
assert.ok(appSource.includes('loadV2OutcomeChart();'));
assert.ok(appSource.includes("api('/api/wallet-follow-v2/scan','POST')"));
assert.ok(!appSource.includes("api('/api/research/experiment')"));
assert.ok(!appSource.includes("api('/api/monitor/scan','POST')"));
assert.ok(!fs.readFileSync(path.join(__dirname, '..', 'app', 'static', 'index.html'), 'utf8').includes('FC14-D81AAF4747E2'));
const source = appSource.slice(appSource.indexOf('const percent = '), appSource.lastIndexOf('refresh();setInterval'));
assert.ok(source.includes('function drawWallets'));
vm.runInContext(source + '\nthis.uiTest = {drawWallets, identityName, avatar, trustedEvent, trustedProfile, trustedAvatar};', context);
const wallet = '0x' + 'a'.repeat(40);
context.uiTest.drawWallets([{address: wallet, tracked: true, card: {
  identity: {source: 'GAMMA_PUBLIC_PROFILE', proxy_wallet: wallet, username: '<script>alert(1)</script>', avatar_url: 'javascript:alert(2)'},
  frequent_categories: [{category: '<img src=x onerror=alert(3)>', observed_positions: 2}],
  categories: [], profitable_settled_positions: 1, settled_position_sample: 2,
  profitable_position_rate: 0.5, leader_historical_realized_pnl: 4,
}}], {exclusions: []}, {wallet_results: {}});
const html = nodes.get('wallet-list').innerHTML;
assert.ok(html.includes('&lt;script&gt;alert(1)&lt;/script&gt;'));
assert.ok(html.includes('&lt;img src=x onerror=alert(3)&gt;'));
assert.ok(!html.includes('<script>'));
assert.ok(!html.includes('src="javascript:'));
assert.equal(context.uiTest.trustedEvent('https://polymarket.com/event/known-event'), 'https://polymarket.com/event/known-event');
assert.equal(context.uiTest.trustedEvent('javascript:alert(1)'), null);
assert.equal(context.uiTest.trustedProfile('https://evil.example/profile/' + wallet), null);
assert.equal(context.uiTest.trustedAvatar('https://127.0.0.1/private'), null);
const mismatched = {source: 'GAMMA_PUBLIC_PROFILE', proxy_wallet: '0x' + 'b'.repeat(40), username: 'Wrong user', avatar_url: 'https://imagedelivery.net/id/avatar'};
assert.equal(context.uiTest.identityName(mismatched, wallet), '0xaaaaaa…');
assert.ok(!context.uiTest.avatar(mismatched, wallet).includes('<img'));
assert.equal(context.uiTest.identityName({username: 'No proxy'}, wallet), '0xaaaaaa…');
const journalSource = appSource.slice(appSource.indexOf('async function journal()'), appSource.indexOf("document.addEventListener('click', event =>"));
const priceWin = {paper_status: 'FILLED', resolution_status: 'FORMALLY_RESOLVED', filled_quantity: '50', filled_notional: '20', entry_fee: '0.10', execution_price: '0.400000', payout_per_share: '1'};
const priceLoss = {...priceWin, payout_per_share: '0'};
const pricePartial = {...priceWin, paper_status: 'PARTIAL', filled_quantity: '5', filled_notional: '2.60', entry_fee: '0.02'};
const pricePending = {...priceWin, resolution_status: 'PENDING'};
const priceRejected = {...priceWin, paper_status: 'REJECTED'};
const notionalBasis = {...priceWin, filled_notional: '21'};
const zeroPnl = {...priceWin, payout_per_share: '0.402'};
assert.equal(context.outcomeTest.paperEntryPrice(priceWin), '0.4000');
assert.equal(context.outcomeTest.paperSettlementPrice(priceWin), '1.0000');
assert.equal(context.outcomeTest.paperRealizedPnl(priceWin), 29.9);
assert.equal(context.outcomeTest.signedMoney(context.outcomeTest.paperRealizedPnl(priceWin)), '+$29.90');
assert.equal(context.outcomeTest.paperRealizedPnl(priceLoss), -20.1);
assert.equal(context.outcomeTest.signedMoney(context.outcomeTest.paperRealizedPnl(priceLoss)), '-$20.10');
assert.equal(context.outcomeTest.paperRealizedPnl(pricePartial), 2.38);
assert.equal(context.outcomeTest.paperRealizedPnl(notionalBasis), 28.9, 'P&L must use ledger filled_notional, not execution_price * quantity');
assert.equal(context.outcomeTest.paperRealizedPnl(zeroPnl), 0);
assert.equal(context.outcomeTest.signedMoney(context.outcomeTest.paperRealizedPnl(zeroPnl)), '$0.00');
assert.equal(context.outcomeTest.paperEntryPrice(pricePending), '0.4000');
assert.equal(context.outcomeTest.paperSettlementPrice(pricePending), '—');
assert.equal(context.outcomeTest.paperRealizedPnl(pricePending), null);
assert.equal(context.outcomeTest.paperEntryPrice(priceRejected), '—');
assert.equal(context.outcomeTest.paperRealizedPnl(priceRejected), null);
assert.equal(context.outcomeTest.paperRealizedPnl({...priceWin, entry_fee: 'Infinity'}), null);
async function verifyJournalAndPagination() {
  const rowItems = [
    {episode_id: 'win', wallet, ...priceWin, direction_correct: 1, market_title: 'Win market'},
    {episode_id: 'loss', wallet, ...priceLoss, paper_status: 'PARTIAL', filled_notional: '20', direction_correct: 0, market_title: 'Loss market'},
    {episode_id: 'partial', wallet, ...pricePartial, direction_correct: 1},
    {episode_id: 'rejected', wallet, ...priceRejected, direction_correct: 0},
    {episode_id: 'pending', wallet, ...pricePending, direction_correct: 1},
    {episode_id: 'zero', wallet, ...zeroPnl, direction_correct: null},
    {episode_id: 'ledger-notional', wallet, ...notionalBasis, direction_correct: null}
  ];
  context.api = async () => ({total: rowItems.length, entries: rowItems});
  context.offset = 0; context.total = 0;
  context.money = value => value == null ? '—' : `$${Number(value).toFixed(2)}`;
  context.stamp = value => value || '—';
  context.identityName = () => 'wallet';
  context.trustedEvent = () => null;
  context.avatar = () => '';
  context.v2Tag = value => `<span>${esc(value)}</span>`;
  context.button = (action, id, label) => `<button data-action="${esc(action)}" data-id="${esc(id)}">${esc(label)}</button>`;
  context.entryStatus = '';
  vm.runInContext(journalSource + '\nthis.journalTest = journal;', context);
  await context.journalTest();
  const journalHtml = nodes.get('journal-list').innerHTML;
  assert.ok(journalHtml.includes('class="journal-outcome-win"'));
  assert.ok(journalHtml.includes('预测成功'));
  assert.ok(journalHtml.includes('class="journal-outcome-loss"'));
  assert.ok(journalHtml.includes('预测失败'));
  assert.ok(journalHtml.includes('模拟成交价'));
  assert.ok(journalHtml.includes('结算价'));
  assert.ok(journalHtml.includes('单笔净盈亏'));
  const journalRows = [...journalHtml.matchAll(/<tr(?: class="([^"]+)")?>(.*?)<\/tr>/g)];
  for (const neutralId of ['rejected', 'pending']) {
    const row = journalRows.find(([, , content]) => content.includes(`data-id="${neutralId}"`));
    assert.ok(row, `missing ${neutralId} row`);
    assert.equal(row[1], undefined);
    assert.ok(!row[2].includes('预测成功') && !row[2].includes('预测失败'));
  }
  const cellsFor = id => {
    const row = journalRows.find(([, , content]) => content.includes(`data-id="${id}"`));
    assert.ok(row, `missing ${id} row`);
    return [...row[2].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/g)].map(([, content]) => content);
  };
  assert.equal(cellsFor('win')[3], '0.4000');
  assert.equal(cellsFor('win')[4], '1.0000');
  assert.ok(cellsFor('win')[5].includes('+$29.90'));
  assert.ok(cellsFor('win')[5].includes('已扣手续费'));
  assert.ok(cellsFor('win')[5].includes('class="journal-pnl positive"'));
  assert.equal(cellsFor('loss')[4], '0.0000');
  assert.ok(cellsFor('loss')[5].includes('-$20.10'));
  assert.ok(cellsFor('loss')[5].includes('class="journal-pnl negative"'));
  assert.ok(cellsFor('partial')[5].includes('+$2.38'));
  assert.equal(cellsFor('pending')[3], '0.4000');
  assert.equal(cellsFor('pending')[4], '—');
  assert.equal(cellsFor('pending')[5], '—');
  assert.equal(cellsFor('rejected')[3], '—');
  assert.equal(cellsFor('rejected')[5], '—');
  assert.ok(cellsFor('zero')[5].includes('$0.00'));
  assert.ok(cellsFor('zero')[5].includes('journal-pnl-neutral'));
  assert.ok(cellsFor('ledger-notional')[5].includes('+$28.90'));

  const resolvedEpisodes = [
    ...Array.from({length: 70}, (_, index) => ({episode_id: `rejected-${index}`, wallet, paper_status: 'REJECTED', resolution_status: 'FORMALLY_RESOLVED', direction_correct: 0})),
    ...Array.from({length: 50}, (_, index) => ({episode_id: `filled-${index}`, wallet, paper_status: 'FILLED', resolution_status: 'FORMALLY_RESOLVED', direction_correct: 1})),
    ...Array.from({length: 20}, (_, index) => ({episode_id: `partial-${index}`, wallet, paper_status: 'PARTIAL', resolution_status: 'FORMALLY_RESOLVED', direction_correct: 0})),
    {episode_id: 'filled-null-outcome', wallet, paper_status: 'FILLED', resolution_status: 'FORMALLY_RESOLVED', direction_correct: null},
    {episode_id: 'pending-filled', wallet, paper_status: 'FILLED', resolution_status: 'PENDING', direction_correct: 1}
  ];
  const resolvedRequests = [];
  context.api = async path => { resolvedRequests.push(path); return {total: resolvedEpisodes.length, entries: resolvedEpisodes}; };
  nodes.get('entry-status').value = 'FORMALLY_RESOLVED';
  context.offset = 0;
  await context.journalTest();
  assert.equal(context.total, 71);
  assert.equal(nodes.get('page-info').textContent, '1–50 / 71');
  assert.equal(((nodes.get('journal-list').innerHTML.match(/<tbody>([\s\S]*?)<\/tbody>/) || ['', ''])[1].match(/<tr(?: class="[^"]+")?>/g) || []).length, 50);
  assert.ok(nodes.get('journal-list').innerHTML.includes('data-id="filled-0"'));
  assert.ok(!nodes.get('journal-list').innerHTML.includes('rejected-'));
  assert.ok(!nodes.get('journal-list').innerHTML.includes('pending-filled'));
  assert.equal(resolvedRequests.length, 1);
  assert.equal(resolvedRequests[0], '/api/wallet-follow-v2/episodes?status=FORMALLY_RESOLVED&offset=0&limit=200');
  context.offset = 50;
  await context.journalTest();
  assert.equal(context.total, 71);
  assert.equal(nodes.get('page-info').textContent, '51–71 / 71');
  assert.equal(((nodes.get('journal-list').innerHTML.match(/<tbody>([\s\S]*?)<\/tbody>/) || ['', ''])[1].match(/<tr(?: class="[^"]+")?>/g) || []).length, 21);
  const secondPageHtml = nodes.get('journal-list').innerHTML;
  const nullOutcomeRow = [...secondPageHtml.matchAll(/<tr(?: class="([^"]+)")?>(.*?)<\/tr>/g)].find(([, , content]) => content.includes('data-id="filled-null-outcome"'));
  assert.ok(nullOutcomeRow);
  assert.equal(nullOutcomeRow[1], undefined);
  assert.ok(!nullOutcomeRow[2].includes('预测成功') && !nullOutcomeRow[2].includes('预测失败'));
  assert.ok(!secondPageHtml.includes('rejected-') && !secondPageHtml.includes('pending-filled'));

  let regularStatusRequest = '';
  context.api = async path => { regularStatusRequest = path; return {total: 123, entries: rowItems}; };
  nodes.get('entry-status').value = 'FILLED';
  context.offset = 50;
  await context.journalTest();
  assert.equal(regularStatusRequest, '/api/wallet-follow-v2/episodes?offset=50&limit=50&status=FILLED');
  assert.equal(context.total, 123);

  const originalApi = context.api;
  const requests = [];
  const firstPage = Array.from({length: 200}, (_, index) => ({resolution_status: 'FORMALLY_RESOLVED', paper_status: index === 199 ? 'FILLED' : 'REJECTED', direction_correct: 1}));
  context.api = async path => { requests.push(path); return requests.length === 1 ? {total: 201, entries: firstPage} : {total: 201, entries: [{resolution_status: 'FORMALLY_RESOLVED', paper_status: 'PARTIAL', direction_correct: 0}]}; };
  const chartNode = {innerHTML: '', textContent: ''};
  Object.defineProperty(chartNode, 'outerHTML', {get() { return this.innerHTML; }, set(value) { this.innerHTML = value; }});
  nodes.set('v2-outcome-chart', chartNode);
  await context.outcomeTest.loadV2OutcomeChart();
  assert.equal(requests.length, 2);
  assert.ok(requests[0].includes('offset=0&limit=200'));
  assert.ok(requests[1].includes('offset=200&limit=200'));
  assert.ok(nodes.get('v2-outcome-chart').innerHTML.includes('总计 <strong>2</strong>'));
  context.api = async () => { throw new Error('temporary failure'); };
  await context.outcomeTest.loadV2OutcomeChart();
  assert.ok(nodes.get('v2-outcome-chart').innerHTML.includes('结果暂时无法读取'));
  context.api = originalApi;
}
verifyJournalAndPagination().then(() => console.log('UI outcome visualization, pagination, journal highlighting, escaping and URL checks passed')).catch(error => { console.error(error); process.exitCode = 1; });
