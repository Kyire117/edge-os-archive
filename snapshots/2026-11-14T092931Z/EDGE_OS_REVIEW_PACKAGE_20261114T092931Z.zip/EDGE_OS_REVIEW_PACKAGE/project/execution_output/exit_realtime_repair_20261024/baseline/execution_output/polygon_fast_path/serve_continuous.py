"""Explicit continuous PAPER_ONLY launcher; reuse frozen strategy and existing records."""
import json
import sqlite3
import sys
from dataclasses import replace
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from app.config import settings
from edge_runtime import active_database

source=Path(settings.database_path).resolve()
assert source==active_database()
with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as con:
    con.execute('PRAGMA query_only=ON')
    row=con.execute("SELECT state,config_json FROM wallet_v2_versions WHERE strategy_version='wallet-follow-v2.0'").fetchone()
    assert row and row[0]=='FORWARD_TEST'
    cfg=json.loads(row[1])
    assert cfg['live_orders'] is False and cfg['fixed_notional']=='25'
    assert cfg['min_net_roi_if_win']=='0.05' and cfg['max_visible_depth_fraction']=='0.10'
    assert cfg['execution_latency_ms']==500 and cfg['max_book_age_ms']==3000

from app.main import app, polygon_fast, pm
polygon_fast.config=replace(polygon_fast.config,backfill_diagnostics=True,
                           diagnostic_backfill_chunk_size=64,rpc_timeout=15,
                           recovery_chunk_blocks=8,max_catchup_blocks=16384,max_chunks_per_cycle=4,
                           segment_large_gaps=True)
polygon_fast.http_read_rpc=pm.polygon_read_rpc
polygon_fast.config.validate()

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host='127.0.0.1',port=8000,access_log=False)
