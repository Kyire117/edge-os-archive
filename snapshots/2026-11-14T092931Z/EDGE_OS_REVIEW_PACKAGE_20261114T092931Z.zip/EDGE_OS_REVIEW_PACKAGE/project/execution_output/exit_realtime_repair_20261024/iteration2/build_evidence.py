"""Build task evidence only; no application/database initialization or network."""
from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, json, shutil

out=Path(__file__).resolve().parent
root=out.parents[2]
files=['app/polygon_fast_path.py','tests/test_exit_realtime_repair.py','tests/test_polygon_fast_path.py']
fixture_baseline=out/'baseline/test_polygon_fast_path.py'
if not fixture_baseline.exists():
    original=(out/'baseline/test_polygon_fast_path.after_fixture_change.py').read_text()
    current="""    event=decode_log(log())
    with database.conn() as c:
        c.execute("UPDATE polygon_fast_events SET state='WAITING_CONFIRMATION' WHERE event_id=? AND block_hash=?",
                  (event['event_id'],event['block_hash']))
"""
    assert current in original
    fixture_baseline.write_text(original.replace(current,"    event=decode_log(log());p.store.transition(event,'WAITING_CONFIRMATION')\n",1))
diff=[]
for name in files:
    old=(out/'baseline'/Path(name).name).read_text().splitlines(True)
    new=(root/name).read_text().splitlines(True)
    diff.extend(difflib.unified_diff(old,new,fromfile='before/'+name,tofile='after/'+name))
(out/'exact.diff').write_text(''.join(diff),encoding='utf-8')
for name in ['production_before.json','production_final.json']:
    shutil.copy2(out.parent/name,out/name)
production=json.loads((out/'production_final.json').read_text())
assert production['all_ok']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest={'task_id':'c2c_exit_realtime_repair_v1','iteration':2,'status':'READY_FOR_REVIEW',
    'captured_at':datetime.now(timezone.utc).isoformat(),'changed_files':files,
    'source_file_hashes':{name:sha(root/name) for name in files},
    'production_preserved':production['all_ok'],'production_started':False,'observation_started':False,
    'historical_void_checkpoint':'BLOCKED; untouched',
    'output_ids':[136,137],
    'validation':{'focused':'105 passed, 1 existing warning','broad_targeted':'222 passed, 1 existing warning','full':'468 passed, 1 existing warning',
                  'static_checks':json.loads((out/'static_checks.json').read_text(encoding='utf-8-sig'))},
    'artifacts':{p.name:{'sha256':sha(p),'size':p.stat().st_size} for p in out.iterdir()
                 if p.is_file() and p.name not in ('manifest.json',)}}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':manifest['status'],'production_preserved':production['all_ok'],'changed_files':files}))
