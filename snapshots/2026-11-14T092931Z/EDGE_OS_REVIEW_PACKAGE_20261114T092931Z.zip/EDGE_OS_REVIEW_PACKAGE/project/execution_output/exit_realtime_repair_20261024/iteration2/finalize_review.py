"""Persist actual browser review result; does not alter product/runtime state."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json
out=Path(__file__).resolve().parent
root=out.parents[2]
manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
for name,digest in manifest['source_file_hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
review=(out/'web_review_final.txt').read_text(encoding='utf-8')
assert 'heading "REVIEW_PASS" [level=1]' in review and '回答已完成' in review
report=out/'execution_report.md'
final='''

## Final independent review: REVIEW_PASS

The original ChatGPT conversation completed its actual source/evidence review and issued REVIEW_PASS for Iteration 2. Full read-back: `web_review_final.txt`; screenshot: `review_pass.png`. This is a code/regression review, not production enablement or a new observation run. No source changed after that review request.

The reviewer noted that normal git diff --check does not cover untracked files. A follow-up explicit git diff --no-index --check compared each of the three task files with its own baseline: all returned 1 (different files), with no whitespace-error output; one existing LF/CRLF notice was emitted. Raw exit codes: `untracked_patch_checks.json`. No Git staging or cleanup occurred.

Final state: connection restored and actual workspace/README/source read verified; 105 focused / 222 broader targeted / 468 full tests passed (one existing warning); production preservation all true. Historical VOID remains BLOCKED. Deployment and further real-data paper observation remain separate next gates, not performed here.
'''
if '## Final independent review: REVIEW_PASS' not in report.read_text(encoding='utf-8'):
    report.write_text(report.read_text(encoding='utf-8')+final,encoding='utf-8')
manifest.update(status='REVIEW_PASS',independent_review='REVIEW_PASS',
                reviewed_at=datetime.now(timezone.utc).isoformat(),review_readback='web_review_final.txt')
manifest['artifacts']={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}
                       for p in out.iterdir() if p.is_file() and p.name!='manifest.json'}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
status=out.parent/'web_review_status.json'
data=json.loads(status.read_text(encoding='utf-8'))
data.update(status='REVIEW_PASS',iteration=2,review_result='REVIEW_PASS',
            required_next_action='Separate forward observation readiness gate; no deployment or observation started',
            source_unchanged_since_review_request=True,output_ids=[136,137])
status.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':'REVIEW_PASS','source_hashes_match':True,'production_changed':False,
                  'observation_started':False,'deployment_started':False}))
