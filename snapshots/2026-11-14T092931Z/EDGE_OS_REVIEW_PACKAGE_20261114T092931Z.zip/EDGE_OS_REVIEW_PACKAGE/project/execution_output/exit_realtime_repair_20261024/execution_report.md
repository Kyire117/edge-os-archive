# Exit / realtime repair — Iteration 1

Status: IMPLEMENTED_LOCAL, independent review pending; not deployed; no forward observation started.

## Authorized scope
- Fix Exit V1 timestamp contract with trigger observation -> new quote requested after trigger -> fresh execution snapshot >=500ms after quote receipt.
- Revalidate exact market identity, accepting_orders, venue minimum and fee evidence concurrently with the final execution fetch; retain 3000ms freshness and all frozen strategy/fee/precision/depth rules.
- Isolate websocket receive/staging, bounded backfill, concurrent event validation/routing. HTTP and identity failures retry without tearing down the websocket or blocking unrelated event slots.
- Coalesce only simultaneous canonical block/receipt reads (no persistent canonical cache); coalesce token metadata lookups while retaining original authoritative mapping and cache validity checks.
- Persist per-event retry backoff. Skip not-due retries before LIMIT to prevent starvation. Periodically prioritize old evidence while normally prioritizing live observations. Compare-and-set ROUTING protects removed events across awaited I/O.
- Keep whole-chunk durable checkpoint advancement; no gap skipping, replay, or invented historical fills. Cancel/drain all worker/RPC/metadata tasks on shutdown.
- Read-only health fields: worker errors, chain head/processing freshness, inflight work, per-method RPC telemetry, catch-up net progress, separate live/backfill latency. Frontend displays degraded state even if socket connected.

## Validation
- Targeted: 135 passed, 1 pre-existing Starlette/anyio deprecation warning, 35.59s (targeted_run2.txt).
- Full regression: 458 passed, 1 same deprecation warning, 109.27s (full_run1.txt).
- Python compileall app/tests: exit 0.
- node --check app/static/app.js: exit 0.
- node tests/ui_v1_static.test.js: exit 0.
- Initial failures retained: targeted_run1.txt (new test inspected fill evidence instead of enriched order evidence); earlier baseline suite stale UI assertion required removed unrealized-PnL card and old chart pagination. Updated those assertions to existing current UI/summary contract without restoring removed UI.

## Safety and limitations
Production manifest, fixed $7000 shared pool, $25 gross notional, 5% if-win net ROI, 10% depth, 500ms latency, 3000ms freshness, live_orders=false preserved. No DB initialization/migration against production, no service start/restart, no fills replayed. Historical VOID checkpoint unchanged. production_before/after evidence compares DB and all available WAL/SHM bytes, counts and active manifest.

No measured real-world latency or provider reliability claim follows from synthetic tests. At least 24h isolated observation is pending independent review. No automatic production loading is approved by a local test result.

Connection repair: existing private EDGE OS plugin packages an outdated temporary workspace address. Prefer in-place package update, preserve plugin ID/defaultPrompt/permissions/chat, no deletion. Actual workspace_info + read-back and review are still required.

## Changed files
- app/wallet_follow_runtime.py
- app/polygon_fast_path.py
- app/main.py
- app/static/app.js
- app/static/index.html
- tests/test_realtime_ingestion_exit_v1.py
- tests/test_exit_realtime_repair.py
- tests/ui_v1_static.test.js
- execution_output/polygon_fast_path/serve_continuous.py

## Final local evidence
- Additional acceptance: 14 passed in 8.48s (acceptance.txt), including exact realized cash/PnL after partial SELL + formal settlement and strict audit-chain validation.
- git diff --check: exit 0; existing LF/CRLF notices are not errors.
- production_after.json: all_ok=true; source main DB and available WAL/SHM SHA256+size identical, all ten inspected table counts identical, active manifest hash/run ID identical, quick_check=ok. No source database mutation was performed.
- Existing plugin update was explicitly authorized by the user at action time. Uploaded original identity-preserving version 0.1.2; browser still reports upload in progress, not independently verified.
- No production runtime or new isolated forward observation has been started.

## Final self-review findings and external review state
- Added post-ledger-commit crash regressions for full and partial SELL: recovery fetches zero new books, retains exactly one existing SELL, releases reservations, and verifies the strict audit chain.
- Fixed latched partial hard-stop depth precheck to count all actual executable bids, including improved bids after rebound. Strict best-price walking, participation and fee rules remain unchanged. A dedicated regression verifies exit after rebound.
- Latest acceptance: 17 passed (acceptance_latest.txt); final full regression passed: 461 tests, 1 existing dependency warning, 99.90s (full_verified.txt).
- Read-only network probe: both direct and the existing configured public proxy verified Polygon chain_id=137 in this single test (953.5ms / 726.5ms). This does not isolate the historical timeout cause or establish a latency SLO.
- Original plugin successfully updated in-place to 0.1.2; unchanged plugin ID, same original conversation, no deletions/new chats. Screenshot plugin_updated.png.
- Actual independent webpage result: REVIEW_BLOCKED_BY_MISSING_EDGE_OS_TOOL. Reviewer mistakenly tried git-node first; after correction, exact EDGE OS tool discovery returned zero tools. No source/evidence was independently read. The plugin directory entry is present, but the ChatGPT tool-connection settings contain no EDGE OS connector.
- A specific authorization request to restore a read-only EDGE OS tool connection is pending. Do not deploy/start the 24h observation until actual workspace_info/read-back and independent review succeed.
- Existing c2c_fix_p1_execution_void BLOCKED checkpoint was read from actual C2C session and left unchanged. C2C session was not overwritten for this task.

## 最终状态（中文）

本地实现已完成，独立审查被原网页对话缺少EDGE OS工具阻塞；未部署、未启动24小时观察。

- 退出：触发盘口与执行报价分离；报价请求晚于触发，执行盘口在报价接收后至少500ms重新获取；市场/费用重新核验，3000ms限制保持。
- 退出边界：部分卖出后继续使用最佳真实买价；卖出已记账但状态更新前中断，重启只恢复已提交证据，无新盘口/重复卖出；未成交不伪造，预留及时释放。
- 实时：接收落盘、补漏、事件处理分离；有限并发、同一请求合并、身份失败持久退避；保留检查点和无重放约束；移除事件跨网络等待后使用CAS阻止入场。
- 诊断：按处理阶段区分区块验证、回执、身份解析、路由；身份解析失败不会误标为上一条链RPC失败，不记录异常原文/密钥。
- 当前验收：17 passed；当前全回归：461 passed，1条既有弃用警告；compileall、Node语法、前端检查、git diff --check均exit 0。
- 最终生产保全：production_final.json all_ok=true；数据库/WAL/SHM字节、10张关键表数量、运行标识与active manifest hash全部不变，quick_check=ok。
- C2C真实可读输出：134（最终验收）、135（最终全回归）；130保留先前失败，131–133为中间通过记录。
- 原插件已在用户明确确认后原位更新至0.1.2，ID与原对话保留。网页实际反馈为REVIEW_BLOCKED_BY_MISSING_EDGE_OS_TOOL：尚未独立读取本轮源码/输出，不能宣称REVIEW_PASS。
- 已请求授权恢复仅属于EDGE OS的只读工具连接。待实际workspace_info和证据读取、独立审查通过后，才能开始隔离24小时前向观察；通过观察后再决定生产加载。
- 现有历史VOID BLOCKED检查点未改，历史失败成交/卖出均未重放。

![原插件原位更新为0.1.2](plugin_updated.png)
