"""Read-only production preservation comparison; never imports application DB classes."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sqlite3
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
before=json.loads((out/'production_before.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
m=json.loads((root/'data/active_experiment.json').read_text(encoding='utf-8-sig'));db=(root/m['database']).resolve()
assert (root/'data').resolve() in db.parents
r={'at':datetime.now(timezone.utc).isoformat(),'run_id':m['run_id'],'manifest_sha256':sha(root/'data/active_experiment.json'),'files':{str(p.relative_to(root)): {'size':p.stat().st_size,'sha256':sha(p)} for p in [db,Path(str(db)+'-wal'),Path(str(db)+'-shm')] if p.exists()}}
c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True,timeout=30);c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
r['counts']={t:c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in before['counts']};r['quick_check']=c.execute('PRAGMA quick_check').fetchone()[0];c.rollback();c.close()
r['comparison']={k:r[k]==before[k] for k in ['run_id','manifest_sha256','files','counts']};r['all_ok']=all(r['comparison'].values()) and r['quick_check']=='ok';(out/'production_final.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps({'comparison':r['comparison'],'all_ok':r['all_ok']}));assert r['all_ok']
