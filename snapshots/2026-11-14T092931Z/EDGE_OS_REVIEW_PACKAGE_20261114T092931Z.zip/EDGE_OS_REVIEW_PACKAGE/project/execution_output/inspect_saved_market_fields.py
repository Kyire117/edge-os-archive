import json
import sqlite3

connection = sqlite3.connect('file:data/edge_mvp.db?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
connection.execute('PRAGMA query_only=ON')
rows = connection.execute(
    "SELECT id, reason, entry_json FROM research_experiment_entries "
    "WHERE experiment_id=? AND id IN (4,12,87) ORDER BY id",
    ('FC14-D81AAF4747E2',),
).fetchall()
for row in rows:
    evidence = json.loads(row['entry_json'])
    print(f"ID {row['id']} reason={row['reason']}")
    print('entry keys:', sorted(evidence))
    for key in ('market', 'market_state', 'raw_market'):
        market = evidence.get(key)
        if isinstance(market, dict):
            print(key, 'keys:', sorted(market))
            print(key, 'endDate=', market.get('endDate'), 'gameStartTime=', market.get('gameStartTime'))
            events = market.get('events')
            if isinstance(events, list):
                print('events:', [{k: event.get(k) for k in ('startDate', 'endDate', 'gameStartTime')} for event in events if isinstance(event, dict)])
    print('horizon:', evidence.get('horizon'))
