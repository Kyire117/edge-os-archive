# EDGE OS 网页连接诊断

记录时间：2026-10-09T10:59:35Z。范围：连接诊断与证据修正；没有修改产品源码、访问生产数据库、启动/重启 EDGE OS、重新配对或删除插件。

## 当前验证

- 实际代码根目录：`C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp`，C2C 工作区 ID `47fec7b8248c`。
- `c2c doctor` 本轮全部通过；`chatgptRepair.needed=false`，当前/先前地址一致。
- 正确工作区公开地址的 `/health` HTTP 200，返回工作区 ID `47fec7b8248c`；未授权 `/mcp` HTTP 401，属于预期访问控制，不代表已授权读取成功。
- 原 EDGE OS Project 聊天 `6ac857f6-5684-83ec-b949-ee5197af0261` 实际返回 workspace 名 `EDGE OS 101`、虚拟根 `workspace:/` 和 README 标题 `# EDGE OS · Wallet Follow V2.0`。
- 后续网页读回句子“当前生产模式为 wallet-follow-v2.0 / FORWARD_TEST。”，与本地 README 对应内容一致；外层目录没有 README.md。
- ChatGPT 网页进一步读取了 execution_output、summary、test status，报告本地记录 18 / 208 / 315 测试通过，并开始独立源码审查。此处只记录读取成功，不据此宣布代码 REVIEW_PASS。

## 已确认的混淆与故障

1. 先前 Codex 内部调用报错的工具属于其他工作区连接。把那些内部错误描述为 EDGE OS 网页工具错误，证据不成立；已修正原执行摘要，新增可读 C2C 输出 105。原输出记录保留。
2. 本轮内置浏览器读取与输入操作耗时明显，20 秒工具调用限时多次导致自动化上下文重置。改用分别执行的操作、足够的单次限时并在发送前检查草稿后，同一聊天成功完成读取。没有更换聊天或插件。这是浏览器自动化超时证据，不是聊天配对失效证据。
3. C2C 有两套同名本地工作区：代码目录 ID `47fec7b8248c`，外层目录 ID `07eb5855973a`。各有不同地址、进程和保存聊天。两个 endpoint 都使用 `Codex with ChatGPT · EDGE OS 101`。名称不是唯一身份，检查必须同时核对 ID、代码目录和读取内容。
4. 历史日志记录代码目录连接在 10 月 2/3/6/9 日多次启动并取得不同临时地址；外层目录连接也在 10 月 9 日另行启动。临时地址变化确实发生过，但本轮正确代码目录的地址没有变化。日志没有证明每次启动的发起者，不能把全部重启归因于某一个用户操作或程序。

## 源码语义与尚未证明的解释

- C2C `src/mcp/http.ts` 使用无状态请求处理，每次 POST 创建服务/传输，`sessionIdGenerator=undefined`。保存的聊天 URL、连接授权和浏览器操作上下文是不同状态；任一读取错误不足以证明聊天 session 丢失。
- `src/auth/store.ts` 默认访问凭据有效期 1 小时，刷新凭据 30 天，支持持久保存；这说明授权刷新值得单独诊断，但本轮没有确认授权过期造成错误。没有读取任何凭据文件。
- 10 月 9 日筛选日志未出现 `Rejected MCP request` 或 `MCP request handling failed`；日志不记录每次成功请求，且混有不同工作区，所以该缺失不是对所有历史请求正常的证明。
- 尚未得到用户此前那一次网页内部错误的请求级对应证据，不能宣布其唯一根因已确认。当前成功读回也不能保证未来永不出现网络或授权故障。

## 后续操作约束

- 按用户要求：不再删除/重建插件。也不以浏览器超时或其他工作区工具错误作为重启、换地址的理由。
- 对本项目固定使用实际代码根目录。避免在外层目录再次启动另一套同名 C2C；本轮只报告现状，未停止任何现有进程。
- 连接恢复与代码批准分别验证。等待原 Project 聊天的真实独立审查结果；保留 `c2c_fix_p1_execution_void` 既有 BLOCKED 检查点。

## 已读取的证据文件

- C2C checkout：`src/mcp/http.ts`、`src/auth/store.ts`、`src/auth/middleware.ts`、`src/bridge/server.ts`；相关 workspace/runtime 路径代码搜索。
- C2C 状态目录：两个工作区 runtime/endpoints/sessions 的非凭据字段；bridge 日志的错误/启动匹配行；execution record/output index 的非凭据元数据。
- 项目：README.md；`execution_output/c2c_realtime_ingestion_reliability_and_exit_v1/summary.md`。
- 网页：原 EDGE OS Project 聊天的 workspace/README/执行输出读回。

本轮没有运行应用测试；18 / 208 / 315 是此前已记录测试结果，正在由网页独立检查。
