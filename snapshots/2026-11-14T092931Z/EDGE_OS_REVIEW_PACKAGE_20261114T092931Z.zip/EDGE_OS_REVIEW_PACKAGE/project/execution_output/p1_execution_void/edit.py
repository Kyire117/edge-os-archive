from pathlib import Path
p=Path('app/wallet_follow_v2.py')
s=p.read_text(encoding='utf-8').replace('from app.strict_ledger import StrictPaperLedger','from app.strict_ledger import StrictPaperLedger, validate_void_resolution')
a=s.index('    def record_resolution(');b=s.index('    def wallet_metrics(',a)
s=s[:a]+'''    def reconcile_void(self, episode_id: str, *, observed_at: datetime,
                       authoritative_source: str, evidence: dict[str, Any]) -> bool:
        """Explicit historical correction; retain original settlement and episode evidence."""
        return self.record_resolution(episode_id, status="VOID", observed_at=observed_at,
            authoritative_source=authoritative_source, payout_per_share="0.5",
            evidence=evidence, reconcile_void=True)

    def record_resolution(self, episode_id: str, *, status: str, observed_at: datetime,
                          authoritative_source: str | None = None,
                          winning_token_id: str | None = None,
                          payout_per_share: Any | None = None,
                          evidence: dict[str, Any] | None = None,
                          reconcile_void: bool = False) -> bool:
        if status not in {"MARKET_CLOSED", "RESULT_PENDING", "FORMALLY_RESOLVED", "VOID", "API_FAILURE"}:
            raise ValueError("INVALID_RESOLUTION_STATUS")
        row = self.episode(episode_id)
        ledger = self.ledger(row["wallet"])
        when = _utc(observed_at).isoformat()
        # Financial effects, episode update, and correction audit commit together.
        with ledger._tx() as con:
            row = dict(con.execute("SELECT * FROM wallet_v2_episodes WHERE episode_id=?", (episode_id,)).fetchone())
            identity = MarketIdentity(row["condition_id"], row["first_token_id"], row["first_outcome"])
            payout = None
            if status == "FORMALLY_RESOLVED":
                if not authoritative_source or not winning_token_id or payout_per_share is None:
                    raise ValueError("MISSING_AUTHORITATIVE_RESOLUTION")
                payout = _decimal(payout_per_share)
                if payout not in (Decimal("0"), Decimal("1")) or payout != int(row["first_token_id"] == winning_token_id):
                    raise ValueError("INCONSISTENT_FORMAL_PAYOUT")
            elif status == "VOID":
                if winning_token_id is not None:
                    raise ValueError("VOID_HAS_NO_DIRECTIONAL_WINNER")
                payout = validate_void_resolution(identity, authoritative_source, payout_per_share, evidence or {})
            elif payout_per_share is not None or winning_token_id is not None:
                raise ValueError("NONFINAL_RESOLUTION_HAS_RESULT")
            if reconcile_void and (status != "VOID" or row["resolution_status"] != "VOID"):
                raise ValueError("NOT_A_HISTORICAL_VOID")
            terminal = status in {"FORMALLY_RESOLVED", "VOID"}
            correction = reconcile_void and row["payout_per_share"] is None
            if row["resolution_status"] in {"FORMALLY_RESOLVED", "VOID"} and not correction:
                if (row["resolution_status"] == status and row["winning_token_id"] == winning_token_id
                        and row["payout_per_share"] is not None and _decimal(row["payout_per_share"]) == payout):
                    return False
                raise ValueError("RESOLUTION_ALREADY_FINAL")
            details = dict(evidence or {})
            if correction:
                details["correction_of"] = {"episode_id":episode_id,
                    "original_resolution_evidence_json":row["resolution_evidence_json"],
                    "original_settled_at":row["settled_at"],
                    "original_settlement_id":hashlib.sha256(f"settle|{episode_id}|VOID".encode()).hexdigest()}
            if row["paper_order_id"]:
                key = (f"settle|{episode_id}|{status}" if terminal else f"settle|{episode_id}|{status}|{when}")
                if status == "VOID":
                    key += "|financial-void-v1"
                settlement_id = hashlib.sha256(key.encode()).hexdigest()
                ledger.record_settlement(settlement_id=settlement_id,identity=identity,status=status,
                    observed_at=when,authoritative_source=authoritative_source,payout_per_share=payout,
                    details=details,connection=con)
            serialized = json.dumps(details,sort_keys=True,separators=(",", ":"),default=str)
            con.execute("""UPDATE wallet_v2_episodes SET resolution_status=?,winning_token_id=?,direction_correct=?,payout_per_share=?,authoritative_source=?,settled_at=?,resolution_evidence_json=? WHERE episode_id=?""",
                (status,winning_token_id,int(row["first_token_id"] == winning_token_id) if status == "FORMALLY_RESOLVED" else None,
                 str(payout) if payout is not None else None,authoritative_source,when if terminal else None,serialized,episode_id))
            if correction:
                con.execute("INSERT INTO wallet_v2_audit(strategy_version,episode_id,action,observed_at,evidence_json) VALUES(?,?,?,?,?)",
                    (self.strategy_version,episode_id,"VOID_FINANCIAL_RECONCILIATION",when,serialized))
        return True

'''+s[b:]
s=s.replace('for x in filled if x["resolution_status"] == "FORMALLY_RESOLVED"','for x in filled if x["resolution_status"] == "FORMALLY_RESOLVED" or (x["resolution_status"] == "VOID" and x["payout_per_share"] is not None)')
p.write_text(s,encoding='utf-8')
p=Path('app/wallet_follow_runtime.py');s=p.read_text(encoding='utf-8')
s=s.replace('if x["resolution_status"]=="FORMALLY_RESOLVED" and x["paper_status"] in {"FILLED","PARTIAL"}','if (x["resolution_status"]=="FORMALLY_RESOLVED" or (x["resolution_status"]=="VOID" and x["payout_per_share"] is not None)) and x["paper_status"] in {"FILLED","PARTIAL"}')
s=s.replace('"resolved":market.get("resolved"),"resolution_source":market.get("resolution_source")}','"resolved":market.get("resolved"),"resolution_source":market.get("resolution_source"),\n                          "resolution_is_void":market.get("resolution_is_void"),\n                          "condition_id":market.get("condition_id"),"token_id":market.get("token_id"),\n                          "outcome":market.get("outcome"),"settlement_price":market.get("settlement_price"),\n                          "authoritative_source":market.get("authoritative_source") or market.get("resolution_source")}')
s=s.replace('source=market.get("resolution_source")','source=market.get("authoritative_source") or market.get("resolution_source")')
s=s.replace('status="VOID"; winning=None; payout=None','status="VOID"; winning=None; payout=market.get("settlement_price")')
p.write_text(s,encoding='utf-8')
p=Path('app/polymarket.py');s=p.read_text(encoding='utf-8').replace('"resolution_source": market.get("resolutionSource"),','"resolution_source": market.get("resolutionSource"),\n        "authoritative_source": market.get("resolutionSource"),')
p.write_text(s,encoding='utf-8')
