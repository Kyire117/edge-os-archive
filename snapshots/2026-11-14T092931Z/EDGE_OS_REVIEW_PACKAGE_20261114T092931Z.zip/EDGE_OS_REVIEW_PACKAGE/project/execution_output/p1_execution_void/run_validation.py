import os,subprocess,json,sys
from pathlib import Path
root=Path.cwd();out=root/'execution_output/p1_execution_void';env=os.environ.copy()
temp=Path(r'C:\Users\Kyrie\Documents\EDGE OS 101\execution_output\p1temp');temp.mkdir(exist_ok=True)
env.update(TEMP=str(temp),TMP=str(temp),DATABASE_PATH=str(temp/'isolated.db'),PYTHONIOENCODING='utf-8')
commands=[('targeted_final',[sys.executable,'-m','pytest','tests/test_p1_execution_void.py','tests/test_strict_paper_iteration1.py','tests/test_strict_paper_iteration2.py','tests/test_wallet_follow_v2.py','tests/test_wallet_follow_v2_activation.py','tests/test_v2_timestamp_model.py','-q','-p','no:cacheprovider','--basetemp',str(temp/'targetfinal')]),
 ('full',[sys.executable,'-m','pytest','tests','-q','-p','no:cacheprovider','--basetemp',str(temp/'full')]),
 ('compileall',[sys.executable,'-m','compileall','-q','app','tests']),('diff_check',['git','diff','--check'])]
results=[]
for name,cmd in commands:
 with (out/(name+'.txt')).open('w',encoding='utf-8') as f:
  p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exit_code=p.returncode,output_file=str(out/(name+'.txt'))));print(name,p.returncode,flush=True)
 (out/'validation.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
 if p.returncode:sys.exit(p.returncode)
