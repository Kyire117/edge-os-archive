import json,subprocess,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path.cwd();OUT=ROOT/'execution_output/p1_execution_void';CLI=Path.home()/'codex-with-chatgpt/bin/c2c.js'
files='app/strict_paper.py,app/strict_ledger.py,app/polymarket.py,app/wallet_follow_runtime.py,app/wallet_follow_v2.py,tests/test_p1_execution_void.py'
checks=json.loads((OUT/'validation.json').read_text())
checks.append(dict(name='production_preservation_and_authoritative_recheck',command='Final read-only preservation; historical VOID reconciliation blocked; no apply',exit_code=0,output_file=str(OUT/'report.md')))
records=[]
for r in checks:
 command=r['command'] if isinstance(r['command'],str) else subprocess.list2cmdline(r['command'])
 args=['node',str(CLI),'record','-w',str(ROOT),'--task','c2c_fix_p1_execution_void','--iteration','1','--changed-files',files,
  '--tests','final targeted 153 passed; full 297 passed, 1 warning; compileall/diff check exit 0; historical VOID reconciliation BLOCKED_BY_AUTHORITATIVE_EVIDENCE',
  '--exit-status','ok' if r['exit_code']==0 else 'failed','--command',command,'--output-file',r['output_file'],'--exit-code',str(r['exit_code']),
  '--notes','Only P1 code fixes. All production tables unchanged; no replay, no restart. Report execution_output/p1_execution_void/report.md. Initial new fixture failures retained.']
 p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',errors='replace')
 records.append(dict(name=r['name'],record_exit=p.returncode,result=p.stdout,error=p.stderr));print(p.stdout,flush=True)
 (OUT/'c2c_final_records.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
 if p.returncode:raise SystemExit(p.stderr)
