import json,sqlite3,sys,socket
from pathlib import Path
from decimal import Decimal
from unittest.mock import patch
sys.path.insert(0,str(Path.cwd()))
from preservation import capture,ro,SOURCE,OUT
from app.strict_ledger import StrictPaperLedger
before=json.loads((OUT/'production_before.json').read_text(encoding='utf-8'));after=capture()
assert before['tables']==after['tables'] and before['main_sha256']==after['main_sha256']
original=sqlite3.connect
def only_read(database,*args,**kwargs):
 if str(database)==str(SOURCE):return ro(SOURCE)
 return original(database,*args,**kwargs)
with patch('sqlite3.connect',only_read):
 reconciliations=[dict(account_id=a['account_id'],**StrictPaperLedger(SOURCE,account_id=a['account_id']).reconcile()) for a in after['rows']['strict_accounts']]
 audit=StrictPaperLedger(SOURCE).verify_audit_chain()
assert len(reconciliations)==9 and all(r['ok'] for r in reconciliations) and audit['ok']
s=socket.socket();running=s.connect_ex(('127.0.0.1',8000))==0;s.close();assert not running
preservation=dict(main_sha256_before=before['main_sha256'],main_sha256_after=after['main_sha256'],
 all_tables_unchanged=before['tables']==after['tables'],tables=after['tables'],quick_check=after['quick_check'],
 account_reconciliation=reconciliations,audit=audit,reserved_cash=str(sum(Decimal(a['reserved_cash']) for a in after['rows']['strict_accounts'])),
 open_order_count=sum(r['status']=='OPEN' for r in after['rows']['strict_orders']),
 historical_incomplete_episodes=sum(r['rejection_reason']=='EXECUTION_COMMIT_INCOMPLETE' for r in after['rows']['wallet_v2_episodes']),
 backend_running=running,production_reconciliation='BLOCKED_BY_AUTHORITATIVE_EVIDENCE; no production writes')
(OUT/'final_preservation.json').write_text(json.dumps(preservation,indent=2,ensure_ascii=False),encoding='utf-8')
backup=json.loads((OUT/'backup.json').read_text());rechecks=json.loads((OUT/'authoritative_recheck.json').read_text())
positions=[]
for e in after['rows']['wallet_v2_episodes']:
 if e['episode_id'] in {r['episode_id'] for r in rechecks}:
  pos=next(p for p in after['rows']['strict_positions'] if p['account_id']=='wallet-follow-v2.0:'+e['wallet'] and p['condition_id']==e['condition_id'] and p['token_id']==e['first_token_id'] and p['outcome']==e['first_outcome'])
  account=next(a for a in after['rows']['strict_accounts'] if a['account_id']==pos['account_id'])
  positions.append(dict(episode_id=e['episode_id'],before=pos,after=pos,account_before=account,account_after=account))
(OUT/'positions_before_after.json').write_text(json.dumps(positions,indent=2),encoding='utf-8')
lines=['# P1 Execution / VOID 修复报告','',
 'TASK_ID: c2c_fix_p1_execution_void; ITERATION: 1',
 'STATE: EXECUTED_LOCAL; 代码完成，生产历史修正 BLOCKED_BY_AUTHORITATIVE_EVIDENCE','',
 '## 本轮文件',
 '- app/strict_paper.py：共享 executable_level；预算不足形成有效便宜档成交时 break；整档 microscopic 容量才可 continue。',
 '- app/strict_ledger.py：价格优先使用相同量化谓词；拒绝零成本 fill；权威 VOID @0.5 财务结算与对账；可加入调用者事务。',
 '- app/polymarket.py：保留公开 resolutionSource 为 authoritative_source。',
 '- app/wallet_follow_runtime.py：传递精确 VOID payout、identity 和来源证据；财务 ROI denominator 纳入已财务结算 VOID。',
 '- app/wallet_follow_v2.py：VOID 验证、原子财务/episode 提交、显式 append-only reconciliation；财务 ROI denominator 修正，方向胜率不纳入 VOID。',
 '- tests/test_p1_execution_void.py：20 项确定性回归，全部使用临时数据库。','',
 '## 不变量',
 '价档有效性 = quantity >= frozen min_quantity 且 floor(price × quantity, MONEY_QUANTUM) > 0。',
 '整个允许容量无效才可跳过；整个容量有效但预算限制后的 quantity/cost 无效时停止，不允许到更贵档套利量化边界。',
 'quantity/money precision、逐档成本/手续费 rounding、ROI/depth/IOC/frozen rule config 未变。25−0.000001 按既有 completion tolerance 安全结束，剩余现金立即释放。',
 'financial VOID 必须 resolved=true、resolution_is_void=true、非空 source、精确 condition/token/outcome，以及 source payout=0.5；VOID 不得有 directional winner。',
 '财务结算以既有 MONEY_QUANTUM 向下量化 quantity×0.5，归零 quantity/cost basis/reserved shares，释放 OPEN orders，记录现金/mark/settlement/audit。',
 '原始 VOID evidence 不删除；历史 correction 新 settlement ID 带 financial-void-v1，原始 episode evidence 嵌入 correction evidence。',
 'ledger financial effect、episode update、correction audit 共用 BEGIN IMMEDIATE 事务；失败一起回滚。','',
 '## 验证',
 '- targeted 新回归及相关 strict/V2/integration/timestamp suites：153 passed，1 warning，exit 0。',
 '- full python -m pytest tests -q：297 passed，1 warning，exit 0。',
 '- python -m compileall -q app tests：exit 0。',
 '- git diff --check：exit 0；仅既有 LF/CRLF 提示。',
 '- 初始新测试夹具错误保留 target1/target2 输出；修正了 crossed book、缺失 evidence 参数、错误 status API key，最终全部通过。',
 '- 未改 frontend，不执行额外 frontend 工作。','',
 '## 生产备份',f"- 路径：{backup['path']}",f"- SHA256：{backup['sha256']}",f"- bytes：{backup['size']}; integrity_check=ok。",'SQLite backup 包含已提交 WAL；备份在 Git ignore 内。','',
 '## 权威重查与生产处理',
 '两个目标 market 的标准公开 API 查询与保留证书验证的 direct HTTPS 重试均失败（PolymarketError/request failed，direct retry ConnectError）。未取得任何新的权威 settlement response。',
 '两个目标均 BLOCKED_BY_AUTHORITATIVE_EVIDENCE；没有执行 --apply，没有修改生产 positions/episodes/accounts，也没有猜测 payout。','']
for item in positions:
 p=item['before'];lines.append(f"- {item['episode_id']}: quantity {p['quantity']} → {p['quantity']}; cost_basis {p['cost_basis']} → {p['cost_basis']}; realized_pnl {p['realized_pnl']} → {p['realized_pnl']}; payout remains NULL。")
lines+=['', '共用账户完整前后数值见 positions_before_after.json；生产全表 count/hash 见 final_preservation.json。',
 '## 保存证明',f"- 主 DB SHA256 before=after={after['main_sha256']}。",f"- {len(after['tables'])} 表 contents/count/hash 完全一致（全部生产表均无改变）。",
 '- 9 account reconciliation 均 ok；strict audit chain ok；quick_check=ok；reserved_cash=0；OPEN orders=0。',
 '- 74 EXECUTION_COMMIT_INCOMPLETE cancelled attempts、orders、decisions、fills、原始 VOID settlements 全量内容保持原样。',
 '- strategy config/live_orders=false、wallets/raw trades/discovery/market metadata、所有非相关表无漂移。',
 '- 没有 production schema/init/migration、历史 replay、Git cleanup、服务启动或 restart；P2/P3 未处理。','',
 '## 限制与下一步',
 '代码测试通过不等于两个历史 VOID 已修复。只有再次取得完整权威证据后，才可执行显式 reconciliation，并重新核对全表差异及账户/audit。',
 '证据目录：execution_output/p1_execution_void。生产历史修正仍阻塞，停止于此；不启动 V4。']
(OUT/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('All production tables unchanged; 9 accounts/audit valid; historical VOID reconciliation blocked')
