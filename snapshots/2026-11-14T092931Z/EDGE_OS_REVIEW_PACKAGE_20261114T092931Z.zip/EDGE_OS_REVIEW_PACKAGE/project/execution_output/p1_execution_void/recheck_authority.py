import asyncio, json, sqlite3, sys
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,str(Path.cwd()))
from preservation import capture, ro, sha, SOURCE, OUT
from app.polymarket import PolymarketClient,normalize_market_state
from app.config import settings
from app.strict_paper import MarketIdentity
from app.strict_ledger import validate_void_resolution
IDS=['474f12ce92176f3798bb5b807c943959c2cd2da2b313b513ae33678b4cd077a0',
     '7c626d86785fefbd81d82661d1ec3b4a5e73d8fe94791d170892e10646b4751d']
pre=capture();baseline=json.loads((OUT/'production_before.json').read_text(encoding='utf-8'))
assert pre['tables']==baseline['tables'],'Production drifted during tests; abort'
assert pre['quick_check']==['ok']
assert settings.database_path=='data/edge_mvp.db','Unexpected DB config'
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
backup=SOURCE.parent/'backups'/f'edge_mvp.pre-p1-void-{stamp}.db';backup.parent.mkdir(exist_ok=True)
with ro(SOURCE) as src:
 with sqlite3.connect(backup) as dst:src.backup(dst)
with ro(backup) as c:integrity=[r[0] for r in c.execute('PRAGMA integrity_check')]
assert integrity==['ok']
info=dict(path=str(backup),sha256=sha(backup),size=backup.stat().st_size,integrity_check=integrity,utc=stamp)
(OUT/'backup.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
assert capture(backup)['tables']==pre['tables']
(OUT/'pre_reconciliation.json').write_text(json.dumps(pre,indent=2,ensure_ascii=False),encoding='utf-8')
print('Consistent backup integrity ok',flush=True)
episodes={e['episode_id']:e for e in pre['rows']['wallet_v2_episodes']}
async def verify(client,eid):
 e=episodes[eid];ident=MarketIdentity(e['condition_id'],e['first_token_id'],e['first_outcome'])
 result=dict(episode_id=eid,requested_at=datetime.now(timezone.utc).isoformat(),status='BLOCKED_BY_AUTHORITATIVE_EVIDENCE')
 try:
  raw=None;market=None
  for closed in (False,True):
   payload=await client._get(f'{settings.gamma_api}/markets',{'clob_token_ids':ident.token_id,'closed':str(closed).lower(),'limit':5},attempts=2,timeout_seconds=12)
   values=payload if isinstance(payload,list) else payload.get('data',[])
   for item in values:
    try:normalized=normalize_market_state(item,ident.token_id)
    except Exception:continue
    if normalized['condition_id']==ident.condition_id and normalized['outcome']==ident.outcome:
     raw=item;market=normalized;break
   if market is not None:break
  result['received_at']=datetime.now(timezone.utc).isoformat()
  if market is None:raise ValueError('EXACT_MARKET_NOT_FOUND')
  source=market.get('authoritative_source');evidence=dict(market)
  evidence.update(request_timestamp=result['requested_at'],received_timestamp=result['received_at'],
      endpoint=f'{settings.gamma_api}/markets',request_params={'clob_token_ids':ident.token_id,'closed':str(closed).lower(),'limit':5},
      raw_market=raw)
  validate_void_resolution(ident,source,market.get('settlement_price'),evidence)
  result.update(status='VERIFIED',authoritative_source=source,evidence=evidence)
 except Exception as exc:
  result.update(error_type=type(exc).__name__,error=str(exc))
 print(eid[:12],result['status'],flush=True)
 return result
async def main():
 client=PolymarketClient()
 try:return await asyncio.gather(*(verify(client,eid) for eid in IDS))
 finally:await client.close()
results=asyncio.run(main());(OUT/'authoritative_recheck.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf-8')
assert capture()['tables']==pre['tables'],'Read-only network recheck changed production'
