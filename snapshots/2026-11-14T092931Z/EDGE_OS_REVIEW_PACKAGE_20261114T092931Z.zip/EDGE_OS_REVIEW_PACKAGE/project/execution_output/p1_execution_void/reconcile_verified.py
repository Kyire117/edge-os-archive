import json,sqlite3,sys,shutil,socket
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal,ROUND_DOWN
from unittest.mock import patch
sys.path.insert(0,str(Path.cwd()))
from preservation import capture, ro, SOURCE, OUT
from app.wallet_follow_v2 import WalletFollowV2
from app.strict_ledger import StrictPaperLedger
D=Decimal
pre=json.loads((OUT/'pre_reconciliation.json').read_text(encoding='utf-8'))
checks=json.loads((OUT/'authoritative_recheck.json').read_text(encoding='utf-8'))
backup=json.loads((OUT/'backup.json').read_text(encoding='utf-8'))
assert capture()['tables']==pre['tables'],'Production drift since backup'
assert pre['quick_check']==['ok']
verified=[x for x in checks if x['status']=='VERIFIED'];ids={x['episode_id'] for x in verified}
episodes={r['episode_id']:r for r in pre['rows']['wallet_v2_episodes']}
wallets={episodes[eid]['wallet'] for eid in ids}
accounts={'wallet-follow-v2.0:'+w for w in wallets}
keys={(episodes[eid]['condition_id'],episodes[eid]['first_token_id'],episodes[eid]['first_outcome']) for eid in ids}
now=datetime.now(timezone.utc)

def reconcile_all(path):
 original=sqlite3.connect
 def read_only(database,*args,**kwargs):
  if str(database)==str(path):return ro(Path(database))
  return original(database,*args,**kwargs)
 results=[]
 with patch('sqlite3.connect',read_only):
  for a in pre['rows']['strict_accounts']:
   ledger=StrictPaperLedger(path,account_id=a['account_id']);result=ledger.reconcile()
   results.append(dict(account_id=a['account_id'],**result))
  audit=StrictPaperLedger(path).verify_audit_chain()
 return results,audit

def compare(before,after):
 changed=[t for t in before['tables'] if before['tables'][t]!=after['tables'][t]]
 allowed={'wallet_v2_episodes','strict_accounts','strict_positions','strict_settlements','strict_cash_ledger','strict_marks','strict_audit_events','wallet_v2_audit','sqlite_sequence'}
 assert set(changed)<=allowed,(changed,'unrelated table drift')
 for t,key in [('wallet_v2_episodes','episode_id'),('strict_accounts','account_id')]:
  old={r[key]:r for r in before['rows'][t]};new={r[key]:r for r in after['rows'][t]};assert old.keys()==new.keys()
  scope=ids if t=='wallet_v2_episodes' else accounts
  assert all(new[k]==v for k,v in old.items() if k not in scope)
  if t=='wallet_v2_episodes':
   allowed_fields={'payout_per_share','authoritative_source','settled_at','resolution_evidence_json'}
   assert all(all(new[k][f]==v[f] for f in v if f not in allowed_fields) for k,v in old.items())
 old={ (r['account_id'],r['condition_id'],r['token_id'],r['outcome']):r for r in before['rows']['strict_positions']}
 new={ (r['account_id'],r['condition_id'],r['token_id'],r['outcome']):r for r in after['rows']['strict_positions']}
 assert old.keys()==new.keys()
 assert all(new[k]==v for k,v in old.items() if k[0] not in accounts or k[1:] not in keys)
 for t,key in [('strict_settlements','settlement_id'),('strict_marks','mark_id'),('strict_cash_ledger','ledger_id'),('strict_audit_events','event_id'),('wallet_v2_audit','audit_id')]:
  # Cash primary identifier is read from schema instead of assuming its name.
  if t=='strict_cash_ledger':key=next(iter(before['rows'][t][0]))
  old={r[key]:r for r in before['rows'][t]};new={r[key]:r for r in after['rows'][t]}
  assert all(new.get(k)==v for k,v in old.items()),('append-only history changed',t)
  assert len(new)-len(old)==len(verified),('unexpected append count',t)
 assert len([r for r in after['rows']['strict_orders'] if r['status']=='OPEN'])==0
 assert all(D(r['reserved_cash'])==0 for r in after['rows']['strict_accounts'])
 for eid in ids:
  e=next(r for r in after['rows']['wallet_v2_episodes'] if r['episode_id']==eid)
  assert e['resolution_status']=='VOID' and e['direction_correct'] is None and D(e['payout_per_share'])==D('.5')
  pkey=('wallet-follow-v2.0:'+e['wallet'],e['condition_id'],e['first_token_id'],e['first_outcome'])
  pos=newpos={ (r['account_id'],r['condition_id'],r['token_id'],r['outcome']):r for r in after['rows']['strict_positions']}[pkey]
  assert all(D(pos[f])==0 for f in ('quantity','cost_basis','reserved_quantity'))
 assert after['quick_check']==['ok']
 return changed

def apply(path):
 sim=WalletFollowV2(path)
 for result in verified:
  assert sim.reconcile_void(result['episode_id'],observed_at=now,authoritative_source=result['authoritative_source'],evidence=result['evidence'])
 after=capture(path);changed=compare(pre,after);account_checks,audit=reconcile_all(path)
 assert len(account_checks)==9 and all(r['ok'] for r in account_checks) and audit['ok']
 for result in verified:
  assert not sim.reconcile_void(result['episode_id'],observed_at=now,authoritative_source=result['authoritative_source'],evidence=result['evidence'])
 assert capture(path)['tables']==after['tables'],'Second run is not a no-op'
 return dict(after=after,changed_tables=changed,account_reconciliation=account_checks,audit=audit)
trial=OUT/'reconciliation_trial.db'
with ro(Path(backup['path'])) as src:
 with sqlite3.connect(trial) as dst:src.backup(dst)
trial_result=apply(trial)
(OUT/'reconciliation_trial.json').write_text(json.dumps(trial_result,indent=2,ensure_ascii=False),encoding='utf-8')
assert capture()['tables']==pre['tables']
print('Temporary backup trial passed, all 9 accounts and append-only audit reconcile',flush=True)
if '--apply' not in sys.argv:sys.exit(0)
s=socket.socket();running=s.connect_ex(('127.0.0.1',8000))==0;s.close();assert not running
result=apply(SOURCE)
result.update(authoritative_rechecks=checks,backup=backup,completed_at=now.isoformat())
(OUT/'reconciliation_result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
print('Production reconciliation committed:',len(verified),'verified VOID positions; unrelated tables unchanged',flush=True)
