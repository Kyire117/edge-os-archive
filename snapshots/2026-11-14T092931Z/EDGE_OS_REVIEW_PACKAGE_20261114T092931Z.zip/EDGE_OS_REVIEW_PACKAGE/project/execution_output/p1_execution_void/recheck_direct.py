import asyncio,json,sys
from pathlib import Path
from datetime import datetime,timezone
import httpx
sys.path.insert(0,str(Path.cwd()))
from preservation import capture,OUT
from app.polymarket import normalize_market_state
from app.strict_paper import MarketIdentity
from app.strict_ledger import validate_void_resolution
pre=json.loads((OUT/'pre_reconciliation.json').read_text(encoding='utf-8'))
results=json.loads((OUT/'authoritative_recheck.json').read_text(encoding='utf-8'))
episodes={e['episode_id']:e for e in pre['rows']['wallet_v2_episodes']}
async def attempt(client,result):
 if result['status']=='VERIFIED':return
 e=episodes[result['episode_id']];ident=MarketIdentity(e['condition_id'],e['first_token_id'],e['first_outcome'])
 endpoint='https://gamma-api.polymarket.com/markets';params={'clob_token_ids':ident.token_id,'closed':'true','limit':5}
 at=datetime.now(timezone.utc).isoformat()
 try:
  response=await client.get(endpoint,params=params);response.raise_for_status();values=response.json()
  received=datetime.now(timezone.utc).isoformat()
  for raw in values:
   m=normalize_market_state(raw,ident.token_id)
   if m['condition_id']!=ident.condition_id or m['outcome']!=ident.outcome:continue
   evidence={**m,'request_timestamp':at,'received_timestamp':received,'endpoint':endpoint,'request_params':params,
      'http_status':response.status_code,'raw_market':raw,'verification_route':'direct HTTPS; certificate validation enabled'}
   validate_void_resolution(ident,m['authoritative_source'],m.get('settlement_price'),evidence)
   result.update(status='VERIFIED',authoritative_source=m['authoritative_source'],evidence=evidence,received_at=received)
   print(result['episode_id'][:12],'VERIFIED',flush=True);return
  raise ValueError('EXACT_AUTHORITATIVE_VOID_NOT_FOUND')
 except Exception as exc:
  result['direct_retry']={'requested_at':at,'error_type':type(exc).__name__,'status':'BLOCKED_BY_AUTHORITATIVE_EVIDENCE'}
  print(result['episode_id'][:12],type(exc).__name__,flush=True)
async def main():
 async with httpx.AsyncClient(trust_env=False,timeout=httpx.Timeout(15,connect=10)) as client:
  await asyncio.gather(*(attempt(client,r) for r in results))
asyncio.run(main())
(OUT/'authoritative_recheck.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf-8')
assert capture()['tables']==pre['tables']
