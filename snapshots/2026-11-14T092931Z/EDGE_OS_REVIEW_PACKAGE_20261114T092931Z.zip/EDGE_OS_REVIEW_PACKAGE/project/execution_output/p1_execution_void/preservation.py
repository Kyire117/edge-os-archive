import hashlib,json,sqlite3,socket,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;SOURCE=ROOT/'data/edge_mvp.db'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ro(p):
 c=sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('PRAGMA query_only=ON');return c
def capture(p=SOURCE):
 with ro(p) as c:
  c.execute('BEGIN');tables={};rows={}
  for t, in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
   values=[dict(r) for r in c.execute('SELECT * FROM "'+t.replace('"','""')+'"')];rows[t]=values
   encoded=sorted(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),default=str) for x in values)
   tables[t]={'count':len(values),'sha256':hashlib.sha256('\n'.join(encoded).encode()).hexdigest()}
  result=dict(captured_at=datetime.now(timezone.utc).isoformat(),source=str(p),main_sha256=sha(p),quick_check=[r[0] for r in c.execute('PRAGMA quick_check')],tables=tables,rows=rows)
  c.rollback();return result
if __name__=='__main__':
 s=socket.socket();active=s.connect_ex(('127.0.0.1',8000))==0;s.close()
 if active:raise SystemExit('Unexpected backend listener; abort')
 result=capture();(OUT/'production_before.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
