"""Read-only diagnostic; never instantiate production execution/ledger classes."""
import asyncio, csv, hashlib, json, math, statistics, subprocess, sys, time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import httpx
import urllib.request
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.wallet_follow_runtime import _as_datetime
OUT=ROOT/'execution_output'/'timestamp_diagnosis_20261002'
OUT.mkdir(exist_ok=True)
def utc(): return datetime.now(timezone.utc)
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def ms(a,b): return round((_as_datetime(a)-_as_datetime(b)).total_seconds()*1000,3)
def stats(v):
    if not v:return {'n':0}
    s=sorted(v);return {'n':len(s),'min':s[0],'median':statistics.median(s),'p95':s[math.ceil(.95*len(s))-1],'max':s[-1]}
def snapshot():
    con=sqlite3.connect((ROOT/'data/edge_mvp.db').as_uri()+'?mode=ro',uri=True)
    con.row_factory=sqlite3.Row;con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
    tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    counts={t:con.execute('SELECT COUNT(*) FROM "'+t+'"').fetchone()[0] for t in tables}
    versions=[dict(r) for r in con.execute('SELECT * FROM wallet_v2_versions')]
    restart=con.execute("SELECT * FROM wallet_v2_audit WHERE action='CLEAN_FORWARD_RESTART' ORDER BY audit_id DESC LIMIT 1").fetchone()
    cutoff=json.loads(restart['evidence_json'])['forward_started_at']
    episodes=[];decisions=[];runtime=[];raws=[]
    for r in con.execute('SELECT * FROM wallet_v2_episodes WHERE julianday(first_detected_at)>=julianday(?) ORDER BY first_detected_at',(cutoff,)):
        e=dict(r);episodes.append(e)
        for d in con.execute('SELECT * FROM strict_decisions WHERE signal_id=?',(e['first_signal_id'],)):
            d=dict(d);d['evidence']=json.loads(d.pop('evidence_json'));decisions.append(d)
        for d in con.execute('SELECT * FROM wallet_v2_runtime_events WHERE episode_id=?',(e['episode_id'],)):
            d=dict(d);d['evidence']=json.loads(d.pop('evidence_json'));runtime.append(d)
        t=con.execute('SELECT trade_key,timestamp,raw_json FROM trades WHERE trade_key=?',(e['first_signal_id'],)).fetchone()
        if t:
            raw=json.loads(t['raw_json']);raws.append({'episode_id':e['episode_id'],'trade_key':t['trade_key'],'stored_timestamp':t['timestamp'],'raw':raw})
    # Roll back read transaction; no product functions capable of writing called.
    con.rollback();con.close()
    save('snapshot.json',{'captured_at':utc(),'cutoff':cutoff,'counts':counts,'versions':versions,'episodes':episodes,'decisions':decisions,'runtime_events':runtime,'leader_payloads':raws,'db_mode':'mode=ro; PRAGMA query_only=ON; BEGIN snapshot; ROLLBACK'})
    print(json.dumps({'cutoff':cutoff,'episodes':len(episodes),'reasons':Counter(e['rejection_reason'] for e in episodes),'decisions':len(decisions),'runtime_events':len(runtime)},ensure_ascii=False),flush=True)
    return episodes
async def probe(episodes):
    tokens=list(dict.fromkeys(e['first_token_id'] for e in episodes if e['rejection_reason'] in ('FUTURE_ORDER_BOOK_TIMESTAMP','QUOTE_PREDATES_SIGNAL','EXECUTION_BOOK_NOT_NEWER')))
    async with httpx.AsyncClient(proxy=urllib.request.getproxies().get('https'),timeout=12) as client:
        async def request(route,params=None):
            before=utc();mono=time.monotonic()
            try:
                r=await client.get('https://clob.polymarket.com/'+route,params=params)
                after=utc();rtt=(time.monotonic()-mono)*1000
                try: raw=r.json()
                except ValueError:raw=r.text[:400]
                data={'route':route,'params':params,'request_utc':before.isoformat(),'receive_utc':after.isoformat(),'monotonic_rtt_ms':round(rtt,3),'http_status':r.status_code,'raw':raw}
                data['http_date']=r.headers.get('date');data['cache_control']=r.headers.get('cache-control');data['age']=r.headers.get('age')
                if r.status_code==200:
                    stamp=raw.get('timestamp') if route=='book' else raw
                    norm=_as_datetime(stamp);mid=before+(after-before)/2
                    data.update(raw_timestamp=stamp,raw_type=type(stamp).__name__,digit_count=len(str(stamp).replace('.','')),normalized_utc=norm.isoformat(),source_minus_request_ms=ms(norm,before),source_minus_receive_ms=ms(norm,after),server_minus_local_midpoint_ms=ms(norm,mid))
                return data
            except Exception as exc:return {'route':route,'params':params,'request_utc':before.isoformat(),'receive_utc':utc().isoformat(),'error_type':type(exc).__name__,'error':str(exc)[:180]}
        times=[]
        for i in range(20):
            times.append(await request('time'));save('time_samples.json',times)
            print('time',i+1,times[-1].get('server_minus_local_midpoint_ms',times[-1].get('error_type')),flush=True)
            await asyncio.sleep(.1)
        books=[];valid=[]
        for token in tokens:
            b=await request('book',{'token_id':token});books.append(b)
            if b.get('http_status')==200:valid.append(token)
            save('book_samples.json',books)
            if len(valid)>=4:break
        if valid:
            while sum(b.get('http_status')==200 for b in books)<20 and len(books)<max(40,len(tokens)):
                b=await request('book',{'token_id':valid[len(books)%len(valid)]});books.append(b);save('book_samples.json',books)
        pairs=[]
        for token in valid[:4]:
            for repeat in range(4):
                a=await request('book',{'token_id':token});start=time.monotonic();await asyncio.sleep(.5);wait=(time.monotonic()-start)*1000;b=await request('book',{'token_id':token})
                pair={'token_id':token,'repeat':repeat,'frozen_wait_target_ms':500,'actual_monotonic_wait_ms':wait,'a':a,'b':b}
                if a.get('http_status')==b.get('http_status')==200:
                    pair.update(timestamp_equal=a['raw_timestamp']==b['raw_timestamp'],timestamp_delta_ms=ms(b['normalized_utc'],a['normalized_utc']),a_hash=a['raw'].get('hash'),b_hash=b['raw'].get('hash'),levels_changed=any(a['raw'].get(k)!=b['raw'].get(k) for k in ('bids','asks')))
                pairs.append(pair);save('paired_books.json',pairs)
                print('pair',len(pairs),pair.get('timestamp_delta_ms'),flush=True)
        # Adjacent time sample quantifies comparison error; do not mistake this for simultaneous server time.
        for b in books:
            if b.get('http_status')==200:
                t=await request('time');b['adjacent_time_probe']=t
                if t.get('http_status')==200:b['book_source_minus_adjacent_clob_server_time_ms']=ms(b['normalized_utc'],t['normalized_utc'])
        save('book_samples.json',books)
        offsets=[t['server_minus_local_midpoint_ms'] for t in times if 'server_minus_local_midpoint_ms' in t]
        summary={'clock_offset_ms':stats(offsets),'time_rtt_ms':stats([t['monotonic_rtt_ms'] for t in times if 'monotonic_rtt_ms' in t]),'book_samples':len(books),'successful_books':sum(b.get('http_status')==200 for b in books),'pairs':len(pairs),'valid_pairs':sum('timestamp_equal' in p for p in pairs),'equal_timestamp_pairs':sum(p.get('timestamp_equal',False) for p in pairs),'book_source_minus_receive_ms':stats([b['source_minus_receive_ms'] for b in books if 'source_minus_receive_ms' in b])}
        save('probe_summary.json',summary);print(json.dumps(summary),flush=True)
if __name__=='__main__':
    episodes=snapshot()
    if '--probe' in sys.argv:asyncio.run(probe(episodes))
