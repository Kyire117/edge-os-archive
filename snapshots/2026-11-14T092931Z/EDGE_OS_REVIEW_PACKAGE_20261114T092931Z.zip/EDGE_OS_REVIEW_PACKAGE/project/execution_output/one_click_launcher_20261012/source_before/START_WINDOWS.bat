@echo off
setlocal
cd /d "%~dp0"
echo.
echo ==============================================
echo   Polymarket Edge OS - Paper Only
echo ==============================================
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python was not found on this computer.
  echo Please install Python 3.11 or newer and retry.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo First run: preparing the local environment...
  py -m venv .venv
  if errorlevel 1 goto :venv_failed
)

rem A half-created .venv can survive a failed download. Always verify the
rem actual runtime packages instead of trusting that python.exe exists.
".venv\Scripts\python.exe" -c "import fastapi, httpx, pydantic, uvicorn, socksio" >nul 2>nul
if errorlevel 1 (
  echo Installing or repairing Python dependencies...
  ".venv\Scripts\python.exe" -m ensurepip --upgrade >nul 2>nul
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo.
    echo Primary package source failed. Retrying with Tsinghua PyPI mirror...
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
    if errorlevel 1 goto :deps_failed
  )
)

".venv\Scripts\python.exe" -c "import uvicorn" >nul 2>nul
if errorlevel 1 goto :deps_failed

start "" "dashboard.html"
echo Backend is starting. Keep this window open.
echo Dashboard will open at http://127.0.0.1:8000 automatically.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
exit /b 0

:venv_failed
echo.
echo [ERROR] Could not create the Python environment.
echo Please install or repair Python 3, then run this file again.
pause
exit /b 1

:deps_failed
echo.
echo [ERROR] Python dependencies could not be installed.
echo Check your network, then run START_WINDOWS.bat again.
echo If the error continues, delete only the .venv folder and retry.
pause
exit /b 1
