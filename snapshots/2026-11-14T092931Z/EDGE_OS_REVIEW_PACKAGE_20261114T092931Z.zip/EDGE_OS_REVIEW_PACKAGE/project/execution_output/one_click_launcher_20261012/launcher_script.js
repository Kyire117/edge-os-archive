
'use strict';
const statusBox=document.getElementById('status'),button=document.getElementById('start'),network=document.getElementById('network');
let busy=false,wantOpen=false;
function render(data){
 statusBox.textContent=data.message||'状态未知';
 button.disabled=busy||data.state==='STARTING'||data.state==='CONFLICT';
 button.textContent=data.state==='RUNNING'?'打开正在运行的 EDGE OS':data.state==='STARTING'?'正在启动…':'启动并打开 EDGE OS';
 const errors={BACKFILL_GAP_EXCEEDS_BOUND:'补漏缺口超过安全上限，实时通路需要处理',WSS_MESSAGE_TOO_BIG:'实时响应超过接收上限',TimeoutError:'实时请求超时'};
 network.textContent=data.state==='RUNNING'?`钱包监控：${data.monitor_running?'运行中':'未运行'}；实时通路：${data.fast_connected?'已连接':'未连接'}${data.fast_error?'；'+(errors[data.fast_error]||data.fast_error):''}`:'';
 network.className=data.state==='RUNNING'&&!data.fast_connected?'warn':'';
 if(wantOpen&&data.state==='RUNNING'){wantOpen=false;window.location.href='http://127.0.0.1:8000/?ui=20261012-runtime-ui-1';}
}
async function refresh(){if(busy)return;try{const response=await fetch('/status',{cache:'no-store',signal:AbortSignal.timeout(7000)});if(!response.ok)throw Error();render(await response.json());}catch{statusBox.textContent='启动台连接中断。请重新双击项目里的“启动 EDGE OS.cmd”。';button.disabled=true;}}
button.onclick=async()=>{busy=true;button.disabled=true;wantOpen=true;statusBox.textContent='正在检查并启动；首次备份可能需要稍候…';try{const response=await fetch('/start',{method:'POST',headers:{'X-Edge-Launcher':'start'},signal:AbortSignal.timeout(100000)});if(!response.ok)throw Error();const data=await response.json();busy=false;render(data);if(['FAILED','CONFLICT'].includes(data.state))wantOpen=false;}catch{busy=false;wantOpen=false;statusBox.textContent='启动请求暂未确认，请等待状态检查；请勿重复启动。';await refresh();}};
refresh();setInterval(refresh,3000);
