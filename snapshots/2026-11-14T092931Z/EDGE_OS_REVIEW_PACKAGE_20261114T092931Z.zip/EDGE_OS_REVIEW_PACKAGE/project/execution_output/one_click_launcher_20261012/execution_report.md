# EDGE OS 一键启动台

日期：2026-10-12。状态：本地实现完成；当前已运行实例下的入口检查通过。

## 用户入口

- 项目外层：C:\Users\Kyrie\Documents\EDGE OS 101\启动 EDGE OS.cmd
- 项目代码目录：启动 EDGE OS.cmd / START_WINDOWS.bat
- 启动台：http://127.0.0.1:8766
- 现有页面顶栏新增“启动台 / 运行状态”。

双击启动文件打开启动台，点击“启动并打开 EDGE OS”；已经运行时改为“打开正在运行的 EDGE OS”。
网页无法在本机服务全关闭时自行启动 Python，所以保留本地启动文件作为首次入口；启动台自身与交易服务独立。

## 修改文件

- edge_launcher.py：只依赖标准库的本机启动服务、状态检查、重复启动保护和启动前备份。
- app/static/launcher.html：启动按钮、进度/失败状态及真实监控/实时通路状态。
- app/static/index.html：启动台链接。
- START_WINDOWS.bat：打开独立启动台，避免直接重复运行 uvicorn。
- dashboard.html：提供启动台入口，移除固定 5 秒盲目跳转。
- 代码目录与工作区外层的“启动 EDGE OS.cmd”：用户可直接找到的入口。

## 行为及安全

- 本机已运行时只打开现有服务，不停止、不重复启动、不重置记录。
- 未运行时检查现有 Python 环境和已验证的本机代理，再执行 SQLite backup/integrity 和冻结策略检查，成功后才启动已批准的持续模拟 launcher。
- 使用既有 production DB，保留旧记录和账户；真实交易关闭。
- 启动台只绑定 127.0.0.1，校验 Host；启动 POST 要求同源 Origin 和特定 header；拒绝外部来源。没有停止、删除、重置、任意命令或真实订单接口。
- 运行页面内容及 PAPER_ONLY 状态必须与当前项目一致；地址冲突、未知服务和备份失败都阻止启动。
- 网络代理与数据源沿用当前已验证路线，不读取或输出 API key/其他生产凭据。
- 日志保留于 execution_output/one_click_launcher；用户界面只给出安全的失败描述。

## 验证

- Python py_compile：exit 0。
- 启动台 JavaScript node --check：exit 0。
- 页面和状态接口可访问。
- 当前已运行实例下再次 POST /start 返回 RUNNING，没有生成第二份启动进程/last_launch.json。
- 缺少 Origin 与外部 Origin 的 POST 均返回 403。
- 没有运行测试套件，没有为本轮验证停止/重启当前生产模拟或调用数据库备份/重置。
- 中文状态返回值已核对为正确 Unicode；控制台编码显示不影响页面。

## 局限

没有为了测试关闭当前实验，因此真正停机后的首次冷启动分支尚未实测。
启动台不修复当前 Fast Path 的 BACKFILL_GAP_EXCEEDS_BOUND；页面会如实显示。主服务运行不等于实时通路已恢复。
系统开机自启未配置；电脑重启后需双击启动文件。本地代理必须保持可用；环境缺失会阻止启动，不自动重装或重建数据。
本轮为本地审查/入口验证，没有网页 ChatGPT 独立审查。
