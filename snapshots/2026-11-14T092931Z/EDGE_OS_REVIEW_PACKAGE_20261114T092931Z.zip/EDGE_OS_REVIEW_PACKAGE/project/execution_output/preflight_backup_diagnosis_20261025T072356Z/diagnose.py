"""Evidence-only diagnostic; never calls production startup or writes its pointers."""
import concurrent.futures, ctypes, hashlib, heapq, json, os, shutil, sqlite3, subprocess, sys, threading, time, traceback, types
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from urllib.request import build_opener, ProxyHandler

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT))
from edge_runtime import active_database, active_run
SOURCE=active_database()
TIMINGS={}; PROGRESS=[]; START=time.monotonic()
POINTER=ROOT/'execution_output/polygon_fast_path/current_continuous_start.json'
OLD=ROOT/'data/backups/edge_mvp.pre-continuous-fast-path-20261025T065056Z.db'
BACKUP=OUT/'diagnostic_snapshot.db'

def utc(): return datetime.now(timezone.utc).isoformat()
def write(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def log(phase,**kw):
    item={'at_utc':utc(),'phase':phase,**kw}
    print(json.dumps(item,ensure_ascii=False,default=str),flush=True)
    with (OUT/'diagnostic_run.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(item,ensure_ascii=False,default=str)+'\n')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def stat(p,hash_file=False):
    if not p.exists():return {'path':str(p),'exists':False}
    s=p.stat();r={'path':str(p),'exists':True,'size':s.st_size,'mtime_ns':s.st_mtime_ns}
    if hash_file:r['sha256']=sha(p)
    return r
def ro(p):
    c=sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True,timeout=30)
    c.execute('PRAGMA query_only=ON');return c
def phase(name,fn):
    log(name+'_START');t=time.monotonic();r=fn();TIMINGS[name]={'seconds':time.monotonic()-t,'result':r};write('phase_timings.json',TIMINGS);log(name+'_END',seconds=TIMINGS[name]['seconds']);return r
def health():
    result={}
    opener=build_opener(ProxyHandler({}))
    for key,url in [('health','http://127.0.0.1:8000/api/health'),('launcher_identity','http://127.0.0.1:8766/identity'),('launcher_status','http://127.0.0.1:8766/status')]:
        t=time.monotonic()
        try:
            with opener.open(url,timeout=20) as r:result[key]={'status':r.status,'body':json.load(r),'seconds':time.monotonic()-t}
        except Exception as e:result[key]={'error_type':type(e).__name__,'seconds':time.monotonic()-t}
    return {'captured_at_utc':utc(),**result}
def files():
    paths=[ROOT/'edge_launcher.py',ROOT/'edge_runtime.py',ROOT/'data/active_experiment.json',ROOT/'execution_output/polygon_fast_path/prepare_continuous_start.py',ROOT/'execution_output/polygon_fast_path/serve_continuous.py']
    paths += [p for p in (ROOT/'app').rglob('*') if p.is_file() and p.suffix in {'.py','.js','.css','.html'}]
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
def protected():return {'pointer':stat(POINTER,True),'incomplete_backup':stat(OLD,True),'incomplete_journal':stat(Path(str(OLD)+'-journal'),True),'source_files':files()}
def source_stats():return {k:stat(Path(str(SOURCE)+s)) for k,s in [('main',''),('wal','-wal'),('shm','-shm')]}
def frozen(c):
    c.row_factory=sqlite3.Row
    versions=[dict(r) for r in c.execute('SELECT * FROM wallet_v2_versions ORDER BY strategy_version')]
    rules=[dict(r) for r in c.execute('SELECT * FROM strict_rule_versions ORDER BY rule_version')]
    wallets=[r[0] for r in c.execute('SELECT address FROM wallets WHERE tracked=1 ORDER BY address')]
    return {'versions':versions,'rules':rules,'tracked_wallets':wallets,'tracked_wallet_sha256':hashlib.sha256('\n'.join(wallets).encode()).hexdigest(),'active_experiment':active_run()}
def ledger_snapshot(name):
    import app.strict_ledger as lm
    c=ro(SOURCE);c.row_factory=sqlite3.Row;c.execute('BEGIN')
    mem=sqlite3.connect(':memory:');mem.row_factory=sqlite3.Row
    names=['strict_accounts','strict_cash_pools','strict_cash_ledger','strict_orders','strict_fills','strict_positions','strict_decisions','strict_marks','strict_audit_events','strict_settlements']
    counts={}; hashes={}; immutable={}
    for table in names:
        mem.execute(c.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone()[0])
        rows=c.execute('SELECT * FROM '+table).fetchall();counts[table]=len(rows)
        if rows:mem.executemany('INSERT INTO '+table+' VALUES('+','.join('?' for _ in rows[0])+')',rows)
        canonical=sorted(json.dumps(tuple(r),ensure_ascii=False,separators=(',',':'),default=str) for r in rows)
        hashes[table]=hashlib.sha256('\n'.join(canonical).encode()).hexdigest()
        if table in {'strict_fills','strict_orders','strict_positions'}:
            pk={'strict_fills':'fill_id','strict_orders':'order_id','strict_positions':None}[table]
            if pk:immutable[table]={r[pk]:hashlib.sha256(json.dumps(tuple(r),ensure_ascii=False,separators=(',',':'),default=str).encode()).hexdigest() for r in rows}
        del rows,canonical
    f=frozen(c);c.rollback();c.close();mem.commit();mem.execute('PRAGMA query_only=ON')
    old=lm.sqlite3;lm.sqlite3=types.SimpleNamespace(connect=lambda *a,**k:mem,Row=sqlite3.Row)
    try:
        accounts=[dict(r) for r in mem.execute('SELECT * FROM strict_accounts ORDER BY account_id')]
        checks={a['account_id']:lm.StrictPaperLedger(':memory:',a['account_id']).reconcile() for a in accounts}
        audit=lm.StrictPaperLedger(':memory:').verify_audit_chain()
    finally:lm.sqlite3=old
    r={'captured_at_utc':utc(),'access':'mode=ro/query_only/read transaction; reconcile and audit use immutable in-memory SELECT snapshot, no production DB class initialization','accounts':accounts,'checks':checks,'passed':sum(v['ok'] for v in checks.values()),'account_count':len(checks),'audit':audit,'counts':counts,'hashes':hashes,'frozen':f,'open_orders':mem.execute("SELECT COUNT(*) FROM strict_orders WHERE status='OPEN'").fetchone()[0],'reserved_cash':str(sum((Decimal(a['reserved_cash']) for a in accounts),Decimal(0))),'reserved_quantity':str(sum((Decimal(r[0]) for r in mem.execute('SELECT reserved_quantity FROM strict_positions')),Decimal(0))),'immutable_rows':immutable}
    mem.close();write(name,r);return {k:r[k] for k in ['passed','account_count','audit','counts','open_orders','reserved_cash','reserved_quantity']}

def copy_default(src):
    assert not BACKUP.exists()
    done=threading.Event();t=time.monotonic();page_size=src.execute('PRAGMA page_size').fetchone()[0];total=src.execute('PRAGMA page_count').fetchone()[0]
    def sample():
        observer=ro(SOURCE)
        try:
            while not done.wait(2):
                size=BACKUP.stat().st_size if BACKUP.exists() else 0
                r={'at_utc':utc(),'elapsed_seconds':time.monotonic()-t,'kind':'file_growth_estimate_NOT_committed_page_progress','total_pages_at_start':total,'estimated_file_pages':size//page_size,'estimated_remaining_pages':max(0,total-size//page_size),'destination_bytes':size,'source_data_version':observer.execute('PRAGMA data_version').fetchone()[0],'source_files':source_stats()}
                PROGRESS.append(r)
                if len(PROGRESS)%5==0:write('backup_progress.json',PROGRESS);log('BACKUP_SAMPLE',elapsed=r['elapsed_seconds'],bytes=size,data_version=r['source_data_version'])
        finally:observer.close()
    th=threading.Thread(target=sample,daemon=True);th.start()
    def callback(status,remaining,total_pages):
        r={'at_utc':utc(),'elapsed_seconds':time.monotonic()-t,'kind':'sqlite_backup_progress_authoritative','status':status,'total_pages':total_pages,'pages_copied':total_pages-remaining,'remaining_pages':remaining};PROGRESS.append(r);log('BACKUP_CALLBACK',**{k:v for k,v in r.items() if k!='at_utc'})
    try:
        with sqlite3.connect(BACKUP) as dst:src.backup(dst,progress=callback) # exact original pages=-1/sleep defaults
    finally:done.set();th.join();write('backup_progress.json',PROGRESS)
    return {'path':str(BACKUP),'bytes':BACKUP.stat().st_size,'pages_argument':-1,'method':'same SQLite backup default single step as existing preflight; callback plus independent file-growth estimates','completed':True,'source_activity_samples':len(PROGRESS),'seconds_copy_only':time.monotonic()-t}

def hash_tables():
    c=ro(BACKUP);c.execute('BEGIN');results={};spool=OUT/'sort_spool';spool.mkdir()
    for table, in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
        t=time.monotonic();q='"'+table.replace('"','""')+'"';rows=[];n=nb=0;chunks=[];chunk_bytes=0
        def spill():
            nonlocal rows,chunk_bytes
            rows.sort();p=spool/(table+'.'+str(len(chunks))+'.jsonl')
            with p.open('x',encoding='utf-8',newline='\n') as f:
                for r in rows:f.write(r+'\n')
            chunks.append(p);rows=[];chunk_bytes=0
        for row in c.execute('SELECT * FROM '+q):
            s=json.dumps(tuple(row),ensure_ascii=False,separators=(',',':'),default=str);rows.append(s);size=len(s.encode());n+=1;nb+=size;chunk_bytes+=size
            if chunk_bytes>=64*1024*1024:spill()
        h=hashlib.sha256();first=True
        if chunks:
            if rows:spill()
            handles=[p.open('r',encoding='utf-8',newline='') for p in chunks]
            iterator=heapq.merge(*(map(lambda x:x[:-1],f) for f in handles))
        else:rows.sort();iterator=iter(rows);handles=[]
        for s in iterator:
            if not first:h.update(b'\n')
            h.update(s.encode());first=False
        for f in handles:f.close()
        results[table]={'count':n,'sha256':h.hexdigest(),'canonical_json_bytes':nb,'seconds':time.monotonic()-t,'sort_method':'external_merge_64MiB_runs' if chunks else 'in_memory_sorted','spool_chunks':len(chunks),'hash_contract':'identical UTF-8 sha256 of newline-joined lexicographically sorted JSON tuples; bounded-memory hashing avoids original giant join/encode allocation'}
        write('table_hashes.json',results);log('TABLE_HASH',table=table,**results[table]);del rows
    c.rollback();c.close();return {'table_count':len(results),'total_rows':sum(x['count'] for x in results.values()),'canonical_bytes':sum(x['canonical_json_bytes'] for x in results.values()),'note':'safe completed diagnostic snapshot, not later live-source state; bounded-memory implementation, not exact original allocation timing'}

def main():
    write('workspace_info.json',{'workspaceId':'47fec7b8248c','workspaceName':'EDGE OS 101','verified_by':'actual createMcpServer workspace_info via existing local InMemoryTransport; stale Codex connector tool returned Unknown tool','git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'git_branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()})
    phase('protected_files_before',lambda:write('protected_before.json',protected()) or {'saved':True})
    write('source_before.json',source_stats());h=health();write('health_before.json',h)
    assert h['health']['status']==200 and h['health']['body']['mode']=='PAPER_ONLY'
    assert h['health']['body']['experiment']['run_id']=='FORWARD-20261012T073343Z'
    assert h['health']['body'].get('live_trading') is False
    assert shutil.disk_usage(OUT).free>30*1024**3
    phase('ledger_before',lambda:ledger_snapshot('ledger_before.json'))
    before=json.loads((OUT/'ledger_before.json').read_text(encoding='utf-8'))
    assert before['passed']==before['account_count']==13 and before['audit']['ok']
    assert before['frozen']['active_experiment']['run_id']=='FORWARD-20261012T073343Z' and before['frozen']['active_experiment']['live_orders'] is False
    t=time.monotonic();src=ro(SOURCE);TIMINGS['source_read_open']={'seconds':time.monotonic()-t}
    phase('source_quick_check',lambda:{'rows':[r[0] for r in src.execute('PRAGMA quick_check')]})
    assert TIMINGS['source_quick_check']['result']['rows']==['ok']
    phase('sqlite_backup_default_copy',lambda:copy_default(src));src.close()
    c=ro(BACKUP)
    phase('backup_integrity_check',lambda:{'rows':[r[0] for r in c.execute('PRAGMA integrity_check')]})
    assert TIMINGS['backup_integrity_check']['result']['rows']==['ok']
    phase('frozen_config_tracked_wallet_snapshot',lambda:frozen(c));c.close()
    phase('all_table_count_sort_hash',hash_tables)
    phase('backup_file_sha256_streaming',lambda:stat(BACKUP,True))
    phase('source_main_sha256_streaming_non_atomic',lambda:stat(SOURCE,True))
    phase('ledger_after',lambda:ledger_snapshot('ledger_after.json'))
    write('health_after.json',health());write('source_after.json',source_stats())
    phase('protected_files_after',lambda:write('protected_after.json',protected()) or {'saved':True})
    after=json.loads((OUT/'ledger_after.json').read_text(encoding='utf-8'));p0=json.loads((OUT/'protected_before.json').read_text());p1=json.loads((OUT/'protected_after.json').read_text())
    preserve={'at_utc':utc(),'protected_files_equal':p0==p1,'frozen_equal':before['frozen']==after['frozen'],'ledger_before_passed':before['passed'],'ledger_after_passed':after['passed'],'audits_ok':before['audit']['ok'] and after['audit']['ok'],'existing_fills_unchanged':all(after['immutable_rows']['strict_fills'].get(k)==v for k,v in before['immutable_rows']['strict_fills'].items()),'before_counts':before['counts'],'after_counts':after['counts'],'source_changes_expected':'application remains running and is the only intended production writer; no source table write SQL used by diagnosis','source_file_hash_warning':'streamed source main-file hash is not a transactionally consistent WAL-inclusive database hash'}
    write('source_preservation.json',preserve)
    write('run_result.json',{'state':'COMPLETED','started_elapsed_seconds':time.monotonic()-START,'ended_at_utc':utc(),'exit_code':0,'backup_complete':True,'preservation':preserve});log('DIAGNOSIS_COMPLETE',elapsed=time.monotonic()-START)

if __name__=='__main__':
    try:main()
    except Exception as e:
        write('run_result.json',{'state':'FAILED_CLOSED','error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'ended_at_utc':utc(),'exit_code':1});log('FAILED_CLOSED',error_type=type(e).__name__);raise
