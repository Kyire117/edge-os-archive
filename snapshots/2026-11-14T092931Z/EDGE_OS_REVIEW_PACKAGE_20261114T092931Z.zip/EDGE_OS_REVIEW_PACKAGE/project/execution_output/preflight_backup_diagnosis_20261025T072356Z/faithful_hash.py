"""Measure original allocation/hash algorithm on completed diagnostic copy only."""
import ctypes,hashlib,json,os,sqlite3,threading,time
from pathlib import Path
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parent
EXPECTED=json.loads((OUT/'table_hashes.json').read_text(encoding='utf-8'))
RESULT={'started_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'completed diagnostic snapshot only','tables':{},'memory_guard_min_available_bytes':4*1024**3}
class MEM(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total_phys','avail_phys','total_page','avail_page','total_virtual','avail_virtual','extended']]
def free():
    m=MEM();m.length=ctypes.sizeof(m);ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));return m.avail_phys
def save(): (OUT/'faithful_hash_timings.json').write_text(json.dumps(RESULT,indent=2),encoding='utf-8')
def guard():
    while True:
        f=free();RESULT['minimum_observed_available_bytes']=min(RESULT.get('minimum_observed_available_bytes',f),f)
        if f<RESULT['memory_guard_min_available_bytes']:
            RESULT.update(state='ABORTED_MEMORY_GUARD',exit_code=47);save();os._exit(47)
        time.sleep(.1)
threading.Thread(target=guard,daemon=True).start()
assert free()>10*1024**3
c=sqlite3.connect((OUT/'diagnostic_snapshot.db').as_uri()+'?mode=ro',uri=True)
c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
t0=time.monotonic()
for table, in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
    q='"'+table.replace('"','""')+'"';t=time.monotonic()
    rows=sorted(json.dumps(tuple(row),ensure_ascii=False,separators=(',',':'),default=str) for row in c.execute('SELECT * FROM '+q))
    digest=hashlib.sha256('\n'.join(rows).encode()).hexdigest()
    assert digest==EXPECTED[table]['sha256'] and len(rows)==EXPECTED[table]['count']
    RESULT['tables'][table]={'seconds':time.monotonic()-t,'count':len(rows),'sha256':digest,'matches_bounded_memory_hash':True};save()
    print(json.dumps({'table':table,**RESULT['tables'][table]}),flush=True)
RESULT['all_table_hash_seconds']=time.monotonic()-t0
del rows;c.rollback();c.close()
t=time.monotonic();digest=hashlib.sha256((OUT/'diagnostic_snapshot.db').read_bytes()).hexdigest()
RESULT['original_read_bytes_file_hash']={'seconds':time.monotonic()-t,'sha256':digest,'matches_streamed_hash':digest==json.loads((OUT/'phase_timings.json').read_text())['backup_file_sha256_streaming']['result']['sha256']}
RESULT.update(state='COMPLETED',exit_code=0,finished_at_utc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in RESULT.items() if k!='tables'}),flush=True)
