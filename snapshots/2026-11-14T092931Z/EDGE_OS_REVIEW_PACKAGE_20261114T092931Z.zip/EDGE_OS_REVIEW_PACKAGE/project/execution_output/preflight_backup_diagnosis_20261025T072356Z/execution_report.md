[C2C] STATE: EXECUTED
TASK_ID: c2c_preflight_backup_diagnosis_v1
ITERATION: 1
REVIEW_STATE: REVIEW_PASS_WITH_LIMITATIONS (独立网页审查完成；output 148 保留审查前版本)

# EDGE OS preflight 非破坏性分阶段诊断

## 结论

**首选 B：将安全备份与昂贵的全表哈希分阶段；同时采用 C：阶段进度和安全中止证据。仅建议，未实施。**

- 当前活动库约 6.12 GB。原算法全表排序/JSON/哈希的逐表计时合计 **104.331 秒**，单独已超过 90 秒。
- 本轮原默认 SQLite backup 复制仅 **13.716 秒**，且副本 integrity_check=ok。不能把旧超时直接解释为持续写入导致无法收敛。
- **历史失败与本轮结论要分开**：旧 20261025T065056Z 副本只有 5,240,066,048 字节且保留 journal，旧报告显示 90 秒超时；结合原脚本阶段顺序，支持那次尚未完成复制/提交。没有当时逐阶段进度，不能还原它的 quick_check 与 backup 精确占比，更不能归咎于 hash 已经运行。
- 本轮复制成功一次，旧流程失败一次；缓存、I/O 竞争、系统负载未做受控实验。**不能承诺在线备份稳定在 90 秒内，也没有足够样本给出新的安全 timeout 数字。**
- 本轮不运行正式 preflight，不更新 current_continuous_start，不重启、不改产品代码、配置或策略；历史 VOID 仍 BLOCKED。

## 身份与运行环境

- 实际调用现有 C2C MCP workspace_info：47fec7b8248c / EDGE OS 101。Codex 旧连接工具返回 Unknown tool 后，使用现有本地 MCP server 的 InMemoryTransport 调用同名 workspace_info，结果保存在 workspace_info_actual.json；这本身不冒充网页读取成功。
- 仓库：C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp
- 源库由 edge_runtime.active_database / data/active_experiment.json 确认：data\edge_forward_20261012T073343Z.db
- FORWARD-20261012T073343Z / wallet-follow-v2.0 / PAPER_ONLY / live_orders=false / live_trading=false。
- 原应用 PID 16072、wrapper 26548、launcher 21624 均保持，前后完整进程记录一致。
- 初始磁盘空余约 152 GB，内存空余约 16 GB；原算法计时期间观察到的可用物理内存最低值 12.07 GiB，未触发 4 GiB 内存中止保护。
- 产品源脚本 SHA256：efa53a4fa08684fbb236681fdd17d9300f86ab2bda41437881323b907fc7b28c

## 原流程阶段与本轮计时

原流程：mode=ro/query_only 打开源库 → quick_check → SQLite backup 默认 pages=-1 → 副本 integrity_check → **另起源库读事务**逐表 JSON、排序、全量 join/encode/SHA → 读取冻结版本/钱包 → source main-file read_bytes SHA → backup read_bytes SHA → 写 before_start.json 和正式 pointer。

**最后两个正式输出步骤本轮没有执行。**

| 阶段 | 秒 |
|---|---:|
| source_open | 0.001 |
| source_quick_check | 11.530 |
| copy | 13.716 |
| integrity_check | 9.531 |
| original_table_hash_sum | 104.331 |
| bounded_memory_table_hash | 60.013 |
| frozen_config_wallet_snapshot | 0.001 |
| original_backup_file_hash | 5.796 |
| original_source_main_file_hash | 29.998 |
| separate_component_sum_estimate | 174.904 |

以上 component sum 是分开测量阶段相加，约 174.9 秒，**不是实际完整启动或一次连续原 preflight 的墙钟耗时**，不作为 SLA。源 main-file 哈希测量期间应用仍写入，因此该值是非原子文件读取的审计元数据，不能作为含 WAL 的一致数据库内容哈希。

### 哈希测量方法与限制

1. 首轮在完整通过 integrity_check 的诊断副本上，使用 64 MiB 分块外部排序与流式 SHA256，避免原算法大对象分配，耗时 60.013 秒。
2. 随后在**同一个完整诊断副本**上逐表执行原脚本的 `sorted(json.dumps(tuple(row), ensure_ascii=False, separators=(',',':'), default=str) ...)` 与 `sha256('\n'.join(rows).encode())`。
3. 54/54 表 count/hash 与首轮全部一致；原算法逐表计时合计 104.331 秒（不含小量报告写入开销）。本轮共 3,349,514 行，规范 JSON 合计 6,126,997,975 字节。
4. 原算法 helper 最后用默认 GBK 编码读取 UTF-8 报告时退出 1。54 张表结果此前逐表落盘，均保留；已单独补测原 read_bytes 文件哈希，退出 0，副本 SHA 与流式结果一致。未重跑备份或历史数据。
5. 原算法时长发生在已完成副本上、缓存状态非受控；不能声称是当前活动源库完整事务的精准时长或原历史超时的复现。

| 原算法主要表 | 行数 | 规范 JSON GB | 秒 |
|---|---:|---:|---:|
| fill_identity_audit | 1230441 | 2.463 | 43.188 |
| wallet_v2_audit | 998181 | 0.568 | 11.677 |
| wallet_v2_exit_events | 66427 | 1.508 | 11.063 |
| strict_decisions | 35109 | 0.681 | 7.616 |
| wallet_v2_exit_positions | 406 | 0.000 | 6.800 |
| polygon_fast_audit | 613025 | 0.184 | 5.881 |

## 在线复制与源写入活动

- 新副本：C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\execution_output\preflight_backup_diagnosis_20261025T072356Z\diagnostic_snapshot.db
- 大小：6,118,666,240 bytes
- SHA256：c98b8f7e6161d82312bbc38a0568e701c2bb68bedd3764bee774fb83c3ce03bb
- integrity_check：ok；完整后才进行任何副本 SQL 校验或表哈希。
- 默认 pages=-1 保持原行为。SQLite 权威回调：total=1,493,815，copied=1,493,815，remaining=0，status=SQLITE_DONE(101)，elapsed=13.715s。
- 默认单步复制只有完成时的权威 progress 回调；中间每 2 秒记录目标文件增长估算，**不是已提交页数，也不是可恢复/完整备份证明**。两种记录已在 backup_progress.json 的 kind 字段区分。
- 同一独立只读连接的 source data_version 样本：[2, 3, 4, 5, 6, 7]，证明复制期间其他连接有提交；不能由差值推导精确事务数量。
- 未观察到 BUSY/LOCKED 回调；未获得“持续写入导致重启复制”的证据。当前默认单步并不等同于多步增量备份；改成分块时必须另外验证重启/饥饿风险。

## A/B/C/D 选择

| 选项 | 数据依据与判断 |
|---|---|
| A 调整 timeout | 不单独选。原哈希阶段已超 90s，而旧失败又发生在复制未完成时；没有冷/热缓存和尾延迟样本，不能随意改成 180/300s。现有 90s 未改。 |
| **B 分阶段** | **首选。** 把可恢复副本、完整性检查、冻结配置/身份核对保持为不可绕过的安全条件；在副本上独立做昂贵全表哈希。若全表哈希仍为审批必需，则可在准备阶段预先完成并按不可变结果绑定，不能跳过或复用过时证据。是否启动仍由下一任务单独授权。 |
| **C progress/abort** | **配套推荐。** 原默认大步回调无法提供复制中的权威页进度；旧失败缺少阶段定位。未来可加入阶段日志、busy/locked、单调时钟预算、正常 backup_finish/关闭与明确 incomplete 状态；如调整为分块，需验证源写入下重启和 snapshot/read transaction 的 WAL 保留成本。未实施。 |
| D 其他官方快照 | 暂不选。SQLite 官方支持 VACUUM INTO，但本轮未实测，其 CPU/I/O 权衡与 ROWID 影响需另审；现有 backup API 本轮已安全完成，无证据表明必须替换。 |

SQLite 官方依据：[Backup API](https://www.sqlite.org/backup.html)、[backup_step/finish 语义](https://www.sqlite.org/c3ref/backup_finish.html)、[VACUUM INTO](https://www.sqlite.org/lang_vacuum.html)。负页数复制剩余全部页；外部修改发生在多次 step 之间可能触发自动重启。VACUUM INTO 是一致快照选项，但不能由存在该选项推断更适合当前库。

## 保护结果与账本

- 前后 13/13 reconcile 均通过；audit 45848 → 45852，两次有效，原审计前缀完全一致。
- 最终 OPEN orders=0，reserved cash=0.000000，reserved quantity=0.000000。
- strict_accounts/cash_pools/cash_ledger/orders/fills/positions/decisions/marks 的内容哈希均相同；旧 fill/order 逐行内容未改。
- 持续运行期间 settlements 6175 → 6179、audit +4；是运行中的追加观察，不把整个数据库声称为字节未变，也不把 SHM/WAL 文件变化当作诊断写入交易。见 source_preservation_final.json。
- frozen versions/config/rules、tracked wallet 地址集合、active_experiment.json、所有产品源文件、正式 pointer、旧 incomplete DB 与 journal 的内容及所记录元数据均未变。
- 未对旧 incomplete DB 建立 SQLite 连接或进行写恢复，只读取文件 hash/stat。
- 最终 health HTTP200、monitor_running=true、PAPER_ONLY；Fast Path 仍 disconnected/TimeoutError。本任务没有修复或重启网络链路，也不宣称恢复。
- 历史 c2c_fix_p1_execution_void 仍 BLOCKED；没有历史 VOID reconciliation。

## 实际命令与退出状态

| 命令 | 退出码/状态 |
|---|---|
| .venv/Scripts/python.exe -u execution_output/preflight_backup_diagnosis_20261025T072356Z/diagnose.py | 0；2026-10-25T07:26:06Z → 07:28:53Z |
| .venv/Scripts/python.exe -u execution_output/preflight_backup_diagnosis_20261025T072356Z/faithful_hash.py | 1；54 表已完成，最后报告读取 GBK/UTF-8 错误；证据保留 |
| .venv/Scripts/python.exe - （内存保护下补测原 backup/source read_bytes SHA） | 0；original_file_hash_timings.json 记录起止 UTC |
| .venv/Scripts/python.exe - （同一只读 ledger 方法最终核对） | 0；ledger_after_final.json |
| workspace_info / doctor / 进程与内存只读核对 | 身份符合；连接健康；应用身份保持 |
| 早期读取 UTF-8 timing JSON 时遗漏 encoding 的辅助打印命令 | 1；仅控制台汇总失败，已用显式 UTF-8 重读，不影响测量 |
| pytest / full regression / 启动或重启 | **未运行**；本轮无产品代码修改，任务仅诊断 |

精确读文件清单见 manifest.json；产品改动文件为 0。新增内容全部位于当前独立诊断目录，包括两个证据用 helper，不属于产品实现。保留副本、排序中间文件及所有结果，不清理历史文件。

## 后续边界

仅提交 B+C 的实现建议等待独立审查与下一任务授权；没有改 timeout、没有正式 preflight 成功标记、没有更新 current_continuous_start、没有启动/停止/重启 EDGE OS，也没有进入代码修复。


## 独立网页审查完成

[C2C] REVIEW_RESULT: REVIEW_PASS_WITH_LIMITATIONS

原 Connection verification report 对话实际调用 workspace_info 并读取 output 148 与底层文件，认可诊断及 B+C 方向。审查只批准诊断结果，不批准实现或重启。待设计边界：备份 freshness/身份绑定、全表哈希是否同步阻塞启动、若改成分块复制需验证写入饥饿与重启风险。完整原文与截图分别在 web_review_final.txt / web_review_final.png。历史 VOID 保持 BLOCKED。
