# EDGE OS 100U / 1U execution evidence

**Status: BLOCKED — risk implementation and tests completed; experiment cutover not executed.**

Recorded: 2026-11-01 (UTC+08:00)

## Completed in the workspace

- Upgraded the new trial defaults to `paper-trial-risk-v2`: 100.000000 USDC initial cash, 1.000000 USDC order and cumulative market caps, 2.000000 USDC event cap, 30.000000 USDC portfolio cap, unchanged 20/70 USDC loss thresholds, and `live_orders=false`.
- `snapshot()` counts open position cost basis and open BUY reserve cash by `(condition_id, token_id, outcome)`; event exposure remains grouped by `condition_id`.
- `check_buy()` enforces the cumulative market cap with `TRIAL_RISK_MARKET_LIMIT` inside the ledger reservation transaction. If fixed sizing does not fit the remaining market allowance, the BUY is rejected.
- Added coverage for market cap, repeat ADD_ON, partial remaining market room, shared event cap, portfolio cap, concurrent reservation, venue minimum, loss pause/stop, fee-inclusive sizing, and position-plus-reservation exposure.
- Added archive evidence fields and fresh-run preparation/activation checks. These scripts were syntax-checked but activation was not run.

## Verification

| Command | Result |
|---|---|
| `python -m pytest -p no:cacheprovider --basetemp <isolated-temp> -q tests/test_paper_trial_risk.py` | 15 passed in 13.15s |
| `python -m compileall -q app scripts tests` | Passed |
| `python -m pytest tests -p no:cacheprovider --basetemp <isolated-temp> -q` | 483 passed, 1 deprecation warning, 141.81s |
| `python scripts/archive_paper_run.py` | Exited 1 before snapshot creation: `RuntimeError: APPLICATION_MUST_BE_STOPPED` |

An unscoped `pytest` invocation also collected historical backup tests under `execution_output/` and restricted temporary directories (73 collection errors). The official `tests/` suite above completed successfully.

## Active service evidence and cutover blocker

- `data/active_experiment.json` still names `FORWARD-20261028T032351Z`, database `data/edge_forward_20261028T032351Z.db`, strategy `wallet-follow-v2.0`, and `live_orders=false`.
- `GET http://127.0.0.1:8000/api/health` responded with `ok=true`, `mode=PAPER_ONLY`, `live_trading=false`, `monitor_running=true`, and `wallet_follow_v2_state=ACTIVE`.
- The archive script's precondition probes `127.0.0.1:8000`; the connection succeeds, so it correctly refuses to snapshot a database that may still be changing. The health endpoint was also still reporting active monitoring.
- The execution shell did not expose a local owning process/PID (`Get-Process`/`netstat` showed no service process/listener), and the Task Manager UI attempt timed out. No process was killed.

No archive database snapshot, archive manifest, new database, active-manifest switch, or new service start was produced. The existing experiment and its database were left intact; no real orders were submitted.

## Resume point

Stop the EDGE OS service from the host/session that owns the responding port 8000, then rerun `scripts/archive_paper_run.py`. After its SQLite snapshot passes `integrity_check`, continue with the prepared fresh-run and activation steps. Keep `PAPER_ONLY` and `live_orders=false` throughout.

## Recheck after user reported the service stopped

The stop confirmation did not match the observable service state at recheck:

- `http://127.0.0.1:8766/status` returned `state=RUNNING`, `monitor_running=true`, and run `FORWARD-20261028T032351Z`.
- `http://127.0.0.1:8000/api/health` returned `monitor_running=true`, `mode=PAPER_ONLY`, and `live_trading=false`; its last Polygon read was `2026-11-01T10:01:43.578214+08:00`.
- `execution_output/one_click_launcher/last_launch.json` records PID `27276` for this workspace and `PAPER_ONLY`. `Get-Process -Id 27276` reports that PID is not visible in the execution shell.
- The launcher source exposes `/status` and `/start` only; it has no stop/reset API. The Task Manager UI request again timed out before interaction.
- A second `python scripts/archive_paper_run.py` invocation exited 1 with `APPLICATION_MUST_BE_STOPPED`; no snapshot was started.

The HTML page can close while the launcher-managed backend remains running. The service must show `STOPPED` and port 8000 must refuse connections before archive can proceed.
