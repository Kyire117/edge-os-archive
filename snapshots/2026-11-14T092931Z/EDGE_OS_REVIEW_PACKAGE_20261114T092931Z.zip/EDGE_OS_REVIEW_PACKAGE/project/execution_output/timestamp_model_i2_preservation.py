"""Read-only production evidence; never instantiate application DB classes."""
import hashlib,json,sqlite3,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
P=R/'execution_output/timestamp_model_i2';P.mkdir(exist_ok=True)
db=R/'data/edge_mvp.db'
c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
tables=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
counts={t:c.execute('SELECT COUNT(*) FROM "'+t+'"').fetchone()[0] for t in tables}
ids=[e['episode_id'] for e in json.loads((R/'execution_output/timestamp_diagnosis_20261002/snapshot.json').read_text(encoding='utf-8'))['episodes']]
rows=[dict(c.execute('SELECT * FROM wallet_v2_episodes WHERE episode_id=?',(i,)).fetchone()) for i in ids]
signals=[r['first_signal_id'] for r in rows]
decisions=[dict(r) for r in c.execute('SELECT * FROM strict_decisions ORDER BY decision_id') if r['signal_id'] in signals]
versions=[dict(r) for r in c.execute('SELECT * FROM wallet_v2_versions ORDER BY strategy_version')]
wallets=[r[0] for r in c.execute('SELECT address FROM wallets ORDER BY address')]
rules=[dict(r) for r in c.execute('SELECT * FROM strict_rule_versions ORDER BY rule_version')]
c.rollback();c.close()
result={'db_access':'mode=ro; query_only=ON; transaction ROLLBACK; no application constructors',
 'db_file_sha256':hashlib.sha256(db.read_bytes()).hexdigest(),'counts':counts,
 'historical85_count':len(rows),'historical85_sha256':digest(rows),'historical_decisions_sha256':digest(decisions),
 'v2_versions_sha256':digest(versions),'v2_versions':versions,'wallet_addresses_sha256':digest(wallets),'strict_rules':rules}
phase=sys.argv[1]
if phase=='after':
 before=json.loads((P/'preservation_before.json').read_text(encoding='utf-8'))
 result['comparison']={k:result[k]==before[k] for k in ['db_file_sha256','historical85_sha256','historical_decisions_sha256','v2_versions_sha256','wallet_addresses_sha256','strict_rules']}
(P/('preservation_'+phase+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))

