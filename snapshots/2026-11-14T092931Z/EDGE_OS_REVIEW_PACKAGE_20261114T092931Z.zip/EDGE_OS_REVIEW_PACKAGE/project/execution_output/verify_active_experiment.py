import sqlite3
connection = sqlite3.connect('file:data/edge_mvp.db?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
connection.execute('PRAGMA query_only=ON')
row = connection.execute("SELECT id,rule_version,status,started_utc,ends_utc,rules_json FROM research_experiments WHERE id='FC14-D81AAF4747E2'").fetchone()
cohort = connection.execute("SELECT count(*) FROM research_experiment_wallets WHERE experiment_id=?", (row['id'],)).fetchone()[0]
entries = connection.execute("SELECT count(*) FROM research_experiment_entries WHERE experiment_id=?", (row['id'],)).fetchone()[0]
print('id=', row['id'], 'rule_version=', row['rule_version'], 'status=', row['status'])
print('started_utc=', row['started_utc'], 'ends_utc=', row['ends_utc'], 'cohort=', cohort, 'entries=', entries)
