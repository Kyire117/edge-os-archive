# EDGE OS 当前运行检查

检查时间：2026-10-25T14:16:02.351261+08:00（Asia/Shanghai）。
结论：DEGRADED。应用和模拟账本仍在工作，Fast Path 持续停滞，不能称为整体正常。

## 已确认的当前状态

- 本机启动器返回正确的 EDGE OS 101 仓库路径；manifest 和健康接口均为 FORWARD-20261012T073343Z，wallet-follow-v2.0，PAPER_ONLY，live_orders=false。固定共享本金7000。
- /api/health 和 /api/wallet-follow-v2 都 HTTP200；health ok=true、monitor_running=true、independent_lanes=true。
- 应用PID16072、启动器PID21624仍监听；代理7897监听；剩余磁盘 159558987776 字节。
- 轮询仍推进，有当前新BUY模拟成交；扫描耗时44.6至68.3秒，存在REQUEST_TIMEOUT。初次快照3个钱包超时。
- Fast Path connected=false；最后事件 2026-10-24T23:29:35.103396+00:00，截至最终健康快照已 6.77 小时没有新事件。
- 最后处理成功 2026-10-24T11:32:36.820036+00:00，距快照 18.72 小时。
- 重连 764 次；错误 PoolTimeout；backfill和processing均PoolTimeout。
- 补漏积压 210633 区块；待metadata 314。两次检查期间这些数字及最后事件时间均未推进。
- PoolTimeout证明获取连接池资源超时；连接池饱和、占用未释放和网络超时的具体因果尚未验证，不能据此宣布唯一根因。

## 账本与退出

- 13/13账户使用现有reconcile方法全部通过，审计链 45622 条通过。
- OPEN订单0、预留现金0、超过120秒OBSERVED 0。
- 实际未平仓 126，缺少有效mark 126，因此未知未实现收益与市场价值权益。
- Exit V1 ACTIVE，47个EXITED仓位、48笔SELL模拟fill，说明已经实际执行过退出。最近退出状态更新 2026-10-25T06:15:14.001834+00:00；本轮看到近期PROFIT_PROTECTION_ACTIVATED及FORMAL_RESOLUTION事件，不能由此保证当前网络下的及时退出。
- 最新BUY/SELL：[{'side': 'BUY', 'count': 2108, 'latest_at': '2026-10-25T06:15:06.409968+00:00'}, {'side': 'SELL', 'count': 48, 'latest_at': '2026-10-24T23:00:12.509213+00:00'}]。
- 首次API_FAILURE共99；稍后按paper_status统计 [{'paper_status': 'FILLED', 'count': 34}, {'paper_status': 'REJECTED', 'count': 34}]，其中34个FILLED。状态正在变化，说明有重试进展，不把它们全部称为永久卡死。
- 已实现净盈亏 -167.541458 USD，可用现金3652.504838，预留0；这是运行中的快照，金额会变化。

## 启动台误标

两次启动台/status均返回STARTING，直接应用健康则200且有新成交。当前edge_launcher.py中request_json与首页核验限时2秒；首次健康接口耗时8.6秒，启动台约2.05秒返回STARTING，与超时回退路径一致。不能据此判断应用尚未启动，亦不应重复启动。

## 建议优先级

P1：实时Fast Path多小时没有事件/处理进展，持续PoolTimeout和重连。优先定位RPC/HTTP连接池、超时请求释放和网络出口；保留有界补漏及游标，不回放历史成交。
P2：轮询扫描慢且钱包超时、已成交仓位结算资料API_FAILURE、缺少mark、启动台状态误标。
本轮未修复、未改产品代码/配置/冻结策略、未重启EDGE OS、未强制结算、未运行新的观察或回归测试。新增文件仅为本目录检查证据。

## 网页审阅连接

workspace_info连接工具返回-32603 Internal error。c2c doctor随后发现旧临时地址address_reclaimed，自动恢复审阅连接桥并生成新地址；网页连接尚需更新，退出1。本轮未删除、重建或授权网页插件，独立网页复核未完成。审阅连接桥不是EDGE OS应用。

## 证据及读取方法

services.json、ledger.json、details.json、exit_check.json、health_after.json、launcher_after.json。
活动SQLite只使用mode=ro、query_only=ON及读事务；strict表SELECT结果复制到内存，再调用现有对账/审计方法，未初始化生产数据库。
读取文件：data/active_experiment.json、edge_runtime.py（活动库解析）、edge_launcher.py（超时逻辑）、app/strict_ledger.py、app/shared_pool.py（现有核对方法）。
HTTP检查、账本快照、补充SQL及最终HTTP检查均exit0；网页workspace_info返回内部错误；c2c doctor exit1。报告首次生成因本机缺少tzdata失败，后使用明确UTC+8时间偏移完成；未安装依赖。
历史c2c_fix_p1_execution_void仍BLOCKED，未改变。
页面：http://127.0.0.1:8000/
