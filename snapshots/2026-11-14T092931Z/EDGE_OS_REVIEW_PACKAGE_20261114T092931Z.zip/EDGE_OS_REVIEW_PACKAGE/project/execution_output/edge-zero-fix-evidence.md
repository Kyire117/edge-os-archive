# EDGE OS zero-fill follow-up evidence

Task: `c2c_edge_zero_fills`, implementation iteration 5 after independent review.

## Historical records (read-only)

SQLite was opened read-only with `PRAGMA query_only=ON`. Experiment rows 4, 12 and 87 retain normalized `end_timestamp` and source fields but not raw Gamma `category`, `gameStartTime`, or original market payload. The earlier sanitized evidence says those end values coincide with kickoff times in market descriptions while markets remained open. The original raw response cannot be reconstructed and was not fabricated.

## Current implementation

- New activations freeze `forward-copy-v0.3` / `REQUIRE_SEMANTICALLY_VERIFIED_MARKET_END`.
- `app/polymarket.py` accepts only a supported category plus market-level Gamma `endDate`. Sports metadata must include a distinct kickoff. Every present market-level, nested sports-metadata, and event-level `gameStartTime` is parsed independently; blank, invalid, conflicting, or end-matching times cannot be marked verified. Unknown categories fail even when sports markers are present. Event-only end dates and missing categories/start times remain unverified.
- `app/research.py` records explicit `UNVERIFIED_END_TIME` / `UNRELIABLE_END_TIME` skips before fees and order books. Frozen V0.1 keeps original admission semantics; V0.2 keeps its original match-only policy. Existing entries are never replayed.
- Monitor recovery clears only stale `monitor:` errors and nonempty exception diagnostics are recorded. The dashboard counts skip reasons across all persisted experiment entries.
- README and PRD reflect V0.3 behavior and limitations.

## Verification

- Full Python suite: `126 passed, 1 warning` (Starlette/AnyIO deprecation).
- Frontend static check `node tests/ui_v1_static.test.js`: passed.
- `git diff --check`: passed with Git line-ending normalization warnings only.
- Test fixtures use temporary databases; production DB reads were read-only.
- Final read-only active experiment check: ID `FC14-D81AAF4747E2`, `RUNNING`, frozen at `forward-copy-v0.1`, cohort size 10, 96 existing entries; start `2026-09-24T01:46:21.874371Z`, end `2026-10-08T01:46:21.874371Z`.

## Evidence limits

Because raw Gamma responses were not persisted, the historical records cannot reveal whether their original API responses contained category or kickoff fields. V0.3 fails closed on ambiguous current input; it does not derive times from descriptions, titles, or later data. Official Polymarket SDK separately models Gamma market `endDate` and sports `gameStartTime`: https://github.com/Polymarket/py-sdk/blob/main/src/polymarket/models/gamma/market.py
