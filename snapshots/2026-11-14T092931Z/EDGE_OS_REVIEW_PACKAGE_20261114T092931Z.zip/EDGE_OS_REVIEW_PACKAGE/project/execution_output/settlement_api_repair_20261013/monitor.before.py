from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from datetime import datetime, timezone

from .config import settings
from .db import db
from .decay import decay_tracker
from .polymarket import pm
from .service import process_new_trade
from .settlement import refresh_open_paper_positions, refresh_signal_settlements
from . import research as research_module
from .wallet_follow_runtime import V2ActivationState, WalletFollowRuntime, v2_activation_state

log = logging.getLogger("edge.monitor")


def _ingest_error(exc: Exception) -> tuple[str, dict]:
    metadata=getattr(exc,"response_metadata",None)
    metadata=metadata if isinstance(metadata,dict) else {}
    status=metadata.get("http_status")
    detail=str(exc)[:500]
    if isinstance(exc,asyncio.TimeoutError):
        category="REQUEST_TIMEOUT"
    elif status==429 or "HTTP 429" in detail:
        category="HTTP_429"
    elif status==503 or "HTTP 503" in detail:
        category="HTTP_503"
    elif status is not None:
        category="HTTP_FAILURE"
    elif "ReadTimeout" in detail or metadata.get("last_error_type")=="ReadTimeout":
        category="READ_TIMEOUT"
    elif "ConnectTimeout" in detail or metadata.get("last_error_type")=="ConnectTimeout":
        category="CONNECT_TIMEOUT"
    elif "INVALID_REALTIME" in detail or "UNVERIFIABLE_REALTIME" in detail or "MISSING_REALTIME" in detail:
        category="INVALID_RESPONSE"
    elif metadata.get("last_error_type") in {"JSONDecodeError","ValueError"}:
        category="INVALID_RESPONSE"
    elif metadata.get("last_error_type"):
        category="TRANSPORT_ERROR"
    else:
        category="INGEST_ERROR"
    return category,{**metadata,"error_type":type(exc).__name__,"error_detail":detail}


class WalletMonitor:
    def __init__(self):
        self._stop = asyncio.Event()
        self._task: asyncio.Task | None = None
        self.last_scan_at: int | None = None
        self.last_success_at: int | None = None
        self.last_error: str | None = None
        self.last_result: dict | None = None
        self.last_scan_duration_ms: int | None = None
        self.upstream_lag_seconds: float | None = None
        self._last_paper_refresh = 0.0
        self._last_freshness_check = 0.0
        self._last_signal_settlement_refresh = 0.0
        self._experiment_task: asyncio.Task | None = None
        self._settlement_task: asyncio.Task | None = None
        self._failure_counts: dict[str, int] = {}
        self._next_scan_at: dict[str, float] = {}
        self._scan_lock = asyncio.Lock()

    def start(self):
        if not self._task or self._task.done():
            self._task = asyncio.create_task(self.run())
        if not self._experiment_task or self._experiment_task.done():
            self._experiment_task = asyncio.create_task(self._refresh_experiments())

    def _v2_state(self) -> V2ActivationState:
        if not hasattr(db, "path"):
            return V2ActivationState.NOT_CONFIGURED
        try:
            return v2_activation_state(db.path)
        except Exception:
            # A state read failure must never enable legacy settlement work.
            return V2ActivationState.READ_ERROR

    async def _refresh_once(self) -> dict:
        state = self._v2_state()
        legacy_enabled = state in {V2ActivationState.NOT_CONFIGURED, V2ActivationState.INACTIVE}
        if legacy_enabled:
            await research_module.refresh_experiment(db, pm)
            return {"v2_state": state.value, "legacy_refresh_enabled": True}
        if state in {V2ActivationState.ACTIVE, V2ActivationState.LOCKED}:
            runtime=WalletFollowRuntime(db.path, pm)
            result = await runtime.refresh_settlements()
            exit_refresh=await runtime.refresh_exit_v1() if state is V2ActivationState.ACTIVE else {"checked":0,"exited":0,"protected":0,"errors":0}
            if result.get("errors"):
                log.warning("V2 settlement refresh had %s isolated market errors", result["errors"])
            if exit_refresh.get("errors"):
                log.warning("Exit V1 refresh had %s isolated errors",exit_refresh["errors"])
            return {"v2_state": state.value, "legacy_refresh_enabled": False, "v2_settlement": result,
                    "exit_v1":exit_refresh}
        if state is V2ActivationState.READ_ERROR:
            log.error("V2 activation state could not be read; all settlement refresh is paused fail-closed")
        return {"v2_state": state.value, "legacy_refresh_enabled": False}

    async def stop(self):
        self._stop.set()
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=3)
            except Exception:
                self._task.cancel()
        if self._settlement_task and not self._settlement_task.done():
            self._settlement_task.cancel()
        if self._experiment_task and not self._experiment_task.done():
            self._experiment_task.cancel()

    async def _refresh_experiments(self):
        while not self._stop.is_set():
            try:
                await self._refresh_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.warning("experiment refresh failed: %s", exc)
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=30)
            except asyncio.TimeoutError:
                pass

    async def run(self):
        while not self._stop.is_set():
            started = time.monotonic()
            try:
                await self.scan_once()
            except Exception as e:
                self.last_error = str(e)
                log.exception("monitor scan failed")
            try:
                remaining = max(0.2, settings.poll_interval_seconds - (time.monotonic() - started))
                await asyncio.wait_for(self._stop.wait(), timeout=remaining)
            except asyncio.TimeoutError:
                pass

    async def _scan_wallet(self, wallet: dict, semaphore: asyncio.Semaphore) -> dict:
        if (hasattr(db,"begin_ingest_range") and callable(getattr(pm,"trades_page",None))):
            return await self._scan_wallet_paged(wallet,semaphore)
        address = wallet["address"]
        result = {"wallets_scanned": 0, "wallets_backing_off": 0, "trades_seen": 0, "new_trades": 0, "signals_created": 0, "errors": []}
        if time.monotonic() < self._next_scan_at.get(address, 0):
            result["wallets_backing_off"] = 1
            return result
        async with semaphore:
            result["wallets_scanned"] = 1
            scan_started_at = time.time()
            try:
                start = max(1, int(wallet.get("last_trade_ts") or (time.time() - 86400)) - 5)
                trades = await asyncio.wait_for(
                    pm.trades(
                        address,
                        start=start,
                        limit_total=settings.realtime_trade_limit,
                        realtime=True,
                    ),
                    timeout=settings.realtime_request_timeout_seconds + 1,
                )
                result["trades_seen"] = len(trades)
                existing = db.existing_trade_keys(t.get("trade_key") for t in trades)
                new_trades = [t for t in trades if t.get("trade_key") not in existing]
                result["new_trades"] = len(new_trades)
                # Oldest first so multiple new trades preserve order. One
                # bad/closed market must not discard later trades.
                for trade in sorted(new_trades, key=lambda x: x.get("timestamp", 0)):
                    try:
                        signal = await process_new_trade(wallet, trade, scan_started_at)
                        if signal:
                            result["signals_created"] += 1
                            if not settings.research_enabled and not signal.get("wallet_follow_v2"):
                                decay_tracker.schedule(signal)
                    except Exception as exc:
                        result["errors"].append(f"{address}: {exc}")
                        log.exception("trade scan failed %s: %s", address, exc)
                db.clear_wallet_monitor_error(address)
                self._failure_counts.pop(address, None)
                self._next_scan_at.pop(address, None)
            except Exception as exc:
                failures = self._failure_counts.get(address, 0) + 1
                self._failure_counts[address] = failures
                backoff = min(60, 2 ** min(failures, 6))
                self._next_scan_at[address] = time.monotonic() + backoff
                error_text=str(exc).strip() or "无详细错误信息"
                result["errors"].append(f"{address}: {type(exc).__name__}: {error_text} (retry in {backoff}s)")
                monitor_error=f"monitor: {type(exc).__name__}: {error_text}"
                db.set_wallet_error(address, monitor_error)
                log.warning("wallet scan failed %s (%s): %s", address, type(exc).__name__, error_text)
        return result

    async def _scan_wallet_paged(self, wallet: dict, semaphore: asyncio.Semaphore) -> dict:
        """Fetch a bounded cursor slice, stage it durably, then process a bounded queue batch."""
        address=wallet["address"].lower()
        result={"wallets_scanned":0,"wallets_backing_off":0,"trades_seen":0,"new_trades":0,
                "signals_created":0,"errors":[],"pages_requested":0,"backlog_remaining":0,
                "rows_received_this_slice":0,"cursor_present":False,"checkpoint_advanced":False,
                "ingest_state":None,"error_category":None,"wallet":address}
        if time.monotonic()<self._next_scan_at.get(address,0):
            result["wallets_backing_off"]=1
            return result
        async with semaphore:
            result["wallets_scanned"]=1;slice_started=time.monotonic()
            wall_started=time.time();started_iso=datetime.now(timezone.utc).isoformat();attempt_id=uuid.uuid4().hex
            pages=rows=retry_count=0;retry_backoff=0.0;error=None;error_category=None
            page_size=max(1,min(int(getattr(settings,"realtime_page_size",25)),25))
            page_budget=max(1,int(getattr(settings,"realtime_pages_per_slice",3)))
            process_budget=max(1,int(getattr(settings,"realtime_process_limit_per_slice",25)))
            baseline=int(wallet.get("last_trade_ts") or (wall_started-5))
            try:
                state=db.begin_ingest_range(address,baseline_timestamp=baseline,now=started_iso)
                next_retry=state.get("next_retry_at")
                if next_retry and float(next_retry)>time.time():
                    result["wallets_backing_off"]=1
                    result["backlog_remaining"]=sum(1 for _ in db.pending_ingest_trades(address,1))
                    return result
                if state["state"]=="FETCHING":
                    for _ in range(page_budget):
                        state=db.ingest_poll_state(address) or state
                        cursor=state.get("next_cursor")
                        start=int(state.get("range_start") or max(1,baseline-5))
                        request_started=time.monotonic()
                        try:
                            page=await asyncio.wait_for(pm.trades_page(address,start=start,cursor=cursor,limit=page_size),
                                timeout=float(getattr(settings,"realtime_request_timeout_seconds",8.0))+1)
                        except Exception as exc:
                            error=exc;error_category,evidence=_ingest_error(exc)
                            retry_count=int(evidence.get("retry_count",0) or 0)
                            retry_backoff=float(evidence.get("retry_backoff_seconds",0) or 0)
                            break
                        if not isinstance(page,dict) or not isinstance(page.get("trades"),list) or not isinstance(page.get("has_more"),bool):
                            error=ValueError("INVALID_REALTIME_PAGE_RESPONSE");error_category="INVALID_RESPONSE";break
                        next_cursor=page.get("next_cursor")
                        if page["has_more"] and (not isinstance(next_cursor,str) or not next_cursor.strip()):
                            error=ValueError("MISSING_REALTIME_NEXT_CURSOR");error_category="INVALID_RESPONSE";break
                        try:
                            db.stage_ingest_page(address,page["trades"],current_cursor=cursor,
                                next_cursor=next_cursor,has_more=page["has_more"],now=datetime.now(timezone.utc).isoformat())
                        except Exception as exc:
                            error=exc;error_category="INVALID_RESPONSE";break
                        pages+=1;rows+=len(page["trades"]);result["trades_seen"]+=len(page["trades"])
                        if not page["has_more"]:
                            break
                pending=db.pending_ingest_trades(address,process_budget)
                for queued in pending:
                    trade=queued["trade"]
                    try:
                        signal=await process_new_trade(wallet,trade,wall_started,source="DATA_API_POLL",advance_checkpoint=False)
                        outcome=(signal or {}).get("decision") if isinstance(signal,dict) else "DUPLICATE_OR_NO_SIGNAL"
                        if signal is not None:
                            result["new_trades"]+=1
                            result["signals_created"]+=1
                            if not settings.research_enabled and not signal.get("wallet_follow_v2"):
                                decay_tracker.schedule(signal)
                        db.finish_ingest_queue_item(address,queued["trade_key"],outcome=str(outcome or "NO_SIGNAL"))
                    except Exception as exc:
                        # Raw observation and routing failure remain auditable;
                        # checkpoint progress must not turn this into replay.
                        db.finish_ingest_queue_item(address,queued["trade_key"],outcome=f"ROUTING_FAILED:{type(exc).__name__}")
                        result["errors"].append(f"{address}: {type(exc).__name__}: {str(exc)[:180]}")
                state=db.ingest_poll_state(address) or state
                if state["state"]=="DRAINING":
                    result["checkpoint_advanced"]=bool(db.finalize_ingest_range(address,now=datetime.now(timezone.utc).isoformat()))
                state=db.ingest_poll_state(address) or state
                result["cursor_present"]=bool(state.get("next_cursor"))
                result["backlog_remaining"]=len(db.pending_ingest_trades(address,100000))
                if error is not None:
                    failures=int(state.get("failure_count") or 0)+1
                    backoff=min(60,2**min(failures,6))
                    retry_at=time.time()+backoff
                    detail=str(error).strip() or "no error detail"
                    db.fail_ingest_range(address,category=error_category or "INGEST_ERROR",detail=detail,
                        failure_count=failures,retry_at=retry_at,now=datetime.now(timezone.utc).isoformat())
                    self._failure_counts[address]=failures;self._next_scan_at[address]=time.monotonic()+backoff
                    result["errors"].append(f"{address}: {error_category}: {detail[:180]} (retry in {backoff}s)")
                    db.set_wallet_error(address,f"monitor: {error_category}: {detail}")
                    result["backoff_seconds"]=backoff
                elif state.get("state")=="IDLE":
                    db.clear_wallet_monitor_error(address)
                    self._failure_counts.pop(address,None);self._next_scan_at.pop(address,None)
                elif pages:
                    # Work progressed but cursor pages remain. This is backlog,
                    # not a wallet failure; the next scheduler slice continues.
                    self._failure_counts.pop(address,None);self._next_scan_at.pop(address,None)
            except Exception as exc:
                error=exc;error_category,evidence=_ingest_error(exc)
                state=db.ingest_poll_state(address) or {}
                failures=int(state.get("failure_count") or 0)+1
                backoff=min(60,2**min(failures,6));retry_at=time.time()+backoff
                db.fail_ingest_range(address,category=error_category,detail=str(exc),failure_count=failures,
                    retry_at=retry_at,now=datetime.now(timezone.utc).isoformat())
                db.set_wallet_error(address,f"monitor: {error_category}: {str(exc)[:500]}")
                self._failure_counts[address]=failures;self._next_scan_at[address]=time.monotonic()+backoff
                result["errors"].append(f"{address}: {error_category}: {str(exc)[:180]} (retry in {backoff}s)")
            finally:
                state=db.ingest_poll_state(address) or {}
                result["pages_requested"]=pages
                result["rows_received_this_slice"]=rows
                result["cursor_present"]=bool(state.get("next_cursor"))
                result["backlog_remaining"]=len(db.pending_ingest_trades(address,100000))
                result["checkpoint_timestamp"]=state.get("checkpoint_timestamp")
                result["ingest_state"]=state.get("state")
                result["error_category"]=error_category
                db.record_ingest_attempt(attempt_id=attempt_id,wallet=address,started_at=started_iso,
                    finished_at=datetime.now(timezone.utc).isoformat(),
                    outcome="ERROR" if error else "COMPLETE" if state.get("state")=="IDLE" else "BACKLOG",
                    error_category=error_category,pages_requested=pages,rows_received=rows,
                    backlog_remaining=result["backlog_remaining"],cursor_present=result["cursor_present"],
                    retry_count=retry_count,backoff_seconds=retry_backoff+float(result.get("backoff_seconds",0)),
                    elapsed_ms=round((time.monotonic()-slice_started)*1000,3),
                    evidence={"state":state.get("state"),"range_start":state.get("range_start"),
                        "next_cursor":state.get("next_cursor"),"range_max_timestamp":state.get("range_max_timestamp"),
                        "checkpoint_timestamp":state.get("checkpoint_timestamp"),"rows_received_total":state.get("rows_received"),
                        "pages_received_this_slice":pages,"rows_received_this_slice":rows,
                        "error_type":type(error).__name__ if error else None})
        return result

    async def scan_once(self, force_paper_refresh: bool = False, *, require_v2: bool = False):
        async with self._scan_lock:
            scan_started = time.monotonic()
            activation_state = self._v2_state()
            if require_v2 and activation_state is not V2ActivationState.ACTIVE:
                raise RuntimeError("WALLET_FOLLOW_V2_NOT_ACTIVE")
            legacy_refresh_enabled = activation_state in {
                V2ActivationState.NOT_CONFIGURED, V2ActivationState.INACTIVE
            }
            result = {
                "wallets_scanned": 0,
                "wallets_backing_off": 0,
                "trades_seen": 0,
                "new_trades": 0,
                "signals_created": 0,
                "errors": [],
                "ingestion":{"pages_requested":0,"rows_received":0,"backlog_remaining":0,"wallets":[]},
                "paper_checked": 0,
                "paper_marked": 0,
                "paper_settled": 0,
                "paper_errors": [],
                "replay_tokens_checked": 0,
                "replay_signals_settled": 0,
                "wallet_follow_v2_state": activation_state.value,
                "legacy_refresh_enabled": legacy_refresh_enabled,
            }
            if activation_state is V2ActivationState.READ_ERROR:
                result["errors"].append("V2 activation state read failed; legacy processing suppressed")
            semaphore = asyncio.Semaphore(max(1, settings.monitor_max_concurrency))
            wallets = db.tracked_wallets()
            now = time.monotonic()
            paper_due = legacy_refresh_enabled and (force_paper_refresh or (
                now - self._last_paper_refresh >= settings.paper_refresh_seconds
            ))
            paper_task = (
                asyncio.create_task(
                    asyncio.wait_for(
                        refresh_open_paper_positions(),
                        timeout=settings.realtime_request_timeout_seconds + 2,
                    )
                )
                if paper_due
                else None
            )
            freshness_due = now - self._last_freshness_check >= 30
            freshness_task = (
                asyncio.create_task(pm.data_freshness())
                if freshness_due
                else None
            )
            settlement_due = now - self._last_signal_settlement_refresh >= settings.signal_settlement_refresh_seconds
            if legacy_refresh_enabled and settlement_due and not self._settlement_task and not settings.research_enabled:
                self._settlement_task = asyncio.create_task(refresh_signal_settlements())
            try:
                wallet_results = await asyncio.gather(
                    *(self._scan_wallet(wallet, semaphore) for wallet in wallets)
                )
            except BaseException:
                # A cancelled isolated scan still owns these child tasks.
                # Drain failures before closing the client; don't leave an
                # unobserved data_freshness exception behind on shutdown.
                children = [task for task in (paper_task, freshness_task) if task is not None]
                for task in children:
                    if not task.done():task.cancel()
                await asyncio.gather(*children, return_exceptions=True)
                raise
            for wallet_result in wallet_results:
                for key in ("wallets_scanned", "wallets_backing_off", "trades_seen", "new_trades", "signals_created"):
                    result[key] += wallet_result[key]
                result["errors"].extend(wallet_result["errors"])
                if wallet_result.get("ingest_state") is not None:
                    ingest=result["ingestion"]
                    ingest["pages_requested"]+=int(wallet_result.get("pages_requested",0))
                    ingest["rows_received"]+=int(wallet_result.get("rows_received_this_slice",0))
                    ingest["backlog_remaining"]+=int(wallet_result.get("backlog_remaining",0))
                    if len(ingest["wallets"])<10:
                        ingest["wallets"].append({"wallet":wallet_result.get("wallet",None),
                            "state":wallet_result.get("ingest_state"),"cursor_present":wallet_result.get("cursor_present"),
                            "checkpoint_timestamp":wallet_result.get("checkpoint_timestamp"),
                            "error_category":wallet_result.get("error_category")})

            if paper_task:
                try:
                    paper_result = await paper_task
                    for key in ("paper_checked", "paper_marked", "paper_settled"):
                        result[key] = paper_result[key]
                    result["paper_errors"] = paper_result["paper_errors"]
                    self._last_paper_refresh = now
                except Exception as exc:
                    result["paper_errors"] = [f"paper refresh timeout/error: {exc}"]
                    self._last_paper_refresh = now
            if self._settlement_task and self._settlement_task.done():
                try:
                    settlement_result = self._settlement_task.result()
                    result["replay_tokens_checked"] = settlement_result["tokens_checked"]
                    result["replay_signals_settled"] = settlement_result["signals_settled"]
                    result["paper_errors"].extend(settlement_result["errors"])
                    self._last_signal_settlement_refresh = now
                except Exception as exc:
                    result["paper_errors"].append(f"signal settlement error: {exc}")
                    self._last_signal_settlement_refresh = now
                finally:
                    self._settlement_task = None
            result["wallets_auto_paused"] = [] if settings.research_enabled else db.auto_pause_slow_wallets()
            if freshness_task:
                try:
                    freshness = await freshness_task
                    serving = freshness.get("serving") if isinstance(freshness.get("serving"), dict) else {}
                    self.upstream_lag_seconds = float(serving.get("lag_seconds") or 0)
                    self._last_freshness_check = now
                except Exception as exc:
                    log.debug("data freshness unavailable: %s", exc)
            self.last_scan_at = int(time.time())
            all_errors = result["errors"] + result["paper_errors"]
            self.last_error = all_errors[0] if all_errors else None
            result["ok"] = not all_errors
            if result["ok"]:
                self.last_success_at = self.last_scan_at
            # Keep the response and logs bounded even if many wallets fail.
            result["errors"] = result["errors"][:10]
            result["upstream_lag_seconds"] = self.upstream_lag_seconds
            result["scan_duration_ms"] = round((time.monotonic() - scan_started) * 1000)
            self.last_scan_duration_ms = result["scan_duration_ms"]
            self.last_result = result
            return result


monitor = WalletMonitor()
