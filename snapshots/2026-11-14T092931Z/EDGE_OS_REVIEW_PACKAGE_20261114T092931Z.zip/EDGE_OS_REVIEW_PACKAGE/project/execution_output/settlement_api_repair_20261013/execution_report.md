# 交易档案 API_FAILURE 修复

状态：EXECUTED_VALIDATED_LOCALLY。2026-10-13 09:58:47 上海时间完成后台核对，10:03 页面核对正常。

## 实测问题

修复前：59 笔已成交持仓 +39 未成交观察为 API_FAILURE。原失败记录大量 TimeoutError、reason 为空；后台轮询也持续 transport failure。同一真实市场以新客户端单独查询 1.336 秒成功，且正式 resolved。已确认运行中的长期读取失败和新连接可用；旧连接池、代理/网络抖动的唯一底层起因未独立证实，不把连接池损坏当成已证实根因。

## 实际修改

- app/polymarket.py：连续 transport error 达到 3 次时可限频换公共读取连接池（至少间隔 30 秒），原代理/TLS 校验/连接限制保留；旧连接只在在途请求结束后关闭。保存底层异常类型与 HTTP 状态，保留 exception cause，避免只显示 request failed。Gamma 查询每个 open/closed 分支改为 1 次、单阶段超时 6 秒，外层仍严格 15 秒；减少内外超时互相取消，未放宽盘口或入场规则。
- app/wallet_follow_runtime.py：按最近结算检查时间轮换限量刷新的市场，避免最老未解决市场一直占据前 100 条；并发 2；每次检查写现有 wallet_v2_audit 的 SETTLEMENT_CHECK，保存成功/失败、时间和安全异常类型；原始失败证据保留于旧记录。API_FAILURE 写入失败不再静默吞掉，单独返回 persistence_errors 并记录日志。
- app/monitor.py：一页成功但仍有 backlog 时也清除已恢复的 monitor 红字；不假称整段已完成，不推进未成功 checkpoint。
- app/main.py：只读 health 新增 public_http.pool_reset_count / last_transport_error_type，没有凭据或网络地址。
- 3 个测试文件：新增 8 个确定性回归，详见 exact.diff。前端源文件未修改。

## 测试与修复验证

专项 144 passed；全仓 425 passed；均 exit 0、1 个既有 Starlette/anyio 警告。compileall 和 git diff --check exit 0。初轮测试因临时目录过长造成已有 Windows 备份测试失败，改用短临时目录后重跑；初次全仓发现注入 client 的兼容性问题，修复后完整重跑通过；不修改或清理系统长路径配置。

59 笔原失败持仓：26 FORMALLY_RESOLVED、33 RESULT_PENDING，API_FAILURE=0。所有 episode 的 API_FAILURE=0。20 个跟踪钱包当前错误数 0，扫描已成功。378 条已记录结算检查为 SUCCESS。新增连接池换池路径已通过确定性测试；当前观察实际 pool_reset_count=0，恢复后的初始 ConnectError 不代表持续故障。

## 数据和财务安全

- 部署前一致性 SQLite 备份：C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\data\backups\edge_mvp.pre-continuous-fast-path-20261013T015511Z.db，integrity_check=ok，SHA256=4b8ff00a2d9701c72112d9dbe1953e208e213741ddf5397a2e8a752340ae2c74。
- 仅重启身份核实的 paper runtime，通过已有启动台继续 FORWARD-20261012T073343Z，没有创建/清空/重新激活实验。
- 原 85 fills、459 strict decisions 的每行内容全部保持；版本配置、严格规则、激活 manifest 完全保持。
- 原旧实验库全部表 count/hash 与历史只读基线一致：True。旧 VOID checkpoint 未改，无历史 VOID correction。
- 原 REJECTED 转为 FILLED/PARTIAL 的数量：0；重复正式 financial settlement 分组：0；当前库 quick_check=ok。
- 全部模拟账户在一致性副本上 ledger 与 audit 对账通过，reserved cash=0。
- 修复后的公开请求恢复后继续按原冻结规则处理新观察，已有成交未重写；权威结果到达后，之前未能结算的持仓按正常流程入账，所以已实现 PnL 会更新。本次核对时 realized PnL=-31.802815，不是通过重算历史或补造利润得到的。
- live_orders / live_trading 仍 false；没有订单签名、私钥或真实交易。

## 仍需如实看待

这是本次恢复与数分钟运行核验，不是长期稳定性或低延迟保证。若真实上游不可用、身份/正式结果缺失，仍保留 pending 或 API_FAILURE，不伪造结算。断线后的延迟信号仍按当前冻结策略处理，未暗改信号年龄规则。已有 EXECUTION_COMMIT_INCOMPLETE 等执行拒绝不在本轮范围，未回放其成交。未做网页 ChatGPT 独立审查，未宣称 REVIEW_PASS。

完整证据：生成与核对脚本 verify_recovery.py、runtime_verified.json、manifest.json、exact.diff、targeted_final.txt、full_final.txt、journal_verified.png。
