from __future__ import annotations

import logging
import asyncio
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import sqlite3
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .config import settings
from edge_runtime import public_run
from .analytics import wallet_card_data
from .db import db
from .decay import decay_tracker
from .discovery import discovery
from .monitor import monitor
from .polymarket import pm
from .service import analyze_and_store, refresh_due_public_profiles, validate_wallet
from .service import ingest_fast_path_trade
from .polygon_fast_path import PolygonProducer, ProducerConfig
from .wallet_follow_runtime import (activate_v2, status_v2, v2_episode_list,
                                    v2_episode_detail)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
_profile_refresh_task: asyncio.Task | None = None
polygon_fast = PolygonProducer(db, pm, ingest_fast_path_trade, ProducerConfig(
    url=settings.polygon_wss_url, enabled=settings.polygon_fast_enabled,
    contracts=tuple(x.strip().lower() for x in settings.polygon_exchange_contracts.split(',') if x.strip()),
    confirmation_depth=settings.polygon_confirmation_depth, backfill_blocks=settings.polygon_backfill_blocks))


def _wallet_view(item: dict, paper_totals: dict) -> dict:
    return {**item, "card": wallet_card_data(item, paper_totals.get(item["address"]))}


@asynccontextmanager
async def lifespan(app: FastAPI):
    db_path=Path(db.path)
    backup=db_path.with_suffix('.pre-ai-v1.backup')
    if db_path.exists() and not backup.exists():
        with sqlite3.connect(db.path) as source, sqlite3.connect(backup) as target:
            source.backup(target)
    db.init()
    if settings.research_enabled:
        ai.start()
    else:
        decay_tracker.start()
    monitor.start()
    discovery.start()
    polygon_fast.start()
    yield
    await polygon_fast.stop()
    await discovery.stop()
    await monitor.stop()
    await ai.stop()
    await decay_tracker.stop()
    await pm.close()


app = FastAPI(title="Polymarket Edge OS MVP", version="0.3.0-ai-research", lifespan=lifespan)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=['127.0.0.1','localhost','testserver'])

@app.middleware('http')
async def local_writes(request, call_next):
    if request.method in ('POST','PUT','PATCH','DELETE'):
        origin=request.headers.get('origin')
        if request.headers.get('x-edge-client')!='dashboard' or (origin and origin!=str(request.base_url).rstrip('/')):
            return JSONResponse({'detail':'请从本机 Edge OS 页面操作'},status_code=403)
    response=await call_next(request)
    if request.url.path.startswith('/api/') or request.url.path in ('/','/static/app.js','/static/launcher.html'):
        response.headers['Cache-Control']='no-store'
    return response

from .research_api import router, ai
app.include_router(router)
app.mount("/static", StaticFiles(directory=STATIC), name="static")


class WalletIn(BaseModel):
    address: str


class TrackIn(BaseModel):
    tracked: bool


@app.get("/")
async def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/health")
async def health():
    ai_config = ai.public_config()
    return {
        "ok": True,
        "mode": "PAPER_ONLY",
        "experiment": public_run(db.path),
        "polygon_fast_path": polygon_fast.status(),
        "live_trading": False,
        "monitor_last_scan_at": monitor.last_scan_at,
        "monitor_last_success_at": monitor.last_success_at,
        "monitor_running": bool(monitor._task and not monitor._task.done()),
        "monitor_last_error": monitor.last_error,
        "monitor_last_result": monitor.last_result,
        "monitor_last_scan_duration_ms": monitor.last_scan_duration_ms,
        "data_api_lag_seconds": monitor.upstream_lag_seconds,
        "poll_interval_seconds": settings.poll_interval_seconds,
        "paper_refresh_seconds": settings.paper_refresh_seconds,
        "discovery_enabled": settings.discovery_enabled,
        "discovery_last_run_at": discovery.last_run_at,
        "discovery_last_success_at": discovery.last_success_at,
        "discovery_running": bool(discovery._task and not discovery._task.done()),
        "discovery_last_error": discovery.last_error,
        "ai": {key: ai_config.get(key) for key in ("provider", "enabled", "has_key", "daily_call_limit", "calls_today")},
    }


@app.get("/api/wallet-follow-v2")
async def wallet_follow_v2_status():
    """Read-only status; does not initialize V2 tables or activate a strategy."""
    try:
        return status_v2(db.path)
    except sqlite3.Error as exc:
        raise HTTPException(503, "Wallet Follow V2 status is temporarily unavailable") from exc


@app.get("/api/polygon-fast-path")
async def polygon_fast_path_status():
    return polygon_fast.status()


@app.get("/api/wallet-follow-v2/episodes")
async def wallet_follow_v2_episodes(offset: int = Query(0, ge=0),
                                    limit: int = Query(50, ge=1, le=200), status: str = ""):
    try:
        return v2_episode_list(db.path, offset=offset, limit=limit, status=status)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from None
    except sqlite3.Error as exc:
        raise HTTPException(503, "Wallet Follow V2 episodes are temporarily unavailable") from exc


@app.get("/api/wallet-follow-v2/episodes/{episode_id}")
async def wallet_follow_v2_episode_detail(episode_id: str):
    try:
        item = v2_episode_detail(db.path, episode_id)
    except sqlite3.Error as exc:
        raise HTTPException(503, "Wallet Follow V2 evidence is temporarily unavailable") from exc
    if item is None:
        raise HTTPException(404, "No such V2 episode")
    return item


@app.post("/api/wallet-follow-v2/scan")
async def scan_wallet_follow_v2():
    """Manual scan is restricted to the live V2 routing path."""
    try:
        return await monitor.scan_once(require_v2=True)
    except RuntimeError as exc:
        if str(exc) == "WALLET_FOLLOW_V2_NOT_ACTIVE":
            raise HTTPException(409, str(exc)) from None
        raise HTTPException(503, "Wallet Follow V2 scan failed") from exc


@app.post("/api/wallet-follow-v2/activate")
async def activate_wallet_follow_v2():
    """Explicit one-time activation. This endpoint is never called at startup."""
    try:
        return activate_v2(db)
    except RuntimeError as exc:
        code=str(exc)
        status=409 if "CONFLICT" in code or "ALREADY" in code else 503
        raise HTTPException(status, code) from None
    except (sqlite3.Error, OSError) as exc:
        raise HTTPException(503, "Wallet Follow V2 activation failed safely") from exc


@app.get("/api/dashboard")
async def dashboard():
    return db.dashboard()


@app.get("/api/live")
async def live_snapshot():
    """One bounded request for the auto-refreshing dashboard."""
    return {
        "dashboard": db.dashboard(),
        "wallets": db.list_wallets(),
        "signals": db.recent_signals(200),
        "paper": db.paper_trades(200),
        "decay": db.alpha_decay(),
        "candidates": db.candidates(100),
        "health": {
            "monitor_last_scan_at": monitor.last_scan_at,
            "monitor_last_scan_duration_ms": monitor.last_scan_duration_ms,
            "data_api_lag_seconds": monitor.upstream_lag_seconds,
            "monitor_last_error": monitor.last_error,
        },
    }


@app.get("/api/wallets")
async def wallets():
    global _profile_refresh_task
    if _profile_refresh_task is None or _profile_refresh_task.done():
        due = db.public_profile_refresh_candidates(time.time())
        if due:
            _profile_refresh_task = asyncio.create_task(refresh_due_public_profiles(due))
    totals = db.wallet_paper_totals()
    return [_wallet_view(item, totals) for item in db.list_wallets()]


@app.post("/api/wallets/analyze")
async def analyze(body: WalletIn):
    try:
        address = validate_wallet(body.address)
        return await analyze_and_store(address)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(502, f"Polymarket 数据读取失败：{e}")


@app.get("/api/wallets/{address}")
async def wallet(address: str):
    try:
        address = validate_wallet(address)
    except ValueError as e:
        raise HTTPException(400, str(e))
    result = db.get_wallet(address)
    if not result:
        raise HTTPException(404, "钱包尚未分析")
    return _wallet_view(result, db.wallet_paper_totals())


@app.post("/api/wallets/{address}/track")
async def track(address: str, body: TrackIn):
    try:
        address = validate_wallet(address)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not db.get_wallet(address):
        raise HTTPException(404, "钱包尚未分析")
    try:
        db.set_wallet_tracked(address, body.tracked)
    except ValueError as e:
        raise HTTPException(409,str(e))
    return db.get_wallet(address)


@app.post("/api/monitor/scan")
async def scan_now():
    try:
        return await monitor.scan_once(force_paper_refresh=True)
    except Exception as e:
        raise HTTPException(502, str(e))


@app.get("/api/discovery/candidates")
async def discovery_candidates(limit: int = 100):
    return db.candidates(max(1, min(limit, 500)))


@app.post("/api/discovery/run")
async def discovery_now():
    try:
        return {
            "ok": True,
            "started": discovery.trigger(),
            "last_result": discovery.last_result,
        }
    except Exception as e:
        raise HTTPException(502, str(e))


@app.get("/api/signals")
async def signals(limit: int = 100):
    return db.recent_signals(max(1, min(limit, 500)))


@app.get("/api/signals/{signal_id}/snapshots")
async def signal_snapshots(signal_id: int):
    return db.signal_snapshots(signal_id=signal_id)


@app.get("/api/alpha-decay")
async def alpha_decay():
    return db.alpha_decay()


@app.get("/api/paper-trades")
async def paper_trades(limit: int = 100):
    return db.paper_trades(max(1, min(limit, 500)))
