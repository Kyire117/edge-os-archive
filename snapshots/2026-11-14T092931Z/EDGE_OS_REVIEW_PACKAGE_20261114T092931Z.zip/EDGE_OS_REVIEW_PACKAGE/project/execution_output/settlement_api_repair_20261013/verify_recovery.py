"""Verify the running repair read-only; reconcile only a consistent DB copy."""
from pathlib import Path
import collections
import hashlib
import json
import sqlite3
import sys
import urllib.request
from datetime import datetime, timezone

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT))
from edge_runtime import active_database
from app.strict_ledger import StrictPaperLedger

opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
health=json.load(opener.open('http://127.0.0.1:8000/api/health',timeout=10))
state=json.load(opener.open('http://127.0.0.1:8000/api/wallet-follow-v2',timeout=10))
affected=json.loads((OUT/'affected_episodes.json').read_text(encoding='utf-8'))['episode_ids']
baseline=json.loads((OUT/'pre_deploy_pointer.json').read_text(encoding='utf-8'))
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
copy=OUT/f'verification_{stamp}.db'
source=sqlite3.connect(active_database().as_uri()+'?mode=ro',uri=True)
source.execute('PRAGMA query_only=ON')
with sqlite3.connect(copy) as target:source.backup(target)
source.close()
current=sqlite3.connect(copy.as_uri()+'?mode=ro',uri=True)
current.row_factory=sqlite3.Row;current.execute('PRAGMA query_only=ON')
before=sqlite3.connect(Path(baseline['backup']).as_uri()+'?mode=ro',uri=True)
before.row_factory=sqlite3.Row;before.execute('PRAGMA query_only=ON')

def rows(c,table):
    return [dict(x) for x in c.execute('SELECT * FROM "'+table+'"')]

def hash_rows(values):
    data='\n'.join(sorted(json.dumps(x,sort_keys=True,separators=(',',':'),default=str) for x in values))
    return hashlib.sha256(data.encode()).hexdigest()

preserved={}
for table,key in [('strict_fills','fill_id'),('strict_decisions','decision_id')]:
    prior=rows(before,table);new={x[key]:x for x in rows(current,table)}
    preserved[table]={'prior_count':len(prior),'unchanged':all(new.get(x[key])==x for x in prior)}
for table in ['wallet_v2_versions','strict_rule_versions']:
    preserved[table]={'unchanged':hash_rows(rows(before,table))==hash_rows(rows(current,table))}
preserved['activation_manifest']={'unchanged':(OUT/'active_experiment.before.json').read_bytes()==(ROOT/'data/active_experiment.json').read_bytes()}
episodes={x['episode_id']:x for x in rows(current,'wallet_v2_episodes')}
statuses=collections.Counter(episodes[x]['resolution_status'] for x in affected)
wallet_errors=sum(bool(x['last_error']) for x in rows(current,'wallets') if x['tracked'])
accounts=[x['account_id'] for x in rows(current,'strict_accounts')]
checks=collections.Counter(json.loads(x['evidence_json']).get('result') for x in rows(current,'wallet_v2_audit') if x['action']=='SETTLEMENT_CHECK')
current.close();before.close()
reconcile={a:{'ledger':StrictPaperLedger(copy,a).reconcile(),'audit':StrictPaperLedger(copy,a).verify_audit_chain()} for a in accounts}
result={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'snapshot':str(copy),
        'run_id':health['experiment']['run_id'],'state':state['state'],
        'live_trading':health['live_trading'],'live_orders':state['frozen_config']['live_orders'],
        'affected_before':len(affected),'affected_after_statuses':dict(statuses),
        'filled_api_failures_now':sum(x['paper_status'] in ('FILLED','PARTIAL') and x['resolution_status']=='API_FAILURE' for x in episodes.values()),
        'all_api_failures_now':sum(x['resolution_status']=='API_FAILURE' for x in episodes.values()),
        'tracked_wallet_errors_now':wallet_errors,'monitor_last_success_at':health.get('monitor_last_success_at'),
        'monitor_last_error':health.get('monitor_last_error'),'public_http':health.get('public_http'),
        'counts':state['counts'],'performance':state['performance'],
        'preservation':preserved,'all_preserved':all(x['unchanged'] for x in preserved.values()),
        'settlement_request_checks':dict(checks),'accounts':reconcile,
        'all_accounts_reconcile':all(x['ledger']['ok'] and x['audit']['ok'] for x in reconcile.values())}
(OUT/'runtime_verified.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='accounts'},ensure_ascii=True,indent=2))
