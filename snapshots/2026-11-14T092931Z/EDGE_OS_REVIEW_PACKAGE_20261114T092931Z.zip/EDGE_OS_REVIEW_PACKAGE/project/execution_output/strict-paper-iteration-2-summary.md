# Strict paper Iteration 2 execution output

Task: `c2c_edge_strict_paper_v1`, Iteration 2. State: ready for independent review.

## Change scope

- `app/strict_paper.py`: engine `strict-paper-engine-v2` treats BUY amount as a fixed gross notional, excluding fees. The fresh execution book determines quantity; the quote is evidence only. SELL remains quantity-driven.
- `app/strict_ledger.py`: additive nullable notional fields on isolated strict orders; a v2 partial fill becomes terminal `PARTIALLY_FILLED` and releases unused BUY cash or SELL share reservation atomically. Existing v1 rows keep their prior behavior.
- `tests/test_strict_paper_iteration1.py`: retain v1 ledger fixtures and update engine expectations.
- `tests/test_strict_paper_iteration2.py`: deterministic budget, fresh-price, partial, restart, duplicate, fee-reservation, reconciliation, and additive-init coverage.
- `STRICT_PAPER_ITERATION_2.md`: behavior and accounting definition.

The frozen v2 evidence names `GROSS_NOTIONAL_EXCLUDING_FEES`. Gross execution cost cannot exceed requested notional; fees are additional. The ledger checks the actual gross plus fees against reserved cash. No fee formula changed.

## Verification

- `strict-paper-iteration-2-targeted-tests.txt`: 43 passed.
- `strict-paper-iteration-2-full-tests.txt`: 181 passed, 1 third-party deprecation warning.
- `strict-paper-iteration-2-static-check.txt`: JavaScript syntax check and 1 static UI test passed.
- `git diff --check`: passed; only Git line-ending notices were printed.
- `strict-paper-iteration-2-production-preservation.txt`: read-only production database check. SHA-256 `88A8D65386EB5C02A82E83F3304E21FA9FA598193DE0B6072BE0B2E238157D21`, same as pre-verification value; one experiment, 10 cohort wallets, 219 experiment entries, zero `strict_*` tables. Tests used temporary databases.

The strict v2 engine is opt-in and is not wired into the running V0.1 experiment, legacy paper trades, or dashboard. Historical records were not replayed or changed. Wallet-follow strategy V2 has not begun.
