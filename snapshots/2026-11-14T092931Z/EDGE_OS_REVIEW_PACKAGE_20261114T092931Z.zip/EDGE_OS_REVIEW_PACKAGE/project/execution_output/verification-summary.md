# EDGE OS Forward Copy V0 verification

## Git baseline

- Local root commit: `a4b5400` (`Establish local source baseline`)
- Remote repository: none
- Dirty files are listed by the final `git status`; no product database, backup, credentials, virtual environment, or runtime output is staged.
- Complete baseline diff: `review-diff.patch` (13 files, 1,030 insertions, 10 deletions; SHA-256 `586E5A04EF99BB1ADB04C577EF102246FF80A2F87433468201BE03399769B324`). The patch was regenerated after the latest schema-migration test edit; it contains the Iteration 1 old-column removal and migration regression.
- Local Git command evidence and artifact hash are recorded in `git-evidence.txt` for comparison; this does not change the connector's inability to query the nested repository directly.

## Automated checks

- Baseline before implementation: `57 passed, 1 warning`.
- Independent review remediation suite: `101 passed, 1 warning` (baseline 57 + 44 V0 cases).
- Python compile check: passed for all `app/*.py` modules.
- JavaScript parse check: `node --check app/static/app.js` passed.
- Database upgrade: performed against a local SQLite backup copy; original database was not opened for writes.

The single test warning is a Starlette deprecation notice for AnyIO's `BlockingPortal` alias; no test failed.

## Preserved database counts (copy before -> after `Database.init()`)

| Table | Before | After |
|---|---:|---:|
| wallets | 35 | 35 |
| trades | 38,854 | 38,854 |
| signals | 611 | 611 |
| paper_trades | 169 | 169 |
| research_entries | 92 | 92 |

## Remaining limitations

- The V0 experiment has not been activated; no live forward sample or strategy profitability is claimed.
- Order-book source timestamps accept numeric seconds/milliseconds, numeric strings, and timezone-aware ISO strings. Missing, malformed, non-finite, future, or over-15-second timestamps are skipped. A fresh timestamp still cannot guarantee that displayed public depth remains executable at fill time.
- Legacy Iteration 1 opposite-outcome positions are preserved as-is during schema upgrade. When they conflict, the stricter SQLite unique index is not created; a serialized transactional guard prevents new entries for the same experiment/wallet/market.
- Cohort selection uses existing tracked wallets, the existing eight-market historical gate, recent recorded activity, and FAST candidate priority. Markets lacking verifiable expected end time are skipped.
- Recent/FAST prioritization is an indirect activity proxy. Historical per-trade market duration is not backfilled when the source does not provide it.
- Market expected end time remains distinct from formal resolution. Unresolved positions stay open and outside realized PnL after the entry window closes.
- ChatGPT's final independent source/patch review returned `REVIEW_PASS` (iteration 4), verifying F01–F05 and the old-schema migration behavior. The connector cannot inspect the nested repository's native Git status/diff (`isRepo=false`); it reviewed the exported complete patch and cross-checked current source. The final review verified that the regenerated patch includes the migration-test lines. Git state is reported locally but was not independently queried by ChatGPT.
