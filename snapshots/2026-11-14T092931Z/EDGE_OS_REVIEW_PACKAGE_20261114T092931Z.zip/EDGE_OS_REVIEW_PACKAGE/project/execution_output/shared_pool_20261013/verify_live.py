"""Post-start evidence: production is read-only; reconciliation uses a copy."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import sqlite3
import sys
import urllib.request

ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from edge_runtime import active_database
from app.strict_ledger import StrictPaperLedger
from app.shared_pool import capital_metrics

opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
health=json.load(opener.open('http://127.0.0.1:8000/api/health',timeout=10))
state=json.load(opener.open('http://127.0.0.1:8000/api/wallet-follow-v2',timeout=20))
conversion=json.loads((OUT/'production_conversion.json').read_text(encoding='utf-8'))
snapshot=OUT/'runtime_snapshot.db'
src=sqlite3.connect(active_database().as_uri()+'?mode=ro',uri=True);src.execute('PRAGMA query_only=ON')
with sqlite3.connect(snapshot) as target:src.backup(target)
target.close()  # Finish/checkpoint a reused WAL-mode copy before file hashing.
src.close()
con=sqlite3.connect(snapshot.as_uri()+'?mode=ro',uri=True);con.row_factory=sqlite3.Row;con.execute('PRAGMA query_only=ON')
before=sqlite3.connect(Path(conversion['backup']).as_uri()+'?mode=ro',uri=True);before.row_factory=sqlite3.Row;before.execute('PRAGMA query_only=ON')

def rows(c,t):return [dict(x) for x in c.execute('SELECT * FROM '+t)]

preserved={}
for table,key in [('strict_fills','fill_id'),('strict_decisions','decision_id'),('strict_cash_ledger','entry_id'),('strict_audit_events','seq')]:
    current={x[key]:x for x in rows(con,table)}
    preserved[table]=all(current.get(x[key])==x for x in rows(before,table))
preserved['wallet_v2_versions']=rows(con,'wallet_v2_versions')==rows(before,'wallet_v2_versions')
accounts=rows(con,'strict_accounts')
old_accounts={x['account_id'] for x in rows(before,'strict_accounts')}
new=[x for x in accounts if x['account_id'] not in old_accounts and not x['account_id'].endswith(':shared-cash')]
pool=capital_metrics(con,'wallet-follow-v2.0')
at=pool['activated_at']
live_fills=[dict(x) for x in con.execute('SELECT fill_id,account_id,side,gross_amount,fee,created_at FROM strict_fills WHERE julianday(created_at)>=julianday(?)',(at,))]
result={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'run_id':health['experiment']['run_id'],
    'monitor_running':health['monitor_running'],'monitor_last_success_at':health.get('monitor_last_success_at'),
    'monitor_last_error':health.get('monitor_last_error'),'live_trading':health['live_trading'],
    'live_orders':state['frozen_config']['live_orders'],'snapshot':str(snapshot),
    'snapshot_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),
    'integrity_check':con.execute('PRAGMA integrity_check').fetchone()[0],
    'foreign_key_check':[tuple(x) for x in con.execute('PRAGMA foreign_key_check')],
    'capital_pool':pool,'original_rows_preserved':preserved,
    'initial_cash_event_count':con.execute("SELECT COUNT(*) FROM strict_cash_ledger WHERE entry_type='INITIAL_CASH'").fetchone()[0],
    'new_initial_cash_events':con.execute("SELECT COUNT(*) FROM strict_cash_ledger WHERE entry_type='INITIAL_CASH' AND julianday(created_at)>=julianday(?)",(at,)).fetchone()[0],
    'new_wallet_books':new,'new_wallet_books_have_zero_initial_cash':all(Decimal(x['initial_cash'])==0 for x in new),
    'genuine_post_conversion_fills':live_fills,'return_curve_points':len(pool['return_curve']),
    'financial_settlement_events':con.execute("SELECT count(*) FROM strict_capital_events WHERE event_type='SETTLEMENT'").fetchone()[0]}
con.close();before.close()
result['ledger_checks']={x['account_id']:StrictPaperLedger(snapshot,x['account_id']).reconcile() for x in accounts}
result['all_ledger_checks_pass']=all(x['ok'] for x in result['ledger_checks'].values())
result['audit']=StrictPaperLedger(snapshot,accounts[0]['account_id']).verify_audit_chain()
assert result['integrity_check']=='ok' and not result['foreign_key_check']
assert result['all_ledger_checks_pass'] and result['audit']['ok']
assert all(preserved.values()) and result['new_initial_cash_events']==0
assert result['new_wallet_books_have_zero_initial_cash']
assert pool['fixed_initial_cash']=='7000.000000' and pool['reconciliation']['ok']
assert result['monitor_running'] and result['live_trading'] is False and result['live_orders'] is False
(OUT/'runtime_verified.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('capital_pool','ledger_checks','new_wallet_books','genuine_post_conversion_fills')},ensure_ascii=True,indent=2))
print('POST_CONVERSION_FILLS',len(live_fills),'ZERO_FUNDED_NEW_BOOKS',len(new))
