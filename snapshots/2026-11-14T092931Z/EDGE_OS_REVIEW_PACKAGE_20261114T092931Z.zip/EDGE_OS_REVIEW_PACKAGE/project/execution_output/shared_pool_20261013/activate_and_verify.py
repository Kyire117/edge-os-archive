"""User-approved offline cash conversion, with exact preservation evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import socket
import sqlite3
import sys

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from edge_runtime import active_database
from app.shared_pool import activate_pool, capital_metrics
from app.strict_ledger import StrictPaperLedger

with socket.socket() as sock:
    sock.settimeout(1)
    assert sock.connect_ex(('127.0.0.1',8000))!=0, 'APPLICATION_MUST_BE_STOPPED'
source=active_database()
assert source.parent==(ROOT/'data').resolve()
manifest=ROOT/'data/active_experiment.json'
before_manifest=manifest.read_bytes()
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup=ROOT/'data/backups'/f'edge_forward.pre-shared-pool-final-{stamp}.db'

def connect_ro(path):
    con=sqlite3.connect(Path(path).as_uri()+'?mode=ro',uri=True)
    con.row_factory=sqlite3.Row;con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
    return con

def rows(con,table):
    return [dict(x) for x in con.execute('SELECT * FROM "'+table.replace('"','""')+'"')]

def fingerprint(con):
    result={}
    for name, in con.execute("SELECT name FROM sqlite_master WHERE type='table'"):
        data=sorted(json.dumps(tuple(x),ensure_ascii=False,separators=(',',':'),default=str) for x in con.execute('SELECT * FROM "'+name.replace('"','""')+'"'))
        result[name]={'count':len(data),'sha256':hashlib.sha256('\n'.join(data).encode()).hexdigest()}
    return result

src=connect_ro(source)
with sqlite3.connect(backup) as target:src.backup(target)
target.close()
src.rollback();src.close()
prior=connect_ro(backup)
assert prior.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
before=fingerprint(prior)
before_rows={t:rows(prior,t) for t in ['strict_cash_ledger','strict_audit_events','strict_accounts']}
report={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'source_db':str(source),
    'source_sha256_before':hashlib.sha256(source.read_bytes()).hexdigest(),
    'backup':str(backup),'backup_sha256':hashlib.sha256(backup.read_bytes()).hexdigest(),
    'backup_size':backup.stat().st_size,'backup_integrity_check':'ok','before_tables':before}
prior.close()

report['activation']=activate_pool(source,initial_cash='7000',at=datetime.now(timezone.utc))
current=connect_ro(source)
after=fingerprint(current)
report['after_tables']=after
exceptions={'strict_accounts','strict_cash_ledger','strict_audit_events','sqlite_sequence'}
report['unchanged_protected_tables']={t:before[t]==after[t] for t in before if t not in exceptions}
report['all_protected_tables_unchanged']=all(report['unchanged_protected_tables'].values())
report['preserved_append_only_rows']={}
for table,key in [('strict_cash_ledger','entry_id'),('strict_audit_events','seq')]:
    new={x[key]:x for x in rows(current,table)}
    report['preserved_append_only_rows'][table]=all(new.get(x[key])==x for x in before_rows[table])
report['account_original_capital_and_identity_preserved']=True
after_accounts={x['account_id']:x for x in rows(current,'strict_accounts')}
for row in before_rows['strict_accounts']:
    report['account_original_capital_and_identity_preserved'] &= all(after_accounts[row['account_id']][field]==row[field] for field in ('account_id','ledger_version','initial_cash','fees_total','created_at'))
report['capital_pool']=capital_metrics(current,'wallet-follow-v2.0')
report['integrity_check']=current.execute('PRAGMA integrity_check').fetchone()[0]
report['foreign_key_check']=[tuple(x) for x in current.execute('PRAGMA foreign_key_check')]
ids=list(after_accounts)
current.rollback();current.close()
report['accounts']={aid:StrictPaperLedger(source,aid).reconcile() for aid in ids}
report['all_accounts_reconcile']=all(x['ok'] for x in report['accounts'].values())
report['audit']=StrictPaperLedger(source,ids[0]).verify_audit_chain()
assert report['all_protected_tables_unchanged']
assert all(report['preserved_append_only_rows'].values())
assert report['account_original_capital_and_identity_preserved']
assert report['all_accounts_reconcile'] and report['audit']['ok']
assert report['integrity_check']=='ok' and not report['foreign_key_check']
assert manifest.read_bytes()==before_manifest
data=json.loads(before_manifest)
data.update(funding_model='SHARED_FIXED',fixed_initial_cash='7000.000000',funding_version='shared-cash-pool-v1')
pending=manifest.with_suffix('.shared-pool.pending.json')
pending.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
pending.replace(manifest)
report['manifest_frozen_config_preserved']=json.loads(before_manifest)['frozen_config']==data['frozen_config']
report['source_sha256_after']=hashlib.sha256(source.read_bytes()).hexdigest()
(OUT/'production_conversion.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('accounts','before_tables','after_tables','capital_pool','unchanged_protected_tables')},ensure_ascii=True,indent=2))
