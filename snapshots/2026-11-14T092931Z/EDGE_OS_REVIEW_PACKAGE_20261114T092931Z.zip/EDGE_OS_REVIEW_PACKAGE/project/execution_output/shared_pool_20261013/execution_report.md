# 固定共享资金池与首页看板 — 执行报告

状态：EXECUTED / 已加载并持续模拟运行。用户确认的方案：固定 7,000 USD 初始本金，延续当前实验，承接实际余额、仓位与盈亏。

当前生产验证时点：2026-10-13T12:40:22.454418+08:00（上海时间）。以下金额均为模拟资金；运行继续，时点数值会变化。

## 实施结果

- 资金版本：shared-cash-pool-v1。
- 实验 ID：FORWARD-20261012T073343Z，没有另开实验或清空旧记录。
- 统一现金账户：wallet-follow-v2.0:shared-cash；钱包订单和持仓仍分别归属原钱包。
- 新钱包初始资金为零；数据库触发器拒绝旧逻辑继续追加本金。
- 扣款、预留、IOC 释放、退出回款、权威正式结算均使用同一现金账户。并发使用 SQLite BEGIN IMMEDIATE，禁止透支。
- 原始策略/执行配置保持原样，包括 $25 本金、费用另计、5% ROI、10% 深度、500ms、3000ms、live_orders=false。
- 初始 INITIAL_CASH 流水仍有 7 条，共享池启用后新增 0 条。
- 恢复运行后的真实前向模拟成交：6 笔；资金曲线已有 17 点（承接起点 + 16 次实际金融结算）。没有制造信号。

## 首页

首页最上方展示：当前资金占用率、平均资金占用率、本金周转次数、平均持仓时长。四项均读取实际账本，并沿用每 10 秒自动刷新。

已实现收益 / 固定初始本金使用折线图；每次金融结算或模拟退出原子追加真实图点，下一次页面刷新显示。横轴上海时间，纵轴收益率。承接旧盈亏起点，未实现盈亏不计入。

平均占用从共享池启用时间开始按时间积分，不伪造启用前动态资金池的历史平均值。本金周转与关闭仓位时长包含本轮承接交易，页面注明口径。尚未成交的预留订单被正式结果取消时，会及时结束其预留占用记录。

解决了内置浏览器旧 CSS 缓存问题，为 CSS 和 JS 添加版本查询参数。已实际核对两列布局、四项数值及曲线，截图：homepage.png。

## 生产快照

| 项目 | 数值 |
|---|---:|
| 固定初始本金 | 7000.000000 USD |
| 可用现金 | 5625.797765 USD |
| 预留现金 | 0.000000 USD |
| 未平仓成本 | 1130.409038 USD |
| 已实现收益率 | -0.03482759957142857142857142857 |
| 当前资金占用率 | 0.1614870054285714285714285714 |
| 平均资金占用率 | 0.1788150987450997548059449539 |
| 本金周转 | 0.4533649011428571428571428571 |
| 平均持仓时长 | 15309.57687366666666666666667 秒 |

资金核对：True；8 个账本均核对通过；审计链 1531 条事件通过。快照 integrity_check=ok，foreign_key_check 无异常。

## 备份和迁移

切换前完整 SQLite backup：`C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\data\backups\edge_forward.pre-shared-pool-final-20261013T035726Z.db`。

- SHA256：`9a4e9fab74228376e0b1a8c200840fe29639d6d7dc4ef6afcd7a5c30198a2f6f`
- 大小：346353664 字节
- integrity_check：ok
- 已检查文件结束关闭后的 SHA256 与记录一致。

归集现金 5491.077259 USD；没有重新补足 7,000 USD 现金。原有 7 个钱包账户通过成对转账归集，转移净额为零，共享现金账户初始资金字段为零。持仓成本和原有盈亏不修改。

原 strict_accounts 的 >0 CHECK 不支持零资金钱包账本，因此原子重建该表的 CHECK 为 >=0，原行完整复制并检查外键。其余表不重建；追加 strict_cash_pools 和 strict_capital_events 及保护触发器。具体行为见 SHARED_CASH_POOL.md。

生产转换期间，除账户余额/现金流及新增现金、审计记录外，所有原业务表 count/hash 保持一致。原账户初始资金、身份、费用和创建时间保持原样。原始现金流水与审计行完整保留。恢复运行后原成交、决策、现金流水、审计行及冻结策略行仍逐条保持完整。正在运行产生的新交易/结算是正常追加，不要求全表 hash 永久不变。

验证快照：runtime_snapshot.db，SHA256 `917526172a8c344ccc84d5bd31c8f7af8d95de87ac1069bd2133a6933bdba131`；已再次检查落盘文件哈希匹配。备份和快照均被 git ignore。

## 验证

- 资金池专项：19 passed；退出码 0，pool_release.txt。
- 全仓库：444 passed, 1 existing DeprecationWarning；退出码 0，full_release.txt。
- 相关综合测试：154 passed（较早阶段），targeted_final.txt；最终全部由全仓库回归覆盖。
- node --check app/static/app.js：0。
- node tests/ui_v1_static.test.js：0。
- python -m compileall -q app tests：0。
- git diff --check：0。
- 再次启动验证：固定本金、共享池激活时间、已有曲线均保留；没有重新归集或补充资金。
- monitor_running=True，最后成功扫描时间戳 1791866418，monitor_last_error=None。
- live_trading=False，live_orders=False。

新增钱包零资金行为由临时数据库和数据库触发器测试覆盖；生产验证时尚未出现新的钱包金融账本，未将此项冒称为真实新钱包观察。

## 变更文件

- app/shared_pool.py
- app/strict_ledger.py
- app/wallet_follow_v2.py
- app/wallet_follow_runtime.py
- edge_runtime.py
- app/static/index.html
- app/static/app.js
- app/static/ui_v1.css
- tests/test_shared_pool.py
- tests/ui_v1_static.test.js
- SHARED_CASH_POOL.md
- data/active_experiment.json

此外追加 execution_output 下的核查、转换、验证脚本及证据。exact.diff 是本轮工作副本前后差异，不包含此前其他任务的 Git 未提交改动。未清理 Git、未提交或上传仓库。

## 本地审查与限制

本地审查覆盖统一现金 owner 的全部资金入口/出口、钱包持仓隔离、资金守恒、数据库保全、零初始资金约束、并发预留、资金不足竞态、部分成交/崩溃恢复、重启保留，以及预留因正式结算取消后的平均占用边界。

- 不设置新钱包额度或优先级，活跃钱包仍可能占用较多共享资金。
- 平均资金占用率仅从共享池启用起统计。
- 缺少有效持仓估值时，未实现盈亏/市值净资产仍为未知，不能把持仓成本当市值。
- 本轮没有验证网络长期稳定性或跟单延迟达标。
- 本轮是本地审查与验证，没有声称网页 ChatGPT 独立 REVIEW_PASS。原有未完成 C2C/VOID 检查点保持原样。

证据索引：production_conversion.json、runtime_verified.json、restart_verified.json、validation.json、manifest.json、exact.diff、homepage.png。
