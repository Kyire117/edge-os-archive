# V4 Paper prestart backup and snapshot

Task: c2c_v4_paper_prestart_backup_snapshot, Iteration 1

Captured at: 2026-10-03T03:19:27.542364+00:00 (UTC)

Workspace: `C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp`
Commit: `a4b5400d08db355c9e286a7a5d18023e75bb1e07`; branch `main`; dirty=True.

Source: `C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\data\edge_mvp.db`
Main-file SHA256: `ff025eb47b682e125ae82980f203628c4ebf429703622d144b4c28294264e0aa`

Backup: `C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\data\backups\edge_mvp.pre-v4-paper-20261003T031927303834Z.db`
SHA256: `b3126b7090f27aac8c7eef4c3dd1954580241575ebe3140832035383e7da42c1`
Size: 122265600 bytes
Integrity: ['ok']

Snapshot: `C:\Users\Kyrie\Documents\EDGE OS 101\polymarket-edge-mvp-fixed\polymarket-edge-mvp\execution_output\v4_prestart_20261003T031927303834Z\snapshot.json`

## Method and scope

No application imports/DB constructors, runtime actions, migrations or replay. Source connections use mode=ro, query_only=ON, BEGIN and ROLLBACK. A pinned source read transaction feeds SQLite's backup API; a newly created destination is the only writable SQLite connection. The backup is checked against the pinned source counts and full protected-table hashes. No naive DB file copy and no immutable=1 flag that would ignore WAL.

Source journal_mode=wal, WAL exists=True, SHM exists=True; source total_changes=0.

Logical hashes: SHA256 of UTF-8 canonical JSON array; each full row is a sorted-key JSON object; full rows sorted lexicographically by canonical JSON, duplicate rows retained. JSON text columns retain exact original text. Address set uses exact distinct tracked=1 addresses, sorted canonically. Main-file hashes are physical metadata; logical snapshots/backup include committed WAL and may differ from the main-file-only representation. SQLite read locks/sidecar existence are operational metadata, not application writes.

## Current state

| Item | Actual |
|---|---|
| Episodes | 85 |
| Fills / orders | 0 / 0 |
| Order statuses | {} |
| Tracked wallets | 20 |
| Reserved account cash | 0.000000 |
| V2 state / live_orders | FORWARD_TEST / False |
| Effective forward cutoff | 2026-10-01T03:46:07.104741+00:00 |
| V4 rule registrations / fills | 0 / 0 |

Full V2 version rows/config and strict rule rows are in snapshot.json.

## Historical baseline comparison

| Field | Expected | Actual | Matches |
|---|---|---|---|
| source_db_main_sha256 | "ff025eb47b682e125ae82980f203628c4ebf429703622d144b4c28294264e0aa" | "ff025eb47b682e125ae82980f203628c4ebf429703622d144b4c28294264e0aa" | True |
| wallet_v2_episodes_count | 85 | 85 | True |
| strict_fills_count | 0 | 0 | True |
| strict_rule_engine_versions | ["strict-paper-engine-v3"] | ["strict-paper-engine-v3"] | True |
| live_orders | false | false | True |

## Backup comparison

{"all_table_row_counts":true,"strict_accounts":true,"strict_audit_events":true,"strict_cash_ledger":true,"strict_decisions":true,"strict_fills":true,"strict_orders":true,"strict_positions":true,"strict_rule_versions":true,"strict_settlements":true,"wallet_v2_audit":true,"wallet_v2_episodes":true,"wallet_v2_events":true,"wallet_v2_runtime_events":true,"wallet_v2_versions":true,"wallets":true}

## Final production preservation comparison

| Field | Unchanged |
|---|---|
| source_db_main_sha256 | True |
| all_table_row_counts | True |
| tracked_wallet_address_set_sha256 | True |
| wallet_v2_episodes | True |
| strict_decisions | True |
| wallet_v2_versions | True |
| wallets | True |
| strict_rule_versions | True |
| strict_fills | True |
| strict_orders | True |
| strict_accounts | True |
| strict_positions | True |
| strict_cash_ledger | True |
| strict_settlements | True |
| wallet_v2_events | True |
| wallet_v2_runtime_events | True |
| wallet_v2_audit | True |
| strict_audit_events | True |

## All table counts

| Table | Rows |
|---|---|
| paper_trades | 0 |
| research_ai_runs | 86 |
| research_audit | 1796 |
| research_entries | 0 |
| research_exclusions | 0 |
| research_experiment_entries | 0 |
| research_experiment_events | 0 |
| research_experiment_wallets | 0 |
| research_experiments | 0 |
| research_identity | 0 |
| research_jobs | 89 |
| research_leader_outcomes | 20568 |
| research_versions | 0 |
| signal_snapshots | 0 |
| signals | 0 |
| sqlite_sequence | 4 |
| strict_accounts | 5 |
| strict_audit_events | 42 |
| strict_cash_ledger | 5 |
| strict_decisions | 37 |
| strict_fills | 0 |
| strict_marks | 0 |
| strict_orders | 0 |
| strict_positions | 0 |
| strict_rule_versions | 1 |
| strict_settlements | 0 |
| system_state | 2 |
| trades | 40014 |
| wallet_candidates | 188 |
| wallet_category_stats | 150 |
| wallet_public_profiles | 35 |
| wallet_v2_audit | 47 |
| wallet_v2_episodes | 85 |
| wallet_v2_events | 388 |
| wallet_v2_runtime_events | 48 |
| wallet_v2_versions | 1 |
| wallets | 35 |

## Limitations

No production process was stopped or locked for writing. If another process commits during the task, comparisons may report drift; it must not be attributed to this read-only tool or forced back to the historical baseline. Config resolution uses actual source field/default and the invoking environment, not a dump of another process's environment. Successful unchanged comparisons establish observed preservation across this capture interval; they do not promise future state will remain unchanged. V4 paper runtime has not been started.
