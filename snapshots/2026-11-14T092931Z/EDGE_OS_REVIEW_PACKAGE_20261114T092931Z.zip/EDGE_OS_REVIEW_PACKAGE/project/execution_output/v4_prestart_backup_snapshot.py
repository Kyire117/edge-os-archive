"""Opt-in prestart evidence tool. Stdlib only; production is read-only.

Do not import application DB classes, launch a server, or alter source pragmas.
The only SQLite write connection is the new, exclusively created backup file.
"""
from __future__ import annotations

import ast
import base64
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess


ROOT = Path(__file__).resolve().parents[1]
TASK = "c2c_v4_paper_prestart_backup_snapshot"
EXPECTED = {
    "source_db_main_sha256": "ff025eb47b682e125ae82980f203628c4ebf429703622d144b4c28294264e0aa",
    "wallet_v2_episodes_count": 85,
    "strict_fills_count": 0,
    "strict_rule_engine_versions": ["strict-paper-engine-v3"],
    "live_orders": False,
}
PROTECTED = (
    "wallet_v2_episodes", "strict_decisions", "wallet_v2_versions", "wallets",
    "strict_rule_versions", "strict_fills", "strict_orders", "strict_accounts",
    "strict_positions", "strict_cash_ledger", "strict_settlements",
    "wallet_v2_events", "wallet_v2_runtime_events", "wallet_v2_audit",
    "strict_audit_events",
)


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def file_hash(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    def binary(item):
        if isinstance(item, bytes):
            return {"sqlite_blob_base64": base64.b64encode(item).decode("ascii")}
        raise TypeError(type(item).__name__)
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                      allow_nan=False, default=binary)


def rows_hash(rows):
    # Include full values of every column; JSON strings remain exact strings.
    # Sort canonical full rows, then hash a canonical JSON array (duplicates retained).
    body = "[" + ",".join(sorted(canonical(row) for row in rows)) + "]"
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "--no-optional-locks", *args], cwd=ROOT,
                                   text=True, encoding="utf-8").strip()


def resolve_source():
    # Read the actual Settings field without importing any application code.
    config_path = ROOT / "app/config.py"
    tree = ast.parse(config_path.read_text(encoding="utf-8-sig"))
    settings = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Settings")
    field = next(node for node in settings.body if isinstance(node, ast.AnnAssign)
                 and isinstance(node.target, ast.Name) and node.target.id == "database_path")
    call = field.value
    if not (isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
            and isinstance(call.func.value, ast.Name) and call.func.value.id == "os"
            and call.func.attr == "getenv" and len(call.args) == 2):
        raise RuntimeError("Unrecognized database config; stop before backup")
    variable, default = [ast.literal_eval(arg) for arg in call.args]
    if variable != "DATABASE_PATH":
        raise RuntimeError("Unexpected database environment variable")
    override = os.getenv(variable)
    configured = override if override is not None else default
    path = Path(configured)
    path = (ROOT / path).resolve() if not path.is_absolute() else path.resolve()
    expected_path = (ROOT / "data/edge_mvp.db").resolve()
    if path != expected_path or not path.is_file():
        raise RuntimeError("Resolved source is not the verified production data/edge_mvp.db")
    with path.open("rb") as stream:
        header = stream.read(16)
    if header != b"SQLite format 3\x00":
        raise RuntimeError("Source is not a SQLite database")
    return path, {
        "config_source": str(config_path), "config_source_sha256": file_hash(config_path),
        "config_line": field.lineno, "environment_variable": variable,
        "environment_override_present": override is not None,
        "configured_path": configured, "resolved_path": str(path),
        "db_consumer": "app/db.py: Database.path = path or settings.database_path; db = Database()",
        "resolution_base": str(ROOT),
        "application_imports": False, "application_db_classes_instantiated": False,
    }


def readonly(path):
    con = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("BEGIN")
    # Establish a consistent committed SQLite/WAL read view immediately.
    con.execute("SELECT COUNT(*) FROM sqlite_master").fetchone()
    return con


def capture(con, source_path):
    captured = utc_now()
    names = [row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    counts = {name: con.execute('SELECT COUNT(*) FROM "' + name.replace('"', '""') + '"').fetchone()[0]
              for name in names}
    missing = sorted(set(PROTECTED) - set(names))
    if missing:
        raise RuntimeError("Required production tables missing: " + ",".join(missing))
    rows = {name: [dict(row) for row in con.execute('SELECT * FROM "' + name + '"')]
            for name in PROTECTED}
    hashes = {name: rows_hash(value) for name, value in rows.items()}
    versions = sorted(rows["wallet_v2_versions"], key=lambda row: row["strategy_version"])
    current = next((row for row in versions if row["strategy_version"] == "wallet-follow-v2.0"), None)
    config = json.loads(current["config_json"]) if current else None
    clean = con.execute("SELECT audit_id,occurred_at FROM wallet_v2_audit WHERE action='CLEAN_FORWARD_RESTART' ORDER BY audit_id DESC LIMIT 1").fetchone()
    effective_cutoff = clean["occurred_at"] if clean else current["activated_at"] if current else None
    addresses = sorted({row["address"] for row in rows["wallets"] if row["tracked"] == 1})
    account_rows = sorted(rows["strict_accounts"], key=lambda row: row["account_id"])
    rules = sorted(rows["strict_rule_versions"], key=lambda row: row["rule_version"])
    orders = rows["strict_orders"]
    order_map = {row["order_id"]: row for row in orders}
    def is_v4(record):
        return str(record.get("engine_version", "")).startswith("strict-paper-engine-v4") or str(record.get("rule_version", "")).startswith("strict-paper-rules-v4")
    v4_fills = []
    for fill in rows["strict_fills"]:
        ev = json.loads(fill["evidence_json"])
        if is_v4(ev) or is_v4(order_map.get(fill["order_id"], {})):
            v4_fills.append(fill["fill_id"])
    return {
        "captured_at": captured, "source_db_path": str(source_path),
        "source_db_main_sha256": file_hash(source_path),
        "source_db_main_size_bytes": source_path.stat().st_size,
        "journal_mode": con.execute("PRAGMA journal_mode").fetchone()[0],
        "wal_exists": Path(str(source_path) + "-wal").exists(),
        "shm_exists": Path(str(source_path) + "-shm").exists(),
        "sqlite_data_version": con.execute("PRAGMA data_version").fetchone()[0],
        "read_only": {"uri_mode": "ro", "query_only": con.execute("PRAGMA query_only").fetchone()[0],
                      "total_changes": con.total_changes, "transaction_end": "ROLLBACK"},
        "all_table_row_counts": counts, "protected_full_table_hashes": hashes,
        "wallet_v2_episodes_count": counts["wallet_v2_episodes"],
        "wallet_v2_episodes_sha256": hashes["wallet_v2_episodes"],
        "strict_decisions_sha256": hashes["strict_decisions"],
        "wallet_v2_versions": versions, "wallet_v2_versions_sha256": hashes["wallet_v2_versions"],
        "strict_rule_versions": rules, "strict_rule_versions_sha256": hashes["strict_rule_versions"],
        "tracked_wallet_count": len(addresses), "tracked_wallet_address_set_sha256": rows_hash(addresses),
        "strict_fills_count": counts["strict_fills"], "strict_orders_count": len(orders),
        "strict_orders_status_summary": dict(sorted(Counter(row["status"] for row in orders).items())),
        "strict_accounts": {
            "count": len(account_rows), "available_cash": str(sum((Decimal(row["available_cash"]) for row in account_rows), Decimal(0))),
            "reserved_cash": str(sum((Decimal(row["reserved_cash"]) for row in account_rows), Decimal(0))),
            "nonzero_reserved_account_count": sum(Decimal(row["reserved_cash"]) != 0 for row in account_rows),
            "rows": account_rows, "sha256": hashes["strict_accounts"],
        },
        "strict_order_reservations": {
            "cash": str(sum((Decimal(row["reserve_cash_remaining"]) for row in orders), Decimal(0))),
            "shares": str(sum((Decimal(row["reserved_quantity_remaining"]) for row in orders), Decimal(0))),
        },
        "current_v2": {"version_row": current, "state": current["state"] if current else None,
            "activated_at": current["activated_at"] if current else None,
            "evidence_cutoff": current["evidence_cutoff"] if current else None,
            "effective_forward_cutoff": effective_cutoff,
            "clean_forward_restart_audit": dict(clean) if clean else None,
            "config": config, "live_orders": config.get("live_orders") if isinstance(config, dict) else None},
        "v4_strict_rule_registration_count": sum(is_v4(rule) for rule in rules),
        "contains_v4_strict_rule_registration": any(is_v4(rule) for rule in rules),
        "v4_fill_count": len(v4_fills), "contains_v4_fill": bool(v4_fills),
    }


def main():
    if Path.cwd().resolve() != ROOT:
        raise RuntimeError("Run only from bound EDGE OS 101 repository root")
    source_path, resolution = resolve_source()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    backup_path = ROOT / "data/backups" / f"edge_mvp.pre-v4-paper-{stamp}.db"
    if git("ls-files", "--", "data/backups"):
        raise RuntimeError("Backup directory contains tracked files")
    git("check-ignore", "--", str(backup_path.relative_to(ROOT)))
    output = ROOT / "execution_output" / f"v4_prestart_{stamp}"
    output.mkdir(parents=True, exist_ok=False)
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    git_state = {"commit": git("rev-parse", "HEAD"), "branch": git("branch", "--show-current"),
                 "dirty": bool(git("status", "--porcelain=v1", "--untracked-files=normal")),
                 "status": git("status", "--porcelain=v1", "--untracked-files=normal")}
    source = readonly(source_path)
    try:
        before = capture(source, source_path)
        (output / "before.json").write_text(json.dumps(before, indent=2, ensure_ascii=False), encoding="utf-8")
        with backup_path.open("xb"):
            pass
        dest = sqlite3.connect(backup_path.as_uri() + "?mode=rw", uri=True)
        try:
            dest.execute("PRAGMA journal_mode=DELETE")
            source.backup(dest, pages=256, sleep=0.05)
        finally:
            dest.close()
        source_changes = source.total_changes
    finally:
        source.rollback()
        source.close()
    backup = readonly(backup_path)
    try:
        integrity = [row[0] for row in backup.execute("PRAGMA integrity_check")]
        backup_view = capture(backup, backup_path)
    finally:
        backup.rollback()
        backup.close()
    backup_wal = Path(str(backup_path) + "-wal")
    if backup_wal.exists() and backup_wal.stat().st_size > 0:
        raise RuntimeError("Backup is not self-contained; destination WAL is nonempty")
    backup_comparison = {
        "all_table_row_counts": before["all_table_row_counts"] == backup_view["all_table_row_counts"],
        **{name: before["protected_full_table_hashes"][name] == backup_view["protected_full_table_hashes"][name]
           for name in PROTECTED},
    }
    after_con = readonly(source_path)
    try:
        after = capture(after_con, source_path)
    finally:
        after_con.rollback()
        after_con.close()
    preservation = {
        "source_db_main_sha256": before["source_db_main_sha256"] == after["source_db_main_sha256"],
        "all_table_row_counts": before["all_table_row_counts"] == after["all_table_row_counts"],
        "tracked_wallet_address_set_sha256": before["tracked_wallet_address_set_sha256"] == after["tracked_wallet_address_set_sha256"],
        **{name: before["protected_full_table_hashes"][name] == after["protected_full_table_hashes"][name]
           for name in PROTECTED},
    }
    observed = {key: before[key] for key in ("source_db_main_sha256", "wallet_v2_episodes_count", "strict_fills_count")}
    observed.update(strict_rule_engine_versions=sorted({rule["engine_version"] for rule in before["strict_rule_versions"]}),
                    live_orders=before["current_v2"]["live_orders"])
    baseline = {key: {"expected": expected, "actual": observed[key], "matches": observed[key] == expected}
                for key, expected in EXPECTED.items()}
    result = {
        "task_id": TASK, "iteration": 1, "captured_at": before["captured_at"],
        "workspace_root": str(ROOT), "workspace_name": "EDGE OS 101", "git": git_state,
        "source_resolution": resolution, "source_db_path": str(source_path),
        "source_db_main_sha256": before["source_db_main_sha256"],
        "backup": {"path": str(backup_path), "sha256": file_hash(backup_path),
                   "size_bytes": backup_path.stat().st_size, "integrity_check": integrity,
                   "method": "sqlite3.Connection.backup from pinned BEGIN read transaction; committed WAL included",
                   "outside_git_tracking": bool(git("check-ignore", "--", str(backup_path.relative_to(ROOT)))),
                   "source_total_changes": source_changes, "same_read_view_comparison": backup_comparison},
        "snapshot": before, "expected_safety_baseline_comparison": baseline,
        "final_read_only_snapshot": after, "preservation_comparison": preservation,
        "all_preservation_checks_passed": all(preservation.values()),
        "all_backup_checks_passed": integrity == ["ok"] and all(backup_comparison.values()),
        "snapshot_path": str(output / "snapshot.json"), "report_path": str(output / "report.md"),
        "safety": {"production_sql_write_statements": 0, "application_db_classes_instantiated": False,
                   "runtime_started_stopped_restarted": False, "production_initialized_or_migrated": False,
                   "historical_replay": False, "v4_runtime_started": False},
    }
    (output / "after.json").write_text(json.dumps(after, indent=2, ensure_ascii=False), encoding="utf-8")
    (output / "backup_view.json").write_text(json.dumps(backup_view, indent=2, ensure_ascii=False), encoding="utf-8")
    (output / "snapshot.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    report = [f"# V4 Paper prestart backup and snapshot\n\nTask: {TASK}, Iteration 1\n",
              f"Captured at: {before['captured_at']} (UTC)\n",
              f"Workspace: `{ROOT}`\nCommit: `{git_state['commit']}`; branch `{git_state['branch']}`; dirty={git_state['dirty']}.\n",
              f"Source: `{source_path}`\nMain-file SHA256: `{before['source_db_main_sha256']}`\n",
              f"Backup: `{backup_path}`\nSHA256: `{result['backup']['sha256']}`\nSize: {result['backup']['size_bytes']} bytes\nIntegrity: {integrity}\n",
              f"Snapshot: `{output / 'snapshot.json'}`\n",
              "## Method and scope\n\nNo application imports/DB constructors, runtime actions, migrations or replay. Source connections use mode=ro, query_only=ON, BEGIN and ROLLBACK. A pinned source read transaction feeds SQLite's backup API; a newly created destination is the only writable SQLite connection. The backup is checked against the pinned source counts and full protected-table hashes. No naive DB file copy and no immutable=1 flag that would ignore WAL.\n",
              f"Source journal_mode={before['journal_mode']}, WAL exists={before['wal_exists']}, SHM exists={before['shm_exists']}; source total_changes={source_changes}.\n",
              "Logical hashes: SHA256 of UTF-8 canonical JSON array; each full row is a sorted-key JSON object; full rows sorted lexicographically by canonical JSON, duplicate rows retained. JSON text columns retain exact original text. Address set uses exact distinct tracked=1 addresses, sorted canonically. Main-file hashes are physical metadata; logical snapshots/backup include committed WAL and may differ from the main-file-only representation. SQLite read locks/sidecar existence are operational metadata, not application writes.\n",
              "## Current state\n\n| Item | Actual |\n|---|---|",
              f"| Episodes | {before['wallet_v2_episodes_count']} |",
              f"| Fills / orders | {before['strict_fills_count']} / {before['strict_orders_count']} |",
              f"| Order statuses | {canonical(before['strict_orders_status_summary'])} |",
              f"| Tracked wallets | {before['tracked_wallet_count']} |",
              f"| Reserved account cash | {before['strict_accounts']['reserved_cash']} |",
              f"| V2 state / live_orders | {before['current_v2']['state']} / {before['current_v2']['live_orders']} |",
              f"| Effective forward cutoff | {before['current_v2']['effective_forward_cutoff']} |",
              f"| V4 rule registrations / fills | {before['v4_strict_rule_registration_count']} / {before['v4_fill_count']} |\n",
              "Full V2 version rows/config and strict rule rows are in snapshot.json.\n",
              "## Historical baseline comparison\n\n| Field | Expected | Actual | Matches |\n|---|---|---|---|",
              *[f"| {key} | {canonical(item['expected'])} | {canonical(item['actual'])} | {item['matches']} |" for key, item in baseline.items()],
              "\n## Backup comparison\n\n" + canonical(backup_comparison),
              "\n## Final production preservation comparison\n\n| Field | Unchanged |\n|---|---|",
              *[f"| {key} | {value} |" for key, value in preservation.items()],
              "\n## All table counts\n\n| Table | Rows |\n|---|---|",
              *[f"| {key} | {value} |" for key, value in before['all_table_row_counts'].items()],
              "\n## Limitations\n\nNo production process was stopped or locked for writing. If another process commits during the task, comparisons may report drift; it must not be attributed to this read-only tool or forced back to the historical baseline. Config resolution uses actual source field/default and the invoking environment, not a dump of another process's environment. Successful unchanged comparisons establish observed preservation across this capture interval; they do not promise future state will remain unchanged. V4 paper runtime has not been started.\n",
    ]
    (output / "report.md").write_text("\n".join(report), encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("task_id", "captured_at", "backup", "snapshot_path", "report_path",
          "preservation_comparison", "all_backup_checks_passed", "all_preservation_checks_passed",
          "expected_safety_baseline_comparison")}, indent=2, ensure_ascii=False))
    if not result["all_backup_checks_passed"] or not result["all_preservation_checks_passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
