from pathlib import Path
from datetime import datetime,timezone,timedelta
from decimal import Decimal as D
from collections import Counter,defaultdict
import sqlite3,json,csv,math,hashlib
OUT=Path(__file__).resolve().parent
meta=json.loads((OUT/'snapshot.json').read_text(encoding='utf-8'))
M=meta['manifest'];STRATEGY=M['strategy_version'];PREFIX=STRATEGY+':'
con=sqlite3.connect((OUT/'snapshot.db').as_uri()+'?mode=ro',uri=True);con.row_factory=sqlite3.Row;con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
def rows(sql,args=()):return [dict(r) for r in con.execute(sql,args)]
def dec(x):
 try:
  v=D(str(x));return v if v.is_finite() else None
 except:return None
def num(x):return dec(x) or D(0)
def parsed(s):
 try:return datetime.fromisoformat(str(s).replace('Z','+00:00'))
 except:return None
def j(s):
 try:return json.loads(s or '{}')
 except:return {}
def counter(data,key):return dict(Counter(str(r[key]) for r in data))
def key(r):return (r['account_id'],r['condition_id'],r['token_id'],r['outcome'])
def pct(values,p):
 a=sorted(values)
 if not a:return None
 k=(len(a)-1)*p;i=int(k);return a[i]+(a[min(i+1,len(a)-1)]-a[i])*(k-i)
def distro(values):return {'n':len(values),'p50':pct(values,.5),'p90':pct(values,.9),'p95':pct(values,.95),'max':max(values) if values else None}
E=rows('SELECT * FROM wallet_v2_episodes WHERE strategy_version=?',(STRATEGY,))
F=rows('SELECT * FROM strict_fills WHERE account_id LIKE ?',(PREFIX+'%',))
P=rows('SELECT * FROM strict_positions WHERE account_id LIKE ?',(PREFIX+'%',))
A=rows('SELECT * FROM strict_accounts WHERE account_id LIKE ?',(PREFIX+'%',))
O=rows('SELECT * FROM strict_orders WHERE account_id LIKE ?',(PREFIX+'%',))
S=rows('SELECT * FROM strict_settlements WHERE account_id LIKE ?',(PREFIX+'%',))
C=rows('SELECT entry_id,entry_type,cash_flow,fee,created_at FROM strict_cash_ledger WHERE account_id LIKE ?',(PREFIX+'%',))
V=rows('SELECT * FROM wallet_v2_versions WHERE strategy_version=?',(STRATEGY,))[0]
POOL=rows('SELECT * FROM strict_cash_pools')[0]
profiles={r['address']:r.get('username') for r in rows('SELECT address,username FROM wallet_public_profiles')}
wallets=rows('SELECT address,tracked,last_error FROM wallets')
byfills=defaultdict(list);bysettlements=defaultdict(list)
for f in F:byfills[key(f)].append(f)
for s in S:bysettlements[key(s)].append(s)
buy=[r for r in F if r['side']=='BUY'];sell=[r for r in F if r['side']=='SELL']
filled=[r for r in E if r['paper_status'] in ('FILLED','PARTIAL')]
byepisode={(PREFIX+r['wallet'],r['condition_id'],r['first_token_id'],r['first_outcome']):r for r in E}
projection={};decision_ids={}
for r in rows('''SELECT e.episode_id,d.decision_id,d.evidence_json FROM wallet_v2_episodes e
 JOIN strict_orders o ON o.order_id=e.paper_order_id
 LEFT JOIN strict_decisions d ON d.idempotency_key=o.idempotency_key
 WHERE e.strategy_version=? AND e.paper_status IN ('FILLED','PARTIAL')''',(STRATEGY,)):
 evidence=j(r['evidence_json']);projection[r['episode_id']]=dec(evidence.get('projected_net_roi_if_win'));decision_ids[r['episode_id']]=r['decision_id']
source_byepisode={r['episode_id']:j(r['evidence_json']).get('source','UNKNOWN') for r in rows("SELECT episode_id,evidence_json FROM wallet_v2_events WHERE event_type='FIRST'")}

def price_band(v):
 if v is None:return 'UNKNOWN'
 if v<D('.2'):return '<0.20'
 if v<D('.4'):return '[0.20,0.40)'
 if v<D('.6'):return '[0.40,0.60)'
 if v<=D('.8'):return '[0.60,0.80]'
 return '>0.80'
def delay_band(v):
 if v is None:return 'UNKNOWN'
 if v<0:return 'NEGATIVE'
 for boundary,label in [(15,'<15s'),(60,'15-60s'),(300,'1-5min'),(1800,'5-30min'),(7200,'30min-2h'),(43200,'2-12h')]:
  if v<boundary:return label
 return '>=12h'
def roi_band(v):
 if v is None:return 'UNKNOWN'
 for boundary,label in [(D('.05'),'<5%'),(D('.10'),'5-10%'),(D('.25'),'10-25%'),(D('.50'),'25-50%'),(D('1'),'50-100%'),(D('3'),'100-300%'),(D('10'),'300-1000%')]:
  if v<boundary:return label
 return '>=1000%'
lineage=[];unmatched=[];closed=[];openpos=[]
for p in P:
 pk=key(p);e=byepisode.get(pk);fs=byfills[pk];bs=[f for f in fs if f['side']=='BUY'];ss=[s for s in bysettlements[pk] if s['payout_per_share'] is not None and num(s['quantity'])>0 and s['status'] in ('FORMALLY_RESOLVED','VOID')]
 if num(p['quantity'])>0:openpos.append(p)
 if not bs:unmatched.append({'position':pk,'reason':'NO_BUY'});continue
 gross=sum((num(f['gross_amount']) for f in bs),D(0));entry_fee=sum((num(f['fee']) for f in bs),D(0));sell_proceeds=sum((num(f['gross_amount']) for f in fs if f['side']=='SELL'),D(0));exit_fees=sum((num(f['fee']) for f in fs if f['side']=='SELL'),D(0));payout=sum((num(s['cash_flow']) for s in ss),D(0));cost=gross+entry_fee
 first=min(parsed(f['created_at']) for f in bs);last=max([parsed(s['observed_at']) for s in ss]+[parsed(f['created_at']) for f in fs if f['side']=='SELL'],default=None)
 qty=sum((num(f['quantity']) for f in bs),D(0));entry=gross/qty if qty else None
 isclosed=num(p['quantity'])==0
 pnl=num(p['realized_pnl']);delay=dec(e['detection_delay_seconds']) if e else None;roi=projection.get(e['episode_id']) if e else None
 mathematical_pnl=sell_proceeds+payout-cost-exit_fees if isclosed else None
 row={'episode_id':e['episode_id'] if e else None,'decision_id':decision_ids.get(e['episode_id']) if e else None,'wallet':e['wallet'] if e else p['account_id'].removeprefix(PREFIX),'username':profiles.get(e['wallet']) if e else None,'condition_id':p['condition_id'],'token_id':p['token_id'],'outcome':p['outcome'],'category':e['category'] if e else 'UNKNOWN','paper_status':e['paper_status'] if e else None,'resolution_status':e['resolution_status'] if e else None,'direction_correct':e['direction_correct'] if e else None,'entry_price':dec(e['execution_price']) if e else entry,'leader_price':dec(e['leader_price']) if e else None,'detection_delay_seconds':delay,'projected_roi_if_win':roi,'entry_cost_including_fee':cost,'gross_buy':gross,'buy_fee':entry_fee,'sell_fee':exit_fees,'buy_quantity':qty,'remaining_quantity':num(p['quantity']),'remaining_cost':num(p['cost_basis']),'realized_pnl':pnl,'mathematical_pnl':mathematical_pnl,'pnl_reconciles':mathematical_pnl==pnl if isclosed else None,'closed':isclosed,'fill_ids':[f['fill_id'] for f in fs],'order_ids':list({f['order_id'] for f in fs}),'settlement_ids':[s['settlement_id'] for s in ss],'first_fill_at':first.isoformat(),'financial_close_at':last.isoformat() if isclosed and last else None,'holding_seconds':D(str((last-first).total_seconds())) if isclosed and last else None,'source':source_byepisode.get(e['episode_id'],'UNKNOWN') if e else 'UNKNOWN'}
 row.update(price_band=price_band(row['entry_price']),delay_band=delay_band(delay),roi_band=roi_band(roi),financial_result='WIN' if pnl>0 else 'LOSS' if pnl<0 else 'BREAKEVEN')
 if not e:unmatched.append({'position':pk,'reason':'NO_EPISODE'})
 lineage.append(row)
 if isclosed:closed.append(row)

def aggregate(group, dimensions):
 values=defaultdict(list)
 for r in group:values[tuple(r.get(k,'UNKNOWN') for k in dimensions)].append(r)
 result=[]
 for labels,rs in values.items():
  cost=sum((r['entry_cost_including_fee'] for r in rs),D(0));pnl=sum((r['realized_pnl'] for r in rs),D(0));n=len(rs);wins=sum(r['realized_pnl']>0 for r in rs);losses=sum(r['realized_pnl']<0 for r in rs)
  result.append(dict(zip(dimensions,labels),n=n,wins=wins,losses=losses,pnl=pnl,cost=cost,net_roi=pnl/cost if cost else None,financial_win_rate=D(wins)/n))
 return sorted(result,key=lambda r:r['pnl'],reverse=True)
rollups={k:aggregate(closed,[k]) for k in ['wallet','price_band','category','delay_band','roi_band','source']}
matrix=aggregate(closed,['wallet','price_band','category','delay_band','roi_band','financial_result'])
initial=sum((num(a['initial_cash']) for a in A),D(0));cash=sum((num(a['available_cash']) for a in A),D(0));reserve=sum((num(a['reserved_cash']) for a in A),D(0));buy_gross=sum((num(f['gross_amount']) for f in buy),D(0));sell_gross=sum((num(f['gross_amount']) for f in sell),D(0));fees=sum((num(f['fee']) for f in F),D(0));settle_cash=sum((num(s['cash_flow']) for s in S),D(0));realized=sum((num(p['realized_pnl']) for p in P),D(0));basis=sum((num(p['cost_basis']) for p in openpos),D(0));missing=[p for p in openpos if p['mark_price'] is None or p['unrealized_pnl'] is None]
closed_pnl=sum((r['realized_pnl'] for r in closed),D(0));closed_cost=sum((r['entry_cost_including_fee'] for r in closed),D(0));finwins=[r['realized_pnl'] for r in closed if r['realized_pnl']>0];finloss=[r['realized_pnl'] for r in closed if r['realized_pnl']<0]
directional=[r for r in E if r['resolution_status']=='FORMALLY_RESOLVED' and r['direction_correct'] in (0,1)]
filled_directional=[r for r in directional if r['paper_status'] in ('FILLED','PARTIAL')]
fill_delays=[float(dec(e['detection_delay_seconds'])) for e in filled if dec(e['detection_delay_seconds']) is not None and dec(e['detection_delay_seconds'])>=0]
now=parsed(meta['capture_completed_utc']);stale_observed=[e for e in E if e['paper_status']=='OBSERVED' and (now-parsed(e['first_detected_at'])).total_seconds()>120]
wallet_summary=[]
for w in sorted({r['wallet'] for r in E}):
 own=[r for r in E if r['wallet']==w];pos=[p for p in P if p['account_id']==PREFIX+w];cl=[r for r in closed if r['wallet']==w];bs=[f for f in buy if f['account_id']==PREFIX+w]
 wallet_summary.append({'wallet':w,'username':profiles.get(w),'episodes':len(own),'filled':sum(r['paper_status'] in ('FILLED','PARTIAL') for r in own),'closed':len(cl),'financial_wins':sum(r['realized_pnl']>0 for r in cl),'realized_pnl':sum((num(p['realized_pnl']) for p in pos),D(0)),'buy_notional':sum((num(f['gross_amount']) for f in bs),D(0)),'open_cost':sum((num(p['cost_basis']) for p in pos if num(p['quantity'])>0),D(0)),'resolved_directions':sum(r['resolution_status']=='FORMALLY_RESOLVED' and r['direction_correct'] in (0,1) for r in own)})
wallet_summary.sort(key=lambda r:r['realized_pnl'],reverse=True)
capital=rows('SELECT * FROM strict_capital_events ORDER BY seq');peak=None;maxdd=D(0)
for r in capital:
 equity=initial+num(r['realized_pnl']);peak=max(peak or equity,equity)
 if peak>0:maxdd=max(maxdd,(peak-equity)/peak)
integral=D(0)
for i,r in enumerate(capital):
 end=parsed(capital[i+1]['captured_at']) if i+1<len(capital) else now
 integral+=(num(r['open_cost_basis'])+num(r['reserved_cash']))*D(str(max(0,(min(end,now)-parsed(r['captured_at'])).total_seconds())))
elapsed=D(str(max(0,(now-parsed(POOL['activated_at'])).total_seconds())))
byday=defaultdict(lambda:{'n':0,'pnl':D(0)})
for r in closed:
 if r['financial_close_at']:
  day=parsed(r['financial_close_at']).astimezone(timezone(timedelta(hours=8))).date().isoformat();byday[day]['n']+=1;byday[day]['pnl']+=r['realized_pnl']
exitpos=rows('SELECT state,protection_active,exit_reason FROM wallet_v2_exit_positions');exitevents=rows('SELECT event_type,COUNT(*) AS n FROM wallet_v2_exit_events GROUP BY event_type')
source_counts=rows('SELECT source,COUNT(*) AS n FROM wallet_ingest_sources GROUP BY source');source_first=rows('SELECT first_source,COUNT(*) AS n FROM wallet_ingest_events GROUP BY first_source')
monitor=rows('SELECT state,failure_count,last_error_category,last_attempt_at,last_success_at FROM wallet_ingest_state')
settlement_audits=rows("SELECT occurred_at,evidence_json FROM wallet_v2_audit WHERE action='SETTLEMENT_CHECK' ORDER BY audit_id DESC LIMIT 100")
audit_types=Counter()
for r in settlement_audits:
 ev=j(r['evidence_json']);audit_types[str(ev.get('error_type') or ev.get('result') or ev.get('status') or ev.get('outcome') or 'UNKNOWN')]+=1
raw_filled_missing=con.execute("""SELECT COUNT(*) FROM strict_decisions d WHERE d.status IN ('FILLED','PARTIAL') AND NOT EXISTS (SELECT 1 FROM strict_orders o JOIN strict_fills f ON f.order_id=o.order_id WHERE o.idempotency_key=d.idempotency_key)""").fetchone()[0]
checks={'cash_equation_exact':initial+settle_cash+sell_gross-buy_gross-fees==cash+reserve,'cash_cost_equals_initial_plus_realized':cash+reserve+basis==initial+realized,'original_capital_fixed':initial==D(POOL['fixed_initial_cash']),'all_closed_positions_reconciled':all(r['pnl_reconciles'] for r in closed),'all_positions_mapped':len(unmatched)==0,'rollup_pnl_sums_match':all(sum((r['pnl'] for r in group),D(0))==closed_pnl for group in rollups.values()),'rollup_count_sums_match':all(sum(r['n'] for r in group)==len(closed) for group in rollups.values()),'matrix_pnl_matches':sum((r['pnl'] for r in matrix),D(0))==closed_pnl,'no_overspent_cash':all(num(a['available_cash'])>=0 for a in A)}
summary={'snapshot':meta,'strategy_state':V['state'],'frozen_config':j(V['config_json']),'counts':{'episodes':len(E),'episode_paper_status':counter(E,'paper_status'),'episode_resolution_status':counter(E,'resolution_status'),'buy_fills':len(buy),'sell_fills':len(sell),'closed_positions':len(closed),'open_positions':len(openpos),'filled_resolution_status':counter(filled,'resolution_status'),'tracked_wallets':sum(r['tracked']==1 for r in wallets),'participating_wallets':sum(w['filled']>0 for w in wallet_summary),'financial_wins':len(finwins),'financial_losses':len(finloss),'financial_breakeven':len(closed)-len(finwins)-len(finloss),'directional_sample':len(directional),'directional_wins':sum(r['direction_correct']==1 for r in directional),'filled_directional_sample':len(filled_directional),'filled_directional_wins':sum(r['direction_correct']==1 for r in filled_directional),'stale_observed':len(stale_observed),'open_orders':counter([r for r in O if r['status']=='OPEN'],'side'),'raw_fill_decisions_without_fill':raw_filled_missing},'money':{'initial_capital':initial,'available_cash':cash,'reserved_cash':reserve,'buy_notional':buy_gross,'all_fees':fees,'settlement_returns':settle_cash,'sell_returns':sell_gross,'open_cost_basis':basis,'realized_pnl':realized,'return_on_initial':realized/initial,'closed_trade_pnl':closed_pnl,'closed_trade_cost':closed_cost,'closed_trade_net_roi':closed_pnl/closed_cost if closed_cost else None,'average_win':sum(finwins,D(0))/len(finwins) if finwins else None,'average_loss':sum(finloss,D(0))/len(finloss) if finloss else None,'profit_factor':sum(finwins,D(0))/-sum(finloss,D(0)) if finloss else None,'buy_turnover':buy_gross/initial,'current_utilization':(basis+reserve)/initial,'average_utilization_since_pool_activation':integral/elapsed/initial if elapsed else None,'realized_only_max_drawdown_since_pool_activation':maxdd,'missing_open_marks':len(missing),'unrealized_pnl':None if missing else sum((num(p['unrealized_pnl']) for p in openpos),D(0)),'market_value_equity':None if missing else cash+reserve+sum((num(p['cost_basis'])+num(p['unrealized_pnl']) for p in openpos),D(0)),'all_open_zero_payout_return':(cash+reserve-initial)/initial},'checks':checks,'wallets':wallet_summary,'rollups':rollups,'matrix':matrix,'closed_by_day':dict(sorted(byday.items())),'filled_detection_delay_seconds':distro(fill_delays),'filled_delay_gt30m':sum(x>1800 for x in fill_delays),'filled_delay_gt2h':sum(x>7200 for x in fill_delays),'closed_holding_seconds':distro([float(r['holding_seconds']) for r in closed if r['holding_seconds'] is not None]),'no_fill_reasons':dict(Counter(e['rejection_reason'] for e in E if e['paper_status']=='REJECTED')),'sources':{'observations':source_counts,'first_claims':source_first,'filled_episodes':dict(Counter(source_byepisode.get(e['episode_id'],'UNKNOWN') for e in filled))},'exit_v1':{'states':counter(exitpos,'state'),'reasons':counter(exitpos,'exit_reason'),'protected':sum(r['protection_active'] for r in exitpos),'events':exitevents},'monitor':{'states':counter(monitor,'state'),'wallets_with_failures':sum(r['failure_count']>0 for r in monitor),'error_categories':counter([r for r in monitor if r['last_error_category']],'last_error_category'),'last_successes':sorted([r['last_success_at'] for r in monitor if r['last_success_at']])},'latest_100_settlement_check_types':dict(audit_types),'unmatched':unmatched}
(OUT/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
for name,data in [('position_lineage.csv',lineage),('pnl_attribution_matrix.csv',matrix)]:
 if data:
  with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader()
   for r in data:writer.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()})
con.rollback();con.close()
print(json.dumps({k:v for k,v in summary.items() if k not in ('snapshot','matrix','unmatched')},ensure_ascii=False,indent=2,default=str))