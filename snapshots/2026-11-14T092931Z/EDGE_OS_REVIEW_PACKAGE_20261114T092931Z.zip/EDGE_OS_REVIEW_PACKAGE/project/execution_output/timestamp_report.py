"""Render existing read-only observations; no application or database writes."""
import csv,json,math,statistics
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1]; P=R/'execution_output/timestamp_diagnosis_20261002'
def load(n):return json.loads((P/n).read_text(encoding='utf-8'))
def dt(v):return datetime.fromisoformat(v.replace('Z','+00:00'))
def delta(a,b):return round((dt(a)-dt(b)).total_seconds()*1000,3)
def stats(v):
 s=sorted(v);return dict(n=len(s),min=s[0],median=statistics.median(s),p95=s[math.ceil(.95*len(s))-1],max=s[-1]) if s else {'n':0}
def table(rows):
 if not rows:return '无。'
 keys=list(rows[0]);return '\n'.join(['| '+' | '.join(keys)+' |','|'+'|'.join(['---']*len(keys))+'|']+['| '+' | '.join(str(r.get(k,'')).replace('|','/').replace('\n',' ') for k in keys)+' |' for r in rows])
def csvout(n,rows):
 with (P/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
s=load('snapshot.json'); episodes=s['episodes']; decisions={d['signal_id']:d for d in s['decisions']}; events={e['episode_id']:e for e in s['runtime_events']}
matrix=[];quotes=[];future=[];newer=[];leaders=[]
for e in episodes:
 matrix.append({k:e[v] for k,v in {'episode_id':'episode_id','wallet':'wallet','condition_id':'condition_id','token_id':'first_token_id','outcome':'first_outcome','signal_id':'first_signal_id','leader_UTC':'first_leader_at','detected_UTC':'first_detected_at','status':'paper_status','reason':'rejection_reason'}.items()})
 if e['first_signal_id'] in decisions:
  d=decisions[e['first_signal_id']]; ev=d['evidence'];q=ev['quote'];x=ev['execution'];detect=ev['edge_detected_timestamp']
  row={'episode_id':e['episode_id'],'leader':ev['leader_trade_timestamp'],'detected':detect,'quote_source':q['source_timestamp'],'quote_request':q['request_timestamp'],'quote_received':q['received_timestamp'],'execution_source':x['source_timestamp'],'execution_request':x['request_timestamp'],'execution_received':x['received_timestamp'],'request_minus_detected_ms':delta(q['request_timestamp'],detect),'source_minus_detected_ms':delta(q['source_timestamp'],detect),'received_minus_detected_ms':delta(q['received_timestamp'],detect),'received_minus_source_ms':delta(q['received_timestamp'],q['source_timestamp'])}
  a=row['request_minus_detected_ms']<0;b=row['source_minus_detected_ms']<0;row['predicate']='C_BOTH' if a and b else 'A_REQUEST' if a else 'B_SOURCE' if b else 'NEITHER'
  if d['reason']=='QUOTE_PREDATES_SIGNAL':quotes.append(row)
  else:newer.append({'episode_id':e['episode_id'],'quote_source':q['source_timestamp'],'execution_source':x['source_timestamp'],'source_delta_ms':delta(x['source_timestamp'],q['source_timestamp']),'execution_request_minus_quote_received_ms':delta(x['request_timestamp'],q['received_timestamp']),'quote_age_ms':delta(q['received_timestamp'],q['source_timestamp']),'execution_age_ms':delta(x['received_timestamp'],x['source_timestamp']),'quote_snapshot_id':q['snapshot_id'],'execution_snapshot_id':x['snapshot_id']})
 else:
  ev=events[e['episode_id']]
  future.append({'episode_id':e['episode_id'],'token_id':e['first_token_id'],'leader':e['first_leader_at'],'detected':e['first_detected_at'],'event_UTC':ev['occurred_at'],'phase':ev['evidence'].get('phase'),'error_type':ev['evidence'].get('error_type'),'raw_book_timestamp':'NOT_PERSISTED','book_request_receive':'NOT_PERSISTED','quote_or_execution':'UNKNOWN'})
for r in s['leader_payloads']:
 raw=r['raw'].get('timestamp');leaders.append({'episode_id':r['episode_id'],'raw_timestamp':raw,'raw_type':type(raw).__name__,'digits':len(str(raw)),'normalized_UTC':datetime.fromtimestamp(float(raw),timezone.utc).isoformat(),'stored_epoch':r['stored_timestamp'],'subsecond_observed':float(raw)%1!=0})
for n,rows in [('episode_matrix.csv',matrix),('quote_predicates.csv',quotes),('future_evidence.csv',future),('execution_not_newer.csv',newer),('leader_precision.csv',leaders)]:csvout(n,rows)
times=load('time_samples.json');books=load('book_samples.json');pairs=load('paired_books.json');summary=load('probe_summary.json')
pairrows=[{'token_id':p['token_id'],'repeat':p['repeat'],'A_raw':p['a'].get('raw_timestamp'),'B_raw':p['b'].get('raw_timestamp'),'A_hash':p.get('a_hash'),'B_hash':p.get('b_hash'),'levels_changed':p.get('levels_changed'),'source_delta_ms':p.get('timestamp_delta_ms'),'actual_wait_ms':round(p['actual_monotonic_wait_ms'],3),'A_request':p['a']['request_utc'],'A_receive':p['a']['receive_utc'],'B_request':p['b']['request_utc'],'B_receive':p['b']['receive_utc']} for p in pairs]
csvout('paired_matrix.csv',pairrows)
timerows=[{k:t.get(v) for k,v in {'raw':'raw_timestamp','type':'raw_type','digits':'digit_count','server_UTC':'normalized_utc','before_UTC':'request_utc','after_UTC':'receive_utc','RTT_ms':'monotonic_rtt_ms','server_minus_midpoint_ms':'server_minus_local_midpoint_ms'}.items()} for t in times]
bookrows=[]
for b in books:
 if b.get('http_status')!=200:continue
 bookrows.append({'token_id':b['params']['token_id'],'raw':b['raw_timestamp'],'type':b['raw_type'],'digits':b['digit_count'],'normalized':b['normalized_utc'],'request':b['request_utc'],'receive':b['receive_utc'],'RTT_ms':b['monotonic_rtt_ms'],'source_minus_request_ms':b['source_minus_request_ms'],'source_minus_receive_ms':b['source_minus_receive_ms'],'source_minus_later_server_ms':b.get('book_source_minus_adjacent_clob_server_time_ms'),'later_server_probe_request':b['adjacent_time_probe']['request_utc']})
csvout('clock_matrix.csv',timerows);csvout('book_matrix.csv',bookrows)
analysis={'episode_count':len(episodes),'reason_counts':dict(Counter(e['rejection_reason'] for e in episodes)),'status_counts':dict(Counter(e['paper_status'] for e in episodes)),'quote_predicate_counts':dict(Counter(r['predicate'] for r in quotes)),'quote_age_over_3000':sum(r['received_minus_source_ms']>3000 for r in quotes),'quote_age_ms':stats([r['received_minus_source_ms'] for r in quotes]),'quote_source_minus_detected_ms':stats([r['source_minus_detected_ms'] for r in quotes]),'quote_request_minus_detected_ms':stats([r['request_minus_detected_ms'] for r in quotes]),'execution_equal_source':sum(r['source_delta_ms']==0 for r in newer),'pairs_equal_source':sum(p.get('timestamp_equal',False) for p in pairs),'pairs_equal_hash':sum(p.get('a_hash')==p.get('b_hash') for p in pairs),'pairs_unchanged_levels':sum(p.get('levels_changed') is False for p in pairs),'pair_wait_ms':stats([p['actual_monotonic_wait_ms'] for p in pairs]),'leader_type_counts':dict(Counter(r['raw_type'] for r in leaders)),'leader_subsecond_count':sum(r['subsecond_observed'] for r in leaders),'book_raw_type_digits':dict(Counter(str(b.get('raw_type'))+':'+str(b.get('digit_count')) for b in books if b.get('http_status')==200)),'time_source_after_receive_count':sum(t['source_minus_receive_ms']>0 for t in times),'counts_at_snapshot':s['counts']}
(P/'analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2),encoding='utf-8')
report=f'''# V2 时间戳证据诊断（只读）

任务：`c2c_v2_timestamp_evidence_diagnosis`，Iteration 1，READY_FOR_REVIEW。
记录日期：2026-10-02；数据库一致性快照截止：{s['captured_at']}。所有时间矩阵均为 UTC。

## 1. 结论与边界

- **FACT：85/85 episode 均 REJECTED**；48 FUTURE_ORDER_BOOK_TIMESTAMP、33 QUOTE_PREDATES_SIGNAL、4 EXECUTION_BOOK_NOT_NEWER。全量提取，无最近50条截断。
- **FACT：33 个 QUOTE_PREDATES_SIGNAL 全部是 source_timestamp < detected，而非 HTTP 请求发生在检测前**。精确 A/B/C 计数见下。它们中 {analysis['quote_age_over_3000']} 个报价在接收时已经超过冻结的3000ms年龄上限；不能把所有拒绝解释为误拒绝。
- **FACT：4 个 EXECUTION_BOOK_NOT_NEWER 均源时间相等**；独立的新请求确实存在。当前16组双请求也16/16相等；盘口时间不会随每次响应自动推进。
- **FACT：48 个未来时间拒绝发生在适配器，原始被拒盘口未持久化**。历史“未来多少毫秒”、单位、失败属于quote还是execution，均不能从现有记录证明。
- **INFERENCE：盘口源时间体现书本状态/更新或服务端缓存时间，而不是每次HTTP响应时间**。实测支持；不能由16组静态盘口保证所有市场的供应商内部时间语义。
- **UNRESOLVED：未来时间的唯一根因**。当前Windows报告未同步，服务器相对本机也有正偏差样本；秒级/time和网络不对称限制精确时钟归因。此次当前盘口没有重现future，不足以反证历史故障。

## 2. 工作区与保护

实际仓库：`{R}`；git.isRepo=true；branch main；HEAD a4b5400。已有脏工作树保留。
本会话尝试连接工具时遇到旧工具句柄的Unknown tool/transport错误，使用本地只读Git及SQLite等价检查；不将本地替代查询称为ChatGPT端读取验证。
Git status及要求的两个unstaged diff保存于 `execution_output/timestamp_diagnosis_git_status.txt`、`timestamp_diagnosis_polymarket.diff`、`timestamp_diagnosis_strict_paper.diff`。
生产数据库使用 `mode=ro`、`PRAGMA query_only=ON`、一致性BEGIN、ROLLBACK；没有执行DML、迁移、初始化或引擎实例化。运行中的监控可能继续写入，不能宣称整轮诊断DB hash不变。
新增内容仅为本报告和 `execution_output/` 诊断脚本/证据。没有运行测试套件（此任务为诊断），没有修改Windows时间。

V2状态：FORWARD_TEST；版本wallet-follow-v2.0；clean forward起点{s['cutoff']}。冻结配置：

```json
{json.dumps(json.loads(s['versions'][0]['config_json']),ensure_ascii=False,indent=2)}
```

快照关键计数：wallets={s['counts']['wallets']}，raw trades={s['counts']['trades']}，episodes=85，strict decisions=37，runtime events=48，orders/fills/positions/settlements均0；legacy experiment/entries/paper_trades均0。账户初始化现金流水不属于成交。

## 3. 精确拒绝谓词与优先级

|位置|判定|影响|
|---|---|---|
|app/wallet_follow_runtime.py _book_snapshot（约460–475）|normalized source > local received|抛FUTURE_ORDER_BOOK_TIMESTAMP；在构建/保存BookSnapshot之前|
|app/strict_paper.py evaluate（约359）|quote.request < edge_detected|QUOTE_PREDATES_SIGNAL，A|
|同文件（约361）|quote.source < edge_detected|QUOTE_PREDATES_SIGNAL，B|
|同文件（约374）|quote.received - quote.source > 3000ms|STALE_QUOTE；但A/B在前，会遮蔽这个原因|
|同文件（约384）|execution.source <= quote.source|EXECUTION_BOOK_NOT_NEWER；请求独立、500ms等待不足以确保源时间改变|

请求时间和源时间不是同一个概念。当前代码的这些顺序不允许从单一拒绝标签断言其他后续检查通过。
单位：_as_datetime 对大于1e10的数值除1000；本次/time为10位int秒、/book为13位str毫秒，转换与实际日期一致。**当前样本未发现秒/毫秒归一化错误**，缺失历史原始值不能排除那48条的具体输入异常。

理由分布：

{table([{'reason':k,'count':v} for k,v in analysis['reason_counts'].items()])}

A/B/C计算：{json.dumps(analysis['quote_predicate_counts'])}。A-only=0；C-both=0；B-only=33。
报价年龄统计ms：{json.dumps(analysis['quote_age_ms'])}。
quote.source-detected统计ms：{json.dumps(analysis['quote_source_minus_detected_ms'])}。
quote.request-detected统计ms：{json.dumps(analysis['quote_request_minus_detected_ms'])}。

## 4. 当前只读网络与时钟采样

公共CLOB API，经同一Windows代理配置路径；没有交易请求、签名或账户访问。20/time成功；48次单盘口尝试中20成功、28 HTTP404（已无盘口的历史token），另有32次配对盘口读取。HTTP200表示可读取结构，未证明所有策略执行门槛满足。

```json
{json.dumps(summary,ensure_ascii=False,indent=2)}
```

offset=server时间减本地请求/接收中点。p95为排序后ceil(0.95*n)项。/time整秒量化误差接近1秒，加上非对称网络延迟；正offset不等于已证明本机准确慢了该数值。{analysis['time_source_after_receive_count']}次服务器秒值仍晚于本地接收时间，支持相对时间差线索。没有可信第三时钟，不能区分WINDOWS_CLOCK_SKEW与CLOB_SERVER_CLOCK_OFFSET。
[官方/time说明](https://docs.polymarket.com/api-reference/data/get-server-time)确认Unix秒；[官方/book说明](https://docs.polymarket.com/api-reference/market-data/get-order-book)展示盘口timestamp/hash，但所读说明未保证每次请求都刷新timestamp。实际单位以本次原始返回为证。
book-source减本地receive范围见统计（负值，约6–80秒旧）。`source_minus_later_server_ms` 使用随后追加的/time，不是同时服务器时间：表中保留其独立请求时间；不可把该差当成同时的精确盘口年龄。

### 4.1 全20次/time

{table(timerows)}

### 4.2 全20次成功/book（原始完整响应含盘口档位见book_samples.json）

{table(bookrows)}

## 5. 500ms配对盘口结果

4个受影响token，每个4组。冻结等待目标500ms；操作系统调度实际等待ms统计：{json.dumps(analysis['pair_wait_ms'])}，并未声称物理上恰好500.000ms。
时间相等{analysis['pairs_equal_source']}/16；hash相等{analysis['pairs_equal_hash']}/16；levels不变{analysis['pairs_unchanged_levels']}/16。
**实证回答YES**：两次独立、可读取盘口、相隔至少500ms可返回相同源时间。

{table(pairrows)}

历史4条EXECUTION_BOOK_NOT_NEWER：

{table(newer)}

## 6. Data API与检测精度

85条对应raw trade均在snapshot.json.leader_payloads，未重新拉取或补造历史交易。类型统计{json.dumps(analysis['leader_type_counts'])}；观察到子秒时间条数{analysis['leader_subsecond_count']}。下表保留每条raw与归一化时间。
Data API整数秒；CLOB当前毫秒字符串；本地检测UTC微秒。精度差真实存在，但33条拒绝比较的是book source与**detected**，不是leader时间，所以不能以leader秒精度单独解释它们。

{table(leaders)}

## 7. Windows时钟只读证据

UTC采样见/time矩阵的before/after。w32tm原始查询和退出码保存windows_clock_decoded.json。
/query /status成功：Leap indicator3未同步；stratum0未指定；precision -23；root delay0.1127688s；root dispersion9.7471558s；last successful sync本地2026/10/2 08:18:29；source time.windows.com,0x9；poll1024s。
/query /source 返回访问拒绝0x80070005，未绕过；source仍可由成功的status报告获取。/peers显示暂停/不可用状态。status未提供实际clock offset；root dispersion不是实际偏移。无任何校时/配置命令。
结论：**当前未同步是FACT；历史48次拒绝由它导致尚UNRESOLVED**。

## 8. 分类、影响与建议（不实施）

|问题|分类|证据强度/影响|
|---|---|---|
|FUTURE_ORDER_BOOK_TIMESTAMP|MIXED/UNRESOLVED；Windows/CLOB相对时钟线索|48历史输入未保存，不能精确归因；当前未重现未来盘口|
|QUOTE_PREDATES_SIGNAL|BOOK_TIMESTAMP_IS_LAST_UPDATE_NOT_RESPONSE_TIME（推断） + ACTUAL_STALE_OR_INVALID_BOOK（年龄事实）|33/33 B谓词；其中{analysis['quote_age_over_3000']}/33同时超3000ms；标签遮蔽stale|
|STALE_QUOTE|实际老源时间 + 时间语义待确认|不能在诊断中把3秒安全门槛放松；当前20成功book亦旧于3秒|
|EXECUTION_BOOK_NOT_NEWER|BOOK_TIMESTAMP_IS_LAST_UPDATE_NOT_RESPONSE_TIME（推断）|4历史相等；16当前双请求相等；要求书本发生更新不等价于fresh独立请求|
|TIMESTAMP_UNIT_NORMALIZATION_BUG|当前未证实|当前13位毫秒/10位秒均正确；48缺原始数据|
|LEADER_TIMESTAMP_PRECISION_MISMATCH|精度差已观察，主因未证实|不得补造Data API缺失的毫秒|

建议下一轮先修证据：在任何盘口校验抛错**之前**保存raw时间/type/token/source、quote或execution阶段、request/received、单调RTT、服务器时间辅助样本。审计失败不应生成成交。
独立核对Windows与可信时间源和CLOB；校时属于另行批准的修复，当前未执行。对/time整秒量化及网络不对称使用误差区间，不用单次差值盲目调钟。
向供应商核实/book timestamp的更新/缓存语义；在**新引擎/新冻结规则版本**中区分因果HTTP请求、响应新鲜度和书本状态年龄。独立execution请求+冻结500ms+可验证的新响应不能天然要求盘口内容改变；仍需保留严格book年龄、身份、深度、ROI、去重、IOC检查。未经审查不得把旧拒绝重算成fills。
建议回归fixture：请求发生在detected之后但旧source；请求早于detected；source比receive略未来并保存原始证据；真正stale；新请求/同hash同source；500ms不足；单位秒/毫秒；缺时间；network错误；历史拒绝不改写。此轮不添加/运行产品测试。

## 9. 全量85 episode矩阵

{table(matrix)}

## 10. 全33条QUOTE_PREDATES_SIGNAL不可变证据与计算

{table(quotes)}

## 11. 全48条未来时间失败的现存证据索引

每条完整runtime evidence见snapshot.json.runtime_events，按episode_id查找：identity、Gamma状态、fee、error、phase均保留。以下不存在的值明确NOT_PERSISTED，没有用今天盘口替代昨天盘口。

{table(future)}

## 12. 可复核证据

- `execution_output/timestamp_diagnosis_20261002/snapshot.json`：一致性全量DB只读数据、raw leader、不可变decision/runtime证据。
- 同目录 `time_samples.json`、`book_samples.json`、`paired_books.json`：原始公开响应和本地时序。
- `analysis.json`、`probe_summary.json`及7份CSV：可重算的矩阵/统计。
- `windows_clock_decoded.json`：只读Windows状态。
- `execution_output/timestamp_diagnosis.py`：采集脚本；`timestamp_report.py`：只读现有证据渲染。
- `execution_output/timestamp_diagnosis_command.txt`：实际采集命令输出。

报告仅代表上述快照与采样区间；运行中的新episode不在此固定85条矩阵中。
'''
(R/'V2_TIMESTAMP_DIAGNOSIS.md').write_text(report,encoding='utf-8')
print(json.dumps(analysis,ensure_ascii=False,indent=2));print('REPORT='+str(R/'V2_TIMESTAMP_DIAGNOSIS.md'))
