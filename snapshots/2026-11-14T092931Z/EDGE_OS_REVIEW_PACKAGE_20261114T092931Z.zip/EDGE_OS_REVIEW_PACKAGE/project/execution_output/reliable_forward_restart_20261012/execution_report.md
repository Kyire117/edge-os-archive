# EDGE OS 恢复与独立前向实验

状态：EXECUTED / 本地验证通过，持续仅模拟运行。
当前实验：FORWARD-20261012T073343Z，激活 UTC：2026-10-12T07:33:43.100043+00:00。
当前库：data\edge_forward_20261012T073343Z.db；旧库：data\edge_mvp.db。

## 已解决的问题

1. 页面旧进度：创建新的独立实验库，复用钱包身份、公开原始历史和发现/排除资料；不迁移旧 paper episode、订单、成交或仓位。当前账户按原冻结配置初始化，旧账户完整留在归档。
2. 补漏永久卡住：保留默认旧模式限制；新的持续模式按小块和每轮有限请求推进已提交 checkpoint，大缺口分段追赶，重启不跳过未提交区块。
3. 实时断线：订阅与日志/区块/receipt 查询拆分；只读 HTTPS 查询与恢复通路继续验证 chain_id、区块、receipt 和 token 身份。过滤未跟踪 maker 的推送，避免无关流量填满队列。
4. 轮询超时：每页单次请求，重试交由持久化调度器；并发 2、每轮每钱包 1 页，避免内外两层超时互相取消。
5. 启动与页面混淆：一键启动绑定 active_experiment.json，默认应用入口也选择该库；库不匹配和配置缺失阻止启动。页面显示独立实验 ID、起点、历史归档和实际读取/追赶状态。HTML/JS 不缓存。
6. 未知浮盈亏：缺有效估值的开放仓位返回 null、页面显示 —；不会虚构零浮盈亏。AI 历史研究失败与主采集状态分开；保留 AI 调用记录的每日额度。

## 保持不变

$25 本金、5% if-win 净 ROI、10% 可见深度、500ms 执行延迟、3000ms 盘口要求、最少 20 个正式方向结果等冻结参数未改。真实订单关闭。
未放松最低订单量/费用/身份/盘口验证，未重放历史 SKIP 或修改旧 VOID checkpoint，未删除旧数据。

## 验证

- 修复专项：118 passed, 1 个既有警告；最终代码全仓 **417 passed, 1 个既有警告**，exit 0，结果见 final_all_tests.txt。
- 前端静态行为、筛选、分页、转义、URL、盈亏、独立归档及恢复状态测试通过；node --check、compileall、diff 空白检查通过。
- 实际停机后通过一键入口启动成功，实验 ID/激活时间与已有新实验记录继续保留；重复启动请求不增加进程。
- 浏览器实际页面显示新实验 ID，旧数字仅在独立历史归档中；当前交易档案全部为本次激活后的记录。
- 一致性快照内全部 3 个账户 cash/fee/position/reservation/order/mark 对账及审计校验通过。
- 无超时 OBSERVED、缺订单的 filled episode 或激活前 episode。
- 原库全部表的 count/hash 与停止时快照一致：2023 条 episode、385 笔 fill 保留。

## 范围与局限

这是可运行的前向模拟，不是实盘或盈利证明。公开网络仍可能短暂失败；重试、补漏进度与安全拒绝会如实显示，不保证网络永不出错。
本次无有效估值的开放仓位仍显示未知，而非伪造行情。电脑和本机代理需保持运行；开机自启未配置，重启电脑后使用同一个启动文件继续。
旧实验是只读归档，旧仓位不在新实验内继续结算或混入新收益。
没有进行网页 ChatGPT 独立审查；没有改写其余未完成 C2C checkpoint。

## 文件与证据

- app/polygon_fast_path.py
- app/polymarket.py
- app/main.py
- app/config.py
- app/wallet_follow_runtime.py
- app/static/app.js
- app/static/index.html
- app/static/launcher.html
- edge_launcher.py
- edge_runtime.py
- execution_output/polygon_fast_path/serve_continuous.py
- execution_output/polygon_fast_path/prepare_continuous_start.py
- execution_output/polygon_fast_path/new_forward_experiment.py
- tests/test_reliable_forward_restart.py
- tests/ui_v1_static.test.js
- RUN_EDGE_OS.md

运行核对：runtime_verified.json；HTTP/重复启动/新记录隔离：http_ui_verified.json；源码差异：exact.diff；最终全仓：final_all_tests.txt。
对于未在任务开始复制的既有 launcher.html，diff 使用当前完整内容；UI 测试基线按明确新增区段重建。其他已修改源文件使用 source_before 的实际基线；不将整棵已有脏工作区当成本轮改动。

## 最终运行快照

核验时间 UTC：2026-10-12T08:49:09.983830+00:00。当前 episode=35，FILLED=18，PARTIAL=2，REJECTED=15。钱包监控运行、实时订阅连接、HTTPS 补漏成功，待追赶区块=0。当前过程已出现 1 次重连并恢复。当前已实现模拟 PnL=-72.489264 USD；浮动 PnL 未知（缺少有效 mark）。样本很小，不作为策略结论。
