"""Read-only live checks plus ledger reconciliation on a consistent COPY."""
import hashlib
import json
import sqlite3
import sys
import urllib.request
from datetime import datetime,timezone
from pathlib import Path

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT))
from edge_runtime import active_run,active_database
from app.strict_ledger import StrictPaperLedger
run=active_run();source=active_database()
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def get(path):
    with opener.open('http://127.0.0.1:8000'+path,timeout=10) as response:return json.load(response)
health=get('/api/health');state=get('/api/wallet-follow-v2')
assert health['experiment']['run_id']==run['run_id'] and state['state']=='FORWARD_TEST'
assert health['live_trading'] is False and state['frozen_config']['live_orders'] is False
fast=health['polygon_fast_path']
assert health['monitor_running'] and health['monitor_last_success_at'] is not None
assert fast['last_data_success_at'] and fast['last_block'] is not None
assert fast['error_category']!='BACKFILL_GAP_EXCEEDS_BOUND'
assert (datetime.now(timezone.utc)-datetime.fromisoformat(fast['last_data_success_at'])).total_seconds()<60
capture=OUT/('verification_snapshot_'+datetime.now(timezone.utc).strftime('%H%M%S')+'.db')
src=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True);src.execute('PRAGMA query_only=ON')
with sqlite3.connect(capture) as dst:src.backup(dst)
src.close()
c=sqlite3.connect(capture);c.row_factory=sqlite3.Row;c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
assert c.execute('PRAGMA quick_check').fetchone()[0]=='ok'
accounts=[r[0] for r in c.execute('SELECT account_id FROM strict_accounts')]
old_signals=c.execute('SELECT COUNT(*) FROM wallet_v2_episodes WHERE first_leader_at<? OR first_detected_at<?',
    (run['started_at'],run['started_at'])).fetchone()[0]
assert old_signals==0
stale=c.execute("SELECT COUNT(*) FROM wallet_v2_episodes WHERE paper_status='OBSERVED' AND julianday(first_detected_at)<julianday('now','-120 seconds')").fetchone()[0]
assert stale==0
fill_episodes=c.execute("SELECT episode_id,paper_order_id FROM wallet_v2_episodes WHERE paper_status IN ('FILLED','PARTIAL')").fetchall()
missing_orders=sum(not row['paper_order_id'] or not c.execute('SELECT 1 FROM strict_orders WHERE order_id=?',(row['paper_order_id'],)).fetchone() for row in fill_episodes)
assert missing_orders==0
c.rollback();c.close()
reconciliations={a:{'ledger':StrictPaperLedger(capture,a).reconcile(),
                    'audit':StrictPaperLedger(capture,a).verify_audit_chain()} for a in accounts}
assert all(r['ledger']['ok'] and r['audit']['ok'] for r in reconciliations.values())
old_before=json.loads((ROOT/'execution_output/polygon_fast_path/continuous_start_20261012T073309Z/before_start.json').read_text(encoding='utf-8'))
archive=ROOT/run['archives'][-1]['database'];old=sqlite3.connect(archive.as_uri()+'?mode=ro',uri=True)
old.execute('PRAGMA query_only=ON');old.execute('BEGIN');differences=[]
for table,prior in old_before['tables'].items():
    rows=sorted(json.dumps(tuple(row),ensure_ascii=False,separators=(',',':'),default=str)
        for row in old.execute('SELECT * FROM "'+table.replace('"','""')+'"'))
    digest=hashlib.sha256('\n'.join(rows).encode()).hexdigest()
    if len(rows)!=prior['count'] or digest!=prior['sha256']:differences.append(table)
old.rollback();old.close();assert not differences
report={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'run_id':run['run_id'],
    'state':state['state'],'counts':state['counts'],'performance':state['performance'],
    'monitor':{k:health.get(k) for k in ('monitor_running','monitor_last_success_at','monitor_last_error')},
    'fast':{k:fast.get(k) for k in ('connected','read_transport','error_category','reconnect_count','last_block',
        'last_data_success_at','catchup_remaining_blocks','tracked_events_seen','normalized_events')},
    'ledger_reconciliation_on_snapshot':reconciliations,'stale_observed':stale,'missing_orders':missing_orders,
    'pre_activation_episodes':old_signals,'archive_all_tables_unchanged':True,
    'archive_episodes':run['archives'][-1]['episodes'],'archive_fills':run['archives'][-1]['fills'],
    'live_orders':False,'verification_snapshot':str(capture)}
(OUT/'runtime_verified.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True,indent=2))
