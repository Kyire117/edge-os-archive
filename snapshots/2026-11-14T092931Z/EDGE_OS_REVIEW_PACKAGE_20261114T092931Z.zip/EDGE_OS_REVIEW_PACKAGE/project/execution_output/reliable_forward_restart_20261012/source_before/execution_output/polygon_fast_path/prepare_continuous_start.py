"""Consistent pre-start backup and read-only state baseline. No app imports."""
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'data/edge_mvp.db'
STAMP=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT=ROOT/'execution_output/polygon_fast_path'/('continuous_start_'+STAMP)
OUT.mkdir(parents=True,exist_ok=False)
BACKUP=ROOT/'data/backups'/('edge_mvp.pre-continuous-fast-path-'+STAMP+'.db')
BACKUP.parent.mkdir(parents=True,exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
src=sqlite3.connect(SOURCE.resolve().as_uri()+'?mode=ro',uri=True,timeout=30)
src.execute('PRAGMA query_only=ON')
assert src.execute('PRAGMA quick_check').fetchone()[0]=='ok'
with sqlite3.connect(BACKUP) as dst:
    src.backup(dst)
    assert dst.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
src.execute('BEGIN')
tables={}
for table, in src.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
    quoted='"'+table.replace('"','""')+'"'
    rows=sorted(json.dumps(tuple(row),ensure_ascii=False,separators=(',',':'),default=str)
                for row in src.execute('SELECT * FROM '+quoted))
    tables[table]={'count':len(rows),'sha256':hashlib.sha256('\n'.join(rows).encode()).hexdigest()}
src.row_factory=sqlite3.Row
version=dict(src.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version='wallet-follow-v2.0'").fetchone())
config=json.loads(version['config_json'])
assert version['state']=='FORWARD_TEST' and config['live_orders'] is False
assert config['fixed_notional']=='25' and config['min_net_roi_if_win']=='0.05'
assert config['max_visible_depth_fraction']=='0.10' and config['execution_latency_ms']==500
assert config['max_book_age_ms']==3000
state={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'source_db':str(SOURCE),
    'source_main_sha256':sha(SOURCE),'journal_mode':src.execute('PRAGMA journal_mode').fetchone()[0],
    'tables':tables,'version':version,'frozen_config':config,
    'tracked_wallets':src.execute('SELECT COUNT(*) FROM wallets WHERE tracked=1').fetchone()[0],
    'backup':{'path':str(BACKUP),'sha256':sha(BACKUP),'size':BACKUP.stat().st_size,'integrity_check':'ok'},
    'semantics':'Resume existing frozen V2.0 strategy with a new process baseline; no experiment/account reset.',
    'live_orders':False}
src.rollback();src.close()
(OUT/'before_start.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
pointer={'out':str(OUT),'backup':str(BACKUP),'snapshot':str(OUT/'before_start.json')}
(ROOT/'execution_output/polygon_fast_path/current_continuous_start.json').write_text(json.dumps(pointer,indent=2),encoding='utf-8')
print(json.dumps({**pointer,'backup_integrity':'ok','tracked_wallets':state['tracked_wallets'],
                  'episodes_before':tables['wallet_v2_episodes']['count'],
                  'fills_before':tables['strict_fills']['count'],'strategy_state':version['state']},ensure_ascii=False))
