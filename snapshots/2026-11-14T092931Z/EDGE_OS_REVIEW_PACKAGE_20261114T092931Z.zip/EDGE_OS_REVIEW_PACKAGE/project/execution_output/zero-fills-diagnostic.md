# EDGE OS 零成交实验只读诊断

采样时间：2026-09-24 02:50:39 UTC。只读查询 `data/edge_mvp.db`，没有写入数据库、源代码、实验状态或冻结规则。钱包地址使用代号，不导出完整地址、token ID 或配置内容。

## 记录计数

用户所见的 87 条对应实验记录 ID 1–87：全部 `SKIP`，`eligible=0`、`filled=0`。

| 原因 | 状态 | 数量（ID 1–87） | 数量（当前一致快照 ID 1–96） |
|---|---|---:|---:|
| OUTSIDE_HORIZON_TOO_LONG | SKIP | 39 | 42 |
| EXPIRED_END_TIME | SKIP | 37 | 43 |
| OUTSIDE_HORIZON_TOO_SHORT | SKIP | 3 | 3 |
| STALE_SIGNAL | SKIP | 8 | 8 |
| 合计 | SKIP | 87 | 96 |

当前快照按 UTC 时段：01:00 小时内 29 条（too long 15、expired 12、too short 2）；02:00 小时内 67 条（too long 27、expired 31、too short 1、stale 8）。当前钱包分组（脱敏代号）：W1 3 条全为 stale；W2 22 条（17 too long、4 expired、1 stale）；W3 4 条全为 too long；W4 67 条（21 too long、39 expired、3 too short、4 stale）。

## 代表记录与判定路径

实验 ID `FC14-D81AAF4747E2`，规则 `forward-copy-v0.1`，窗口为市场 end timestamp 之前 1–48 小时；信号年龄上限 900 秒。

- ID 1：`OUTSIDE_HORIZON_TOO_LONG`。信号年龄约 244 秒；记录的 market end timestamp 距决策约 604,318 秒（约 7 天）。市场当时 `accepting_orders=true`、未关闭、未解决。
- ID 4：`EXPIRED_END_TIME`。信号年龄约 220 秒；end timestamp 比决策早约 495 秒；市场仍可交易且未解决。市场描述写的是 9 月 23 日 9:40 PM ET 的比赛开赛时间，恰与该 end timestamp 一致。
- ID 12：`OUTSIDE_HORIZON_TOO_SHORT`。记录剩余约 699 秒；市场描述写 10:00 PM ET 开赛，end timestamp 恰为该开赛时刻；市场仍可交易且未解决。
- ID 47：`STALE_SIGNAL`。信号年龄约 926 秒，超过 900 秒；该条在市场查询前被跳过。
- ID 87：`EXPIRED_END_TIME`。市场描述的 10:10 PM ET 开赛时刻与 end timestamp 一致；当时市场仍可交易、未关闭、未解决。

全部前 87 条：8 条 stale 未请求市场数据；另外 79 条成功保存了市场响应，按 end timestamp 拒绝（39 too long、37 expired、3 too short）。在当前 96 条中，对应为 8 条 stale、88 条 horizon 拒绝。所有 horizon 拒绝都发生在 resolution description、fee schedule、订单簿、深度、spread、价格范围/移动等执行检查之前；这些后续条件是否通过未知，不能据此认定可成交。

结束时间风险已由持久化证据确认：代码把 Gamma 的 market `endDate` 当成预计市场结束时间，但至少 ID 4、12、87 的值与描述中的比赛开赛时刻相符，盘口仍开放。它可能代表开赛/排期而非实际预计关闭时间。不能据此推算结束时间，也不能直接放宽 1–48 小时规则；需要确认上游字段语义。不可靠的 end time 应单独标记并继续 fail closed。

## 钱包 monitor 状态

- 18 个钱包持久化了 `last_error` 前缀 `monitor: `，其后内容均为空；其中 9 个在当前实验 cohort。
- 最早更新：2026-09-19 10:52:44 UTC；最新：2026-09-24 01:37:23 UTC，早于实验激活时间 2026-09-24 01:46:21 UTC。
- 数据库仅保存错误字符串，无法还原异常类、HTTP 状态或具体超时原因；空字符串可能来自无消息异常，但不能确认是哪一种。退避计数只保存在 monitor 进程内存，历史次数没有持久化。
- 查询时 `/api/health` 显示 monitor 正运行；最近成功扫描 2026-09-24 02:50:38 UTC，20 个钱包已扫描、0 个 backoff、25 条交易观察、0 新交易、0 错误。全局扫描已恢复；该接口不提供每钱包本轮结果，不能逐个确认恢复时点。
- 确认 UI 陈旧错误缺陷：单钱包扫描成功只清除内存中的失败/退避计数；不清除 `wallets.last_error`。因此历史错误会持续显示，直到重新分析钱包等其他路径清除。
- 最新遗留 research audit 有两次 `REFRESH_ERROR`（02:32:19、02:33:04 UTC），涉及旧 `research_entries` 的持仓刷新（entry 405）和 `market not found`。它们与 02:32:16 UTC 的 stale signal 时间接近，但属于旧研究记录而非本实验入场；8 条 stale 的信号年龄本身已超过 900 秒。时间接近不能证明因果。

## 代码与数据证据位置

- `app/research.py:347-444`：BUY、信号年龄、市场查询、horizon 与执行 gate 的顺序；horizon 拒绝先于 fee/order book。
- `app/research.py:222-264`：摘要 eligible 来自 `horizon_eligible`，entries 对外仅取最近 100 条。
- `app/polymarket.py:140-183`、`app/polymarket.py:407-419`：market `endDate` 优先于 event `endDate`，保留来源但不校验业务语义。
- `app/monitor.py:82-128`：扫描异常存储、2/4/8…秒递增并最高 60 秒退避、成功时仅清内存计数。
- `app/monitor.py:203-221`、`app/db.py:378-396`：全局最近扫描状态；数据库错误值仅在钱包重新分析时清空。
- `data/edge_mvp.db`：`research_experiments`、`research_experiment_wallets`、`research_experiment_entries`、`wallets`、`research_audit`；以上查询通过 `mode=ro` 与 `PRAGMA query_only=ON` 完成。

## 修复与回归测试建议（未实施）

1. 在 `app/polymarket.py` 明确区分 event start、market expected end 和正式 resolution；只接受语义可验证的预计结束字段。无法验证或字段冲突时记为独立数据质量原因，保持 fail closed，不从标题/描述或历史行情猜算。
2. 在 `app/research.py` 保存 end-time 来源/质量；为比赛开赛早于市场预期关闭、开赛时间被误读为 end、市场仍开放但 end 已过、未知/冲突时间及 1h/48h 边界添加确定性测试。不要回填跳过记录为成交；若资格语义改变，应采用新规则版本和独立实验。
3. 在 `app/monitor.py` 与 `app/db.py` 保存异常类型、发生时间、恢复时间及可安全展示的错误摘要；成功扫描只清除 monitor 自己的旧错误，不能覆盖其他错误。测试空消息异常、超时、成功恢复、退避重置和钱包级状态。
4. 用假 HTTP/本地响应测试 Gamma market lookup 失败与 timeout 的记录方式，区分 monitor、旧 research 持仓刷新与当前实验入场故障；不对生产数据库运行测试。

本次诊断未运行测试（只读调查范围）；未执行任何代码修改。
