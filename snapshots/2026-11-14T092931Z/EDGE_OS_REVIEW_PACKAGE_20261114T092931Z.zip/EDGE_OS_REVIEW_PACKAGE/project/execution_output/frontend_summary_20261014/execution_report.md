# 首页实验概览与资金展示调整

STATE: EXECUTED

## 变更
- app/static/index.html：实验概览（hero、指标及已正式判定图）置顶；固定共享资金池紧接其后；实验身份/版本明细下移。JS/CSS URL 添加本轮版本号，避免缓存旧布局。
- app/static/app.js：新增累计投入本金，读取现有 capital_pool.buy_turnover × fixed_initial_cash；采用实际 BUY 本金口径，不含手续费，包含回款后再次投入，因此可以超过固定初始本金。缺失或无效字段显示 —，不伪造零。
- app/static/app.js：已实现净收益旁显示 capital_pool.realized_return，即账本已实现净收益 / 固定初始本金；正/负收益率使用对应颜色。移除首页“本实验未实现浮动收益”卡片。
- app/static/ui_v1.css：收益金额和收益率并排/自适应换行，共享池紧邻概览。

## 静态检查与实际页面
- node --check app/static/app.js：exit 0。
- git diff --check -- app/static/index.html app/static/app.js：exit 0。
- 未新增或运行自动测试。
- 内置浏览器实际读取当前运行服务：overview 的前两个子节点依次为 overview-summary、capital-dashboard。
- 页面实际显示：累计投入本金 $8,815.81；已实现模拟净收益 $19.51；净收益率 0.28%；固定初始本金 $7,000.00。这是页面检查时读数，运行中会继续变化。
- 两个板块间距约 14px；截图见 homepage.png。

## 边界
只修改上述三个前端文件。未修改后端/API、策略、资金池配置或数据库，未启动/停止/重启运行服务；没有改变交易、结算或已有 C2C/VOID 检查点。已实现收益率是固定本金收益率，不是已结算交易投入分母的单笔/交易 ROI。
本轮为本地改动与页面核对，不声明网页 ChatGPT 独立 REVIEW_PASS。

exact.diff 以本轮修改前工作副本为基线，不包含已有其他 Git 改动。
