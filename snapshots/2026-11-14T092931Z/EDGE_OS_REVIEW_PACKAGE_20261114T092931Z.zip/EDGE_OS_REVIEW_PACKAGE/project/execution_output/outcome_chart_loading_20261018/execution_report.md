# 已正式判定模拟成交图表加载修复

STATE: EXECUTED_AND_RUNNING

## 确认的根因
图表每次刷新都先重设为 loading，并逐页读取全部 FORMALLY_RESOLVED 完整档案。现场第一批 200 条请求耗时 22,909ms，响应 535,264 bytes，总数 1,880；已超过前端 GET 的 20 秒超时。页面每 10 秒刷新且没有等待图表请求结束，可重复发起全量读取、持续重置加载状态。

## 修复
- app/wallet_follow_runtime.py：现有 status_v2 已读取全部当前策略 episodes，在该一致只读视图中计算 resolved_paper_outcomes；不新增 DB 查询、表、索引或写库。
- /api/wallet-follow-v2 新增 resolved_paper_outcomes={wins,losses,total,rate,unscored}。仅 FORMALLY_RESOLVED + FILLED/PARTIAL，方向值 1/0 分别记赢/输，未判定方向单独 unscored，VOID/REJECTED 不计入；保留原有计数口径。
- app/static/app.js：图表直接读取同次总览响应中的摘要，不再单独请求 episodes。同步渲染 ready/error，不反复切 loading；等待新总览期间保留已有结果。缺少/无效摘要明确显示读取失败，不制造零样本。
- app/static/index.html：更新资源版本，避免沿用旧脚本。
- 交易档案的详细证据、正式结果筛选与分页接口保持；本轮没有优化详情分页本身。

## 运行和数据保护
已通过 SQLite backup API 创建完整一致备份，integrity_check=ok，见 backup.json。核实工作区、仅模拟服务、端口及父子进程后重新加载同一 FORWARD-20261012T073343Z。
原 fills 逐行不变、episode 无删除、策略版本/资金池/active manifest 不变，preservation.json 全部通过。没有回放历史失败、修改策略或处理旧 VOID checkpoint，live_orders=false。

## 实际核对
新状态接口返回：总计 1224、赢 691、输 533、成功率 56.45424836601307%、unscored=0；与生产只读 SQL 分组结果一致。该次完整状态请求耗时 8473ms，图表没有再额外下载全部档案；两种接口工作量不同，不将此当成统一性能基准。
实际页面显示 1224 / 691 / 533 / 56.5%；手动刷新过程中仍保留结果，不回到“正在读取”。
Node/Python 源码语法和所选前端 Git 差异检查 exit 0。未新增或运行自动测试，未跑全仓回归，未声明网页独立 REVIEW_PASS。

## 证据
baseline_request.json、api_verified.json、preservation.json、backup.json、exact.diff、homepage.png、manifest.json。
差异以本轮前工作副本为基线，不混入此前其他未提交改动。生产继续运行，业务计数可能后续变化；此报告不是长期网络或全部 API 性能达标结论。
