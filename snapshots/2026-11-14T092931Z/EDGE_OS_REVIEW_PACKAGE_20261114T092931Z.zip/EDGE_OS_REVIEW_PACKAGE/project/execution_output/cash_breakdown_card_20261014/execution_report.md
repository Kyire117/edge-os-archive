# 首页实时模拟资金收支卡片

STATE: EXECUTED

## 实施
首页第四张卡片集中显示初始本金、累计正式结算回款、累计实际模拟买入金额、所有 BUY/SELL 手续费、订单预留及可用现金。模拟 SELL 有回款时另列该项，不把卖出回款藏进结算数字。金额来自账本 Decimal 汇总，以美元两位小数展示；沿用页面每 10 秒刷新。

可用现金 = 固定初始本金 + 累计结算回款 + 模拟卖出回款 - 累计买入金额 - 手续费 - 订单预留。

## 只读 API 扩展
/api/wallet-follow-v2 的 capital_pool.cash_breakdown 新增 Decimal 字符串字段：initial_cash、settlement_returns、sell_proceeds、buy_notional、fees、reserved_cash、available_cash。由既有 pool reconciliation 的已读取账本行汇总，没有新的表或迁移，没有写库计算。原有返回字段和资金核对计算保持。

## 变更文件
- app/shared_pool.py：追加只读汇总字段，复用已有 fills/settlements/account 数据。
- app/static/app.js：收支小卡片、缺失数据显示 —；买入金额标题改为“累计模拟买入金额”，优先读取精确本金汇总。
- app/static/ui_v1.css：紧凑数字对齐与窄屏布局。
- app/static/index.html：JS/CSS 缓存版本更新。

## 加载与数据保全
新增 Python 返回字段需要加载服务。先完成 SQLite backup API 一致备份，integrity_check=ok（backup.json）；核对端口、父/子进程及工作区/实验/仅模拟身份后，只重启该模拟服务，通过原启动台恢复同一实验 FORWARD-20261012T073343Z。
未重设实验、迁移/修改旧成交、增加资金或改冻结策略。preservation.json 的原 fills/现金流水完整保留、episodes 无删除、版本/资金池/manifest 不变、quick_check 与现金等式核对全部通过。运行中业务可以正常新增观察及结算。
live_orders/live_trading=false，监控运行。历史 VOID/C2C 检查点未处理。

## 验证
node --check app/static/app.js、git diff --check（本轮跟踪前端文件）、Python compile 源码语法检查 exit 0。API 实际返回 7 项明细，Decimal 等式精确一致；API pool reconciliation.ok=true。
实际浏览器已显示收支明细及更新后的标题，截图 homepage.png。
未新增或运行自动测试；未声明网页 ChatGPT 独立 REVIEW_PASS。

## 证据
backup.json、api_verified.json、preservation.json、exact.diff、homepage.png、manifest.json。
exact.diff 相对本轮修改前工作副本，不包含此前其他 Git 变更。显示金额各自四舍五入至美分，底层核对使用完整 Decimal 精度。
