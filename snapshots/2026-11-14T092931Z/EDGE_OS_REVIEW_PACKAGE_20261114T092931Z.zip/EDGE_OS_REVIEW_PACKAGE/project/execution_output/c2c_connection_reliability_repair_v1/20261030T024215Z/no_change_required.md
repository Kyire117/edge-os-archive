# No configuration change made

No endpoint was changed because the live identity of the saved endpoint could not be verified: the local bridge/listener was down and the only unauthenticated probe returned HTTP 401. The host divergence between package cache and local endpoint record is confirmed, but neither endpoint can be declared authoritative from this evidence.

The plugin cache is generated package content; the supported source of truth for its enabled/current endpoint configuration was not located in this session. Editing the generated cache or sending credentials to an unverified host would be unsafe. Connector replacement is explicitly forbidden. Recovery that may update the quick-tunnel endpoint or require a Codex desktop restart is pending the user's approval.