# Endpoint and MCP registration recovery — Iteration 3

Captured: 2026-10-30 02:42:15 UTC

## Confirmed

- The local cache contains plugin `codex-with-chatgpt-edge-os-101` version `0.1.2`. Its package declares MCP key `edge-os-101` and `streamable-http`.
- The current active Codex registry has 375 tools across 17 owners. The exact intended owner, **Codex with ChatGPT · EDGE OS 101**, has zero tools.
- The separate **EDGE OS 101 · 只读审查** owner has ten tools, including its own `workspace_info`. These are not the intended plugin and were not used to verify the workspace in this iteration.
- The cached package endpoint and saved local workspace endpoint have matching HTTPS scheme, effective port 443 and `/mcp` path, but different hostnames. Raw endpoint values are intentionally omitted.
- The saved local record names workspace `47fec7b8248c`; this is local metadata, not live proof of the remote endpoint identity.
- An unauthenticated GET to the saved endpoint returned HTTP 401. No credentials or authentication material were sent. This only confirms an HTTP authentication gate.
- The recorded local C2C bridge process and listener were absent when checked. Its log did not contain an initialization marker for the intended plugin.

## Root cause status

The verified failure stage is **before tool registration/mount in the active Codex session**. There is no registered tool to call through the intended integration. The endpoint hostname divergence is real, but its causal relationship to missing registration is **not proven**. The available evidence cannot establish which endpoint is authoritative, whether the target plugin is enabled in the ChatGPT UI, or whether provider-side registration initialized successfully.

The earlier `Unknown tool(edge_os_101.workspace_info)` belongs to the distinct read-only review integration's advertised call path. It does not prove that the intended plugin endpoint rejected that tool, because no call through the intended plugin was possible.

## Actions not taken

- No endpoint was guessed or rewritten; no credential was sent to either host.
- No connector was deleted, replaced, or recreated.
- No bridge/tunnel recovery, DNS change, plugin refresh, or Codex restart was performed.
- No product code, database, WAL/SHM, or EDGE OS runtime was touched.
- The 20-call stability test and post-refresh identity/README checks were not run because the intended tools are absent.

## Needed to continue

The current tunnel/bridge is unavailable, and restoring it can create or change a public quick-tunnel endpoint. A normal Codex desktop restart may also be needed to reload plugin registration. Both actions were held for explicit approval under the task's constraints. After approval, first recover the existing supported bridge/tunnel source, verify its workspace association without disclosing credentials, then refresh the normal Codex session only if the intended owner still is not mounted. Do not use another integration as a substitute.