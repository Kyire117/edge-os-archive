# MCP Tool Registration and Namespace Diagnosis

- Captured: 2026-10-30T01:07:56Z UTC
- Task: c2c_connection_reliability_repair_v1, Iteration 1
- Owning connector shown by tool metadata: **EDGE OS 101 · 只读审查**
- Opaque connector resource ID: not exposed by the active registry

## Confirmed in this session

1. The active caller-side registry lists 10 tools owned by the named read-only connector, including `mcp__codex_apps__edge_os_101_workspace_info`. Each tool has a concrete declaration/schema. No generic `api_tool` appears.
2. After discovering this current registry, I invoked the exact listed identity tool once. It failed with:

```text
tool call error: tool call failed for `codex_apps/edge_os_101.workspace_info`

Caused by:
    Mcp error: -32001: Unknown tool({"name":"edge_os_101.workspace_info"})
```

3. Failure occurs during **tool invocation**, after local tool discovery. It is not a reported authentication error, workspace mismatch, or resource-not-found response.
4. The endpoint rejection means that this caller path cannot invoke the advertised workspace identity recipient. The actual expected provider-side namespace is not exposed, so the specific mapping defect is not proven.
5. User-supplied external evidence says a ChatGPT-side call successfully verified the workspace and read README.md. That observation was not independently reproduced in this invocation context and may refer to a different caller/session path.

## Diagnosis

**Observed status: `WEB_CONNECTOR_TOOL_NOT_MOUNTED` at the downstream invocation boundary for this caller.** The caller-side registry advertises the tool, while the endpoint rejects its internal recipient as unknown. This establishes a registry/endpoint inconsistency, but does not distinguish stale caller metadata from provider-side mount/namespace mapping failure.

There is no evidence here of authentication failure or wrong workspace identity. The only confirmed failure is that `edge_os_101.workspace_info` is unknown to the endpoint reached by this tool call.

## Gated checks not run

Because the identity call failed, README was not read through this caller, and no further workspace tool or 20-call test was attempted. No connector configuration was changed or replaced. No code, database, WAL/SHM, or EDGE OS runtime was touched.

## Next review point

Compare the caller registry's exact recipient with the provider-side registered tool names/resource metadata. Resolve the mismatch in the connector/runtime registration layer before trying the identity call again. No connector replacement is recommended by this evidence.
