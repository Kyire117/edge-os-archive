# Connection Integration Registration Diagnosis — Iteration 2

- Captured: 2026-10-30T01:12:21Z UTC
- Intended integration: **Codex with ChatGPT · EDGE OS 101**

## Confirmed

- The local plugin cache contains `codex-with-chatgpt-edge-os-101`, version `0.1.2`; its manifest declares an MCP server key `edge-os-101` using `streamable-http`.
- The active execution registry has 375 tool definitions across 17 plugin owners, but **zero tools** owned by `Codex with ChatGPT · EDGE OS 101`. No intended-plugin recipient or tool schema is available in this session.
- The ten `mcp__codex_apps__edge_os_101_*` tools belong to **EDGE OS 101 · 只读审查**. The nine similarly named Git Node tools belong to **Codex with ChatGPT · codex-with-chatgpt-1-git-node**. These identities are distinct.
- No generic `api_tool` is present.
- The cached 0.1.2 plugin endpoint host differs from the current local workspace endpoint record for `47fec7b8248c`. URL values are omitted. This is a confirmed local configuration divergence; its causality is unproven.

## Correct attribution of the earlier error

The prior call used `mcp__codex_apps__edge_os_101_workspace_info`, owned by **EDGE OS 101 · 只读审查**. It returned:

```text
tool call error: tool call failed for `codex_apps/edge_os_101.workspace_info`
Caused by: Mcp error: -32001: Unknown tool({"name":"edge_os_101.workspace_info"})
```

That failure occurred on the read-only integration path. It is **not evidence** that the intended `Codex with ChatGPT · EDGE OS 101` endpoint rejected `workspace_info`; the intended plugin was absent from the active registry, so no call through it was possible.

## State distinctions

- Local package cached: yes, version 0.1.2.
- Registered in this active execution session: no.
- Mounted/callable in this session: no.
- ChatGPT UI installation status: not independently checked in this iteration.
- Earlier ChatGPT-side success: user-reported evidence of a separate working access path; not proof of this session's registration.

## Unresolved

The evidence does not identify why the package is not mounted, whether the endpoint divergence caused that, or what tool names the provider currently exposes. The precise provider-side registration state cannot be queried from this session.

No connector was changed. No workspace tool was invoked in this iteration. No code, database, WAL/SHM, or runtime was changed. The 20-call stability test remains gated.
