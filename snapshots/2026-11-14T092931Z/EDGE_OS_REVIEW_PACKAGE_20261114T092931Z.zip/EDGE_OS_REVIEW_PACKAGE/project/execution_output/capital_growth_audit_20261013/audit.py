"""Read-only production audit of automatic virtual funding; no application DB initialization."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
from collections import Counter, defaultdict
import hashlib
import json
import shutil
import sqlite3
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
run = json.loads((ROOT / 'data/active_experiment.json').read_text(encoding='utf-8'))
source_path = (ROOT / run['database']).resolve()
baseline = json.loads((ROOT / 'execution_output/settlement_api_repair_20261013/pre_deploy_pointer.json').read_text(encoding='utf-8'))
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
snapshot_path = OUT / f'snapshot_{stamp}.db'

def ro(path):
    con = sqlite3.connect(Path(path).as_uri() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA query_only=ON')
    return con

source = ro(source_path)
with sqlite3.connect(snapshot_path) as target:
    source.backup(target)
source.close()
current = ro(snapshot_path)
prior = ro(baseline['backup'])

def rows(con, table):
    return [dict(x) for x in con.execute('SELECT * FROM "' + table + '"')]

def total(items, field):
    return sum((Decimal(x[field] or '0') for x in items), Decimal('0'))

def digest(items):
    return hashlib.sha256('\n'.join(sorted(json.dumps(x, sort_keys=True, separators=(',', ':')) for x in items)).encode()).hexdigest()

accounts = rows(current, 'strict_accounts')
prior_accounts = rows(prior, 'strict_accounts')
events = rows(current, 'strict_cash_ledger')
prior_events = rows(prior, 'strict_cash_ledger')
old_ids = {x['entry_id'] for x in prior_events}
added = [x for x in events if x['entry_id'] not in old_ids]
by_type = defaultdict(list)
for row in added:
    by_type[row['entry_type']].append(row)
delta_events = {key: {'count': len(value), 'cash_flow': str(total(value, 'cash_flow')), 'fees': str(total(value, 'fee')), 'net': str(total(value, 'cash_flow') - total(value, 'fee'))} for key, value in by_type.items()}
prior_available = total(prior_accounts, 'available_cash')
available = total(accounts, 'available_cash')
reserved = total(accounts, 'reserved_cash')
old_account_ids = {x['account_id'] for x in prior_accounts}
new_accounts = [x for x in accounts if x['account_id'] not in old_account_ids]
new_details = []
for account in new_accounts:
    aid = account['account_id']
    decisions = [dict(x) for x in current.execute('SELECT decision_id,status,reason,created_at FROM strict_decisions WHERE account_id=? ORDER BY created_at,decision_id', (aid,))]
    audit = [dict(x) for x in current.execute('SELECT seq,event_type,created_at,payload_json FROM strict_audit_events WHERE account_id=? ORDER BY seq', (aid,))]
    new_details.append({'account': account, 'decisions': decisions,
        'fill_count': current.execute('SELECT count(*) FROM strict_fills WHERE account_id=?', (aid,)).fetchone()[0],
        'audit': audit})
fills = rows(current, 'strict_fills')
positions = rows(current, 'strict_positions')
buys = [x for x in fills if x['side'] == 'BUY']
sells = [x for x in fills if x['side'] == 'SELL']
settlements = rows(current, 'strict_settlements')
episodes = rows(current, 'wallet_v2_episodes')
initial = total(accounts, 'initial_cash')
buy_gross = total(buys, 'gross_amount')
buy_fees = total(buys, 'fee')
sell_net = total(sells, 'gross_amount') - total(sells, 'fee')
payout = total(settlements, 'cash_flow')
realized = total(positions, 'realized_pnl')
open_cost = total([x for x in positions if Decimal(x['quantity']) > 0], 'cost_basis')
frozen_before = rows(prior, 'wallet_v2_versions')
frozen_now = rows(current, 'wallet_v2_versions')
result = {
    'captured_at_utc': datetime.now(timezone.utc).isoformat(), 'run_id': run['run_id'],
    'source_db': str(source_path), 'snapshot': str(snapshot_path),
    'snapshot_sha256': hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),
    'snapshot_integrity_check': current.execute('PRAGMA integrity_check').fetchone()[0],
    'comparison_baseline': baseline,
    'baseline_account_count': len(prior_accounts), 'baseline_initial_cash': str(total(prior_accounts, 'initial_cash')),
    'baseline_available_cash': str(prior_available), 'account_count': len(accounts),
    'initial_virtual_cash': str(initial), 'available_cash': str(available), 'reserved_cash': str(reserved),
    'available_delta': str(available - prior_available), 'new_cash_ledger_by_type': delta_events,
    'delta_reconciles': available + reserved - prior_available - total(prior_accounts, 'reserved_cash') == total(added, 'cash_flow') - total(added, 'fee'),
    'cumulative_buy_gross': str(buy_gross), 'buy_fees': str(buy_fees), 'cumulative_buy_debit': str(buy_gross + buy_fees),
    'formal_cash_payout': str(payout), 'sell_net': str(sell_net), 'realized_pnl': str(realized), 'open_cost_basis': str(open_cost),
    'cash_equation_matches': initial - buy_gross - buy_fees + payout + sell_net == available + reserved,
    'cost_basis_equation_matches': available + reserved + open_cost == initial + realized,
    'initial_cash_events_per_account': dict(Counter(x['account_id'] for x in events if x['entry_type'] == 'INITIAL_CASH')),
    'all_previous_cash_rows_unchanged': all({x['entry_id']: x for x in events}.get(x['entry_id']) == x for x in prior_events),
    'frozen_strategy_rows_unchanged': digest(frozen_before) == digest(frozen_now),
    'new_accounts': new_details,
    'buy_fill_count': len(buys), 'sell_fill_count': len(sells),
    'formally_resolved_filled_episode_count': sum(x['resolution_status'] == 'FORMALLY_RESOLVED' and x['paper_status'] in ('FILLED', 'PARTIAL') for x in episodes),
    'open_position_count': sum(Decimal(x['quantity']) > 0 for x in positions),
    'execution_created_at_used_for_account_funding': False,
    'funding_timestamp_limitation': 'Account creation and INITIAL_CASH are dated at experiment activation, not the actual first execution attempt. Audit sequence and first decision provide ordering evidence only.',
    'product_files_changed': [], 'production_connection': 'mode=ro; query_only=ON; SQLite backup to a new evidence file only',
}
current.close()
prior.close()

# Ledger classes are instantiated only against a disposable copy, never production.
from app.strict_ledger import StrictPaperLedger
reconcile_path = OUT / f'reconcile_{stamp}.db'
shutil.copyfile(snapshot_path, reconcile_path)
result['reconciliation_copy'] = str(reconcile_path)
result['account_reconciliations'] = {x['account_id']: StrictPaperLedger(reconcile_path, x['account_id']).reconcile() for x in accounts}
result['audit_validation'] = StrictPaperLedger(reconcile_path, accounts[0]['account_id']).verify_audit_chain()
result['all_accounts_reconcile'] = all(x['ok'] for x in result['account_reconciliations'].values())
(OUT / 'snapshot.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k not in ('account_reconciliations', 'new_accounts')}, ensure_ascii=True, indent=2))
print('NEW_ACCOUNT_DETAILS')
print(json.dumps(new_details, ensure_ascii=True, indent=2))
