# EDGE OS 一键启动修复

状态：本地实施完成、实际启动和重复打开核验通过。

## 根因和修复

1. 启动台 `/status` 同步等待后台 health，现场耗时 2.57 秒；`ensure()` 的 2 秒请求先超时，于是把已运行的正确启动台误报为地址占用。
2. 新增只识别启动台自身的 `/identity`，不访问应用或 DB；`ensure` 优先快速身份检查。对已运行的旧启动台，404 时兼容使用 6 秒 `/status` 检查；其他服务/工作区仍 fail closed。现场快速身份检查 6ms，重复执行脚本 exit=0。
3. 启动后另确认 PublicNode 对昨晚保存的补漏范围返回 HTTP403：Archive requests require a personal token；更小到 1 个区块仍被拒绝。官方 dRPC 文档列出公开 Polygon `eth_getLogs` 入口，现场该入口 chainId=0x89，原 8 区块范围返回 562 条真实日志、HTTP200。仅替换只读 HTTPS 读取源，原 WSS 订阅仍保留；原方法白名单、16MB 限制、block/receipt/身份校验均保留。

参考官方文档：https://drpc.org/docs/polygon-api/eventlogs/eth_getLogs

## 执行和数据保护

重载前已做 SQLite 一致性备份并 integrity_check=ok；只停止身份精确核对的模拟服务和启动台进程，随后通过实际启动台按钮继续同一数据库。未激活新实验、清零、迁移旧成交或调整冻结交易参数。
实际快照与备份路径、SHA256、counts 见 manifest.json。旧归档全部表 count/hash 与已保存基线一致；当前 DB quick_check=ok；激活 manifest 字节完全未改。C2C/VOID checkpoint 未改。

## 验证与限制

- Python 语法检查、git diff --check、重复启动台身份检查 exit=0；实际启动按钮打开正确实验；钱包监控运行、实时订阅已连接且补漏检查已成功。
- 本轮未运行自动测试套件，昨天的 417 tests 不当作本轮回归结果。
- 昨晚断线缺口正在连续分批补回，尚未全部追平；公共源长期稳定性和新恢复速度尚未验证，不能称全量追平或保证低延迟。
- 数据证据不足时仍拒绝模拟成交；不修改原交易/账本/退出规则。
- 本轮按当前本地工作约定进行代码自查和实际操作核验，未声称网页独立 REVIEW_PASS。

exact.diff 为相对于本轮复制基线的两文件精确差异；运行和保存证据见 manifest.json。
