# EDGE OS UI V1 · 可读界面证据

验证环境：2026-09-24，本机 `127.0.0.1:8766`，数据库仅为被 Git 忽略的 `execution_output/preview-ui.db`。浏览器使用 Codex 内置浏览器。下列钱包“界面测试样本”及其数值都是临时界面夹具，不代表任何真实钱包或策略表现；正式 `data/edge_mvp.db` 未参与预览。

| 页面 | 修改前的代码呈现 | 修改后实际浏览器可见内容 |
|---|---|---|
| 钱包列表 | 地址、按正收益筛出的分类、AI 摘要和操作按钮 | 公开资料名“界面测试样本”、跟踪状态、按观察持仓数排出的 Crypto 4 / Politics 2、已结算持仓盈利占比 3 / 5 = 60%、分类分母 2 / 3 与 1 / 2、Leader 历史收益及来源、本实验收益另列；保留原按钮 |
| 钱包详情 | 原始 JSON 弹窗 | 完整地址及复制、资料链接、恰好三句样本描述、分类统计、跟踪时间、Leader 与各模拟收益分栏；“高级数据”可展开查看原始证据及 AI 复盘 JSON |
| 交易档案 | 较早研究的单一列表 | “当前 14 天实验”与“较早研究档案”可切换；两者各有状态筛选、翻页和完整逐笔证据入口。临时库中两个范围都正确显示 0 / 0，而不是混合计数 |
| 自动发现 | 候选列表 | 页面显示“自动发现已停用 · 最近成功：—”，候选为空时给出明确提示 |
| AI | 配置表单和调用记录 | 显示“服务商：deepseek · 未启用 · 未保存 Key · 今日 0 / 24 次”；明确提醒保存 Key 不等于连接成功 |
| 总览 | 旧研究与实验文字邻近 | 当前实验独立区显示“尚未启动”；下方旧研究卡片标明“较早研究”，运行状态显示监控与最近成功时间 |

独立接口夹具验证：`GET /api/wallets` 返回 `card.identity`、样本分母、分类及分开的 `paper.experiment` / `paper.prior_experiments` / `paper.older_research`；`GET /api/research/entries` 只返回旧研究；`GET /api/research/experiment/entries` 只返回本实验，逐笔详情保留 `evidence`。缺少代理钱包或代理钱包与请求地址不匹配时，后端及前端都不显示姓名/头像/主页；伪造标题或非法 slug 不生成外链；经核验的用户名及分类中的 `<script>`/`<img>` 字符被转义。

自动检查：Python 测试集 `107 passed, 1 warning`；`node --check app/static/app.js` 通过；`node tests/ui_v1_static.test.js` 输出 `UI escaping and URL checks passed`。弃用提示来自 Starlette 测试客户端。完整当前工作树补丁见 `ui-v1-working-tree.diff`；该补丁包含本轮以前已存在、尚未提交的 Forward Copy V0 修改。
