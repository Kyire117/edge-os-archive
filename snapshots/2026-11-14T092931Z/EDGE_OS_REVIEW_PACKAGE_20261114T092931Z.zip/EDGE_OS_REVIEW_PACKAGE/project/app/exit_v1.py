"""Frozen, forward-only exit policy for eligible Wallet Follow V2 positions."""
from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

EXIT_RULE_VERSION = "wallet-follow-exit-v1"
ENTRY_MIN = Decimal("0.60")
ENTRY_MAX = Decimal("0.80")
HARD_STOP_RISK_FRACTION = Decimal("0.50")
PROFIT_PROTECTION_UPSIDE_FRACTION = Decimal("0.20")


def decimal_value(value: Any) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("INVALID_EXIT_PRICE") from None
    if not result.is_finite():
        raise ValueError("INVALID_EXIT_PRICE")
    return result


def exit_levels(entry_price: Any) -> dict[str, Decimal]:
    entry=decimal_value(entry_price)
    if not ENTRY_MIN <= entry <= ENTRY_MAX:
        raise ValueError("ENTRY_OUTSIDE_EXIT_V1_RANGE")
    risk=HARD_STOP_RISK_FRACTION*(Decimal("1")-entry)
    return {"entry_price":entry,"initial_stop":entry-risk,
            "profit_protection_trigger":entry+PROFIT_PROTECTION_UPSIDE_FRACTION*(Decimal("1")-entry),
            "active_exit_floor":entry}


def quote_transition(*, entry_price: Any, initial_stop: Any, protection_trigger: Any,
                     protection_active: bool, best_bid: Any,
                     hard_stop_active: bool = False) -> str:
    """Return a deterministic state action from an executable best bid."""
    bid=decimal_value(best_bid)
    if hard_stop_active:
        return "DYNAMIC_HARD_STOP"
    if protection_active:
        return "PROFIT_PROTECTION" if bid <= decimal_value(entry_price) else "HOLD_TO_FORMAL_RESOLUTION"
    if bid <= decimal_value(initial_stop):
        return "DYNAMIC_HARD_STOP"
    if bid >= decimal_value(protection_trigger):
        return "ACTIVATE_PROFIT_PROTECTION"
    return "HOLD_TO_FORMAL_RESOLUTION"


def initialize_exit_v1_schema(path: str | Path) -> None:
    """Add only the V1 policy/evidence tables; safe to rerun."""
    with sqlite3.connect(path,timeout=30) as con:
        con.execute("PRAGMA foreign_keys=ON")
        con.executescript("""
        CREATE TABLE IF NOT EXISTS wallet_v2_exit_rules (
            rule_version TEXT PRIMARY KEY,
            state TEXT NOT NULL CHECK(state IN ('ACTIVE','RETIRED')),
            config_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            activated_at TEXT NOT NULL,
            live_orders INTEGER NOT NULL DEFAULT 0 CHECK(live_orders=0)
        );
        CREATE TRIGGER IF NOT EXISTS wallet_v2_exit_rule_immutable
        BEFORE UPDATE OF rule_version,config_json,created_at,activated_at,live_orders
        ON wallet_v2_exit_rules BEGIN SELECT RAISE(ABORT,'IMMUTABLE_EXIT_RULE'); END;
        CREATE TABLE IF NOT EXISTS wallet_v2_exit_positions (
            episode_id TEXT PRIMARY KEY,
            rule_version TEXT NOT NULL REFERENCES wallet_v2_exit_rules(rule_version),
            wallet TEXT NOT NULL,
            condition_id TEXT NOT NULL,
            token_id TEXT NOT NULL,
            outcome TEXT NOT NULL,
            entry_price TEXT NOT NULL,
            initial_stop TEXT NOT NULL,
            protection_trigger TEXT NOT NULL,
            protection_active INTEGER NOT NULL DEFAULT 0 CHECK(protection_active IN (0,1)),
            protection_activated_at TEXT,
            hard_stop_active INTEGER NOT NULL DEFAULT 0 CHECK(hard_stop_active IN (0,1)),
            hard_stop_triggered_at TEXT,
            active_exit_floor TEXT NOT NULL,
            state TEXT NOT NULL CHECK(state IN ('ACTIVE','EXITED','FORMALLY_RESOLVED','BLOCKED')),
            exit_reason TEXT,
            last_order_id TEXT,
            last_idempotency_key TEXT,
            last_execution_snapshot_id TEXT,
            last_exit_price TEXT,
            last_exit_slippage TEXT,
            last_exit_fee TEXT,
            realized_exit_pnl TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            lease_id TEXT,
            lease_until REAL,
            FOREIGN KEY(episode_id) REFERENCES wallet_v2_episodes(episode_id)
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_v2_exit_active
            ON wallet_v2_exit_positions(state,updated_at);
        CREATE TABLE IF NOT EXISTS wallet_v2_exit_events (
            event_id TEXT PRIMARY KEY,
            episode_id TEXT NOT NULL,
            rule_version TEXT NOT NULL,
            event_type TEXT NOT NULL,
            occurred_at TEXT NOT NULL,
            evidence_json TEXT NOT NULL,
            FOREIGN KEY(episode_id) REFERENCES wallet_v2_exit_positions(episode_id)
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_v2_exit_events_episode
            ON wallet_v2_exit_events(episode_id,occurred_at);
        CREATE TRIGGER IF NOT EXISTS wallet_v2_exit_event_no_update
        BEFORE UPDATE ON wallet_v2_exit_events BEGIN SELECT RAISE(ABORT,'APPEND_ONLY_EXIT_EVIDENCE'); END;
        CREATE TRIGGER IF NOT EXISTS wallet_v2_exit_event_no_delete
        BEFORE DELETE ON wallet_v2_exit_events BEGIN SELECT RAISE(ABORT,'APPEND_ONLY_EXIT_EVIDENCE'); END;
        """)
        columns={row[1] for row in con.execute("PRAGMA table_info(wallet_v2_exit_positions)")}
        if "hard_stop_active" not in columns:
            con.execute("ALTER TABLE wallet_v2_exit_positions ADD COLUMN hard_stop_active INTEGER NOT NULL DEFAULT 0 CHECK(hard_stop_active IN (0,1))")
        if "hard_stop_triggered_at" not in columns:
            con.execute("ALTER TABLE wallet_v2_exit_positions ADD COLUMN hard_stop_triggered_at TEXT")


def frozen_exit_config(v2_config: dict[str, Any]) -> dict[str, Any]:
    """Bind exit execution to the already-frozen V2 paper execution controls."""
    latency=int(v2_config.get("execution_latency_ms",-1))
    max_age=int(v2_config.get("max_book_age_ms",-1))
    depth=decimal_value(v2_config.get("max_visible_depth_fraction"))
    if latency!=500 or max_age!=3000 or depth!=Decimal("0.10") or v2_config.get("live_orders") is not False:
        raise ValueError("EXIT_V1_FROZEN_EXECUTION_CONFIG_MISMATCH")
    return {"rule_version":EXIT_RULE_VERSION,"entry_price_min":str(ENTRY_MIN),
        "entry_price_max":str(ENTRY_MAX),"hard_stop_risk_fraction_of_remaining_upside":str(HARD_STOP_RISK_FRACTION),
        "profit_protection_fraction_of_max_upside":str(PROFIT_PROTECTION_UPSIDE_FRACTION),
        "profit_protection_action":"LATCH_BREAK_EVEN_FLOOR_NO_TAKE_PROFIT",
        "fallback":"HOLD_TO_FORMAL_RESOLUTION","execution_latency_ms":latency,
        "max_book_age_ms":max_age,"max_visible_depth_fraction":str(depth),
        "execution_engine":"strict-paper-engine-v4","partial_execution":"IOC",
        "live_orders":False,"source_strategy_version":"wallet-follow-v2.0"}


def append_exit_event(con: sqlite3.Connection, episode_id: str, event_type: str,
                      occurred_at: str, evidence: dict[str, Any], *, event_key: str) -> bool:
    payload=json.dumps(evidence,sort_keys=True,separators=(",",":"),default=str)
    event_id=hashlib.sha256(f"{EXIT_RULE_VERSION}|{episode_id}|{event_type}|{event_key}".encode()).hexdigest()
    cur=con.execute("INSERT OR IGNORE INTO wallet_v2_exit_events(event_id,episode_id,rule_version,event_type,occurred_at,evidence_json) VALUES(?,?,?,?,?,?)",
        (event_id,episode_id,EXIT_RULE_VERSION,event_type,occurred_at,payload))
    return bool(cur.rowcount)


def ensure_exit_v1_active(path: str | Path, *, activated_at: datetime) -> bool:
    """Activate a separate exit policy only while frozen V2.0 is forward-testing."""
    stamp=activated_at.astimezone(timezone.utc).isoformat()
    initialize_exit_v1_schema(path)
    with sqlite3.connect(path,timeout=30,isolation_level=None) as con:
        con.row_factory=sqlite3.Row
        con.execute("BEGIN IMMEDIATE")
        try:
            version=con.execute("SELECT state,config_json FROM wallet_v2_versions WHERE strategy_version='wallet-follow-v2.0'").fetchone()
            if not version or version["state"]!='FORWARD_TEST':
                con.commit();return False
            config=frozen_exit_config(json.loads(version["config_json"]))
            encoded=json.dumps(config,sort_keys=True,separators=(",",":"))
            prior=con.execute("SELECT config_json,state FROM wallet_v2_exit_rules WHERE rule_version=?",(EXIT_RULE_VERSION,)).fetchone()
            if prior:
                if prior["config_json"]!=encoded:
                    raise ValueError("IMMUTABLE_EXIT_RULE_CONFLICT")
                con.commit();return prior["state"]=='ACTIVE'
            con.execute("INSERT INTO wallet_v2_exit_rules(rule_version,state,config_json,created_at,activated_at,live_orders) VALUES(?, 'ACTIVE',?,?,?,0)",
                        (EXIT_RULE_VERSION,encoded,stamp,stamp))
            con.commit();return True
        except Exception:
            con.rollback();raise


def exit_v1_status(path: str | Path) -> dict[str, Any]:
    uri=f"file:{Path(path).resolve().as_posix()}?mode=ro"
    with sqlite3.connect(uri,uri=True) as con:
        con.row_factory=sqlite3.Row;con.execute("PRAGMA query_only=ON")
        exists=con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wallet_v2_exit_rules'").fetchone()
        if not exists:return {"rule_version":EXIT_RULE_VERSION,"state":"NOT_INITIALIZED","eligible_positions":0,"protected_positions":0,"exited_positions":0,"blocked_positions":0}
        rule=con.execute("SELECT * FROM wallet_v2_exit_rules WHERE rule_version=?",(EXIT_RULE_VERSION,)).fetchone()
        states={row["state"]:row["n"] for row in con.execute("SELECT state,COUNT(*) n FROM wallet_v2_exit_positions WHERE rule_version=? GROUP BY state",(EXIT_RULE_VERSION,))}
        protected=con.execute("SELECT COUNT(*) FROM wallet_v2_exit_positions WHERE rule_version=? AND protection_active=1 AND state='ACTIVE'",(EXIT_RULE_VERSION,)).fetchone()[0]
    return {"rule_version":EXIT_RULE_VERSION,"state":rule["state"] if rule else "NOT_REGISTERED",
        "activated_at":rule["activated_at"] if rule else None,
        "frozen_config":json.loads(rule["config_json"]) if rule else None,
        "eligible_positions":sum(states.values()),"protected_positions":int(protected),
        "exited_positions":states.get("EXITED",0),"blocked_positions":states.get("BLOCKED",0),
        "state_counts":states,"live_orders":False}
