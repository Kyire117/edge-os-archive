"""Explicit fixed-capital paper funding; wallet books remain separate.

No activation on import/startup. All cash and capital observations commit in
the caller's SQLite transaction. Existing fills and strategy rules are retained.
"""
from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal
import json
import sqlite3
import uuid
from pathlib import Path

VERSION = 'shared-cash-pool-v1'
QUANTUM = Decimal('0.000001')


def amount(value):
    result = Decimal(str(value))
    if not result.is_finite():
        raise ValueError('INVALID_POOL_AMOUNT')
    return result.quantize(QUANTUM)


def pool_for(con, account_id):
    if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='strict_cash_pools'").fetchone():
        return None
    rows = con.execute('SELECT * FROM strict_cash_pools').fetchall()
    for row in rows:
        value = dict(row)
        if account_id.startswith(value['account_prefix']):
            return value
    return None


def cash_owner(con, account_id):
    pool = pool_for(con, account_id)
    return pool['cash_account_id'] if pool else account_id


def initialize_schema(path):
    """Permit zero-funded book accounts, preserving every existing account row."""
    con = sqlite3.connect(path, timeout=30, isolation_level=None)
    try:
        # SQLite cannot change CHECK constraints with ADD COLUMN. Rebuild only
        # this table atomically; references retain the original table name.
        con.execute('PRAGMA foreign_keys=OFF')
        con.execute('BEGIN IMMEDIATE')
        sql = con.execute("SELECT sql FROM sqlite_master WHERE name='strict_accounts'").fetchone()[0]
        if 'CAST(initial_cash AS REAL) > 0' in sql:
            con.execute('''CREATE TABLE strict_accounts_pool_upgrade (
                account_id TEXT PRIMARY KEY, ledger_version TEXT NOT NULL,
                initial_cash TEXT NOT NULL CHECK(CAST(initial_cash AS REAL) >= 0),
                available_cash TEXT NOT NULL CHECK(CAST(available_cash AS REAL) >= 0),
                reserved_cash TEXT NOT NULL CHECK(CAST(reserved_cash AS REAL) >= 0),
                realized_cash_flows TEXT NOT NULL, fees_total TEXT NOT NULL, created_at TEXT NOT NULL)''')
            con.execute('INSERT INTO strict_accounts_pool_upgrade SELECT * FROM strict_accounts')
            con.execute('DROP TABLE strict_accounts')
            con.execute('ALTER TABLE strict_accounts_pool_upgrade RENAME TO strict_accounts')
        con.execute('''CREATE TABLE IF NOT EXISTS strict_cash_pools (
            pool_id TEXT PRIMARY KEY, funding_version TEXT NOT NULL,
            account_prefix TEXT NOT NULL UNIQUE, cash_account_id TEXT NOT NULL UNIQUE,
            fixed_initial_cash TEXT NOT NULL, activated_at TEXT NOT NULL,
            config_json TEXT NOT NULL)''')
        con.execute('''CREATE TABLE IF NOT EXISTS strict_capital_events (
            seq INTEGER PRIMARY KEY AUTOINCREMENT, event_key TEXT NOT NULL UNIQUE,
            pool_id TEXT NOT NULL, event_type TEXT NOT NULL,
            captured_at TEXT NOT NULL, source_timestamp TEXT NOT NULL,
            available_cash TEXT NOT NULL, reserved_cash TEXT NOT NULL,
            open_cost_basis TEXT NOT NULL, realized_pnl TEXT NOT NULL)''')
        for table in ('strict_cash_pools', 'strict_capital_events'):
            for operation in ('UPDATE', 'DELETE'):
                con.execute(f"CREATE TRIGGER IF NOT EXISTS {table}_no_{operation.lower()} BEFORE {operation} ON {table} BEGIN SELECT RAISE(ABORT,'append-only funding evidence'); END")
        con.execute("""CREATE TRIGGER IF NOT EXISTS strict_pool_no_new_capital
            BEFORE INSERT ON strict_accounts
            WHEN CAST(NEW.initial_cash AS REAL)!=0 AND EXISTS (
              SELECT 1 FROM strict_cash_pools WHERE NEW.account_id LIKE account_prefix||'%')
            BEGIN SELECT RAISE(ABORT,'SHARED_POOL_NO_NEW_CAPITAL'); END""")
        con.execute("""CREATE TRIGGER IF NOT EXISTS strict_pool_frozen_account_capital
            BEFORE UPDATE OF initial_cash ON strict_accounts
            WHEN NEW.initial_cash!=OLD.initial_cash AND EXISTS (
              SELECT 1 FROM strict_cash_pools WHERE NEW.account_id LIKE account_prefix||'%')
            BEGIN SELECT RAISE(ABORT,'SHARED_POOL_FROZEN_CAPITAL'); END""")
        con.execute("""CREATE TRIGGER IF NOT EXISTS strict_pool_no_initial_cash_credit
            BEFORE INSERT ON strict_cash_ledger
            WHEN NEW.entry_type='INITIAL_CASH' AND EXISTS (
              SELECT 1 FROM strict_cash_pools WHERE NEW.account_id LIKE account_prefix||'%')
            BEGIN SELECT RAISE(ABORT,'SHARED_POOL_NO_NEW_CAPITAL'); END""")
        if con.execute('PRAGMA foreign_key_check').fetchone():
            raise ValueError('POOL_SCHEMA_FOREIGN_KEY_FAILURE')
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def observe_capital(con, account_id, event_key, event_type, at):
    pool = pool_for(con, account_id)
    if not pool:
        return
    cash = con.execute('SELECT available_cash,reserved_cash FROM strict_accounts WHERE account_id=?', (pool['cash_account_id'],)).fetchone()
    positions = con.execute('SELECT quantity,cost_basis,realized_pnl FROM strict_positions WHERE account_id LIKE ?', (pool['account_prefix'] + '%',)).fetchall()
    basis = sum((amount(x['cost_basis']) for x in positions if amount(x['quantity']) > 0), Decimal(0))
    pnl = sum((amount(x['realized_pnl']) for x in positions), Decimal(0))
    previous = con.execute('SELECT captured_at FROM strict_capital_events WHERE pool_id=? ORDER BY seq DESC LIMIT 1', (pool['pool_id'],)).fetchone()
    timestamp = datetime.fromisoformat(at.replace('Z', '+00:00'))
    if timestamp.tzinfo is None:
        raise ValueError('INVALID_POOL_TIMESTAMP')
    if previous:
        timestamp = max(timestamp, datetime.fromisoformat(previous[0]))
    timestamp = timestamp.astimezone(timezone.utc).isoformat()
    con.execute('INSERT OR IGNORE INTO strict_capital_events(event_key,pool_id,event_type,captured_at,source_timestamp,available_cash,reserved_cash,open_cost_basis,realized_pnl) VALUES(?,?,?,?,?,?,?,?,?)',
        (event_key, pool['pool_id'], event_type, timestamp, at, cash[0], cash[1], str(basis), str(pnl)))
    from .paper_trial_risk import observe
    observe(con, account_id, timestamp)


def activate_pool(path, *, initial_cash, at, strategy_version='wallet-follow-v2.0'):
    """Explicit offline conversion; caller must stop writers and save a backup."""
    from .strict_ledger import StrictPaperLedger, LEDGER_VERSION
    total = amount(initial_cash)
    if total <= 0 or at.tzinfo is None:
        raise ValueError('INVALID_POOL_CONFIG')
    initialize_schema(path)
    prefix = strategy_version + ':'
    root_id = prefix + 'shared-cash'
    ledger = StrictPaperLedger(path, root_id)
    when = at.astimezone(timezone.utc).isoformat()
    config = json.dumps({'funding_version': VERSION, 'fixed_initial_cash': str(total),
        'new_wallet_initial_cash': '0.000000', 'live_orders': False,
        'wallet_position_books': 'SEPARATE', 'cash_account_id': root_id}, sort_keys=True)
    with ledger._tx() as con:
        existing = pool_for(con, root_id)
        if existing:
            if existing['config_json'] != config:
                raise ValueError('FROZEN_POOL_CONFIG_CONFLICT')
            return {'already_active': True, **existing}
        version = con.execute('SELECT config_json,state FROM wallet_v2_versions WHERE strategy_version=?', (strategy_version,)).fetchone()
        if not version or version['state'] != 'FORWARD_TEST' or json.loads(version['config_json']).get('live_orders') is not False:
            raise ValueError('POOL_REQUIRES_PAPER_FORWARD_TEST')
        accounts = con.execute('SELECT * FROM strict_accounts WHERE account_id LIKE ?', (prefix + '%',)).fetchall()
        if sum((amount(x['initial_cash']) for x in accounts), Decimal(0)) != total:
            raise ValueError('POOL_INITIAL_CAPITAL_MISMATCH')
        if any(amount(x['reserved_cash']) != 0 for x in accounts) or con.execute("SELECT 1 FROM strict_orders WHERE account_id LIKE ? AND status='OPEN'", (prefix + '%',)).fetchone():
            raise ValueError('POOL_HAS_INFLIGHT_RESERVATIONS')
        con.execute('INSERT INTO strict_accounts VALUES(?,?,?,?,?,?,?,?)', (root_id, LEDGER_VERSION, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', when))
        transferred = Decimal(0)
        for row in accounts:
            cash = amount(row['available_cash'])
            transferred += cash
            con.execute("UPDATE strict_accounts SET available_cash='0.000000',realized_cash_flows=? WHERE account_id=?", (str(amount(row['realized_cash_flows']) - cash), row['account_id']))
            details = json.dumps({'pool_id': root_id, 'destination': root_id, 'funding_version': VERSION}, sort_keys=True)
            con.execute('INSERT INTO strict_cash_ledger VALUES(?,?,?,?,?,?,?,?,?)', (str(uuid.uuid4()), row['account_id'], None, None, 'POOL_TRANSFER_OUT', str(-cash), '0.000000', when, details))
            StrictPaperLedger(path, row['account_id'])._audit(con, 'POOL_TRANSFER_OUT', {'pool_id': root_id, 'cash': str(cash)}, when)
        con.execute('UPDATE strict_accounts SET available_cash=?,realized_cash_flows=? WHERE account_id=?', (str(transferred), str(transferred), root_id))
        con.execute('INSERT INTO strict_cash_ledger VALUES(?,?,?,?,?,?,?,?,?)', (str(uuid.uuid4()), root_id, None, None, 'POOL_TRANSFER_IN', str(transferred), '0.000000', when, config))
        con.execute('INSERT INTO strict_cash_pools VALUES(?,?,?,?,?,?,?)', (root_id, VERSION, prefix, root_id, str(total), when, config))
        ledger._audit(con, 'SHARED_POOL_ACTIVATED', {'fixed_initial_cash': str(total), 'transferred_cash': str(transferred), 'config': json.loads(config)}, when)
        observe_capital(con, root_id, 'pool:' + root_id, 'ACTIVATION', when)
    return {'already_active': False, 'pool_id': root_id, 'fixed_initial_cash': str(total), 'available_cash': str(transferred), 'activated_at': when}


def reconcile_pool(con, pool):
    prefix = pool['account_prefix'] + '%'
    accounts = [dict(x) for x in con.execute('SELECT * FROM strict_accounts WHERE account_id LIKE ?', (prefix,))]
    cash_rows = [dict(x) for x in con.execute('SELECT * FROM strict_cash_ledger WHERE account_id LIKE ?', (prefix,))]
    fills = [dict(x) for x in con.execute('SELECT * FROM strict_fills WHERE account_id LIKE ?', (prefix,))]
    settlements = [dict(x) for x in con.execute('SELECT * FROM strict_settlements WHERE account_id LIKE ?', (prefix,))]
    orders = [dict(x) for x in con.execute('SELECT * FROM strict_orders WHERE account_id LIKE ?', (prefix,))]
    total = lambda rows, key: sum((amount(x[key]) for x in rows), Decimal(0))
    fees = total(fills, 'fee')
    buy_notional = total([x for x in fills if x['side'] == 'BUY'], 'gross_amount')
    sell_proceeds = total([x for x in fills if x['side'] == 'SELL'], 'gross_amount')
    settlement_returns = total(settlements, 'cash_flow')
    flows = sum((amount(x['gross_amount']) * (-1 if x['side'] == 'BUY' else 1) for x in fills), Decimal(0)) + settlement_returns
    expected = amount(pool['fixed_initial_cash']) + flows - fees
    actual = total(accounts, 'available_cash') + total(accounts, 'reserved_cash')
    ledger_cash = total(cash_rows, 'cash_flow') - total(cash_rows, 'fee')
    pending = total([x for x in orders if x['side'] == 'BUY' and x['status'] == 'OPEN'], 'reserve_cash_remaining')
    root = next(x for x in accounts if x['account_id'] == pool['cash_account_id'])
    checks = {
        'fixed_capital_matches': total(accounts, 'initial_cash') == amount(pool['fixed_initial_cash']),
        'cash_reconciles': expected == actual == ledger_cash,
        'fees_match': fees == total(accounts, 'fees_total') == total(cash_rows, 'fee'),
        'flows_match': flows == total(accounts, 'realized_cash_flows'),
        'reservations_match': pending == amount(root['reserved_cash']),
        'cash_only_in_pool': all(amount(x['available_cash']) == 0 and amount(x['reserved_cash']) == 0 for x in accounts if x['account_id'] != pool['cash_account_id']),
        'nonnegative_cash': all(amount(x['available_cash']) >= 0 and amount(x['reserved_cash']) >= 0 for x in accounts),
    }
    return {'ok': all(checks.values()), **checks, 'cash_reconstructed': str(expected), 'cash_accounted': str(actual), 'cash_ledger_total': str(ledger_cash), 'fees_reconstructed': str(fees),
        'cash_breakdown': {'initial_cash': pool['fixed_initial_cash'],
            'settlement_returns': str(settlement_returns), 'sell_proceeds': str(sell_proceeds),
            'buy_notional': str(buy_notional), 'fees': str(fees),
            'reserved_cash': root['reserved_cash'], 'available_cash': root['available_cash']}}


def capital_metrics(con, strategy_version, *, now=None):
    pool = pool_for(con, strategy_version + ':shared-cash')
    if not pool:
        return {'enabled': False}
    total = amount(pool['fixed_initial_cash'])
    root = con.execute('SELECT * FROM strict_accounts WHERE account_id=?', (pool['cash_account_id'],)).fetchone()
    positions = [dict(x) for x in con.execute('SELECT * FROM strict_positions WHERE account_id LIKE ?', (pool['account_prefix'] + '%',))]
    cost = sum((amount(x['cost_basis']) for x in positions if amount(x['quantity']) > 0), Decimal(0))
    realized = sum((amount(x['realized_pnl']) for x in positions), Decimal(0))
    used = cost + amount(root['reserved_cash'])
    events = [dict(x) for x in con.execute('SELECT * FROM strict_capital_events WHERE pool_id=? ORDER BY seq', (pool['pool_id'],))]
    parse = lambda s: datetime.fromisoformat(s.replace('Z', '+00:00'))
    current = now or datetime.now(timezone.utc)
    start = parse(pool['activated_at'])
    seconds = Decimal(str(max(0, (current - start).total_seconds())))
    integral = Decimal(0)
    for i, row in enumerate(events):
        end = parse(events[i + 1]['captured_at']) if i + 1 < len(events) else current
        duration = Decimal(str(max(0, (min(end, current) - parse(row['captured_at'])).total_seconds())))
        integral += (amount(row['open_cost_basis']) + amount(row['reserved_cash'])) * duration
    fills = [dict(x) for x in con.execute('SELECT * FROM strict_fills WHERE account_id LIKE ? ORDER BY created_at,fill_id', (pool['account_prefix'] + '%',))]
    buys = [x for x in fills if x['side'] == 'BUY']
    durations = []
    for pos in positions:
        if amount(pos['quantity']) != 0:
            continue
        own = [x for x in fills if (x['account_id'], x['condition_id'], x['token_id'], x['outcome']) == (pos['account_id'], pos['condition_id'], pos['token_id'], pos['outcome'])]
        entries = [x for x in own if x['side'] == 'BUY']
        if not entries:
            continue
        final = con.execute("SELECT observed_at FROM strict_settlements WHERE account_id=? AND condition_id=? AND token_id=? AND outcome=? AND payout_per_share IS NOT NULL AND CAST(quantity AS REAL)>0 AND status IN ('FORMALLY_RESOLVED','VOID') ORDER BY observed_at DESC LIMIT 1", (pos['account_id'], pos['condition_id'], pos['token_id'], pos['outcome'])).fetchone()
        end = final[0] if final else max(x['created_at'] for x in own)
        duration = (parse(end) - min(parse(x['created_at']) for x in entries)).total_seconds()
        if duration >= 0:
            durations.append(Decimal(str(duration)))
    curve = [{'event_key': x['event_key'], 'at': x['captured_at'], 'event_type': x['event_type'], 'realized_pnl': x['realized_pnl'], 'return': str(amount(x['realized_pnl']) / total)} for x in events if x['event_type'] in ('ACTIVATION', 'SETTLEMENT', 'SELL_FILL')]
    reconciliation = reconcile_pool(con, pool)
    return {'enabled': True, 'funding_version': pool['funding_version'], 'fixed_initial_cash': str(total),
        'activated_at': pool['activated_at'], 'available_cash': root['available_cash'], 'reserved_cash': root['reserved_cash'],
        'open_cost_basis': str(cost), 'current_utilization': str(used / total),
        'average_utilization': str(integral / seconds / total) if seconds > 0 else None,
        'average_utilization_since': pool['activated_at'],
        'buy_turnover': str(sum((amount(x['gross_amount']) for x in buys), Decimal(0)) / total),
        'average_holding_seconds': str(sum(durations, Decimal(0)) / len(durations)) if durations else None,
        'closed_position_samples': len(durations), 'realized_return': str(realized / total),
        'return_curve': curve, 'reconciliation': reconciliation,
        'cash_breakdown': reconciliation['cash_breakdown']}
