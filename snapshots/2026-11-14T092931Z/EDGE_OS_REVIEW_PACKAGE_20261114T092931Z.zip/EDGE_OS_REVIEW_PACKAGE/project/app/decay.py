from __future__ import annotations

import asyncio
import logging
import time

from .config import settings
from .db import db
from .paper import simulate_buy, top_of_book
from .polymarket import pm

log = logging.getLogger("edge.decay")
HORIZONS = (30, 60, 120, 300, 900)


class DecayTracker:
    def __init__(self):
        self.tasks: set[asyncio.Task] = set()
        self.signal_ids: set[int] = set()
        self._semaphore = asyncio.Semaphore(max(1, settings.decay_max_concurrency))
        self._last_warning_at = 0.0

    def start(self) -> None:
        """Recover still-actionable replay jobs after a backend restart."""
        for signal in db.signals_for_decay_recovery(max(HORIZONS) + 30):
            self.schedule(signal)

    def schedule(self, signal: dict):
        signal_id = int(signal.get("id") or 0)
        if (
            not signal_id
            or signal_id in self.signal_ids
            or not signal.get("token_id")
            or signal.get("leader_side") not in {"BUY", "SELL"}
            or not signal.get("leader_timestamp")
        ):
            return
        task = asyncio.create_task(self._track(dict(signal)))
        self.signal_ids.add(signal_id)
        self.tasks.add(task)
        task.add_done_callback(lambda finished, sid=signal_id: self._finished(finished, sid))

    def _finished(self, task: asyncio.Task, signal_id: int) -> None:
        self.tasks.discard(task)
        self.signal_ids.discard(signal_id)

    def _warn_rate_limited(self, signal: dict, error: Exception) -> None:
        now = time.monotonic()
        if now - self._last_warning_at >= 60:
            self._last_warning_at = now
            log.warning("decay snapshots temporarily unavailable; signal=%s: %s", signal.get("id"), error)
        else:
            log.debug("decay snapshot unavailable signal=%s: %s", signal.get("id"), error)

    async def _track(self, signal: dict):
        existing = {int(row["horizon_seconds"]) for row in db.signal_snapshots(int(signal["id"]))}
        leader_timestamp = float(signal["leader_timestamp"])
        for horizon in HORIZONS:
            if horizon in existing:
                continue
            due_at = leader_timestamp + horizon
            now = time.time()
            # A past horizon cannot be reconstructed from the live book. A
            # small grace window handles scheduler jitter without relabeling a
            # 130-second quote as a 120-second observation.
            if now > due_at + 15:
                continue
            try:
                await asyncio.sleep(max(0, due_at - now))
                async with self._semaphore:
                    book = await pm.orderbook(signal["token_id"])
                bid, ask, spread = top_of_book(book)
                actual_delay = max(0.0, time.time() - leader_timestamp)
                if signal["leader_side"] == "BUY":
                    budget = float(signal.get("paper_size_usd") or settings.paper_trade_usd)
                    fee_rate = float(signal.get("fee_rate") or 0)
                    sim = simulate_buy(book, budget, fee_rate)
                    price = float(sim["avg_price"] or ask) if (sim["avg_price"] is not None or ask is not None) else None
                    adverse = max(0.0, (price or signal["leader_price"]) - float(signal["leader_price"] or 0)) if price is not None else None
                    fee_edge = float(sim["fee"] or 0) / max(float(sim["cost"] or 0), 1e-9)
                    delayed_net_edge = (
                        float(signal.get("expected_alpha") or 0)
                        - float(adverse or 0)
                        - max(0.0, float(spread or 0) / 2)
                        - max(0.0, float(sim["slippage"] or 0))
                        - fee_edge
                        - float(signal.get("safety_margin") or settings.safety_margin)
                    )
                else:
                    price = bid
                    adverse = max(0.0, float(signal["leader_price"] or 0) - (price or signal["leader_price"])) if price is not None else None
                    sim = {"filled": bid is not None, "cost": None, "shares": None, "fee": 0, "slippage": 0}
                    delayed_net_edge = None
                db.insert_signal_snapshot(
                    int(signal["id"]), signal["wallet"], signal["token_id"], horizon, price, adverse,
                    actual_delay_seconds=actual_delay,
                    filled=bool(sim["filled"]),
                    cost_usd=sim.get("cost"),
                    shares=sim.get("shares"),
                    fees_usd=sim.get("fee"),
                    slippage=sim.get("slippage"),
                    spread=spread,
                    delayed_net_edge=delayed_net_edge,
                )
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self._warn_rate_limited(signal, e)

    async def stop(self):
        for task in list(self.tasks):
            task.cancel()
        if self.tasks:
            await asyncio.gather(*list(self.tasks), return_exceptions=True)
        self.tasks.clear()
        self.signal_ids.clear()


decay_tracker = DecayTracker()
