'use strict';
const $=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=x=>x===null||x===undefined?'—':Number(x).toLocaleString('en-US',{style:'currency',currency:'USD'});
const stamp=x=>!x?'—':new Date(typeof x==='number'?x*1000:x).toLocaleString();
const short=x=>x?x.slice(0,8)+'…'+x.slice(-5):'—';
const empty=t=>`<div class="empty">${esc(t)}</div>`;
const states={OPEN:'持有中',SETTLED:'已结算',SKIP:'仅归档',PENDING:'处理中',SHADOW:'影子试跑',VALIDATED:'前向验证通过',REJECTED:'条件失效',AI_PAUSED:'AI 暂停条件',RETIRED:'手动停用',REPLACED:'已替换',NEW:'待研究',EXCLUDED:'手动排除',FORWARD_TEST:'前向测试中',OBSERVE:'继续观察',KEEP:'建议保留',REFINE:'细化条件',PAUSE:'暂停条件策略',OK:'成功',ERROR:'失败',RUNNING:'调用中',DEFERRED:'等待次日'};
let active='overview',offset=0,total=0,loading=false,configLoaded=false,currentOverview,currentV2;
function notify(s){$('notice').textContent=s;clearTimeout(notify.timer);notify.timer=setTimeout(()=>$('notice').textContent='',12000)}
async function api(path,method='GET',data){const response=await fetch(path,{method,headers:{'Content-Type':'application/json','X-Edge-Client':'dashboard'},body:data===undefined?undefined:JSON.stringify(data),signal:AbortSignal.timeout(method==='GET'?20000:180000)});if(!response.ok){let e=await response.json().catch(()=>({}));throw Error(typeof e.detail==='string'?e.detail:JSON.stringify(e.detail)||`HTTP ${response.status}`)}return response.json()}
$('close-detail').onclick=()=>$('detail').close();
function table(headers,body){return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${body}</tbody></table></div>`}
function button(action,id,label,cls=''){return `<button class="${cls}" data-action="${action}" data-id="${esc(id)}">${esc(label)}</button>`}
function tag(s){return `<span class="tag">${esc(states[s]||s||'—')}</span>`}
const v2States={OBSERVED:'已观察',FILLED:'已模拟成交',PARTIAL:'部分模拟成交',REJECTED:'未模拟成交',FORMALLY_RESOLVED:'已正式判定',PENDING:'等待正式结果',VOID:'无效 / 作废'};
function v2Tag(s){return `<span class="tag">${esc(v2States[s]||s||'—')}</span>`}
function resolvedPaperOutcome(item) {
  if (item?.resolution_status !== 'FORMALLY_RESOLVED' || !['FILLED', 'PARTIAL'].includes(item?.paper_status)) return null;
  if (item.direction_correct === 1) return 'win';
  if (item.direction_correct === 0) return 'loss';
  return null;
}
function finiteNumericValue(value) {
  if (typeof value !== 'number' && typeof value !== 'string') return null;
  if (typeof value === 'string' && value.trim() === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}
function unitPrice(value) {
  const number = finiteNumericValue(value);
  return number !== null && number >= 0 && number <= 1 ? number : null;
}
function paperEntryPrice(item) {
  if (!['FILLED', 'PARTIAL'].includes(item?.paper_status)) return '—';
  const price = unitPrice(item.execution_price);
  return price === null ? '—' : price.toFixed(4);
}
function paperSettlementPrice(item) {
  if (item?.resolution_status !== 'FORMALLY_RESOLVED') return '—';
  const price = unitPrice(item.payout_per_share);
  return price === null ? '—' : price.toFixed(4);
}
function paperRealizedPnl(item) {
  if (item?.resolution_status !== 'FORMALLY_RESOLVED' || !['FILLED', 'PARTIAL'].includes(item?.paper_status)) return null;
  const quantity = finiteNumericValue(item.filled_quantity);
  const notional = finiteNumericValue(item.filled_notional);
  const fee = finiteNumericValue(item.entry_fee);
  const payout = unitPrice(item.payout_per_share);
  if (quantity === null || quantity <= 0 || notional === null || notional < 0 || fee === null || fee < 0 || payout === null) return null;
  const netPnl = quantity * payout - notional - fee;
  return Math.round(netPnl * 100) / 100;
}
function signedMoney(value) {
  const number = finiteNumericValue(value);
  if (number === null) return '—';
  if (number > 0) return `+${money(number)}`;
  if (number < 0) return `-${money(Math.abs(number))}`;
  return money(0);
}
function summarizeResolvedPaperOutcomes(entries) {
  const result = {wins: 0, losses: 0};
  for (const item of entries || []) {
    const outcome = resolvedPaperOutcome(item);
    if (outcome === 'win') result.wins += 1;
    else if (outcome === 'loss') result.losses += 1;
  }
  result.total = result.wins + result.losses;
  result.rate = result.total ? result.wins / result.total : null;
  return result;
}
function outcomeChartHtml(summary, state = 'ready') {
  if (state === 'loading') return '<section class="outcome-visualization" id="v2-outcome-chart" aria-live="polite"><h3>已正式判定的模拟成交</h3><p class="muted">正在读取已正式判定的模拟成交…</p></section>';
  if (state === 'error') return '<section class="outcome-visualization" id="v2-outcome-chart" aria-live="polite"><h3>已正式判定的模拟成交</h3><p class="muted">结果暂时无法读取；其他 实验总览数据仍可使用。</p></section>';
  if (!summary.total) return '<section class="outcome-visualization" id="v2-outcome-chart"><h3>已正式判定的模拟成交</h3><p class="muted">暂无已正式判定且完成模拟成交的样本。</p></section>';
  const lossPercent = summary.losses / summary.total * 100;
  return `<section class="outcome-visualization" id="v2-outcome-chart"><h3>已正式判定的模拟成交</h3><div class="outcome-metrics"><span>总计 <strong>${summary.total}</strong></span><span class="outcome-win-text">预测成功 <strong>${summary.wins}</strong></span><span class="outcome-loss-text">预测失败 <strong>${summary.losses}</strong></span><span>成功率 <strong>${(summary.rate * 100).toFixed(1)}%</strong></span></div><div class="outcome-bar" role="img" aria-label="${summary.wins} 个预测成功，${summary.losses} 个预测失败"><span class="outcome-bar-win" style="width:${100 - lossPercent}%"></span><span class="outcome-bar-loss" style="width:${lossPercent}%"></span></div></section>`;
}
function resolvedPaperSummary(v2) {
  const summary = v2?.resolved_paper_outcomes;
  if (!summary || ![summary.wins, summary.losses, summary.total].every(value => Number.isSafeInteger(value) && value >= 0)) return null;
  if (summary.total !== summary.wins + summary.losses) return null;
  return {wins: summary.wins, losses: summary.losses, total: summary.total, rate: summary.total ? summary.wins / summary.total : null};
}
async function fetchAllFormallyResolvedEpisodes() {
  const entries = [];
  let offset = 0;
  let expectedTotal = 0;
  do {
    const response = await api(`/api/wallet-follow-v2/episodes?status=FORMALLY_RESOLVED&offset=${offset}&limit=200`);
    if (!Array.isArray(response?.entries) || !Number.isFinite(Number(response.total)) || Number(response.total) < 0) throw new Error('Invalid resolved-episodes response');
    entries.push(...response.entries);
    expectedTotal = Number(response.total);
    if (response.entries.length === 0 && offset < expectedTotal) throw new Error('Incomplete resolved-episodes pagination');
    offset += response.entries.length;
  } while (offset < expectedTotal);
  return entries;
}
async function loadV2OutcomeChart() {
  const root = $('v2-outcome-chart');
  if (!root) return;
  const summary = resolvedPaperSummary(currentV2);
  root.outerHTML = outcomeChartHtml(summary, summary ? 'ready' : 'error');
}
function noFillReasonLabel(reason) {
  return ({STALE_MARKET_STATE:'市场状态资料已超过允许时效，未入场',
    MARKET_DATA_UNAVAILABLE:'市场资料暂不可用，未入场',
    BELOW_MINIMUM_ORDER:'可成交数量低于市场最低要求，未入场',
    INSUFFICIENT_CASH:'模拟账户余额不足，未入场',
    CRASH_RECOVERY_NO_FILL:'中断恢复已完成，未补造成交'})[reason] || reason;
}
function drawV2(v2) {
  currentV2 = v2;
  const root = $('v2-state');
  if (!v2?.configured) { root.innerHTML = empty('Wallet Follow V2 尚未配置。'); return; }
  const c = v2.counts || {}, cfg = v2.frozen_config || {}, obs = v2.observation || {};
  const reasons = v2.performance?.no_fill_reason_distribution || {};
  const reasonRows = Object.entries(reasons).map(([reason, count]) => `<tr><td>${esc(noFillReasonLabel(reason))}</td><td>${esc(count)}</td></tr>`).join('');
  root.innerHTML = `<div class="metrics">
    <div class="metric"><span class="muted">版本 / 状态</span><strong>${esc(v2.strategy_version)}</strong><small>${tag(v2.state)}</small></div>
    <div class="metric"><span class="muted">本次实验开始</span><strong>${esc(stamp(obs.forward_started_at))}</strong><small>仅纳入此后发生并新观察到的交易</small></div>
    <div class="metric"><span class="muted">跟踪钱包 / 已参与</span><strong>${esc(obs.tracked_wallets || 0)} / ${esc(obs.participating_wallets || 0)}</strong><small>按当前跟踪状态与本轮 episode 计数</small></div>
    <div class="metric"><span class="muted">观察交易 / 买入</span><strong>${esc(obs.observed_trades || 0)} / ${esc(obs.observed_buy_trades || 0)}</strong><small>公开钱包的新交易，不等于模拟成交</small></div>
    <div class="metric"><span class="muted">方向 Episode / 模拟成交</span><strong>${esc(c.observed_episodes || 0)} / ${esc((c.filled || 0) + (c.partial || 0))}</strong><small>完整成交 ${esc(c.filled || 0)} · 部分成交 ${esc(c.partial || 0)}</small></div>
    <div class="metric"><span class="muted">未成交 / 待正式结算持仓</span><strong>${esc(c.rejected_no_fill || 0)} / ${esc(v2.settlement?.pending_paper_positions || 0)}</strong><small>方向判断待结果 ${esc(c.pending_resolution || 0)}</small></div>
  </div><p class="muted">冻结配置：每次 ${money(cfg.fixed_notional)} 模拟本金（手续费另计）；胜出净 ROI 至少 ${esc(Number(cfg.min_net_roi_if_win || 0) * 100)}%；最多使用可见深度 ${esc(Number(cfg.max_visible_depth_fraction || 0) * 100)}%；执行延迟 ${esc(cfg.execution_latency_ms)} 毫秒；盘口最长 ${esc(cfg.max_book_age_ms)} 毫秒；方向只在正式结果后统计，收益计已实现退出与结算；真钱订单 ${cfg.live_orders === false ? '关闭' : '状态异常'}。至少 ${esc(cfg.min_resolved_for_review)} 个已判定方向 episode 后才评价钱包。</p>
  <h3>当前实验未成交原因</h3>${reasonRows ? table(['原因','次数'], reasonRows) : empty('目前没有未成交记录。')}`;
}
function capitalNumber(value) {
  if (!['number','string'].includes(typeof value) || (typeof value === 'string' && !value.trim())) return null;
  const result = Number(value);
  return Number.isFinite(result) ? result : null;
}
function capitalPercent(value) {
  const number = capitalNumber(value);
  return number === null ? '—' : `${(number * 100).toFixed(2)}%`;
}
function cumulativeInvestedPrincipal(pool) {
  if (!pool?.enabled) return null;
  const notional = capitalNumber(pool.cash_breakdown?.buy_notional);
  if (notional !== null && notional >= 0) return notional;
  const initial = capitalNumber(pool.fixed_initial_cash);
  const turnover = capitalNumber(pool.buy_turnover);
  if (initial === null || initial <= 0 || turnover === null || turnover < 0) return null;
  const principal = initial * turnover;
  return Number.isFinite(principal) ? principal : null;
}
function cashBreakdownHtml(pool) {
  const cash = pool?.enabled ? pool.cash_breakdown : null;
  if (!cash) return '<div class="metric cash-summary"><span class="muted">模拟资金收支</span><p class="muted">收支明细暂未返回，不能确认完整资金构成。</p></div>';
  const rows = [['初始本金', cash.initial_cash], ['＋累计结算回款', cash.settlement_returns]];
  if (capitalNumber(cash.sell_proceeds) !== 0) rows.push(['＋模拟卖出回款', cash.sell_proceeds]);
  rows.push(['－累计买入金额', cash.buy_notional], ['－手续费', cash.fees], ['－订单预留', cash.reserved_cash]);
  return `<div class="metric cash-summary"><span class="muted">模拟资金收支</span><dl class="cash-breakdown">${rows.map(([label, value]) => `<dt>${esc(label)}</dt><dd>${esc(money(capitalNumber(value)))}</dd>`).join('')}<dt class="cash-total-label">＝可用现金</dt><dd class="cash-total-value">${esc(money(capitalNumber(cash.available_cash)))}</dd></dl><small>本实验账本 · 每 10 秒刷新<br>回款含收回本金，不等于净收益</small></div>`;
}
function holdingTime(value) {
  const seconds = capitalNumber(value);
  if (seconds === null || seconds < 0) return '—';
  if (seconds < 3600) return `${(seconds / 60).toFixed(1)} 分钟`;
  if (seconds < 86400) return `${(seconds / 3600).toFixed(1)} 小时`;
  return `${(seconds / 86400).toFixed(1)} 天`;
}
function realizedReturnChart(pool) {
  const points = (pool.return_curve || []).map(item => ({at: Date.parse(item.at), value: capitalNumber(item.return)}))
    .filter(item => Number.isFinite(item.at) && item.value !== null);
  if (!points.length) return empty('暂无已提交的收益率记录。');
  const width = 820, height = 240, left = 72, right = 24, top = 20, bottom = 48;
  const first = Math.min(...points.map(p => p.at)), last = Math.max(...points.map(p => p.at));
  const low = Math.min(0, ...points.map(p => p.value)), high = Math.max(0, ...points.map(p => p.value));
  const pad = Math.max((high - low) * 0.15, 0.001), minY = low - pad, maxY = high + pad;
  const x = time => left + (last === first ? 0.5 : (time - first) / (last - first)) * (width - left - right);
  const y = value => top + (maxY - value) / (maxY - minY) * (height - top - bottom);
  const timeLabel = time => new Date(time).toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai', month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});
  const ticks = [minY, (minY + maxY) / 2, maxY].map(value => `<line x1="${left}" x2="${width-right}" y1="${y(value)}" y2="${y(value)}" class="capital-grid-line"/><text x="${left-8}" y="${y(value)+4}" text-anchor="end">${esc(capitalPercent(value))}</text>`).join('');
  const labels = first === last ? [first] : [first, (first + last) / 2, last];
  const coordinates = points.map(p => `${x(p.at).toFixed(2)},${y(p.value).toFixed(2)}`).join(' ');
  const end = points[points.length-1];
  return `<div class="capital-chart"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="已实现净盈亏除以固定初始本金，横轴时间，纵轴收益率">${ticks}<line x1="${left}" x2="${width-right}" y1="${y(0)}" y2="${y(0)}" class="capital-zero-line"/><polyline points="${coordinates}" class="capital-return-line"/>${points.map(p => `<circle cx="${x(p.at)}" cy="${y(p.value)}" r="3" class="capital-return-dot"><title>${esc(timeLabel(p.at))} · ${esc(capitalPercent(p.value))}</title></circle>`).join('')}${labels.map(time => `<text x="${x(time)}" y="${height-19}" text-anchor="middle">${esc(timeLabel(time))}</text>`).join('')}<text x="18" y="14">收益率</text><text x="${width-right}" y="${height-2}" text-anchor="end">时间（上海）</text></svg><p class="muted">最近已实现收益率：<strong>${esc(capitalPercent(end.value))}</strong> · ${esc(timeLabel(end.at))}${points.length === 1 ? ' · 尚无新增结算，当前显示承接损益起点。' : ''}</p></div>`;
}
function capitalDashboardHtml(pool) {
  if (!pool?.enabled) return '<article><h3>共享资金池</h3><p class="muted">共享资金池尚未启用，暂不展示固定本金指标。</p></article>';
  const turnover = capitalNumber(pool.buy_turnover);
  const cards = [
    ['当前资金占用率', capitalPercent(pool.current_utilization), `持仓实际成本 ${money(pool.open_cost_basis)} ＋预留现金 ${money(pool.reserved_cash)}`],
    ['平均资金占用率', capitalPercent(pool.average_utilization), `按时间加权，从共享池启用 ${stamp(pool.average_utilization_since)} 起统计`],
    ['本金周转次数', turnover === null ? '—' : `${turnover.toFixed(2)} 次`, '本轮累计实际买入本金 ÷ 固定本金，含切换前承接交易'],
    ['平均持仓时长', holdingTime(pool.average_holding_seconds), `${pool.closed_position_samples || 0} 个已关闭模拟仓位；从实际成交到退出或结算`]
  ];
  return `<article class="capital-panel"><div class="toolbar"><div><h2>固定共享资金池</h2><p>初始本金 <strong>${money(pool.fixed_initial_cash)}</strong> · 剩余现金 <strong>${money(pool.available_cash)}</strong> · 新钱包不增资</p></div><span class="${pool.reconciliation?.ok ? 'outcome-win-text' : 'outcome-loss-text'}">${pool.reconciliation?.ok ? '资金核对通过' : '资金核对异常'}</span></div><div class="capital-metrics">${cards.map(([label,value,note]) => `<div class="metric"><span class="muted">${esc(label)}</span><strong>${esc(value)}</strong><small>${esc(note)}</small></div>`).join('')}</div><h3>已实现收益 / 初始本金</h3>${realizedReturnChart(pool)}<p class="muted">固定本金口径；每次正式结算或模拟退出形成已实现损益后更新。起点承接原有盈亏，未实现浮盈亏不计入。资金占用按持仓成本计算，不代表当前市值。</p></article>`;
}
function drawCandidates(cs,o){const excluded=new Set(o.exclusions.map(x=>x.wallet));cs=cs.filter(c=>!excluded.has(c.address));$('candidate-list').innerHTML=cs.length?table(['钱包','榜单收益','状态 / 原因','操作'],cs.map(c=>`<tr><td class="address">${esc(short(c.address))}</td><td>${money(c.leaderboard_pnl)}</td><td class="market">${tag(c.status)}<br>${esc(c.reject_reason||'')}</td><td>${button('analyze',c.address,'分析')}${button('delete',c.address,'删除','danger')}</td></tr>`).join('')):empty('暂无候选。可以点击“立即发现”，进度将在后台更新。')}
async function aiPage(){if(!configLoaded){const c=await api('/api/research/ai/config');$('provider').value=c.provider;$('model').value=c.model;$('daily-limit').value=c.daily_call_limit;$('max-tokens').value=c.max_tokens;$('ai-enabled').checked=c.enabled;$('key-status').textContent=c.has_key?'已配置 Key（不在页面返回密钥）':'尚未配置 API Key';configLoaded=true}const logs=await api('/api/research/ai/logs');$('ai-logs').innerHTML=logs.length?logs.map(l=>{let response;try{response=JSON.parse(l.response_json||'{}')}catch{response={}}return `<article><div class="wallet-head"><strong>${esc(l.kind)} · ${esc(l.model)}</strong>${tag(l.status)}</div><small>${esc(stamp(l.created_ts))} · ${esc(l.subject)}</small><p>${esc(response.summary||l.error||'正在等待模型返回')}</p>${response.recommendation?tag(response.recommendation):''}<div>${button('ai-log',l.id,'完整依据与结论')}</div></article>`}).join(''):empty('启用 AI 后，研究过程和失败原因都会记录在这里。');aiPage.logs=logs}
async function refresh(){if(loading)return;loading=true;try{const [o,h,ws,cs,v2]=await Promise.all([api('/api/research/overview'),api('/api/health'),api('/api/wallets'),api('/api/discovery/candidates'),api('/api/wallet-follow-v2')]);drawOverview(o,h,v2);drawV2(v2);drawWallets(ws,o,v2);drawCandidates(cs,o);loadV2OutcomeChart();if(active==='journal')await journal();if(active==='ai')await aiPage();$('connection').textContent='● 本机已连接 · '+new Date().toLocaleTimeString()}catch(e){$('connection').textContent='服务未连接或请求失败';notify(e.message)}finally{loading=false}}
for(const b of document.querySelectorAll('nav button'))b.onclick=()=>{active=b.dataset.page;document.querySelectorAll('.page,nav button').forEach(e=>e.classList.remove('active'));$(active).classList.add('active');b.classList.add('active');$('page-title').textContent=b.textContent;refresh()};
$('scan').onclick=()=>run(async()=>{notify('正在扫描 V2 跟踪钱包…');const result=await api('/api/wallet-follow-v2/scan','POST');notify(result.ok?'V2 钱包扫描完成，档案已刷新。':`扫描已完成，部分钱包读取失败：${result.errors?.[0] || '请查看运行状态'}`)});$('refresh').onclick=refresh;$('entry-status').onchange=()=>{offset=0;journal().catch(e=>notify(e.message))};$('previous').onclick=()=>{offset=Math.max(0,offset-50);journal().catch(e=>notify(e.message))};$('next').onclick=()=>{offset+=50;journal().catch(e=>notify(e.message))};
async function run(fn){try{await fn();await refresh()}catch(e){notify(e.message)}}
$('add-wallet').onsubmit=e=>{e.preventDefault();const address=$('wallet-address').value.trim();notify('正在读取历史资料，可能需要一两分钟…');run(async()=>{await api('/api/wallets/analyze','POST',{address});$('wallet-address').value='';notify('分析完成，开始观察未来成交。')})};
$('discover').onclick=()=>run(async()=>{const x=await api('/api/discovery/run','POST');notify(x.started?'发现任务已启动，结果会自动更新。':'发现任务正在运行。')});
$('provider').onchange=()=>$('model').value=$('provider').value==='deepseek'?'deepseek-chat':'qwen-plus';
$('ai-form').onsubmit=e=>{e.preventDefault();run(async()=>{await api('/api/research/ai/config','POST',{provider:$('provider').value,model:$('model').value,api_key:$('api-key').value,enabled:$('ai-enabled').checked,daily_call_limit:Number($('daily-limit').value),max_tokens:Number($('max-tokens').value)});$('api-key').value='';configLoaded=false;notify('AI 设置已保存。')})};
$('test-ai').onclick=()=>run(async()=>{notify('正在测试已保存的 AI 设置…');show('连接测试',await api('/api/research/ai/test','POST'))});$('report').onclick=()=>run(async()=>{await api('/api/research/ai/report','POST');notify('报告已排入研究队列；请保持服务运行并启用 AI。')});
document.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;const a=b.dataset.action,id=b.dataset.id;run(async()=>{if(a==='entry')show('完整交易档案',await api('/api/research/entries/'+id));else if(a==='evidence')show('钱包策略、证据与 AI 复盘',await api('/api/research/wallets/'+id));else if(a==='version')show('条件策略版本',currentOverview.versions.find(v=>String(v.id)===id));else if(a==='ai-log')show('AI 输入证据与输出',aiPage.logs.find(v=>String(v.id)===id));else if(a==='delete'){if(!confirm('删除该候选并停止跟踪？会阻止自动重新加入；历史档案保留。'))return;await api('/api/research/wallets/'+id,'DELETE');notify('已排除，可在自动发现页面恢复。')}else if(a==='restore'){await api('/api/research/wallets/'+id+'/restore','POST');notify('已恢复为候选；可以再次分析并跟踪。')}else if(a==='review'){const v=await api('/api/research/wallets/'+id+'/review','POST');notify(v.message)}else if(a==='track'||a==='pause')await api('/api/wallets/'+id+'/track','POST',{tracked:a==='track'});else if(a==='analyze'){notify('正在分析钱包…');await api('/api/wallets/analyze','POST',{address:id});notify('已开始观察。')}else if(a==='group'){const old=currentOverview.identities.find(x=>x.wallet===id)?.group_id||'';const group_id=prompt('已知关联钱包请填写相同分组名；留空解除分组。未知关联不会被自动识别。',old);if(group_id!==null)await api('/api/research/wallets/'+id+'/identity','POST',{group_id})}else if(a==='retire')await api('/api/research/versions/'+id+'/retire','POST')})});
const percent = value => value === null || value === undefined ? '—' : `${(Number(value) * 100).toFixed(1)}%`;
const numeric = value => value === null || value === undefined ? '—' : Number(value).toLocaleString();
const pnlSourceLabel = value => ({DATA_API_USER_STATS: '公开账户统计', DATA_API_USER_PNL: '公开账户收益', CLOSED_POSITION_SAMPLE: '已读取结算持仓样本', LEGACY_WALLET_ANALYSIS: '旧版分析快照'})[value] || '来源未标明';
const pnlWindowLabel = value => ({all_time_reported: '上游公布的历史累计', fetched_closed_positions: '本次已读取持仓', analysis_snapshot_unknown_coverage: '旧快照，范围未记录'})[value] || '范围未记录';
const trustedProfile = url => typeof url === 'string' && /^https:\/\/polymarket\.com\/profile\/0x[a-fA-F0-9]{40}$/.test(url) ? url : null;
const trustedEvent = url => typeof url === 'string' && /^https:\/\/polymarket\.com\/event\/[a-z0-9]+(?:-[a-z0-9]+)*$/.test(url) ? url : null;
const trustedAvatar = url => {
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' && !parsed.port &&
      ['polymarket.com', 'images.polymarket.com', 'imagedelivery.net'].includes(parsed.hostname) ? parsed.href : null;
  } catch { return null; }
};
const verifiedIdentity = (identity, address) => identity &&
  ['GAMMA_PUBLIC_PROFILE', 'STALE_GAMMA_PUBLIC_PROFILE'].includes(identity.source) &&
  typeof identity.proxy_wallet === 'string' && identity.proxy_wallet.toLowerCase() === address.toLowerCase();
const identityName = (identity, address) => verifiedIdentity(identity, address) && identity.username ? identity.username : short(address);
const avatar = (identity, address, size = '') => {
  const url = verifiedIdentity(identity, address) ? trustedAvatar(identity.avatar_url) : null;
  return url ? `<span class="avatar ${size}"><img src="${esc(url)}" alt="${esc(identityName(identity, address))} 的公开头像" loading="lazy" referrerpolicy="no-referrer"><span class="avatar-fallback" hidden>地址</span></span>`
    : `<span class="avatar ${size} avatar-empty" aria-hidden="true">地址</span>`;
};

function show(title, obj) {
  $('detail-title').textContent = title;
  $('detail-structured').hidden = true;
  $('detail-body').hidden = false;
  $('detail-body').textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2);
  $('detail').showModal();
}

function fastPathStatusHtml(fast) {
  if (!fast || typeof fast !== 'object') return '<p class="muted">实时链路状态未返回，无法确认是否已启用。</p>';
  const recent = value => { const age = Date.now() - Date.parse(value); return Number.isFinite(age) && age >= 0 && age < 45000; };
  const recentRead = recent(fast.last_data_success_at);
  const recentHead = recent(fast.last_head_success_at);
  const liveLatency = fast.latency?.total;
  const gapRate = fast.catchup_net_blocks_per_minute;
  const gapText = gapRate == null || !Number.isFinite(Number(gapRate)) ? '尚无趋势样本' : Number(gapRate) >= 0 ? `每分钟净减少 ${Number(gapRate).toFixed(1)} 区块` : `每分钟净增加 ${Math.abs(Number(gapRate)).toFixed(1)} 区块`;
  const laneErrors = [fast.staging_error, fast.backfill_error, fast.processing_error].filter(Boolean);
  const state = !fast.enabled ? '实时链路未启用' : !fast.configured ? '实时数据源未配置' : fast.connected ? fast.independent_lanes ? recentHead ? '实时流已连接 · 补漏独立运行' : '实时流已连接 · 链头读取待恢复' : '实时流已连接 · 处理健康待确认' : recentRead ? '实时流重连中 · HTTP 补漏正在运行' : '实时通路未恢复';
  const gapBlocked = fast.error_category === 'BACKFILL_GAP_EXCEEDS_BOUND';
  return `<h3>Polygon 实时接收与补漏</h3><div class="status-strip"><span>${esc(state)}</span><span>本进程重连 ${esc(fast.reconnect_count ?? '—')} 次</span></div>
    <p>最近收到事件：${esc(stamp(fast.last_event_at))} · 已补漏确认区块：${esc(fast.last_block ?? '—')}</p>
    <p>最近补漏成功：${esc(stamp(fast.last_data_success_at))} · 尚待补漏 ${esc(fast.catchup_remaining_blocks ?? '—')} 个区块 · 数据读取 ${esc(fast.read_transport || '未返回')}</p>
    <p>补漏趋势：${esc(gapText)} · 最近链头确认：${esc(stamp(fast.last_head_success_at))}</p>
    <p>最近事件处理完成：${esc(stamp(fast.last_processing_success_at))} · 正在处理 ${esc(fast.processing_inflight ?? '—')} 个事件</p>
    <p>实时事件总延迟：P50 ${esc(liveLatency?.p50 == null ? '—' : Number(liveLatency.p50).toFixed(1) + ' 秒')} / P95 ${esc(liveLatency?.p95 == null ? '—' : Number(liveLatency.p95).toFixed(1) + ' 秒')} · 样本 ${esc(liveLatency?.sample_count ?? 0)}（与补漏样本分开）</p>
    ${laneErrors.length ? `<p style="color:var(--red, #ff6b70)">后台处理错误：${esc(laneErrors.join(' / '))}</p>` : ''}
    <p>跟踪事件观察 ${esc(fast.tracked_events_seen ?? '—')} · 完成身份解析 ${esc(fast.normalized_events ?? '—')} · 待身份资料 ${esc(fast.pending_metadata ?? '—')}</p>
    ${fast.error_category ? `<p style="color:var(--red, #ff6b70)">实时链路错误：${esc(fast.error_category)}</p>` : ''}
    ${gapBlocked ? '<p style="color:var(--red, #ff6b70)">补漏缺口已超过安全上限，实时通路当前受阻；系统不会跳过缺口或补造历史成交。</p>' : ''}
    <p class="muted">轮询监控与实时通路分别运行。已连接不代表每笔交易均成功跟上；以上事件计数属于当前进程，不是成交数量。</p>`;
}

function exitPolicyStatusHtml(exit) {
  if (!exit || exit.state !== 'ACTIVE') return '<h3>退出规则</h3><p>未确认启用提前退出规则；基础策略持有到正式结果。</p>';
  const cfg = exit.frozen_config || {};
  return `<h3>已启用的退出规则</h3><p>${esc(exit.rule_version)} · 执行引擎 ${esc(cfg.execution_engine || '未返回')}</p>
    <p>适用入场价 ${esc(cfg.entry_price_min ?? '—')}–${esc(cfg.entry_price_max ?? '—')}。动态止损：入场价减去剩余上涨空间的 ${esc(Number(cfg.hard_stop_risk_fraction_of_remaining_upside) * 100)}%；上涨达到剩余空间的 ${esc(Number(cfg.profit_protection_fraction_of_max_upside) * 100)}% 后激活入场价保护。</p>
    <p>纳入退出跟踪 ${esc(exit.eligible_positions ?? '—')} · 已激活保护 ${esc(exit.protected_positions ?? '—')} · 已退出 ${esc(exit.exited_positions ?? '—')}</p>
    <p class="muted">没有触发退出时继续等待正式结果。卖出仍按真实买盘、深度、延迟和手续费模拟；保护不保证净收益为正。</p>`;
}

function drawOverview(o, h, v2) {
  const c = v2?.counts || {}, p = v2?.performance || {};
  const outcomeSummary = resolvedPaperSummary(v2);
  const pool = v2?.capital_pool;
  const realizedReturn = pool?.enabled ? capitalNumber(pool.realized_return) : null;
  currentOverview = o;
  const experiment = h.experiment;
  const banner = $('experiment-banner');
  const capital = $('capital-dashboard');
  if (capital) capital.innerHTML = capitalDashboardHtml(v2?.capital_pool);
  if (banner) banner.innerHTML = experiment?.run_id ? `<h2>${esc(experiment.label || '当前实验')}</h2><p>实验 ID：<strong>${esc(experiment.run_id)}</strong> · 开始时间：${esc(stamp(experiment.started_at))}</p><p class="muted">以下交易、盈亏和账户只属于当前独立实验。旧实验完整保留在历史归档，未混入本次成绩。</p>${(experiment.archives || []).length ? `<details><summary>历史实验归档（只读概览）</summary>${table(['归档','旧交易样本','旧成交','旧已实现净收益'], experiment.archives.map(x => `<tr><td>${esc(x.label || x.run_id)}</td><td>${esc(x.episodes)}</td><td>${esc(x.fills)}</td><td>${money(x.realized_pnl)}</td></tr>`).join(''))}<p class="muted">旧库及备份保留；旧仓位在归档中，不继续混入当前新实验结算。</p></details>` : ''}` : '<p class="muted">未返回独立实验标识，不能确认新实验状态。</p>';
  $('metrics').innerHTML = [
    ['已正式判定方向', c.resolved_episodes || 0, '当前独立实验，旧样本不计入'],
    ['累计模拟买入金额', money(cumulativeInvestedPrincipal(pool)), '本轮实际模拟买入本金，手续费另计；含回款后再次投入'],
    ['本实验已实现模拟净收益 / 净收益率', money(p.realized_paper_pnl), '已扣手续费；净收益率＝已实现净收益 ÷ 固定初始本金', capitalPercent(realizedReturn)]
  ].map(([label, value, note, rate]) => `<div class="metric"><span class="muted">${esc(label)}</span><div class="overview-metric-value"><strong>${esc(value)}</strong>${rate === undefined ? '' : `<span class="overview-metric-return ${realizedReturn > 0 ? 'outcome-win-text' : realizedReturn < 0 ? 'outcome-loss-text' : 'muted'}" aria-label="已实现模拟净收益率">${esc(rate)}</span>`}</div><small>${esc(note)}</small></div>`).join('') + cashBreakdownHtml(pool) + outcomeChartHtml(outcomeSummary, outcomeSummary ? 'ready' : 'error');
  const monitor = h.monitor_running ? '监控服务运行中' : '监控服务未运行';
  const discovery = h.discovery_enabled ? '自动发现已启用' : '自动发现已停用';
  $('health').innerHTML = `<div class="status-strip"><span>${esc(monitor)}</span><span>${esc(discovery)}</span><span>仅模拟</span></div>
    <p>本机最近完成扫描：${esc(stamp(h.monitor_last_success_at))} · 最近成功发现：${esc(stamp(h.discovery_last_success_at))}</p>
    <p class="muted">${esc(h.monitor_last_error || h.discovery_last_error || '本次采集暂无错误记录；接口是否正常仍以成功请求和新事件为准。')}</p>
    ${fastPathStatusHtml(h.polygon_fast_path)}${exitPolicyStatusHtml(v2?.exit_v1)}`;
  $('discovery-status').innerHTML = `<span>${esc(discovery)}</span><span>最近成功：${esc(stamp(h.discovery_last_success_at))}</span><span>${esc(h.discovery_last_error || '暂无错误记录')}</span>`;
  const ai = h.ai || o.ai;
  $('ai-status').innerHTML = `<span>服务商：${esc(ai.provider || '未选择')}</span><span>${ai.enabled ? '已启用' : '未启用'}</span><span>${ai.has_key ? '已保存 Key' : '未保存 Key'}</span><span>今日 ${esc(ai.calls_today)} / ${esc(ai.daily_call_limit)} 次</span><small>连接是否可用，请查看测试结果和最近调用记录。</small>`;
  $('versions').innerHTML = o.versions.length ? table(['钱包', '版本', '状态', '操作'], o.versions.map(v => `<tr><td>${esc(short(v.wallet))}</td><td>#${esc(v.id)}</td><td>${tag(v.state)}</td><td>${button('version', v.id, '详情')}${['SHADOW', 'VALIDATED'].includes(v.state) ? button('retire', v.id, '停用') : ''}</td></tr>`).join('')) : empty('还没有条件策略。');
  $('excluded-list').innerHTML = o.exclusions.length ? o.exclusions.map(x => `<p class="address">${esc(x.wallet)} ${button('restore', x.wallet, '恢复候选')}</p>`).join('') : empty('暂无手动排除的钱包');
  $('ai-budget').textContent = `今日已调用 ${o.ai.calls_today} 次，上限 ${o.ai.daily_call_limit} 次。`;
}

function drawWallets(wallets, overview, v2) {
  const excluded = new Set(overview.exclusions.map(x => x.wallet));
  const visible = wallets.filter(wallet => !excluded.has(wallet.address));
  $('wallet-list').innerHTML = visible.length ? visible.map(wallet => {
    const card = wallet.card || {};
    const identity = card.identity;
    const frequent = (card.frequent_categories || []).slice(0, 3);
    const categories = (card.categories || []).slice().sort((a, b) => b.settled_positions - a.settled_positions).slice(0, 3);
    const paper = v2?.wallet_results?.[wallet.address.toLowerCase()] || {};
    return `<article class="wallet-card" data-action="wallet-detail" data-id="${esc(wallet.address)}" role="button" tabindex="0" aria-label="查看 ${esc(identityName(identity, wallet.address))} 的钱包详情">
      <div class="wallet-head"><div class="identity">${avatar(identity, wallet.address)}<div><strong>${esc(identityName(identity, wallet.address))}</strong><small class="address">${esc(short(wallet.address))}</small></div></div>${tag(wallet.tracked ? 'V2 前向观察' : '已暂停跟踪')}</div>
      <div class="card-section"><small>常交易分类 · 观察到的持仓数</small><p>${frequent.length ? frequent.map(row => `<span class="category-chip">${esc(row.category)} · ${esc(numeric(row.observed_positions))}</span>`).join('') : '暂无足够样本'}</p></div>
      <div class="card-metrics"><div><small>已结算持仓盈利占比</small><strong>${percent(card.profitable_position_rate)}</strong><small>${esc(numeric(card.profitable_settled_positions))} / ${esc(numeric(card.settled_position_sample))} 个</small></div><div><small>Leader 历史已实现收益</small><strong>${money(card.leader_historical_realized_pnl)}</strong><small>${esc(pnlSourceLabel(card.leader_pnl_source))} · ${esc(pnlWindowLabel(card.leader_pnl_window))}</small></div></div>
      <div class="card-section"><small>分类盈利占比 · 已结算持仓</small><p>${categories.length ? categories.map(row => `<span class="category-rate">${esc(row.category)} ${percent(row.profitable_rate)} <small>(${esc(row.profitable_positions)}/${esc(row.settled_positions)})</small></span>`).join('') : '暂无已结算分类样本'}</p></div>
      <p class="muted">本轮 V2：方向 episode ${esc(paper.episodes || 0)} · 模拟成交 ${esc(paper.fills || 0)} · 未成交 ${esc(paper.rejected || 0)}<br>Leader 历史样本更新：${esc(stamp(card.analyzed_at_utc))}</p>
      ${wallet.last_error ? `<p class="negative">最近资料错误：${esc(wallet.last_error)}</p>` : ''}
      <div class="actions">${button('wallet-detail', wallet.address, '查看详情')}${button('review', wallet.address, '请求 AI 复盘')}${button(wallet.tracked ? 'pause' : 'track', wallet.address, wallet.tracked ? '暂停跟踪' : '恢复跟踪')}${button('group', wallet.address, '关联钱包分组')}${button('delete', wallet.address, '删除并排除', 'danger')}</div>
    </article>`;
  }).join('') : empty('自动发现会陆续加入候选；也可以输入钱包地址。');
}

async function showWalletDetail(address) {
  const [wallet, evidence] = await Promise.all([
    api(`/api/wallets/${encodeURIComponent(address)}`),
    api(`/api/research/wallets/${encodeURIComponent(address)}`).catch(error => ({error: error.message}))
  ]);
  const card = wallet.card || {};
  const identity = card.identity;
  const profile = verifiedIdentity(identity, address) ? trustedProfile(identity.profile_url) : null;
  const rows = (card.categories || []).slice().sort((a, b) => b.settled_positions - a.settled_positions);
  const v2Wallet = currentV2?.wallet_results?.[address.toLowerCase()] || {};
  $('detail-title').textContent = identityName(identity, address);
  $('detail-body').hidden = true;
  $('detail-structured').hidden = false;
  $('detail-structured').innerHTML = `<div class="wallet-detail-head">${avatar(identity, address, 'large')}<div><strong>${esc(identityName(identity, address))}</strong><p class="address">${esc(wallet.address)}</p><button id="copy-wallet-address" type="button">复制完整地址</button> ${profile ? `<a href="${esc(profile)}" target="_blank" rel="noopener noreferrer">已核验 Polymarket 资料</a>` : '<span class="muted">未取得可核验的公开资料链接</span>'}<p class="muted">资料来源：${esc(identity?.source || '未取得')} · 上次成功刷新：${esc(stamp(identity?.refreshed_at))}</p></div></div>
    <div class="detail-grid"><section><h3>交易习惯 · 基于已读取样本</h3><ol>${(card.style_sentences || []).slice(0, 3).map(sentence => `<li>${esc(sentence)}</li>`).join('')}</ol><p class="muted">分类由盘口资料推断；常交易排序依据观察到的持仓数量。</p></section><section><h3>跟踪状态</h3><p>${wallet.tracked ? '正在跟踪未来成交' : '已暂停跟踪'} · ${esc(wallet.status)}</p><p>加入时间：${esc(stamp(wallet.created_at))}<br>资料更新时间：${esc(stamp(wallet.updated_at))}<br>最近成交：${esc(stamp(wallet.last_trade_ts))}<br>暂停时间：${esc(stamp(wallet.paused_at))}</p><p>跟单可行性：${esc(card.copyability?.status || '仍在收集')} · ${esc(card.copyability?.note || '尚无结论')}</p></section></div>
    <section><h3>历史持仓分类</h3>${rows.length ? table(['分类', '已结算样本', '盈利持仓', '盈利占比', '分类历史收益'], rows.map(row => `<tr><td>${esc(row.category)}</td><td>${esc(row.settled_positions)}</td><td>${esc(row.profitable_positions)}</td><td>${percent(row.profitable_rate)}</td><td>${money(row.historical_pnl)}</td></tr>`).join('')) : empty('暂无已结算分类样本')}</section>
    <section><h3>Leader 与本轮 V2</h3><div class="detail-stats"><div><small>Leader 历史已实现</small><strong>${money(card.leader_historical_realized_pnl)}</strong></div><div><small>Leader 历史未实现</small><strong>${money(card.leader_historical_unrealized_pnl)}</strong></div><div><small>本实验已实现模拟净收益</small><strong>${money(v2Wallet.realized_pnl || '0')}</strong></div><div><small>本实验未实现浮动收益</small><strong>${money(v2Wallet.unrealized_pnl)}</strong></div><div><small>V2 方向 / 模拟成交</small><strong>${esc(v2Wallet.episodes || 0)} / ${esc(v2Wallet.fills || 0)}</strong></div></div><p class="muted">Leader 收益来源：${esc(pnlSourceLabel(card.leader_pnl_source))}；时间范围：${esc(pnlWindowLabel(card.leader_pnl_window))}。本地样本更新时间：${esc(stamp(card.analyzed_at_utc))}。分类盈利占比只基于已结算持仓样本 ${esc(card.settled_position_sample)} 个。</p></section>
    <details><summary>高级数据 · 原始证据、AI 复盘和 JSON</summary><pre id="wallet-raw-json"></pre></details>`;
  $('wallet-raw-json').textContent = JSON.stringify({wallet, research_evidence: evidence}, null, 2);
  $('copy-wallet-address').onclick = async () => { try { await navigator.clipboard.writeText(wallet.address); notify('完整地址已复制。'); } catch { notify('复制失败，请手动选择地址。'); } };
  $('detail').showModal();
}

async function journal() {
  const selectedStatus = $('entry-status').value;
  let pageEntries;
  if (selectedStatus === 'FORMALLY_RESOLVED') {
    const entries = await fetchAllFormallyResolvedEpisodes();
    const filtered = entries.filter(item => item.resolution_status === 'FORMALLY_RESOLVED' && ['FILLED', 'PARTIAL'].includes(item.paper_status));
    total = filtered.length;
    pageEntries = filtered.slice(offset, offset + 50);
  } else {
    const response = await api(`/api/wallet-follow-v2/episodes?offset=${offset}&limit=50&status=${encodeURIComponent(selectedStatus)}`);
    total = response.total;
    pageEntries = response.entries;
  }
  $('journal-list').innerHTML = pageEntries.length ? table(
    ['观察时间 / Leader', '盘口 / 方向', '模拟决策', '模拟成交价', '结算价', '单笔净盈亏', '成交本金 / 手续费', '正式结果', '操作'],
    pageEntries.map(item => {
      const name = identityName(item.leader_identity, item.wallet);
      const url = trustedEvent(item.market_url);
      const outcome = resolvedPaperOutcome(item);
      const pnl = paperRealizedPnl(item);
      const rowClass = outcome === 'win' ? 'journal-outcome-win' : outcome === 'loss' ? 'journal-outcome-loss' : '';
      const outcomeBadge = outcome === 'win' ? '<span class="outcome-badge outcome-badge-win">预测成功</span>' : outcome === 'loss' ? '<span class="outcome-badge outcome-badge-loss">预测失败</span>' : '';
      const pnlClass = pnl === null ? '' : pnl > 0 ? 'positive' : pnl < 0 ? 'negative' : 'journal-pnl-neutral';
      const pnlDisplay = pnl === null ? '—' : `<span class="journal-pnl ${pnlClass}">${esc(signedMoney(pnl))}<br><small>已扣手续费</small></span>`;
      return `<tr${rowClass ? ` class="${rowClass}"` : ''}><td>${esc(stamp(item.first_detected_at))}<div class="journal-leader">${avatar(item.leader_identity, item.wallet, 'small')}<span>${esc(name)}</span></div></td><td class="market">${url ? `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(item.market_title || '未命名盘口')}</a>` : esc(item.market_title || '未命名盘口')}<br><small>${esc(item.first_outcome || '')}</small></td><td>${v2Tag(item.paper_status)}<br><small>${esc(noFillReasonLabel(item.rejection_reason || ''))}</small></td><td>${esc(paperEntryPrice(item))}</td><td>${esc(paperSettlementPrice(item))}</td><td>${pnlDisplay}</td><td>${money(item.filled_notional)}<br><small>手续费 ${money(item.entry_fee)}</small></td><td>${v2Tag(item.resolution_status)}${outcomeBadge ? `<br>${outcomeBadge}` : ''}</td><td>${button('v2-episode', item.episode_id, '完整执行证据')}</td></tr>`;
    }).join('')) : empty('本轮 V2 暂无符合条件的 episode。只有新交易才能形成记录。');
  $('page-info').textContent = `${total ? offset + 1 : 0}–${Math.min(offset + 50, total)} / ${total}`;
  $('previous').disabled = offset === 0;
  $('next').disabled = offset + 50 >= total;
}

document.addEventListener('click', event => {
  const target = event.target.closest('[data-action]');
  if (!target || !['wallet-detail', 'v2-episode'].includes(target.dataset.action)) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  const action = target.dataset.action;
  const id = target.dataset.id;
  (action === 'wallet-detail' ? showWalletDetail(id) : api(`/api/wallet-follow-v2/episodes/${encodeURIComponent(id)}`).then(item => show('V2 · 完整执行证据', item)))
    .catch(error => notify(error.message));
}, true);
document.addEventListener('keydown', event => {
  if (!['Enter', ' '].includes(event.key) || !event.target.matches('.wallet-card')) return;
  event.preventDefault();
  showWalletDetail(event.target.dataset.id).catch(error => notify(error.message));
});
document.addEventListener('error', event => {
  if (!event.target.matches?.('.avatar img')) return;
  event.target.hidden = true;
  const fallback = event.target.nextElementSibling;
  if (fallback) fallback.hidden = false;
}, true);

refresh();setInterval(refresh,10000);
