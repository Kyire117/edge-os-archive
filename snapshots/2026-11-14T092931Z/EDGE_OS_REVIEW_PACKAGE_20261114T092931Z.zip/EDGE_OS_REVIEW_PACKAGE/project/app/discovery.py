from __future__ import annotations

import asyncio
import logging
import math
import time
from typing import Any

from .config import settings
from .db import db
from .polymarket import pm
from .service import analyze_and_store, validate_wallet

log = logging.getLogger("edge.discovery")


class WalletDiscovery:
    """Find, analyze and cautiously promote leaderboard wallets."""

    def __init__(self):
        self._stop = asyncio.Event()
        self._task: asyncio.Task | None = None
        self._trigger_task: asyncio.Task | None = None
        self._lock = asyncio.Lock()
        self.last_run_at: int | None = None
        self.last_success_at: int | None = None
        self.last_result: dict[str, Any] | None = None
        self.last_error: str | None = None
        self._allocation_cursor = 0

    def start(self) -> None:
        if settings.discovery_enabled and (not self._task or self._task.done()):
            self._task = asyncio.create_task(self.run())

    async def stop(self) -> None:
        self._stop.set()
        tasks = [task for task in (self._task, self._trigger_task) if task]
        for task in tasks:
            try:
                await asyncio.wait_for(task, timeout=3)
            except Exception:
                task.cancel()

    def trigger(self) -> bool:
        """Start a manual discovery cycle without blocking the HTTP request."""
        if self._lock.locked() or (self._trigger_task and not self._trigger_task.done()):
            return False
        self._trigger_task = asyncio.create_task(self.run_once())
        return True

    async def run(self) -> None:
        try:
            await asyncio.wait_for(
                self._stop.wait(), timeout=max(0, settings.discovery_start_delay_seconds)
            )
            return
        except asyncio.TimeoutError:
            pass
        while not self._stop.is_set():
            try:
                await self.run_once()
            except Exception as exc:
                self.last_error = str(exc)
                log.exception("wallet discovery failed")
            try:
                await asyncio.wait_for(
                    self._stop.wait(), timeout=max(60, settings.discovery_interval_seconds)
                )
            except asyncio.TimeoutError:
                pass

    @staticmethod
    def _score(row: dict[str, Any], time_period: str) -> float:
        rank = max(1, int(row.get("rank") or 1000))
        pnl = max(0.0, float(row.get("pnl") or 0))
        volume = max(0.0, float(row.get("volume") or row.get("vol") or 0))
        efficiency = pnl / volume if volume else 0.0
        period_bonus = {"day": 12, "week": 18, "month": 15, "all": 8}.get(time_period, 0)
        return round(
            period_bonus
            + max(0, 35 - rank)
            + min(30, math.log10(pnl + 1) * 6)
            + min(20, efficiency * 100),
            3,
        )

    def _next_pool(self) -> str:
        # During a frozen short-horizon experiment, discovery prioritizes fast
        # candidates for the *next* cohort; it never mutates the active cohort.
        from .research import experiment_active
        if settings.research_enabled and experiment_active(db):
            return "FAST"
        # Ten-slot rolling budget: 70% Slow, 20% Fast, 10% exploration.
        pattern = ("SLOW", "SLOW", "FAST", "SLOW", "EXPLORE", "SLOW", "SLOW", "FAST", "SLOW", "SLOW")
        pool = pattern[self._allocation_cursor % len(pattern)]
        self._allocation_cursor += 1
        return pool

    async def run_once(self) -> dict[str, Any]:
        if self._lock.locked():
            return self.last_result or {"ok": True, "already_running": True}
        async with self._lock:
            result: dict[str, Any] = {
                "boards_checked": 0,
                "candidates_seen": 0,
                "analyzed": 0,
                "promoted": 0,
                "forward_tests_started": 0,
                "allocation": {"SLOW": 0, "FAST": 0, "EXPLORE": 0},
                "rejected": 0,
                "errors": [],
            }
            periods = ("day", "week", "month", "all")
            board_results = await asyncio.gather(
                *(
                    pm.leaderboard(
                        time_period=period,
                        category="overall",
                        limit=settings.discovery_board_limit,
                    )
                    for period in periods
                ),
                return_exceptions=True,
            )
            for period, rows in zip(periods, board_results):
                if isinstance(rows, Exception):
                    result["errors"].append(f"{period}: {rows}")
                    continue
                result["boards_checked"] += 1
                for row in rows:
                    raw_address = (
                        row.get("user_id")
                        or row.get("proxy_wallet")
                        or row.get("proxyWallet")
                        or row.get("address")
                    )
                    try:
                        address = validate_wallet(str(raw_address or ""))
                    except ValueError:
                        continue
                    from .research import excluded
                    if excluded(db, address):
                        continue
                    db.upsert_candidate(
                        {
                            "address": address,
                            "source": "POLYMARKET_LEADERBOARD",
                            "rank": int(row.get("rank") or 1000),
                            "pnl": float(row.get("pnl") or 0),
                            "volume": float(row.get("volume") or row.get("vol") or 0),
                            "score": self._score(row, period),
                            "time_period": period,
                            "category": "overall",
                            "target_pool": "SLOW" if period in {"month", "all"} else ("FAST" if period == "day" else "EXPLORE"),
                            "slow_prior_score": self._score(row, period) if period in {"month", "all"} else 0,
                            "fast_prior_score": self._score(row, period) if period in {"day", "week"} else 0,
                            "raw": row,
                        }
                    )
                    result["candidates_seen"] += 1

            tracked_count = len(db.tracked_wallets())
            slots = max(0, settings.discovery_max_tracked - tracked_count)
            analyze_limit = min(settings.discovery_analyze_per_cycle, slots)
            selected = []
            for _ in range(analyze_limit):
                requested_pool = self._next_pool()
                rows = db.candidates_for_pool(requested_pool, 1)
                if not rows:
                    rows = db.candidates(limit=1, status="NEW")
                if not rows:
                    break
                candidate = rows[0]
                db.set_candidate_status(candidate["address"], "QUEUED")
                selected.append(candidate)
                actual_pool = str(candidate.get("target_pool") or "EXPLORE")
                result["allocation"][actual_pool] = result["allocation"].get(actual_pool, 0) + 1

            for candidate in selected:
                address = candidate["address"]
                existing = db.get_wallet(address)
                from .research import excluded
                if excluded(db,address):
                    db.set_candidate_status(address,"EXCLUDED")
                    continue
                if existing and existing.get("tracked"):
                    db.set_candidate_status(address, "ALREADY_TRACKED", "钱包已在 Wallet Intelligence 中")
                    continue
                db.set_candidate_status(address, "ANALYZING")
                try:
                    wallet = await analyze_and_store(address, tracked=False)
                    result["analyzed"] += 1
                    analytics = wallet.get("analytics", {})
                    stats = wallet.get("stats", {})
                    skill = float(analytics.get("trader_skill") or 0)
                    closed = int(stats.get("closed_market_count") or 0)
                    top1 = float((analytics.get("profit_concentration") or {}).get("top1") or 0)
                    reasons = []
                    if not settings.research_enabled and skill < settings.discovery_min_skill:
                        reasons.append(f"Trader Skill {skill:.1f} < {settings.discovery_min_skill:.0f}")
                    if closed < settings.min_closed_markets:
                        reasons.append(f"已结算市场 {closed} < {settings.min_closed_markets}")
                    if not settings.research_enabled and top1 > settings.discovery_max_top1_concentration:
                        reasons.append(f"Top-1 盈利集中度 {top1:.0%} 过高")
                    if excluded(db,address):
                        db.set_candidate_status(address,"EXCLUDED")
                        continue
                    if reasons:
                        db.set_candidate_status(address, "REJECTED", "；".join(reasons))
                        result["rejected"] += 1
                    else:
                        db.set_wallet_origin(address, "POLYMARKET_LEADERBOARD", auto_managed=True)
                        db.set_wallet_alpha_target(address, str(candidate.get("target_pool") or "EXPLORE"))
                        db.set_wallet_tracked(address, True)
                        db.set_candidate_status(address, "FORWARD_TEST", "历史样本够用，开始每笔 $25 的前向模拟；等待 AI 条件研究")
                        result["promoted"] += 1
                        result["forward_tests_started"] += 1
                except Exception as exc:
                    db.set_candidate_status(address, "ERROR", str(exc)[:500])
                    result["errors"].append(f"{address}: {exc}")

            result["errors"] = result["errors"][:10]
            result["ok"] = not result["errors"]
            self.last_run_at = int(time.time())
            if result["ok"]:
                self.last_success_at = self.last_run_at
            self.last_error = result["errors"][0] if result["errors"] else None
            self.last_result = result
            return result


discovery = WalletDiscovery()
