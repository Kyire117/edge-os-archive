from __future__ import annotations

import asyncio
import hashlib
import json
import re
import sys
import time
import urllib.request
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

import httpx

from .analytics import category_for, safe_float
from .config import settings

_KNOWN_NONSPORT_MARKET_CATEGORIES = {
    "politics", "geopolitics", "crypto", "business", "economics", "economy",
    "finance", "technology", "tech", "culture", "pop culture", "entertainment",
    "science", "weather", "world", "health",
}
_SPORT_MARKET_CATEGORIES = {
    "sport", "sports", "football", "soccer", "basketball", "baseball",
    "hockey", "tennis", "golf", "mma", "boxing", "esports",
}


class PolymarketError(RuntimeError):
    pass


WALLET_PATTERN = re.compile(r"^0x[a-fA-F0-9]{40}$")
SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def safe_profile_image(value: Any) -> str | None:
    """Only use HTTPS images from Polymarket or its documented image CDN."""
    if not isinstance(value, str) or len(value) > 2048:
        return None
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower()
    try:
        invalid_port = bool(parsed.port)
    except ValueError:
        return None
    if parsed.scheme != "https" or parsed.username or parsed.password or invalid_port or (host not in {
        "polymarket.com", "images.polymarket.com", "imagedelivery.net"
    } and not host.endswith(".polymarket.com")):
        return None
    return value


def normalize_public_profile(payload: Any, requested_wallet: str) -> dict[str, Any]:
    """An absent/partial public profile must never become a fabricated identity."""
    profile = payload if isinstance(payload, dict) else {}
    proxy = profile.get("proxyWallet")
    proxy = proxy.lower() if isinstance(proxy, str) and WALLET_PATTERN.fullmatch(proxy) else None
    # The endpoint accepts both user and proxy addresses.  Without an
    # independently verified user-to-proxy mapping, only an exact proxy match
    # is safe to attribute to this tracked wallet.
    matched = proxy == requested_wallet.lower()
    username = profile.get("name") if profile.get("displayUsernamePublic") is not False else None
    username = username.strip()[:120] if matched and isinstance(username, str) and username.strip() else None
    return {
        "requested_wallet": requested_wallet.lower(),
        "proxy_wallet": proxy if matched else None,
        "username": username,
        "avatar_url": safe_profile_image(profile.get("profileImage")) if matched else None,
        "profile_url": f"https://polymarket.com/profile/{proxy}" if matched else None,
        "source": "GAMMA_PUBLIC_PROFILE" if matched else ("UNVERIFIED_IDENTITY" if profile else "UNAVAILABLE"),
    }


def public_profile_view(cached: dict[str, Any] | None, requested_wallet: str) -> dict[str, Any] | None:
    """Do not expose an incorrectly attributed cached identity from old rows."""
    if cached is None:
        return None
    identity = dict(cached)
    proxy = identity.get("proxy_wallet")
    source = identity.get("source")
    if (not isinstance(proxy, str) or proxy.lower() != requested_wallet.lower()
            or source not in {"GAMMA_PUBLIC_PROFILE", "STALE_GAMMA_PUBLIC_PROFILE"}):
        identity.update(proxy_wallet=None, username=None, avatar_url=None,
                        profile_url=None, source="UNAVAILABLE" if source == "UNAVAILABLE" else "UNVERIFIED_IDENTITY")
        return identity
    identity["avatar_url"] = safe_profile_image(identity.get("avatar_url"))
    identity["profile_url"] = f"https://polymarket.com/profile/{proxy.lower()}"
    return identity


def verified_market_url(evidence: Any) -> str | None:
    """Use only upstream event slugs in saved Data API or Gamma evidence."""
    if not isinstance(evidence, dict):
        return None
    trade = evidence.get("trade") if isinstance(evidence.get("trade"), dict) else {}
    raw = trade.get("raw") if isinstance(trade.get("raw"), dict) else {}
    market = evidence.get("market") if isinstance(evidence.get("market"), dict) else {}
    slug = market.get("event_slug") or trade.get("event_slug") or raw.get("eventSlug") or raw.get("event_slug")
    if isinstance(slug, str) and SLUG_PATTERN.fullmatch(slug):
        return f"https://polymarket.com/event/{slug}"
    return None


def _epoch(v: Any) -> int:
    if v is None:
        return 0
    if isinstance(v, (int, float)):
        n = int(v)
        if n > 10_000_000_000:  # micros/millis defensive
            while n > 10_000_000_000:
                n //= 1000
        return n
    s = str(v)
    if s.isdigit():
        return _epoch(int(s))
    try:
        return int(datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp())
    except Exception:
        return 0


def _first(d: dict[str, Any], *keys: str, default=None):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return default


def _json_array(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, list) else []
        except (TypeError, ValueError):
            return []
    return []


def normalize_market_state(market: dict[str, Any], token_id: str) -> dict[str, Any]:
    """Map a Gamma market to the requested CLOB token and resolution payout."""
    token_ids = [str(x) for x in _json_array(market.get("clobTokenIds"))]
    outcomes = [str(x) for x in _json_array(market.get("outcomes"))]
    prices = [safe_float(x, -1.0) for x in _json_array(market.get("outcomePrices"))]
    if token_id not in token_ids:
        raise PolymarketError("Gamma market does not contain requested token")
    index = token_ids.index(token_id)
    current_price = prices[index] if index < len(prices) and prices[index] >= 0 else None
    outcome = outcomes[index] if index < len(outcomes) else None
    resolution_status = str(market.get("umaResolutionStatus") or "").lower()
    events=market.get("events") if isinstance(market.get("events"),list) else []
    event=events[0] if events and isinstance(events[0],dict) else {}
    market_end=_first(market,"endDate","endDateIso","end_date","end_date_iso")
    event_end=_first(event,"endDate","endDateIso","end_date","end_date_iso")
    raw_end=market_end if market_end is not None else event_end
    sports=market.get("sports") if isinstance(market.get("sports"),dict) else {}
    market_game_start=_first(market,"gameStartTime","game_start_time")
    sports_game_start=_first(sports,"gameStartTime","game_start_time")
    event_game_starts=[(_first(item,"gameStartTime","game_start_time"),
                        any(key in item for key in ("gameStartTime","game_start_time")))
                       for item in events if isinstance(item,dict)]
    end_timestamp=_epoch(raw_end)
    # Gamma exposes a separate sports kickoff field. If the nominal market
    # end exactly coincides with kickoff, it is not safe to treat that value
    # as the expected market end for a short-horizon experiment.
    game_start_sources=[("market.gameStartTime",market_game_start,
                         any(key in market for key in ("gameStartTime","game_start_time"))),
                        ("market.sports.gameStartTime",sports_game_start,
                         any(key in sports for key in ("gameStartTime","game_start_time")))]
    game_start_sources.extend(("event.gameStartTime",value,present)
                              for value,present in event_game_starts)
    present_game_start_sources=[(source,raw) for source,raw,present in game_start_sources if present]
    parsed_game_starts=[(source,(_epoch(raw) or None)) for source,raw in present_game_start_sources]
    invalid_game_start=any(value is None for _,value in parsed_game_starts)
    game_starts=[value for _,value in parsed_game_starts if value is not None]
    end_matches_game_start=bool(end_timestamp and any(abs(end_timestamp-value)<=60 for value in game_starts))
    conflicting_game_starts=bool(len(game_starts)>1 and max(game_starts)-min(game_starts)>60)
    category=str(market.get("category") or "").strip().lower()
    sports_markers=bool(market.get("sportsMarketType") or market.get("gameId") or sports)
    sports_category=category in _SPORT_MARKET_CATEGORIES
    known_non_sports_category=category in _KNOWN_NONSPORT_MARKET_CATEGORIES
    sports_market=sports_markers or sports_category
    if invalid_game_start:
        end_time_quality="UNVERIFIED"
        end_time_quality_reason="INVALID_GAME_START_TIME"
    elif conflicting_game_starts:
        end_time_quality="UNVERIFIED"
        end_time_quality_reason="CONFLICTING_GAME_START_TIMES"
    elif end_matches_game_start:
        end_time_quality="UNRELIABLE_GAME_START"
        end_time_quality_reason="END_MATCHES_GAME_START"
    elif market_end is None:
        end_time_quality="UNVERIFIED"
        end_time_quality_reason="EVENT_END_DATE_ONLY" if event_end is not None else "MISSING_MARKET_END_DATE"
    elif not end_timestamp:
        end_time_quality="UNVERIFIED"
        end_time_quality_reason="INVALID_MARKET_END_DATE"
    elif not known_non_sports_category and not sports_category:
        end_time_quality="UNVERIFIED"
        end_time_quality_reason="UNRECOGNIZED_MARKET_CATEGORY" if category else "MARKET_CATEGORY_MISSING"
    elif sports_market and not game_starts:
        end_time_quality="UNVERIFIED"
        end_time_quality_reason="SPORTS_GAME_START_MISSING"
    elif sports_market:
        end_time_quality="VERIFIED_DISTINCT_FROM_GAME_START"
        end_time_quality_reason=None
    else:
        end_time_quality="VERIFIED_GAMMA_MARKET_END_DATE"
        end_time_quality_reason=None
    closed = bool(market.get("closed"))
    valid_prices = [p for p in prices if p >= 0]
    exact_payouts = bool(valid_prices) and all(p in {0.0, 0.5, 1.0} for p in valid_prices)
    resolved = closed and resolution_status == "resolved"
    settlement_price = None
    winner_outcome = None
    winning_token_id = None
    resolution_is_void = False
    if resolved and current_price is not None:
        valid = [(i, p) for i, p in enumerate(prices) if p >= 0]
        if valid:
            winner_index, winner_price = max(valid, key=lambda x: x[1])
            loser_price = min(p for _, p in valid)
            resolution_is_void = len(valid) == len(token_ids) and len(valid) > 1 and all(p == 0.5 for _, p in valid)
            # Gamma can briefly report 0.995/0.005 for a resolved binary market;
            # the redeemable payout is still exactly 1/0.
            if not resolution_is_void and winner_price >= 0.95 and loser_price <= 0.05:
                settlement_price = 1.0 if index == winner_index else 0.0
                if winner_index < len(token_ids):
                    winning_token_id = token_ids[winner_index]
            else:
                # Invalid/cancelled markets may legitimately resolve to 0.5.
                settlement_price = max(0.0, min(1.0, current_price))
            winner_outcome = outcomes[winner_index] if winner_index < len(outcomes) else None
    updated_at_raw = _first(market, "updatedAt", "updated_at", "lastUpdated")
    updated_at = _epoch(updated_at_raw) if updated_at_raw is not None else 0
    return {
        "token_id": token_id,
        "closed": closed,
        "resolved": resolved,
        "resolution_status": resolution_status or None,
        "resolution_is_void": resolution_is_void,
        "winning_token_id": winning_token_id,
        "market_source_timestamp": updated_at or None,
        "market_source_timestamp_raw": updated_at_raw,
        "outcome": outcome,
        "winner_outcome": winner_outcome,
        "current_price": current_price,
        "settlement_price": settlement_price,
        "question": market.get("question"),
        "condition_id": market.get("conditionId"),
        "description": market.get("description"),
        "resolution_source": market.get("resolutionSource"),
        "authoritative_source": market.get("resolutionSource"),
        "end_timestamp": end_timestamp,
        "end_timestamp_source": "market" if _first(market,"endDate","endDateIso","end_date","end_date_iso") is not None else ("event" if raw_end is not None else None),
        "game_start_timestamp": next((value for _,value in parsed_game_starts if value is not None),None),
        "game_start_timestamp_source": next((source for source,value in parsed_game_starts if value is not None),None),
        "game_start_timestamp_sources": [{"source":source,"timestamp":value}
                                          for source,value in parsed_game_starts],
        "end_timestamp_matches_game_start": end_matches_game_start,
        "expected_end_time_quality": end_time_quality,
        "expected_end_time_quality_reason": end_time_quality_reason,
        "market_category": category or None,
        "is_sports_market": sports_market,
        "event_id": str(event.get("id") or ""),
        "event_slug": event.get("slug") if isinstance(event.get("slug"), str) else None,
        "accepting_orders": market.get("acceptingOrders"),
        "fees_enabled": market.get("feesEnabled"),
        "fee_schedule": market.get("feeSchedule"),
        "minimum_order_size": market.get("orderMinSize"),
        "minimum_order_source": "Gamma.market.orderMinSize" if market.get("orderMinSize") is not None else None,
    }


def normalize_trade(raw: dict[str, Any], wallet: str) -> dict[str, Any]:
    market = raw.get("market") if isinstance(raw.get("market"), dict) else {}
    token_id = str(_first(raw, "token_id", "asset_id", "asset", "tokenId", default=market.get("token_id") or "") or "")
    condition_id = str(_first(raw, "condition_id", "conditionId", "market", default=market.get("condition_id") or market.get("conditionId") or "") or "")
    if condition_id.startswith("{"):
        condition_id = ""
    title = str(_first(raw, "title", "market_title", "question", default=market.get("title") or market.get("question") or "Unknown market"))
    outcome = str(_first(raw, "outcome", "outcome_label", default=market.get("outcome") or ""))
    side = str(_first(raw, "side", "type", default="")).upper()
    price = safe_float(_first(raw, "price", "avg_price", "avgPrice"))
    size = safe_float(_first(raw, "size", "shares", "amount"))
    usd_value = safe_float(_first(raw, "size_usdc", "usd_value", "notional", "cash_amount"), price * size)
    ts = _epoch(_first(raw, "timestamp", "created_at", "createdAt", "time", "matched_at"))
    tx_hash = str(_first(raw, "transaction_hash", "transactionHash", "tx_hash", "transaction", default="") or "")
    event_id = str(_first(raw, "event_id", "eventId", default=market.get("event_id") or "") or "")
    event_slug = _first(raw, "eventSlug", "event_slug", default=market.get("eventSlug") or market.get("event_slug"))
    explicit_category = _first(raw, "category", default=market.get("category"))
    category = category_for(title, explicit_category)
    stable = str(_first(raw, "id", "trade_id", "tradeId", default="") or "")
    if not stable:
        basis = f"{wallet.lower()}|{tx_hash}|{token_id}|{side}|{price:.8f}|{size:.8f}|{ts}|{outcome}"
        stable = hashlib.sha256(basis.encode()).hexdigest()
    return {
        "trade_key": stable,
        "wallet": wallet.lower(),
        "token_id": token_id,
        "condition_id": condition_id,
        "event_id": event_id,
        "event_slug": event_slug if isinstance(event_slug, str) and SLUG_PATTERN.fullmatch(event_slug) else None,
        "side": side,
        "price": price,
        "size": size,
        "usd_value": usd_value,
        "timestamp": ts,
        "title": title,
        "outcome": outcome,
        "category": category,
        "tx_hash": tx_hash,
        "raw": raw,
    }


class PolymarketClient:
    def __init__(self, *, public_http_proxy: str | None = None):
        self._chain_client = None
        # High-volume wallets can return multi-megabyte position/trade pages.  A
        # 20 second read timeout made those wallets fail while ordinary wallets
        # worked, especially on slower routes to the Data API.
        timeout = httpx.Timeout(settings.request_timeout_seconds, connect=10.0)
        limits = httpx.Limits(max_connections=50, max_keepalive_connections=20, keepalive_expiry=20.0)
        # On Windows, httpx honors proxy environment variables but does not
        # read the proxy configured in Internet Settings. After TUN is disabled
        # the latter may be the only working route to the public data APIs.
        system_proxy = urllib.request.getproxies().get("https") if sys.platform == "win32" else None
        self._client_options = dict(
            timeout=timeout,
            limits=limits,
            headers={"User-Agent": "PolymarketEdgeMVP/0.1"},
            proxy=public_http_proxy if public_http_proxy is not None else system_proxy,
        )
        self.client = self._new_public_client()
        self._request_users: dict[int, int] = {}
        self._retired_clients: dict[int, Any] = {}
        self._transport_failures = 0
        self._last_pool_reset = 0.0
        self.pool_reset_count = 0
        self.last_transport_error_type: str | None = None

    def _new_public_client(self):
        return httpx.AsyncClient(**self._client_options)

    async def _public_get(self, url, **kwargs):
        # Existing injected-client adapters bypass __init__. Keep their exact
        # transport and response evidence; they have no replacement pool config.
        if not hasattr(self,'_request_users'):
            return await self.client.get(url,**kwargs)
        client = self.client
        key = id(client)
        self._request_users[key] = self._request_users.get(key, 0) + 1
        try:
            result = await client.get(url, **kwargs)
            if client is self.client:
                self._transport_failures = 0
            return result
        except httpx.TransportError as exc:
            self.last_transport_error_type = type(exc).__name__
            if client is self.client:
                self._transport_failures += 1
                if self._transport_failures >= 3 and time.monotonic() - self._last_pool_reset >= 30:
                    # Preserve the same route, TLS verification and limits. A
                    # retired pool closes only after its in-flight reads finish.
                    self.client = self._new_public_client()
                    self._retired_clients[key] = client
                    self._transport_failures = 0
                    self._last_pool_reset = time.monotonic()
                    self.pool_reset_count += 1
            raise
        finally:
            self._request_users[key] -= 1
            if not self._request_users[key]:
                self._request_users.pop(key)
                retired = self._retired_clients.pop(key, None)
                if retired is not None:
                    await retired.aclose()

    async def close(self):
        await self.client.aclose()
        for retired in list(self._retired_clients.values()):
            await retired.aclose()
        self._retired_clients.clear()
        if self._chain_client is not None:await self._chain_client.aclose()

    async def polygon_read_rpc(self, method: str, params: list) -> Any:
        """Bounded public Polygon reads; deliberately cannot submit transactions."""
        if method not in {'eth_chainId','eth_blockNumber','eth_getLogs',
                          'eth_getBlockByNumber','eth_getTransactionReceipt'}:
            raise PolymarketError('CHAIN_METHOD_NOT_READ_ONLY')
        if self._chain_client is None:
            self._chain_client=httpx.AsyncClient(timeout=httpx.Timeout(12,connect=8),trust_env=False,
                limits=httpx.Limits(max_connections=4,max_keepalive_connections=4))
        # This public Polygon source was verified to serve the saved recovery
        # range. PublicNode rejects older logs as archive requests after downtime.
        async with self._chain_client.stream('POST','https://polygon.drpc.org',
                json={'jsonrpc':'2.0','id':1,'method':method,'params':params}) as response:
            response.raise_for_status();chunks=[];size=0
            async for part in response.aiter_bytes():
                size+=len(part)
                if size>16*2**20:raise PolymarketError('CHAIN_RESPONSE_TOO_LARGE')
                chunks.append(part)
        payload=json.loads(b''.join(chunks))
        if not isinstance(payload,dict) or payload.get('id')!=1 or 'error' in payload or 'result' not in payload:
            raise PolymarketError('CHAIN_HTTP_RPC_ERROR')
        return payload['result']

    async def _get(
        self,
        url: str,
        params: dict[str, Any] | None = None,
        *,
        attempts: int = 4,
        timeout_seconds: float | None = None,
        response_metadata: dict[str, Any] | None = None,
    ) -> Any:
        last = None
        last_exception = None
        # Retain diagnostic types even when the caller did not request metadata.
        capture_response = response_metadata is not None
        response_metadata = response_metadata if response_metadata is not None else {}
        attempts = max(1, attempts)
        retry_backoff = 0.0
        for attempt in range(attempts):
            try:
                if response_metadata is not None:
                    response_metadata.update(request_attempts=attempt + 1,retry_count=attempt,
                                             retry_backoff_seconds=retry_backoff)
                request_options = {"timeout": timeout_seconds} if timeout_seconds is not None else {}
                r = await self._public_get(url, params=params, **request_options)
                if response_metadata is not None:
                    response_metadata.update({"response_received_timestamp": datetime.now(timezone.utc).isoformat(),
                        "response_attempt": attempt + 1, "http_status": r.status_code,
                        "http_date": r.headers.get("Date"), "http_age": r.headers.get("Age"),
                        "http_cache_control": r.headers.get("Cache-Control")})
                    # Public book response only. Preserve what arrived even if
                    # status/JSON validation subsequently rejects it.
                    if capture_response:
                        try:
                            response_metadata["raw_response"] = r.json()
                        except ValueError:
                            response_metadata["raw_response"] = r.text
                if r.status_code in (429, 503):
                    retry = float(r.headers.get("Retry-After", 1 + attempt))
                    retry = min(retry, 5)
                    retry_backoff += retry
                    if response_metadata is not None:
                        response_metadata.update(retry_count=attempt+1,retry_backoff_seconds=retry_backoff)
                    await asyncio.sleep(retry)
                    last = f"HTTP {r.status_code}: {r.text[:300]}"
                    continue
                r.raise_for_status()
                return r.json()
            except (httpx.HTTPError, ValueError) as e:
                last = str(e)
                last_exception = e
                if response_metadata is not None:
                    response_metadata.update({"last_error_type": type(e).__name__,
                                              "last_error_detail": str(e)[:300],
                                              "retry_count":attempt,
                                              "retry_backoff_seconds":retry_backoff})
                # Invalid parameters and missing routes do not become valid by
                # retrying. Long retry chains previously froze realtime scans.
                if isinstance(e, httpx.HTTPStatusError) and 400 <= e.response.status_code < 500:
                    break
                if attempt < attempts - 1:
                    pause=0.5 * (attempt + 1)
                    retry_backoff+=pause
                    await asyncio.sleep(pause)
        error = PolymarketError(last or (type(last_exception).__name__ if last_exception else "request failed"))
        if response_metadata is not None:
            error.response_metadata = dict(response_metadata)
        raise error from last_exception

    @staticmethod
    def _data(payload: Any) -> Any:
        if isinstance(payload, dict) and "data" in payload:
            return payload.get("data")
        return payload

    async def user_stats(self, wallet: str) -> dict[str, Any]:
        p = await self._get(f"{settings.data_api}/v2/user-stats", {"user": wallet})
        return self._data(p) or {}

    async def public_profile(self, wallet: str) -> dict[str, Any]:
        payload = await self._get(f"{settings.gamma_api}/public-profile", {"address": wallet}, attempts=1, timeout_seconds=8)
        return normalize_public_profile(payload, wallet)

    async def user_volume(self, wallet: str) -> dict[str, Any]:
        p = await self._get(f"{settings.data_api}/v2/user-volume", {"user": wallet})
        return self._data(p) or {}

    async def user_pnl(self, wallet: str) -> list[dict[str, Any]]:
        p = await self._get(f"{settings.data_api}/v2/user-pnl", {"user": wallet, "interval": "max", "fidelity": "1d"})
        data = self._data(p) or {}
        return data.get("points", []) if isinstance(data, dict) else []

    async def positions(self, wallet: str, status: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        cursor = None
        while len(out) < settings.max_positions:
            params: dict[str, Any] = {"user": wallet, "status": status, "limit": min(1000, settings.max_positions - len(out))}
            if cursor:
                params["cursor"] = cursor
            p = await self._get(f"{settings.data_api}/v2/positions", params)
            data = self._data(p) or []
            if not isinstance(data, list):
                break
            out.extend(data)
            page = p.get("pagination", {}) if isinstance(p, dict) else {}
            cursor = page.get("next_cursor")
            if not cursor or not page.get("has_more"):
                break
        return out[: settings.max_positions]

    async def trades(
        self,
        wallet: str,
        start: int | None = None,
        limit_total: int | None = None,
        *,
        realtime: bool = False,
    ) -> list[dict[str, Any]]:
        max_items = min(limit_total or settings.max_history_trades, settings.max_history_trades)
        out: list[dict[str, Any]] = []
        cursor = None
        while len(out) < max_items:
            params: dict[str, Any] = {"user": wallet, "limit": min(500, max_items - len(out))}
            if start is not None:
                params["start"] = start
            if cursor:
                params["cursor"] = cursor
            try:
                p = await self._get(
                    f"{settings.data_api}/v2/trades",
                    params,
                    attempts=2 if realtime else 4,
                    timeout_seconds=settings.realtime_request_timeout_seconds if realtime else None,
                )
                data = self._data(p) or []
                if not isinstance(data, list):
                    break
                out.extend(normalize_trade(x, wallet) for x in data)
                page = p.get("pagination", {}) if isinstance(p, dict) else {}
                cursor = page.get("next_cursor")
                if not cursor or not page.get("has_more"):
                    break
            except PolymarketError:
                if realtime:
                    # v2 is the current official route. A legacy fallback here
                    # doubles work and can return an unbounded recent page.
                    raise
                # Compatibility fallback for deployments where only the legacy feed is exposed.
                legacy_params = {"user": wallet, "limit": min(500, max_items)}
                p = await self._get(f"{settings.data_api}/trades", legacy_params)
                data = p if isinstance(p, list) else p.get("data", []) if isinstance(p, dict) else []
                out = [normalize_trade(x, wallet) for x in data]
                break
        out.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
        return out[:max_items]

    async def trades_page(self, wallet: str, *, start: int, cursor: str | None,
                          limit: int = 25) -> dict[str, Any]:
        """Fetch one strictly bounded v2 Data API page with resumable cursor evidence."""
        page_size=max(1,min(int(limit),25))
        params: dict[str, Any] = {"user":wallet,"start":int(start),"limit":page_size}
        if cursor:
            params["cursor"]=cursor
        metadata: dict[str,Any]={}
        requested=datetime.now(timezone.utc).isoformat()
        began=time.monotonic()
        # The durable monitor owns retries. Two full request timeouts inside
        # one shorter scheduler timeout caused the retry to be cancelled.
        payload=await self._get(f"{settings.data_api}/v2/trades",params,attempts=1,
            timeout_seconds=settings.realtime_request_timeout_seconds,response_metadata=metadata)
        received=datetime.now(timezone.utc).isoformat()
        data=self._data(payload)
        if not isinstance(data,list):
            raise PolymarketError("INVALID_REALTIME_TRADE_RESPONSE")
        page=payload.get("pagination") if isinstance(payload,dict) else None
        if page is None:
            # A short page is sufficient evidence that this cursor range ended.
            # A full page without cursor metadata is ambiguous and cannot move
            # the checkpoint safely.
            if len(data)>=page_size:
                raise PolymarketError("UNVERIFIABLE_REALTIME_PAGINATION")
            has_more=False;next_cursor=None
        elif not isinstance(page,dict) or not isinstance(page.get("has_more"),bool):
            raise PolymarketError("INVALID_REALTIME_PAGINATION")
        else:
            has_more=page["has_more"]
            next_cursor=page.get("next_cursor")
            if has_more and (not isinstance(next_cursor,str) or not next_cursor.strip()):
                raise PolymarketError("MISSING_REALTIME_NEXT_CURSOR")
            if next_cursor is not None and not isinstance(next_cursor,str):
                raise PolymarketError("INVALID_REALTIME_NEXT_CURSOR")
        trades=[normalize_trade(row,wallet) for row in data if isinstance(row,dict)]
        if len(trades)!=len(data):
            raise PolymarketError("INVALID_REALTIME_TRADE_ROW")
        return {"trades":trades,"next_cursor":next_cursor,"has_more":has_more,
            "requested_at":requested,"received_at":received,"elapsed_ms":round((time.monotonic()-began)*1000,3),
            "http_metadata":metadata,"page_size":page_size,"rows_received":len(trades)}

    async def leaderboard(
        self,
        time_period: str = "week",
        category: str = "overall",
        limit: int = 30,
    ) -> list[dict[str, Any]]:
        payload = await self._get(
            f"{settings.data_api}/v2/leaderboard",
            {
                "time_period": time_period,
                "category": category,
                "sort_by": "PNL",
                "limit": max(1, min(limit, 1000)),
            },
            attempts=2,
            timeout_seconds=settings.realtime_request_timeout_seconds,
        )
        rows = self._data(payload) or []
        return rows if isinstance(rows, list) else []

    async def data_freshness(self) -> dict[str, Any]:
        payload = await self._get(
            f"{settings.data_api}/v2/status",
            attempts=1,
            timeout_seconds=settings.realtime_request_timeout_seconds,
        )
        data = self._data(payload) or {}
        return data if isinstance(data, dict) else {}

    async def orderbook(self, token_id: str) -> dict[str, Any]:
        metadata: dict[str, Any] = {}
        p = await self._get(f"{settings.clob_api}/book", {"token_id": token_id}, attempts=2,
                            timeout_seconds=8, response_metadata=metadata)
        bids = []
        asks = []
        for key, target in (("bids", bids), ("asks", asks)):
            rows = p.get(key) if isinstance(p, dict) else None
            for x in rows if isinstance(rows, list) else []:
                if isinstance(x, dict):
                    target.append({"price": safe_float(x.get("price")), "size": safe_float(x.get("size"))})
        bids = sorted((x for x in bids if x["price"] > 0 and x["size"] > 0), key=lambda x: x["price"], reverse=True)
        asks = sorted((x for x in asks if x["price"] > 0 and x["size"] > 0), key=lambda x: x["price"])
        source_timestamp = p.get("timestamp") if isinstance(p, dict) else None
        return {"bids": bids, "asks": asks, "timestamp": source_timestamp, "raw": p,
                "http_metadata": {k: metadata.get(k) for k in ("http_status", "http_date", "http_age", "http_cache_control",
                                                             "response_received_timestamp", "response_attempt")}}

    async def market_state(self, token_id: str) -> dict[str, Any]:
        for closed in (False, True):
            p = await self._get(f"{settings.gamma_api}/markets",
                {"clob_token_ids": token_id, "closed": str(closed).lower(), "limit": 5},
                attempts=1, timeout_seconds=6)
            markets = p if isinstance(p,list) else p.get("data",[]) if isinstance(p,dict) else []
            for market in markets:
                try:
                    return normalize_market_state(market,token_id)
                except PolymarketError:
                    continue
        raise PolymarketError(f"market not found for token {token_id}")

    async def fast_token_metadata(self, token_id: str) -> dict[str, Any]:
        """Identity-only lookup with exact token membership and raw Gamma provenance."""
        p = await self._get(f"{settings.gamma_api}/markets", {"clob_token_ids":token_id,"limit":5},
                            attempts=1, timeout_seconds=6)
        markets = p if isinstance(p,list) else p.get("data",[]) if isinstance(p,dict) else []
        matched=[]
        for market in markets:
            if not isinstance(market,dict): continue
            tokens=[str(x) for x in _json_array(market.get("clobTokenIds"))]
            outcomes=_json_array(market.get("outcomes"))
            if tokens.count(token_id)!=1 or len(tokens)!=len(outcomes): continue
            index=tokens.index(token_id)
            matched.append({"token_id":token_id,"condition_id":market.get("conditionId"),
                "outcome":outcomes[index],"title":market.get("question"),
                "category":market.get("category"),"source":"GAMMA_TOKEN_QUERY",
                "request_token_id":token_id,"raw":market})
        if len(matched)!=1: raise PolymarketError("UNVERIFIED_FAST_TOKEN_MAPPING")
        return matched[0]

    async def research_fee(self, condition_id: str, market: dict) -> dict:
        if market.get("fees_enabled") is False:
            return {"rate":0.0,"source":"GAMMA_FEES_DISABLED","exponent":1}
        p=await self._get(f"{settings.clob_api}/clob-markets/{condition_id}",attempts=2,timeout_seconds=10)
        if p.get("fees_enabled") is False or p.get("feesEnabled") is False:
            return {"rate":0.0,"source":"CLOB_FEES_DISABLED","exponent":1}
        fd=p.get("fd") or {}
        import math
        rate=float(fd.get("r",-1)); exponent=float(fd.get("e",1))
        if not math.isfinite(rate) or not 0<=rate<=1 or exponent!=1:
            raise PolymarketError("Unknown fee schedule or unsupported fee exponent")
        return {"rate":rate,"source":"CLOB_FD","exponent":exponent}

    async def market_fee_rate(self, condition_id: str | None, category: str) -> float:
        if condition_id:
            for path in (f"/clob-markets/{condition_id}", f"/markets/{condition_id}/clob"):
                try:
                    p = await self._get(f"{settings.clob_api}{path}")
                    fd = p.get("fd") if isinstance(p, dict) else None
                    if isinstance(fd, dict) and fd.get("r") is not None:
                        return safe_float(fd.get("r"))
                    if fd is None and isinstance(p, dict) and (p.get("fees_enabled") is False or p.get("feesEnabled") is False):
                        return 0.0
                except PolymarketError:
                    pass
        from .analytics import fee_rate_for_category
        return fee_rate_for_category(category)


pm = PolymarketClient()
