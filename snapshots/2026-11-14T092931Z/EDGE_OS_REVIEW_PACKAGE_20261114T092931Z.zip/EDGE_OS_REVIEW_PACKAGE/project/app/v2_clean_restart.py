"""One-time, local maintenance for a clean Wallet Follow V2 forward run.

This module has no HTTP route. The caller must stop the service, provide a
verified full backup, and invoke ``clean_restart_v2`` explicitly.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .wallet_follow_runtime import V2_CONFIG
from .wallet_follow_v2 import STRATEGY_VERSION


LEGACY_TABLES = (
    "paper_trades", "signal_snapshots", "signals",
    "research_experiment_entries", "research_experiment_events",
    "research_experiment_wallets", "research_experiments", "research_entries",
)
V2_SAMPLE_TABLES = ("wallet_v2_events", "wallet_v2_runtime_events", "wallet_v2_episodes")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _counts(con: sqlite3.Connection) -> dict[str, int]:
    tables = [row[0] for row in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    return {table: con.execute('SELECT COUNT(*) FROM "' + table.replace('"', '""') + '"').fetchone()[0]
            for table in tables}


def _version(con: sqlite3.Connection) -> tuple[str, str, str, str] | None:
    return con.execute("SELECT strategy_version,state,activated_at,config_json FROM wallet_v2_versions "
                       "WHERE strategy_version=?", (STRATEGY_VERSION,)).fetchone()


def clean_restart_v2(path: str | Path, backup_path: str | Path, *,
                     now: datetime | None = None, expected_source_sha256: str | None = None) -> dict[str, Any]:
    """Atomically discard old simulation samples after verifying a full backup.

    Raw trades, wallet/discovery data, market data, the frozen V2 version and
    append-only V2 audit history are not deleted. A reset audit record defines
    the forward observation cutoff without rewriting strategy activation.
    """
    source, backup = Path(path).resolve(), Path(backup_path).resolve()
    if not source.is_file() or not backup.is_file() or source == backup or backup.stat().st_size == 0:
        raise RuntimeError("CLEAN_RESTART_BACKUP_MISSING")
    if expected_source_sha256 is not None and _sha256(source) != expected_source_sha256:
        raise RuntimeError("CLEAN_RESTART_SOURCE_CHANGED")
    timestamp = now or datetime.now(timezone.utc)
    if timestamp.tzinfo is None or timestamp.utcoffset() is None:
        raise ValueError("INVALID_RESTART_TIMESTAMP")
    timestamp = timestamp.astimezone(timezone.utc)

    with sqlite3.connect("file:" + backup.as_posix() + "?mode=ro", uri=True, timeout=30) as copy:
        copy.execute("PRAGMA query_only=ON")
        if copy.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise RuntimeError("CLEAN_RESTART_BACKUP_INVALID")
        backup_counts, backup_version = _counts(copy), _version(copy)
    if backup_version is None or backup_version[1] != "FORWARD_TEST":
        raise RuntimeError("CLEAN_RESTART_BACKUP_WRONG_VERSION")
    backup_hash = _sha256(backup)

    con = sqlite3.connect(source, timeout=30, isolation_level=None)
    try:
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA busy_timeout=30000")
        con.execute("BEGIN IMMEDIATE")
        current_counts, current_version = _counts(con), _version(con)
        if current_counts != backup_counts or current_version != backup_version:
            raise RuntimeError("CLEAN_RESTART_SOURCE_DIFFERS_FROM_BACKUP")
        if current_version is None or current_version[1] != "FORWARD_TEST" or not current_version[2]:
            raise RuntimeError("CLEAN_RESTART_V2_NOT_ACTIVE")
        if json.loads(current_version[3]) != V2_CONFIG.evidence():
            raise RuntimeError("CLEAN_RESTART_FROZEN_RULE_CONFLICT")
        if current_counts.get("wallet_v2_versions") != 1:
            raise RuntimeError("CLEAN_RESTART_MULTIPLE_V2_VERSIONS")
        if con.execute("SELECT 1 FROM wallet_v2_audit WHERE action='CLEAN_FORWARD_RESTART' LIMIT 1").fetchone():
            raise RuntimeError("CLEAN_RESTART_ALREADY_DONE")
        if any(count for table, count in current_counts.items() if table.startswith("strict_")):
            raise RuntimeError("CLEAN_RESTART_STRICT_LEDGER_NOT_EMPTY")
        required = set(LEGACY_TABLES + V2_SAMPLE_TABLES + ("wallet_v2_audit",))
        if not required.issubset(current_counts):
            raise RuntimeError("CLEAN_RESTART_SCHEMA_INCOMPLETE")

        removed = {}
        for table in LEGACY_TABLES + V2_SAMPLE_TABLES:
            removed[table] = con.execute(f"DELETE FROM {table}").rowcount
        # Capture the cutoff as late as possible in the same transaction.
        cutoff = timestamp if now is not None else datetime.now(timezone.utc)
        evidence = {"strategy_version": STRATEGY_VERSION, "forward_started_at": cutoff.isoformat(),
                    "backup_file": backup.name, "backup_sha256": backup_hash,
                    "removed_counts": removed, "activated_at_unchanged": current_version[2]}
        con.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES(?,?,?)",
                    ("CLEAN_FORWARD_RESTART", cutoff.isoformat(), json.dumps(evidence, sort_keys=True)))
        if con.execute("PRAGMA foreign_key_check").fetchone() is not None:
            raise RuntimeError("CLEAN_RESTART_FOREIGN_KEY_FAILURE")
        after_counts = _counts(con)
        if any(after_counts[table] != 0 for table in LEGACY_TABLES + V2_SAMPLE_TABLES):
            raise RuntimeError("CLEAN_RESTART_ROWS_REMAIN")
        for table, count in current_counts.items():
            if table not in LEGACY_TABLES + V2_SAMPLE_TABLES + ("wallet_v2_audit",) and after_counts[table] != count:
                raise RuntimeError("CLEAN_RESTART_PROTECTED_DATA_CHANGED")
        if _version(con) != current_version:
            raise RuntimeError("CLEAN_RESTART_VERSION_CHANGED")
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
    return {"strategy_version": STRATEGY_VERSION, "state": "FORWARD_TEST",
            "forward_started_at": cutoff.isoformat(), "backup_file": str(backup),
            "backup_sha256": backup_hash, "removed_counts": removed,
            "preserved_counts": {key: after_counts.get(key, 0) for key in (
                "wallets", "trades", "wallet_candidates", "wallet_category_stats",
                "wallet_public_profiles", "research_leader_outcomes")}}
