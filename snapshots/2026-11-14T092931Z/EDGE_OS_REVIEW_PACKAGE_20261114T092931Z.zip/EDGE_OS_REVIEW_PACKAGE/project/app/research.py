"""Forward-only wallet-condition experiments. No orders or private keys."""
from __future__ import annotations
import asyncio
import json
import math
import sqlite3
import time
import uuid
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator
from .paper import simulate_buy, simulate_sell, top_of_book
from .config import settings

BASELINE = dict(name='baseline-v1', budget=25.0, min_price=.05, max_price=.95,
                max_spread=.04, max_adverse=.03, max_delay=900, min_seconds_to_end=3600,
                exit='HOLD_TO_RESOLUTION', scope='INDEPENDENT_WALLET_EXPERIMENTS')
EXPERIMENT_RULES = dict(
    rule_version='forward-copy-v0.4', duration_days=14, max_wallets=10,
    max_entries_per_wallet=10, trade_notional_usd=25.0,
    min_seconds_to_end=3600, max_seconds_to_end=5 * 86400,
    max_signal_delay_seconds=900, max_book_age_seconds=15,
    require_book_source_timestamp=True,
    max_price=.95, min_price=.05, max_spread=.04, max_adverse=.03,
    minimum_historical_markets=8, entry='FIRST_ELIGIBLE_OBSERVED_BUY',
    expected_end_time_policy='REQUIRE_SEMANTICALLY_VERIFIED_MARKET_END',
    exit='HOLD_TO_FORMAL_RESOLUTION', fees_separate=True, live_orders=False)
CATEGORIES = ['Politics','Geopolitics','Sports','Crypto','Macro','Tech','Culture','Weather','Other']
SKIP_REASON_GROUPS = {
    'Horizon': {'OUTSIDE_HORIZON_TOO_SHORT','OUTSIDE_HORIZON_TOO_LONG','OUTSIDE_HORIZON_AT_QUOTE'},
    'Data quality': {'MISSING_END_TIME','EXPIRED_END_TIME','INCONSISTENT_END_TIME','UNRELIABLE_END_TIME',
        'UNVERIFIED_END_TIME','INVALID_ORDER_BOOK','STALE_ORDER_BOOK','UNKNOWN_ORDER_BOOK_AGE',
        'MISSING_MARKET_ID','MISSING_RESOLUTION_RULES','INVALID_TIME_ORDER'},
    'Market unavailable': {'MARKET_NOT_OPEN','MARKET_DATA_UNAVAILABLE'},
    'Execution': {'STALE_SIGNAL','STALE_AT_QUOTE','INSUFFICIENT_DEPTH','BELOW_MINIMUM_ORDER',
        'INVALID_MINIMUM_ORDER','SPREAD','PRICE_RANGE','PRICE_MOVED','EXPERIMENT_ENTRY_CUTOFF'},
    'Signal / other': {'NOT_A_BUY','MANUALLY_EXCLUDED','CRASH_RECOVERY_NO_FILL',
        'DUPLICATE_POSITION','WALLET_ENTRY_LIMIT'},
}

def dump(x):
    return json.dumps(x, ensure_ascii=False, allow_nan=False)

class Rule(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)
    categories: list[Literal['Politics','Geopolitics','Sports','Crypto','Macro','Tech','Culture','Weather','Other']] = Field(min_length=1,max_length=9)
    title_keywords: list[str] = Field(default_factory=list, max_length=5)
    min_price: float = Field(default=.05, ge=.05, le=.95)
    max_price: float = Field(default=.95, ge=.05, le=.95)
    max_delay: int = Field(default=900, ge=1, le=900)
    max_adverse: float = Field(default=.03, ge=0, le=.03)
    min_consensus: int = Field(default=1, ge=1, le=10)
    @model_validator(mode='after')
    def valid(self):
        if self.min_price > self.max_price:
            raise ValueError('price range reversed')
        if any(not s.strip() or len(s)>80 for s in self.title_keywords):
            raise ValueError('invalid keywords')
        return self

class Review(BaseModel):
    model_config = ConfigDict(extra='forbid')
    recommendation: Literal['OBSERVE','KEEP','REFINE','PAUSE']
    summary: str = Field(min_length=1,max_length=2000)
    risks: list[str] = Field(max_length=10)
    hypothesis: str = Field(max_length=1000)
    falsification: str = Field(max_length=1000)
    supporting_entry_ids: list[int] = Field(max_length=30)
    rule: Rule | None = None


def init(database):
    with database.conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS research_entries(
          id INTEGER PRIMARY KEY, trade_key TEXT UNIQUE NOT NULL, wallet TEXT NOT NULL,
          condition_id TEXT, token_id TEXT, event_id TEXT, category TEXT, title TEXT, outcome TEXT,
          leader_ts REAL, detected_ts REAL, quoted_ts REAL, leader_price REAL,
          status TEXT NOT NULL, reason TEXT, version_id INTEGER, selected INTEGER DEFAULT 0,
          entry_json TEXT NOT NULL, cost REAL, shares REAL, fee REAL, pnl REAL,
          leader_reference_pnl REAL, marked_pnl REAL, mark_ts REAL, settled_ts REAL, settlement_price REAL);
        CREATE INDEX IF NOT EXISTS research_wallet ON research_entries(wallet,id);
        CREATE INDEX IF NOT EXISTS research_open ON research_entries(status,mark_ts);
        CREATE TABLE IF NOT EXISTS research_versions(
          id INTEGER PRIMARY KEY, wallet TEXT NOT NULL, created_ts REAL, cutoff_id INTEGER,
          state TEXT, rule_json TEXT, review_json TEXT, validation_json TEXT DEFAULT '{}');
        CREATE TABLE IF NOT EXISTS research_exclusions(wallet TEXT PRIMARY KEY, created_ts REAL, reason TEXT);
        CREATE TABLE IF NOT EXISTS research_identity(wallet TEXT PRIMARY KEY, group_id TEXT);
        CREATE TABLE IF NOT EXISTS research_audit(id INTEGER PRIMARY KEY, created_ts REAL, action TEXT, data_json TEXT);
        CREATE TABLE IF NOT EXISTS research_ai_runs(id INTEGER PRIMARY KEY, created_ts REAL, kind TEXT,
          subject TEXT, provider TEXT, model TEXT, status TEXT, context_json TEXT, response_json TEXT,
          error TEXT, usage_json TEXT, prompt_version TEXT);
        CREATE TABLE IF NOT EXISTS research_jobs(id INTEGER PRIMARY KEY, kind TEXT, subject TEXT, state TEXT,
          created_ts REAL, error TEXT);
        CREATE UNIQUE INDEX IF NOT EXISTS research_job_pending ON research_jobs(kind,subject) WHERE state='PENDING';
        CREATE TABLE IF NOT EXISTS research_leader_outcomes(wallet TEXT, condition_id TEXT, token_id TEXT,
          fetched_ts REAL, reported_pnl REAL, raw_json TEXT, PRIMARY KEY(wallet,condition_id,token_id));
        CREATE TABLE IF NOT EXISTS research_experiments(
          id TEXT PRIMARY KEY, rule_version TEXT NOT NULL, status TEXT NOT NULL,
          started_at REAL NOT NULL, ends_at REAL NOT NULL, started_utc TEXT NOT NULL,
          ends_utc TEXT NOT NULL, completed_utc TEXT, rules_json TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS research_experiment_events(
          event_id TEXT PRIMARY KEY, experiment_id TEXT NOT NULL, event_type TEXT NOT NULL,
          created_ts REAL NOT NULL, details_json TEXT NOT NULL,
          FOREIGN KEY(experiment_id) REFERENCES research_experiments(id));
        CREATE INDEX IF NOT EXISTS research_experiment_events_lookup
          ON research_experiment_events(experiment_id,event_type,created_ts);
        CREATE UNIQUE INDEX IF NOT EXISTS research_one_active_experiment
          ON research_experiments(status) WHERE status IN ('RUNNING','ENTRY_CLOSED');
        CREATE TABLE IF NOT EXISTS research_experiment_wallets(
          experiment_id TEXT NOT NULL, wallet TEXT NOT NULL, frozen_at_utc TEXT NOT NULL,
          last_activity_ts REAL, discovery_pool TEXT, qualification_json TEXT NOT NULL,
          PRIMARY KEY(experiment_id,wallet),
          FOREIGN KEY(experiment_id) REFERENCES research_experiments(id));
        CREATE TABLE IF NOT EXISTS research_experiment_entries(
          id INTEGER PRIMARY KEY, experiment_id TEXT NOT NULL, trade_key TEXT NOT NULL,
          wallet TEXT NOT NULL, condition_id TEXT, token_id TEXT, event_id TEXT,
          title TEXT, outcome TEXT, leader_ts REAL, detected_ts REAL NOT NULL,
          expected_end_ts REAL, horizon_calculated_ts REAL, horizon_seconds REAL,
          horizon_eligible INTEGER, entry_horizon_checked_ts REAL,
          entry_horizon_seconds REAL, entry_horizon_eligible INTEGER,
          entry_time_distance_category TEXT,
          status TEXT NOT NULL, reason TEXT,
          quote_started_ts REAL, quoted_ts REAL, book_source_ts REAL,
          cost REAL, shares REAL, fee REAL, pnl REAL, unrealized_pnl REAL,
          settlement_price REAL, settled_ts REAL, settlement_delay_seconds REAL,
          missing_data_count INTEGER NOT NULL DEFAULT 0, entry_json TEXT NOT NULL,
          UNIQUE(experiment_id,trade_key),
          FOREIGN KEY(experiment_id) REFERENCES research_experiments(id));
        CREATE INDEX IF NOT EXISTS research_experiment_entries_status
          ON research_experiment_entries(experiment_id,status,detected_ts);
        ''')
        entry_columns={row['name'] for row in c.execute('PRAGMA table_info(research_experiment_entries)').fetchall()}
        for name in ('entry_horizon_checked_ts REAL','entry_horizon_seconds REAL','entry_horizon_eligible INTEGER',
                     'entry_time_distance_category TEXT'):
            column=name.split()[0]
            if column not in entry_columns:c.execute(f'ALTER TABLE research_experiment_entries ADD COLUMN {name}')
        # Preserve opposite-outcome positions already written by the previous
        # schema. A transactional guard below enforces uniqueness when legacy
        # duplicates prevent SQLite from creating the stricter index.
        conflicts=c.execute('''SELECT 1 FROM research_experiment_entries
          WHERE status IN ('OPEN','SETTLED') AND condition_id IS NOT NULL
          GROUP BY experiment_id,wallet,condition_id HAVING COUNT(*)>1 LIMIT 1''').fetchone()
        if not conflicts:
            c.execute('''CREATE UNIQUE INDEX IF NOT EXISTS research_experiment_one_open_market
              ON research_experiment_entries(experiment_id,wallet,condition_id)
              WHERE status IN ('OPEN','SETTLED')''')
        from datetime import datetime, timezone
        c.execute("INSERT OR IGNORE INTO system_state(key,value) VALUES('research_started_at',?)",(datetime.now(timezone.utc).isoformat(),))


def _utc(ts):
    return datetime.fromtimestamp(float(ts), timezone.utc).isoformat().replace('+00:00', 'Z')


def _entry_time_distance_category(seconds):
    """Classify a horizon-eligible decision by distance to expected market end."""
    try:
        seconds=float(seconds)
    except (TypeError,ValueError):
        return None
    if not math.isfinite(seconds) or seconds < 0 or seconds > 5*86400:
        return None
    if seconds <= 86400:
        return 'LAST_DAY'
    if seconds <= 72*3600:
        return 'EARLY'
    return 'FAR_EARLY'


def _epoch_value(value):
    if isinstance(value,bool):
        return None
    if isinstance(value,(int,float)):
        stamp=float(value)
        if not math.isfinite(stamp):return None
        if stamp>10_000_000_000:stamp/=1000
        return stamp if stamp>0 else None
    if isinstance(value,str):
        raw=value.strip()
        if not raw:return None
        try:
            stamp=float(raw)
            if not math.isfinite(stamp):return None
            if stamp>10_000_000_000:stamp/=1000
            return stamp if stamp>0 else None
        except ValueError:
            try:
                parsed=datetime.fromisoformat(raw.replace('Z','+00:00'))
                if parsed.tzinfo is None:return None
                stamp=parsed.timestamp()
                return stamp if math.isfinite(stamp) and stamp>0 else None
            except (TypeError,ValueError,OverflowError):return None
    return None


def _clock(client):
    """Use the client's injectable clock in deterministic simulations."""
    clock = getattr(client, 'clock', None)
    return float(clock()) if callable(clock) else time.time()


def _experiment(database, experiment_id=None, active_only=False):
    if active_only:
        found=rows(database,"SELECT * FROM research_experiments WHERE status='RUNNING' ORDER BY started_at DESC LIMIT 1")
    elif experiment_id:
        found=rows(database,'SELECT * FROM research_experiments WHERE id=?',(experiment_id,))
    else:
        found=rows(database,'SELECT * FROM research_experiments ORDER BY started_at DESC LIMIT 1')
    return found[0] if found else None


def experiment_active(database):
    return _experiment(database,active_only=True)


def start_experiment(database, now=None):
    """Freeze a qualified wallet cohort and persist a 14-day UTC experiment."""
    # The legacy V0.x experiment can be created only before V2 has ever been
    # activated. A transient state-read error is fail-closed for admissions.
    if hasattr(database, 'path'):
        from .wallet_follow_runtime import V2ActivationState, v2_activation_state
        state = v2_activation_state(database.path)
        if state in {V2ActivationState.ACTIVE, V2ActivationState.LOCKED, V2ActivationState.READ_ERROR}:
            raise ValueError('WALLET_FOLLOW_V2_OWNS_RUNTIME')
    now=float(now if now is not None else time.time())
    start_iso=_utc(now); end=now+EXPERIMENT_RULES['duration_days']*86400; end_iso=_utc(end)
    candidates=[]
    for wallet in database.tracked_wallets():
        stats=wallet.get('stats') or {}
        closed=int(stats.get('closed_market_count') or 0)
        if closed < EXPERIMENT_RULES['minimum_historical_markets']:
            continue
        activity=rows(database,'SELECT MAX(timestamp) ts FROM trades WHERE wallet=? AND is_seed=0',(wallet['address'],))[0]['ts']
        if activity is None:
            activity=wallet.get('last_trade_ts')
        pools=rows(database,'SELECT target_pool,fast_prior_score FROM wallet_candidates WHERE address=?',(wallet['address'],))
        pool=pools[0] if pools else {}
        candidates.append((bool(pool.get('target_pool')=='FAST'),float(activity or 0),float(pool.get('fast_prior_score') or 0),wallet,activity,pool))
    candidates.sort(key=lambda x:(x[0],x[1],x[2]),reverse=True)
    cohort=candidates[:EXPERIMENT_RULES['max_wallets']]
    if not cohort:
        raise ValueError('没有达到既有历史样本门槛的已跟踪钱包；先通过自动发现并完成历史分析')
    experiment_id='FC14-'+uuid.uuid4().hex[:12].upper()
    rules={**EXPERIMENT_RULES,'cohort_size':len(cohort),'cohort_frozen_at_utc':start_iso}
    with database.conn() as c:
        c.execute('BEGIN IMMEDIATE')
        if c.execute("SELECT 1 FROM research_experiments WHERE status IN ('RUNNING','ENTRY_CLOSED')").fetchone():
            raise ValueError('已有未完成的 14 天实验')
        c.execute('''INSERT INTO research_experiments(id,rule_version,status,started_at,ends_at,started_utc,ends_utc,rules_json)
          VALUES(?,?,'RUNNING',?,?,?,?,?)''',(experiment_id,rules['rule_version'],now,end,start_iso,end_iso,dump(rules)))
        for fast,activity,score,wallet,_,pool in cohort:
            c.execute('''INSERT INTO research_experiment_wallets
              (experiment_id,wallet,frozen_at_utc,last_activity_ts,discovery_pool,qualification_json)
              VALUES(?,?,?,?,?,?)''',(experiment_id,wallet['address'],start_iso,activity,pool.get('target_pool'),
              dump({'closed_market_count':int((wallet.get('stats') or {}).get('closed_market_count') or 0),
                    'recent_activity_priority':bool(fast),'fast_prior_score':score})))
        c.execute("INSERT INTO research_audit(created_ts,action,data_json) VALUES(?,?,?)",
          (now,'EXPERIMENT_STARTED',dump({'experiment_id':experiment_id,'cohort_size':len(cohort),'rules':rules})))
    return experiment_summary(database,experiment_id,now)


def experiment_summary(database, experiment_id=None, now=None):
    ex=_experiment(database,experiment_id)
    if not ex:
        return {'active':False,'experiment':None}
    now=float(now if now is not None else time.time())
    cohort=rows(database,'SELECT * FROM research_experiment_wallets WHERE experiment_id=? ORDER BY wallet',(ex['id'],))
    data=rows(database,'SELECT * FROM research_experiment_entries WHERE experiment_id=? ORDER BY id',(ex['id'],))
    rules=json.loads(ex['rules_json']); open_rows=[x for x in data if x['status']=='OPEN']
    skip_reasons=defaultdict(int)
    skip_categories={group:0 for group in SKIP_REASON_GROUPS}
    distance_categories={'LAST_DAY':0,'EARLY':0,'FAR_EARLY':0}
    for item in data:
        if item['status']=='SKIP':
            reason=item.get('reason') or 'UNKNOWN_REASON'
            skip_reasons[reason]+=1
            group=next((name for name,reasons in SKIP_REASON_GROUPS.items() if reason in reasons),'Signal / other')
            skip_categories[group]+=1
        category=item.get('entry_time_distance_category')
        if bool(item.get('horizon_eligible')) and category in distance_categories:
            distance_categories[category]+=1
    realized=sum(float(x['pnl'] or 0) for x in data if x['status']=='SETTLED' and x['pnl'] is not None)
    unrealized=sum(float(x['unrealized_pnl'] or 0) for x in open_rows if x['unrealized_pnl'] is not None)
    by_wallet=[]
    for member in cohort:
        wallet=member['wallet']; items=[x for x in data if x['wallet']==wallet]
        settled=[x for x in items if x['status']=='SETTLED' and x['pnl'] is not None]
        by_wallet.append({'wallet':wallet,'last_activity_ts':member['last_activity_ts'],
          'discovery_pool':member['discovery_pool'],'signals':len(items),
          'eligible':sum(bool(x['horizon_eligible']) for x in items),
          'entries':sum(x['status'] in ('OPEN','SETTLED') for x in items),
          'open':sum(x['status']=='OPEN' for x in items),'settled':len(settled),
          'realized_pnl':sum(float(x['pnl'] or 0) for x in settled),
          'unrealized_pnl':sum(float(x['unrealized_pnl'] or 0) for x in items if x['status']=='OPEN' and x['unrealized_pnl'] is not None)})
    quality=sum(int(x['missing_data_count'] or 0) for x in data)+sum(
          x['reason'] in {'MISSING_END_TIME','EXPIRED_END_TIME','INCONSISTENT_END_TIME','UNRELIABLE_END_TIME','UNVERIFIED_END_TIME','MARKET_DATA_UNAVAILABLE',
        'INVALID_ORDER_BOOK','STALE_ORDER_BOOK','UNKNOWN_ORDER_BOOK_AGE','CRASH_RECOVERY_NO_FILL',
        'MISSING_MARKET_ID','MISSING_RESOLUTION_RULES'} for x in data)
    execution=sum(x['reason'] in {'STALE_SIGNAL','STALE_AT_QUOTE','INVALID_ORDER_BOOK','STALE_ORDER_BOOK',
      'INSUFFICIENT_DEPTH','BELOW_MINIMUM_ORDER','INVALID_MINIMUM_ORDER','SPREAD','PRICE_RANGE','PRICE_MOVED',
      'UNKNOWN_ORDER_BOOK_AGE','INVALID_TIME_ORDER','OUTSIDE_HORIZON_AT_QUOTE',
      'DUPLICATE_POSITION','WALLET_ENTRY_LIMIT'} for x in data)
    status=ex['status']
    superseded=bool(rows(database,"SELECT 1 FROM research_experiment_events WHERE experiment_id=? AND event_type='SUPERSEDED_BY_WALLET_FOLLOW_V2' LIMIT 1",(ex['id'],)))
    return {'active':status in ('RUNNING','ENTRY_CLOSED') and not superseded,'experiment':{
      'id':ex['id'],'rule_version':ex['rule_version'],'status':status,
      'started_utc':ex['started_utc'],'ends_utc':ex['ends_utc'],'remaining_seconds':max(0,int(ex['ends_at']-now)),
      'rules':rules,'cohort_size':len(cohort),'wallets':by_wallet,
      'counts':{'signals':len(data),'eligible':sum(bool(x['horizon_eligible']) for x in data),
        'skipped':sum(x['status']=='SKIP' for x in data),'filled':sum(x['status'] in ('OPEN','SETTLED') for x in data),
        'open':len(open_rows),'settled':sum(x['status']=='SETTLED' for x in data),
        'skip_reasons':dict(sorted(skip_reasons.items())),
        'skip_categories':skip_categories,
        'entry_time_distance_categories':distance_categories},
      'realized_pnl':realized,'unrealized_pnl':unrealized,
      'data_quality_failures':quality,'execution_failures':execution,
      'entries':[{key:x.get(key) for key in ('id','wallet','trade_key','condition_id','token_id','event_id','title','outcome',
        'leader_ts','detected_ts','expected_end_ts','horizon_calculated_ts','horizon_seconds','horizon_eligible',
        'entry_horizon_checked_ts','entry_horizon_seconds','entry_horizon_eligible','entry_time_distance_category','status','reason',
        'quoted_ts','cost','shares','fee','pnl','unrealized_pnl','settled_ts','settlement_delay_seconds','missing_data_count')}
        for x in data[-100:]]}}


def experiment_entries(database, experiment_id=None, offset=0, limit=50, status=None, wallet=None):
    ex=_experiment(database,experiment_id)
    if not ex:return {'total':0,'entries':[]}
    where='WHERE experiment_id=?';args=[ex['id']]
    if status:where+=' AND status=?';args.append(status)
    if wallet:where+=' AND wallet=?';args.append(wallet.lower())
    total=rows(database,'SELECT COUNT(*) n FROM research_experiment_entries '+where,args)[0]['n']
    items=rows(database,'SELECT * FROM research_experiment_entries '+where+' ORDER BY id DESC LIMIT ? OFFSET ?',
      [*args,max(1,min(int(limit),200)),max(0,int(offset))])
    for item in items:item['evidence']=json.loads(item.pop('entry_json'))
    return {'experiment_id':ex['id'],'total':total,'entries':items}


def validate_experiment_book(book):
    if not isinstance(book,dict): return 'INVALID_ORDER_BOOK'
    bids=book.get('bids'); asks=book.get('asks')
    if not isinstance(bids,list) or not isinstance(asks,list) or not bids or not asks:
        return 'INVALID_ORDER_BOOK'
    def levels(values,ascending):
        result=[]
        for level in values:
            try:p=float(level['price']); size=float(level['size'])
            except (KeyError,TypeError,ValueError):return None
            if not math.isfinite(p) or not 0<p<1 or not math.isfinite(size) or size<=0:return None
            result.append((p,size))
        if any((result[i][0]>result[i+1][0] if ascending else result[i][0]<result[i+1][0]) for i in range(len(result)-1)):
            return None
        return result
    bid_levels=levels(bids,False); ask_levels=levels(asks,True)
    if bid_levels is None or ask_levels is None or bid_levels[0][0]>ask_levels[0][0]: return 'INVALID_ORDER_BOOK'
    return None


def _finish_experiment_entry(database, entry_id, status, reason, evidence, values=None):
    values=values or {}
    try:
        with database.conn() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT * FROM research_experiment_entries WHERE id=?',(entry_id,)).fetchone()
            if not row or row['status']!='PENDING': return
            if status=='OPEN':
                frozen=json.loads(c.execute('SELECT rules_json FROM research_experiments WHERE id=?',(row['experiment_id'],)).fetchone()['rules_json'])
                count=c.execute('''SELECT COUNT(*) n FROM research_experiment_entries
                  WHERE experiment_id=? AND wallet=? AND status IN ('OPEN','SETTLED')''',(row['experiment_id'],row['wallet'])).fetchone()['n']
                if count>=int(frozen['max_entries_per_wallet']):
                    status='SKIP';reason='WALLET_ENTRY_LIMIT'
                elif row['condition_id'] and c.execute('''SELECT 1 FROM research_experiment_entries
                  WHERE experiment_id=? AND wallet=? AND condition_id=? AND status IN ('OPEN','SETTLED') AND id<>? LIMIT 1''',
                  (row['experiment_id'],row['wallet'],row['condition_id'],entry_id)).fetchone():
                    status='SKIP';reason='DUPLICATE_POSITION'
                else:
                    try:
                        c.execute('''UPDATE research_experiment_entries SET status='OPEN',reason=NULL,
                          expected_end_ts=?,horizon_calculated_ts=?,horizon_seconds=?,horizon_eligible=1,
                          entry_horizon_checked_ts=?,entry_horizon_seconds=?,entry_horizon_eligible=1,
                          entry_time_distance_category=?,
                          quote_started_ts=?,quoted_ts=?,book_source_ts=?,cost=?,shares=?,fee=?,entry_json=?
                          WHERE id=? AND status='PENDING' ''',(values.get('expected_end_ts'),values.get('horizon_calculated_ts'),
                          values.get('horizon_seconds'),values.get('entry_horizon_checked_ts'),values.get('entry_horizon_seconds'),
                          values.get('entry_time_distance_category'),
                          values.get('quote_started_ts'),values.get('quoted_ts'),values.get('book_source_ts'),
                          values.get('cost'),values.get('shares'),values.get('fee'),dump(evidence),entry_id))
                        return
                    except sqlite3.IntegrityError:
                        status='SKIP';reason='DUPLICATE_POSITION'
            c.execute('''UPDATE research_experiment_entries SET status=?,reason=?,expected_end_ts=COALESCE(?,expected_end_ts),
              horizon_calculated_ts=COALESCE(?,horizon_calculated_ts),horizon_seconds=COALESCE(?,horizon_seconds),
              horizon_eligible=COALESCE(?,horizon_eligible),quote_started_ts=COALESCE(?,quote_started_ts),
              entry_horizon_checked_ts=COALESCE(?,entry_horizon_checked_ts),
              entry_horizon_seconds=COALESCE(?,entry_horizon_seconds),
              entry_horizon_eligible=COALESCE(?,entry_horizon_eligible),
              entry_time_distance_category=COALESCE(?,entry_time_distance_category),
              quoted_ts=COALESCE(?,quoted_ts),book_source_ts=COALESCE(?,book_source_ts),entry_json=? WHERE id=? AND status='PENDING' ''',
              (status,reason,values.get('expected_end_ts'),values.get('horizon_calculated_ts'),values.get('horizon_seconds'),
               values.get('horizon_eligible'),values.get('quote_started_ts'),values.get('entry_horizon_checked_ts'),
               values.get('entry_horizon_seconds'),values.get('entry_horizon_eligible'),values.get('entry_time_distance_category'),values.get('quoted_ts'),
               values.get('book_source_ts'),dump(evidence),entry_id))
    except sqlite3.IntegrityError:
        with database.conn() as c:
            c.execute("UPDATE research_experiment_entries SET status='SKIP',reason='DUPLICATE_POSITION',entry_json=? WHERE id=? AND status='PENDING'",(dump(evidence),entry_id))


async def capture_experiment(database, client, wallet, trade, detected_at=None):
    """Record one genuinely observed signal using a frozen experiment and fresh book."""
    ex=experiment_active(database)
    if not ex:return None
    address=str(wallet['address']).lower(); detected=float(detected_at if detected_at is not None else _clock(client))
    member=rows(database,'SELECT 1 FROM research_experiment_wallets WHERE experiment_id=? AND wallet=?',(ex['id'],address))
    if not member:return None
    if not ex['started_at']<=detected<ex['ends_at']:return None
    frozen_rules=json.loads(ex['rules_json'])
    evidence={'trade':trade,'rules':frozen_rules,'experiment_id':ex['id'],'decision_timestamp_utc':_utc(detected)}
    with database.conn() as c:
        inserted=c.execute('''INSERT OR IGNORE INTO research_experiment_entries
          (experiment_id,trade_key,wallet,condition_id,token_id,event_id,title,outcome,leader_ts,detected_ts,status,entry_json)
          VALUES(?,?,?,?,?,?,?,?,?,?,'PENDING',?)''',(ex['id'],trade['trade_key'],address,trade.get('condition_id'),
          trade.get('token_id'),trade.get('event_id'),trade.get('title'),trade.get('outcome'),trade.get('timestamp'),detected,dump(evidence)))
        row=c.execute('SELECT * FROM research_experiment_entries WHERE experiment_id=? AND trade_key=?',(ex['id'],trade['trade_key'])).fetchone()
    if not row or row['status']!='PENDING' or inserted.rowcount==0:return dict(row) if row else None
    entry_id=row['id']; reason=None; values={}; calculation_at=detected
    try:
        signal_ts=float(trade.get('timestamp') or 0)
        age=calculation_at-signal_ts
        if trade.get('side')!='BUY':reason='NOT_A_BUY'
        elif not trade.get('condition_id') or not trade.get('token_id'):reason='MISSING_MARKET_ID'
        elif not math.isfinite(signal_ts) or not -5<=age<=frozen_rules['max_signal_delay_seconds']:reason='STALE_SIGNAL'
        elif excluded(database,address):reason='MANUALLY_EXCLUDED'
        else:
            market=await client.market_state(trade['token_id']); market_received=_clock(client); evidence['market']=market
            evidence['execution_timestamps']={'market_received_utc':_utc(market_received)}
            end_ts=market.get('end_timestamp')
            values['horizon_calculated_ts']=calculation_at
            try:end_ts=float(end_ts)
            except (TypeError,ValueError):end_ts=0
            policy=frozen_rules.get('expected_end_time_policy')
            time_quality=market.get('expected_end_time_quality')
            unreliable_game_start=(policy=='REJECT_IF_GAMMA_END_MATCHES_SPORTS_GAME_START'
              and market.get('end_timestamp_matches_game_start') is True) or (
              policy=='REQUIRE_SEMANTICALLY_VERIFIED_MARKET_END' and time_quality=='UNRELIABLE_GAME_START')
            unverified_end_time=(policy=='REQUIRE_SEMANTICALLY_VERIFIED_MARKET_END'
              and not str(time_quality or '').startswith('VERIFIED_'))
            reject_end_time=unreliable_game_start or unverified_end_time
            horizon=end_ts-calculation_at if math.isfinite(end_ts) and end_ts>0 else None
            values.update(expected_end_ts=None if reject_end_time else (end_ts or None),
                          horizon_seconds=None if reject_end_time else horizon)
            evidence['horizon']={'expected_end_utc':_utc(end_ts) if end_ts>0 else None,
              'calculated_at_utc':_utc(calculation_at),'remaining_seconds':horizon,
              'end_timestamp_source':market.get('end_timestamp_source'),
              'game_start_utc':_utc(market['game_start_timestamp']) if market.get('game_start_timestamp') else None,
              'end_matches_game_start':market.get('end_timestamp_matches_game_start') is True,
              'eligibility_timestamp_quality':time_quality or 'UNVERIFIED',
              'eligibility_timestamp_quality_reason':market.get('expected_end_time_quality_reason')}
            if unreliable_game_start:reason='UNRELIABLE_END_TIME';values['horizon_eligible']=0
            elif unverified_end_time:reason='UNVERIFIED_END_TIME';values['horizon_eligible']=0
            elif not end_ts:reason='MISSING_END_TIME';values['horizon_eligible']=0
            elif end_ts<=calculation_at:reason='EXPIRED_END_TIME';values['horizon_eligible']=0
            elif end_ts>calculation_at+7*365*86400:reason='INCONSISTENT_END_TIME';values['horizon_eligible']=0
            elif horizon<frozen_rules['min_seconds_to_end']:reason='OUTSIDE_HORIZON_TOO_SHORT';values['horizon_eligible']=0
            elif horizon>frozen_rules['max_seconds_to_end']:reason='OUTSIDE_HORIZON_TOO_LONG';values['horizon_eligible']=0
            else:
                values['horizon_eligible']=1
                values['entry_time_distance_category']=_entry_time_distance_category(horizon)
            values['expected_end_ts']=None if reject_end_time else (end_ts or None)
            with database.conn() as c:
                c.execute('UPDATE research_experiment_entries SET expected_end_ts=?,horizon_calculated_ts=?,horizon_seconds=?,horizon_eligible=?,entry_time_distance_category=?,entry_json=? WHERE id=? AND status=\'PENDING\'',
                  (values['expected_end_ts'],calculation_at,values['horizon_seconds'],values['horizon_eligible'],values.get('entry_time_distance_category'),dump(evidence),entry_id))
            if not reason and (market.get('resolved') or market.get('closed') or market.get('accepting_orders') is False):reason='MARKET_NOT_OPEN'
            if not reason and not market.get('description'):reason='MISSING_RESOLUTION_RULES'
            if not reason:
                fee_requested=_clock(client)
                fee=await client.research_fee(trade['condition_id'],market)
                fee_received=_clock(client)
                rate=float(fee.get('rate'))
                if not math.isfinite(rate) or not 0<=rate<=1:raise ValueError('invalid fee rate')
                evidence['fee_schedule']=fee
                evidence['execution_timestamps'].update(fee_requested_utc=_utc(fee_requested),fee_received_utc=_utc(fee_received))
                quote_started=_clock(client);values['quote_started_ts']=quote_started
                book=await client.orderbook(trade['token_id']);quoted=_clock(client);values['quoted_ts']=quoted
                observed_ts=book.get('timestamp') if isinstance(book,dict) else None
                source_ts=_epoch_value(observed_ts)
                values['book_source_ts']=source_ts
                evidence.update(book=book,book_timestamps={'request_started_utc':_utc(quote_started),
                  'observed_utc':_utc(quoted),'source_timestamp_utc':_utc(source_ts) if source_ts else None,
                  'source_age_verified':source_ts is not None})
                with database.conn() as c:c.execute('UPDATE research_experiment_entries SET quote_started_ts=?,quoted_ts=?,book_source_ts=?,entry_json=? WHERE id=? AND status=\'PENDING\'',
                    (quote_started,quoted,source_ts,dump(evidence),entry_id))
                entry_horizon=end_ts-quoted
                values.update(entry_horizon_checked_ts=quoted,entry_horizon_seconds=entry_horizon,
                    entry_horizon_eligible=int(frozen_rules['min_seconds_to_end']<=entry_horizon<=frozen_rules['max_seconds_to_end']))
                evidence['entry_horizon']={'checked_at_utc':_utc(quoted),'remaining_seconds':entry_horizon,
                    'eligible':bool(values['entry_horizon_eligible'])}
                if (not all(math.isfinite(x) for x in (detected,market_received,fee_requested,fee_received,quote_started,quoted,signal_ts))
                    or market_received<detected-1 or fee_requested<market_received or fee_received<fee_requested
                    or quote_started<fee_received or quoted<quote_started or quote_started<detected-1
                    or quoted<signal_ts-5):reason='INVALID_TIME_ORDER'
                elif quoted>=ex['ends_at']:reason='EXPERIMENT_ENTRY_CUTOFF'
                elif not values['entry_horizon_eligible']:reason='OUTSIDE_HORIZON_AT_QUOTE'
                elif source_ts is None:reason='UNKNOWN_ORDER_BOOK_AGE'
                elif source_ts>quoted or quoted-source_ts>frozen_rules['max_book_age_seconds']:reason='STALE_ORDER_BOOK'
                else:
                    reason=validate_experiment_book(book)
                    if not reason:
                        bid,ask,spread=top_of_book(book)
                        sim=simulate_buy(book,frozen_rules['trade_notional_usd'],rate)
                        price=sim.get('avg_price') or 0
                        delay=quoted-signal_ts;adverse=max(0,price-float(trade.get('price') or 0))
                        evidence.update(spread=spread,delay_seconds=delay,adverse_move=adverse,simulation=sim)
                        minimum=float(market.get('minimum_order_size') or 0)
                        if not math.isfinite(minimum) or minimum<0:reason='INVALID_MINIMUM_ORDER'
                        elif delay>frozen_rules['max_signal_delay_seconds']:reason='STALE_AT_QUOTE'
                        elif spread is None or not math.isfinite(spread) or spread<0 or spread>frozen_rules['max_spread']:reason='SPREAD'
                        elif not sim.get('filled') or float(sim.get('unfilled_usd') or 0)>1e-6:reason='INSUFFICIENT_DEPTH'
                        elif float(sim.get('shares') or 0)<minimum:reason='BELOW_MINIMUM_ORDER'
                        elif not frozen_rules['min_price']<=price<=frozen_rules['max_price']:reason='PRICE_RANGE'
                        elif adverse>frozen_rules['max_adverse']:reason='PRICE_MOVED'
                        else:values.update(cost=sim['cost'],shares=sim['shares'],fee=sim['fee'],
                          expected_end_ts=end_ts,horizon_calculated_ts=calculation_at,horizon_seconds=horizon,
                          quote_started_ts=quote_started,quoted_ts=quoted,book_source_ts=source_ts)
    except Exception as exc:
        reason=reason or 'MARKET_DATA_UNAVAILABLE';evidence['data_error']=type(exc).__name__
    _finish_experiment_entry(database,entry_id,'OPEN' if not reason else 'SKIP',reason,evidence,values)
    return rows(database,'SELECT * FROM research_experiment_entries WHERE id=?',(entry_id,))[0]


async def refresh_experiment(database,client,now=None):
    """Close entry admission at day 14; settle open positions only on formal results."""
    now=float(now if now is not None else time.time())
    ex=_experiment(database)
    if not ex or ex['status']=='COMPLETED':return experiment_summary(database,now=now)
    # Pending work is never replayed against a later book. Give a live in-flight
    # capture time to finish; after that record it as a no-fill interruption.
    pending=rows(database,"SELECT * FROM research_experiment_entries WHERE experiment_id=? AND status='PENDING' AND detected_ts<?",
      (ex['id'],now-120))
    for item in pending:
        evidence=json.loads(item['entry_json']);evidence['recovery']={'result':'NO_FILL','reason':'process interrupted before quote was durably completed'}
        _finish_experiment_entry(database,item['id'],'SKIP','CRASH_RECOVERY_NO_FILL',evidence)
    # Raw non-seed rows inserted after activation but not journaled before a crash
    # are explicitly counted as missed opportunities, never simulated later.
    missing=rows(database,'''SELECT t.* FROM trades t JOIN research_experiment_wallets w ON w.wallet=t.wallet
      LEFT JOIN research_experiment_entries e ON e.experiment_id=w.experiment_id AND e.trade_key=t.trade_key
      WHERE w.experiment_id=? AND t.is_seed=0 AND e.id IS NULL
        AND NOT EXISTS (SELECT 1 FROM research_experiment_events x
          WHERE x.experiment_id=w.experiment_id AND x.event_type='SUPERSEDED_BY_WALLET_FOLLOW_V2')
        AND julianday(t.discovered_at)>=julianday(?) AND julianday(t.discovered_at)<julianday(?)
        AND julianday(t.discovered_at)<=julianday(?)
      ORDER BY t.timestamp LIMIT 200''',(ex['id'],ex['started_utc'],ex['ends_utc'],_utc(now-120)))
    for trade in missing:
        try:detected=datetime.fromisoformat(trade['discovered_at'].replace('Z','+00:00')).timestamp()
        except Exception:detected=now-120
        if not ex['started_at']<=detected<ex['ends_at']:
            continue
        evidence={'trade':dict(trade),'rules':json.loads(ex['rules_json']),'recovery':{'result':'NO_FILL','reason':'raw trade persisted without live experiment quote'}}
        with database.conn() as c:
            c.execute('''INSERT OR IGNORE INTO research_experiment_entries
              (experiment_id,trade_key,wallet,condition_id,token_id,event_id,title,outcome,leader_ts,detected_ts,status,reason,missing_data_count,entry_json)
              VALUES(?,?,?,?,?,?,?,?,?,?,'SKIP','CRASH_RECOVERY_NO_FILL',1,?)''',
              (ex['id'],trade['trade_key'],trade['wallet'],trade['condition_id'],trade['token_id'],trade['event_id'],
               trade['title'],trade['outcome'],trade['timestamp'],detected,dump(evidence)))
    open_positions=rows(database,"SELECT * FROM research_experiment_entries WHERE experiment_id=? AND status='OPEN' ORDER BY id LIMIT 200",(ex['id'],))
    semaphore=asyncio.Semaphore(max(1,int(settings.paper_refresh_concurrency)))
    async def refresh_position(pos):
        try:
            async with semaphore:
                market=await asyncio.wait_for(client.market_state(pos['token_id']),
                    timeout=settings.realtime_request_timeout_seconds)
            price=market.get('settlement_price')
            if market.get('resolved') and price is not None and math.isfinite(float(price)) and 0<=float(price)<=1:
                payout=float(price);pnl=float(pos['shares'])*payout-float(pos['cost'])-float(pos['fee']);settled=now
                with database.conn() as c:c.execute('''UPDATE research_experiment_entries SET status='SETTLED',pnl=?,unrealized_pnl=NULL,
                  settlement_price=?,settled_ts=?,settlement_delay_seconds=?,entry_json=json_set(entry_json,'$.settlement',json(?))
                  WHERE id=? AND status='OPEN' ''',(pnl,payout,settled,max(0,settled-(pos['expected_end_ts'] or settled)),
                  dump({'price':payout,'resolved_utc':_utc(settled)}),pos['id']))
            else:
                mark=market.get('current_price')
                unrealized=(float(pos['shares'])*float(mark)-float(pos['cost'])-float(pos['fee'])) if mark is not None and math.isfinite(float(mark)) and 0<=float(mark)<=1 else None
                with database.conn() as c:c.execute('''UPDATE research_experiment_entries SET unrealized_pnl=?,missing_data_count=missing_data_count+?,
                  entry_json=json_set(entry_json,'$.last_mark_utc',?) WHERE id=? AND status='OPEN' ''',(unrealized,int(unrealized is None),_utc(now),pos['id']))
        except Exception as exc:
            evidence=json.loads(pos['entry_json']);evidence['last_data_error']=type(exc).__name__
            with database.conn() as c:c.execute('''UPDATE research_experiment_entries SET unrealized_pnl=NULL,missing_data_count=missing_data_count+1,entry_json=? WHERE id=? AND status='OPEN' ''',(dump(evidence),pos['id']))
    await asyncio.gather(*(refresh_position(pos) for pos in open_positions))
    ex=_experiment(database,ex['id'])
    if ex and now>=ex['ends_at']:
        open_count=rows(database,"SELECT COUNT(*) n FROM research_experiment_entries WHERE experiment_id=? AND status IN ('OPEN','PENDING')",(ex['id'],))[0]['n']
        status='ENTRY_CLOSED' if open_count else 'COMPLETED'
        completed=_utc(now) if status=='COMPLETED' else None
        with database.conn() as c:c.execute('UPDATE research_experiments SET status=?,completed_utc=? WHERE id=? AND status IN (\'RUNNING\',\'ENTRY_CLOSED\')',(status,completed,ex['id']))
    return experiment_summary(database,ex['id'],now)

def audit(database, action, data):
    with database.conn() as c:
        c.execute('INSERT INTO research_audit(created_ts,action,data_json) VALUES(?,?,?)',(time.time(),action,dump(data)))

def excluded(database, wallet):
    with database.conn() as c:
        return bool(c.execute('SELECT 1 FROM research_exclusions WHERE wallet=?',(wallet,)).fetchone())

def exclude(database, wallet, restore=False):
    with database.conn() as c:
        if restore:
            c.execute('DELETE FROM research_exclusions WHERE wallet=?',(wallet,))
            c.execute("UPDATE wallet_candidates SET status='NEW' WHERE address=?",(wallet,))
        else:
            c.execute('INSERT OR REPLACE INTO research_exclusions VALUES(?,?,?)',(wallet,time.time(),'MANUAL_DELETE'))
            c.execute('UPDATE wallets SET tracked=0 WHERE address=?',(wallet,))
            c.execute("UPDATE wallet_candidates SET status='EXCLUDED' WHERE address=?",(wallet,))
            c.execute("UPDATE research_jobs SET state='CANCELLED' WHERE subject=? AND state='PENDING'",(wallet,))
    audit(database,'RESTORE' if restore else 'EXCLUDE',{'wallet':wallet})

def enqueue(database, kind, subject):
    with database.conn() as c:
        c.execute("INSERT OR IGNORE INTO research_jobs(kind,subject,state,created_ts) VALUES(?,?,'PENDING',?)",(kind,subject,time.time()))

def rows(database, sql, args=()):
    with database.conn() as c:
        return [dict(r) for r in c.execute(sql,args).fetchall()]

def entry(database, entry_id):
    r=rows(database,'SELECT * FROM research_entries WHERE id=?',(entry_id,))
    if not r: return None
    r=r[0]; r['evidence']=json.loads(r.pop('entry_json'))
    reported=rows(database,'SELECT reported_pnl,fetched_ts FROM research_leader_outcomes WHERE wallet=? AND condition_id=? AND token_id=?',(r['wallet'],r['condition_id'],r['token_id']))
    r['leader_reported_market_pnl']=reported[0] if reported else None
    return r

def metrics(data):
    settled=[x for x in data if x['status']=='SETTLED' and x.get('pnl') is not None]
    events=defaultdict(float)
    for x in settled: events[x.get('event_id') or x.get('condition_id') or x['token_id']]+=x['pnl']
    cost=sum((x.get('cost') or 0)+(x.get('fee') or 0) for x in settled)
    positive=sum(max(0,p) for p in events.values())
    equity=peak=drawdown=0.0
    for x in sorted(settled,key=lambda x:x.get('settled_ts') or 0):
        equity+=x['pnl']; peak=max(peak,equity); drawdown=max(drawdown,peak-equity)
    return dict(settled=len(settled), independent_events=len(events), pnl=sum(events.values()),
      roi=sum(events.values())/cost if cost else None, cost=cost, realized_drawdown=drawdown,
      top1_profit_share=max([0,*events.values()])/positive if positive else 1,
      open=sum(x['status']=='OPEN' for x in data),
      marked_pnl=sum(x.get('marked_pnl') or 0 for x in data if x['status']=='OPEN'))

def evidence(database,wallet):
    data=rows(database,'SELECT * FROM research_entries WHERE wallet=? ORDER BY id',(wallet,))
    recent=[]
    for x in data[-80:]:
        x=dict(x); ev=json.loads(x.pop('entry_json')); ev.pop('book',None); ev.pop('raw_trade',None)
        x['evidence']=ev; recent.append(x)
    versions=rows(database,'SELECT * FROM research_versions WHERE wallet=? ORDER BY id DESC LIMIT 3',(wallet,))
    w=database.get_wallet(wallet) or {}
    return dict(wallet=wallet,baseline=BASELINE,cutoff_id=max([0,*[x['id'] for x in data]]),
      historical_categories=w.get('category_stats',[]),historical_stats=w.get('stats',{}),
      totals=metrics(data),categories={k:metrics([x for x in data if x['category']==k]) for k in CATEGORIES},
      recent_entries=recent,versions=versions,sampling='latest 80 records; category aggregates use all local entries',
      caveats=['observed trades only; polling can miss trades','categories are heuristic','independent experiments, not a capital-constrained portfolio','leader_reference_pnl is hypothetical same-budget hold, not actual leader return'])

def consensus(database,trade,asof):
    # Observed recent net flow, not current complete holdings. Frozen before AI sees outcomes.
    condition=trade.get('condition_id')
    if not condition: return dict(support_groups=1,expert_groups=0,opposing_groups=0,independence='UNVERIFIED',members=[])
    ts=trade.get('timestamp') or asof
    data=rows(database,'''SELECT t.* FROM trades t JOIN wallets w ON w.address=t.wallet
      WHERE condition_id=? AND timestamp BETWEEN ? AND ? AND w.tracked=1''',(condition,asof-1800,asof))
    identities={x['wallet']:x['group_id'] for x in rows(database,'SELECT * FROM research_identity')}
    flows=defaultdict(float)
    for t in data:
        direction=(1 if t['token_id']==trade['token_id'] else -1)*(1 if t['side']=='BUY' else -1)
        flows[t['wallet']]+=direction*(t.get('usd_value') or (t.get('price') or 0)*(t.get('size') or 0))
    groups=defaultdict(list); members=[]
    for wallet,value in flows.items():
        w=database.get_wallet(wallet) or {}
        cat=next((x for x in w.get('category_stats',[]) if x['category']==trade.get('category')), {})
        expert=cat.get('market_count',0)>=8 and cat.get('pnl',0)>0 and cat.get('roi',0)>0
        group=identities.get(wallet) or wallet
        groups[group].append((value,expert)); members.append(dict(wallet=wallet,net_observed_usd=value,expert=expert,group=group))
    support=opposing=experienced=0
    for vals in groups.values():
        # Mixed opinions inside one known entity do not count as an independent supportive vote.
        if all(v>0 for v,_ in vals):
            support+=1; experienced+=int(any(e for _,e in vals))
        elif all(v<0 for v,_ in vals): opposing+=1
    return dict(support_groups=support,expert_groups=experienced,opposing_groups=opposing,
      independence='UNVERIFIED',window_seconds=1800,members=members,warning='Not a probability estimate; hidden hedges and shared information are unknown')

def matches(rule,trade,price,delay,adverse,votes):
    r=Rule.model_validate(rule)
    return (trade.get('category') in r.categories and r.min_price<=price<=r.max_price
      and delay<=r.max_delay and adverse<=r.max_adverse
      and (not r.title_keywords or any(k.lower() in trade.get('title','').lower() for k in r.title_keywords))
      and (votes.get('support_groups',0)>=1 if r.min_consensus==1 else votes.get('expert_groups',0)>=r.min_consensus))

async def capture(database,client,wallet,trade):
    address=wallet['address']; now=time.time()
    with database.conn() as c:
        c.execute('''INSERT OR IGNORE INTO research_entries(trade_key,wallet,condition_id,token_id,event_id,category,
          title,outcome,leader_ts,detected_ts,leader_price,status,entry_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,'PENDING',?)''',
          (trade['trade_key'],address,trade.get('condition_id'),trade.get('token_id'),trade.get('event_id'),trade.get('category'),
           trade.get('title'),trade.get('outcome'),trade.get('timestamp'),now,trade.get('price'),dump({'trade':trade,'baseline':BASELINE})))
        item=dict(c.execute('SELECT * FROM research_entries WHERE trade_key=?',(trade['trade_key'],)).fetchone())
    if item['status']!='PENDING': return item
    ev=json.loads(item['entry_json'])
    if 'frozen_version' not in ev:
        ev['consensus']=consensus(database,trade,now)
        versions=rows(database,"SELECT * FROM research_versions WHERE wallet=? AND state IN ('SHADOW','VALIDATED') ORDER BY id DESC LIMIT 1",(address,))
        ev['frozen_version']=versions[0] if versions else None
        with database.conn() as c:
            c.execute("UPDATE research_entries SET entry_json=? WHERE id=? AND status='PENDING'",(dump(ev),item['id']))
    version=ev['frozen_version']
    reason=None; sim={}; market={}; selected=False; quoted=now
    try:
        if excluded(database,address): reason='MANUALLY_EXCLUDED'
        elif trade.get('side')!='BUY': reason='EXIT_ARCHIVED_HOLD_EXPERIMENT'
        elif not trade.get('token_id') or not trade.get('condition_id'): reason='MISSING_MARKET_ID'
        elif not 0<float(trade.get('price') or 0)<1: reason='INVALID_LEADER_PRICE'
        elif not trade.get('timestamp') or not -5<=now-trade['timestamp']<=BASELINE['max_delay']: reason='STALE_OR_INVALID_TIMESTAMP'
        elif rows(database,"SELECT id FROM research_entries WHERE wallet=? AND condition_id=? AND status IN ('OPEN','SETTLED') LIMIT 1",(address,trade['condition_id'])):
            reason='EXPERIMENT_ALREADY_EXISTS'
        else:
            market=await client.market_state(trade['token_id'])
            ev['market']=market
            if market.get('closed') or market.get('accepting_orders') is False: reason='MARKET_CLOSED'
            elif not market.get('description') or not market.get('end_timestamp'): reason='MISSING_RESOLUTION_RULES'
            elif market['end_timestamp']-time.time()<BASELINE['min_seconds_to_end']: reason='NEAR_END'
            else:
                fee=await client.research_fee(trade['condition_id'],market)
                ev['fee_schedule']=fee
                book=await client.orderbook(trade['token_id']); quoted=time.time()
                ev['book']=book
                bid,ask,spread=top_of_book(book)
                sim=simulate_buy(book,BASELINE['budget'],fee['rate'])
                price=sim.get('avg_price') or 0
                delay=quoted-trade['timestamp']; adverse=max(0,price-trade['price'])
                ev.update(spread=spread,delay_seconds=delay,adverse_move=adverse,simulation=sim)
                if delay>BASELINE['max_delay']: reason='STALE_AT_QUOTE'
                elif spread is None or spread<0 or spread>BASELINE['max_spread']: reason='SPREAD'
                elif not sim['filled'] or sim['unfilled_usd']>1e-6: reason='INSUFFICIENT_DEPTH'
                elif not BASELINE['min_price']<=price<=BASELINE['max_price']: reason='PRICE_RANGE'
                elif adverse>BASELINE['max_adverse']: reason='PRICE_MOVED'
                elif BASELINE['budget']<float(market.get('minimum_order_size') or 0): reason='BELOW_MINIMUM_ORDER'
                else:
                    selected=bool(version and matches(json.loads(version['rule_json']),trade,price,delay,adverse,ev['consensus']))
        if excluded(database,address): reason='MANUALLY_EXCLUDED'; selected=False
    except Exception as exc:
        reason='MARKET_DATA_UNAVAILABLE'; ev['error']=str(exc)[:300]
    status='SKIP' if reason else 'OPEN'
    with database.conn() as c:
        # Another coroutine may have completed this same persisted claim.
        c.execute('''UPDATE research_entries SET status=?,reason=?,entry_json=?,quoted_ts=?,version_id=?,selected=?,
          event_id=?,cost=?,shares=?,fee=? WHERE id=? AND status='PENDING' ''',
          (status,reason,dump(ev),quoted,version['id'] if version else None,int(selected),
           market.get('event_id') or trade.get('event_id'),sim.get('cost') if not reason else None,
           sim.get('shares') if not reason else None,sim.get('fee') if not reason else None,item['id']))
    if ev['consensus'].get('expert_groups',0)>=2: enqueue(database,'MARKET',str(item['id']))
    return entry(database,item['id'])

def propose(database,wallet,review,context):
    r=Review.model_validate(review)
    available={x['id'] for x in context.get('recent_entries',[])}
    if not set(r.supporting_entry_ids)<=available: raise ValueError('AI cited absent entry IDs')
    if excluded(database,wallet): return None
    if r.rule is None or r.recommendation in ('OBSERVE','PAUSE'): return None
    if not r.supporting_entry_ids or context.get('totals',{}).get('independent_events',0)<8: return None
    with database.conn() as c:
        current=c.execute("SELECT * FROM research_versions WHERE wallet=? AND state IN ('SHADOW','VALIDATED') ORDER BY id DESC LIMIT 1",(wallet,)).fetchone()
        if current and (current['state']=='SHADOW' or json.loads(current['rule_json'])==r.rule.model_dump()): return None
        if current: c.execute("UPDATE research_versions SET state='REPLACED' WHERE id=?",(current['id'],))
        cursor=c.execute("INSERT INTO research_versions(wallet,created_ts,cutoff_id,state,rule_json,review_json) VALUES(?,?,?,'SHADOW',?,?)",
          (wallet,time.time(),context['cutoff_id'],dump(r.rule.model_dump()),dump(r.model_dump())))
        return cursor.lastrowid

def evaluate(database):
    for v in rows(database,"SELECT * FROM research_versions WHERE state IN ('SHADOW','VALIDATED')"):
        data=rows(database,'SELECT * FROM research_entries WHERE version_id=? AND id>?',(v['id'],v['cutoff_id']))
        selected=metrics([x for x in data if x['selected']]); baseline=metrics(data)
        state=v['state']
        if selected['independent_events']>=20:
            valid=(selected['pnl']>0 and selected['roi']>=max(0,baseline['roi'] or 0)
              and selected['top1_profit_share']<=.35 and selected['realized_drawdown']<=125)
            state='VALIDATED' if valid else 'REJECTED'
        with database.conn() as c:
            c.execute('UPDATE research_versions SET state=?,validation_json=? WHERE id=?',(state,dump({'selected':selected,'baseline':baseline,'minimum_future_events':20}),v['id']))
        if state!=v['state']:
            audit(database,'STRATEGY_'+state,dict(id=v['id'],wallet=v['wallet']))
            if state=='REJECTED': enqueue(database,'WALLET',v['wallet'])

async def refresh(database,client):
    # Recover crash between raw-trade persistence and journal claim; ignore legacy history.
    missing=rows(database,'''SELECT t.* FROM trades t LEFT JOIN research_entries e ON t.trade_key=e.trade_key
      WHERE e.id IS NULL AND t.is_seed=0 AND t.discovered_at>=(SELECT value FROM system_state WHERE key='research_started_at')
      ORDER BY t.timestamp LIMIT 20''')
    for t in missing:
        from datetime import datetime
        if time.time()-datetime.fromisoformat(t['discovered_at']).timestamp()<120:
            continue
        await capture(database,client,{'address':t['wallet']},t)
    # A pending claim may have been interrupted after the signal was detected.
    # Never reconstruct that historical fill from a later order book.
    for x in rows(database,"SELECT * FROM research_entries WHERE status='PENDING' AND detected_ts<? LIMIT 20",(time.time()-120,)):
        ev=json.loads(x['entry_json']);ev['recovery']={'result':'NO_FILL','reason':'interrupted before a durable quote was recorded'}
        with database.conn() as c:c.execute("UPDATE research_entries SET status='SKIP',reason='CRASH_RECOVERY_NO_FILL',entry_json=? WHERE id=? AND status='PENDING'",(dump(ev),x['id']))
    for x in rows(database,"SELECT * FROM research_entries WHERE status='OPEN' ORDER BY COALESCE(mark_ts,0) LIMIT 30"):
        now=time.time()
        try:
            market=await client.market_state(x['token_id'])
            if market.get('resolved') and market.get('settlement_price') is not None:
                payout=market['settlement_price']; pnl=x['shares']*payout-x['cost']-x['fee']
                ref=BASELINE['budget']/x['leader_price']*payout-BASELINE['budget']
                with database.conn() as c:
                    c.execute("UPDATE research_entries SET status='SETTLED',pnl=?,leader_reference_pnl=?,settled_ts=?,settlement_price=?,mark_ts=? WHERE id=? AND status='OPEN'",(pnl,ref,now,payout,now,x['id']))
                enqueue(database,'WALLET',x['wallet'])
            else:
                fee=await client.research_fee(x['condition_id'],market)
                book=await client.orderbook(x['token_id']); sim=simulate_sell(book,x['shares'],fee['rate'])
                pnl=sim['proceeds']-sim['fee']-x['cost']-x['fee'] if sim['unfilled_shares']<1e-6 else None
                with database.conn() as c: c.execute('UPDATE research_entries SET marked_pnl=?,mark_ts=? WHERE id=?',(pnl,now,x['id']))
        except Exception as exc:
            with database.conn() as c: c.execute('UPDATE research_entries SET marked_pnl=NULL,mark_ts=? WHERE id=?',(now,x['id']))
            audit(database,'REFRESH_ERROR',{'entry_id':x['id'],'error':str(exc)[:200]})
    evaluate(database)

async def refresh_leader(database,client,wallet):
    positions=await client.positions(wallet,'CLOSED')
    with database.conn() as c:
        for p in positions:
            condition=str(p.get('condition_id') or p.get('conditionId') or '')
            token=str(p.get('token_id') or p.get('asset') or p.get('asset_id') or '')
            realized=p.get('realized_pnl',p.get('realizedPnl'))
            if condition and token and realized is not None and math.isfinite(float(realized)):
                c.execute('INSERT OR REPLACE INTO research_leader_outcomes VALUES(?,?,?,?,?,?)',
                  (wallet,condition,token,time.time(),float(realized),dump(p)))
