"""Conservative cross-source fill aliases; no timestamp/fuzzy ownership claims."""
from __future__ import annotations

import hashlib
import json
import re
from decimal import Decimal, InvalidOperation, localcontext

HEX32 = re.compile(r'^0x[0-9a-fA-F]{64}$')
ADDRESS = re.compile(r'^0x[0-9a-fA-F]{40}$')

SCHEMA = """
CREATE TABLE IF NOT EXISTS fill_canonical (
 canonical_id TEXT PRIMARY KEY, trade_key TEXT NOT NULL, wallet TEXT NOT NULL,
 tx_hash TEXT NOT NULL, token_id TEXT NOT NULL, side TEXT NOT NULL,
 economics TEXT, strong_identity INTEGER NOT NULL, receipt_unique INTEGER NOT NULL,
 first_source TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_fill_domain ON fill_canonical(wallet,tx_hash,token_id,side);
CREATE TABLE IF NOT EXISTS fill_source_observations (
 wallet TEXT NOT NULL, source TEXT NOT NULL, source_id TEXT NOT NULL,
 canonical_id TEXT, state TEXT NOT NULL, observed_at TEXT NOT NULL, evidence_json TEXT NOT NULL,
 PRIMARY KEY(wallet,source,source_id));
CREATE TABLE IF NOT EXISTS fill_identity_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT,wallet TEXT NOT NULL,source TEXT NOT NULL,
 source_id TEXT NOT NULL,state TEXT NOT NULL,observed_at TEXT NOT NULL,evidence_json TEXT NOT NULL);
"""

def decimal_text(value):
    if isinstance(value, bool) or value is None:
        raise ValueError('INVALID_FILL_AMOUNT')
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError('INVALID_FILL_AMOUNT') from None
    if not number.is_finite() or number <= 0:
        raise ValueError('INVALID_FILL_AMOUNT')
    return format(number, 'f')

def economics(trade):
    """Exact source values only. Rounded/missing evidence is never fuzzy-matched."""
    raw = trade.get('raw') if isinstance(trade.get('raw'), dict) else {}
    try:
        size = Decimal(decimal_text(raw.get('size')))
        with localcontext() as ctx:
            ctx.prec = 100
            usd = Decimal(decimal_text(raw['usd_value'])) if 'usd_value' in raw else size * Decimal(decimal_text(raw.get('price')))
            return json.dumps([format(size.normalize(), 'f'), format(usd.normalize(), 'f')])
    except (ValueError, InvalidOperation):
        return None

def strong_key(evidence):
    if not isinstance(evidence, dict):
        return None
    try:
        chain_value=evidence['chain_id']
        if isinstance(chain_value,bool) or not isinstance(chain_value,(str,int)):return None
        chain = int(chain_value,16) if isinstance(chain_value,str) and chain_value.startswith('0x') else int(chain_value)
        index = evidence['log_index']
        if isinstance(index,bool) or not isinstance(index,(str,int)):return None
        index = int(index, 16) if isinstance(index, str) and index.startswith('0x') else int(index)
        contract = str(evidence['contract_address']).lower()
        tx = str(evidence['transaction_hash']).lower()
        if chain != 137 or index < 0 or not ADDRESS.fullmatch(contract) or not HEX32.fullmatch(tx):
            return None
        return f'polygon:{chain}:{contract}:{tx}:{index}'
    except (KeyError, ValueError, TypeError):
        return None

def claim_identity(con, wallet, trade, source, now):
    """Runs inside the same IMMEDIATE/write transaction as the raw trade claim.

    Return False for an auditable ambiguous observation, never an inferred duplicate.
    Receipt uniqueness is established by the producer from ALL supported logs in a
    complete receipt, not from the number of events that happened to arrive so far.
    """
    tx = str(trade.get('tx_hash') or '').lower()
    if not HEX32.fullmatch(tx):
        if source not in {'DATA_API_POLL', 'FAST_PATH'}:
            return True  # Non-live legacy/import callers retain their trade-key gate.
        # A source ID alone cannot reconcile a live observation with a chain fill.
        # Preserve evidence without claiming canonical or execution ownership.
        state = 'AMBIGUOUS_INSUFFICIENT_TRANSACTION_IDENTITY'
        source_id = str(trade['trade_key'])
        evidence = json.dumps({'trade':trade,'match_method':state},sort_keys=True,default=str)
        con.execute('INSERT INTO fill_identity_audit(wallet,source,source_id,state,observed_at,evidence_json) VALUES(?,?,?,?,?,?)',
            (wallet,source,source_id,state,now,evidence))
        con.execute('INSERT OR IGNORE INTO fill_source_observations VALUES(?,?,?,?,?,?,?)',
            (wallet,source,source_id,None,state,now,evidence))
        trade['_canonical_state'] = state
        return False
    raw = trade.get('raw') if isinstance(trade.get('raw'), dict) else {}
    chain_evidence=raw.get('_chain_fill')
    if chain_evidence is None:
        # Use source-provided fields only; Data API usually lacks contract/log index.
        chain_evidence={'chain_id':raw.get('chain_id',raw.get('chainId')),
            'contract_address':raw.get('contract_address',raw.get('contractAddress')),
            'transaction_hash':raw.get('transaction_hash',raw.get('transactionHash')),
            'log_index':raw.get('log_index',raw.get('logIndex'))}
    key = strong_key(chain_evidence)
    if key and str(chain_evidence['transaction_hash']).lower()!=tx:key=None
    unique = raw.get('_receipt_unique') is True
    value = economics(trade)
    source_id = str(trade['trade_key'])
    token = str(trade.get('token_id') or '')
    side = str(trade.get('side') or '').upper()
    domain = (wallet, tx, token, side)
    state = 'FIRST_SOURCE'
    canonical = key or 'source:' + hashlib.sha256(json.dumps([wallet,source,source_id]).encode()).hexdigest()
    prior = con.execute('SELECT * FROM fill_canonical WHERE canonical_id=?', (canonical,)).fetchone()
    aliases = con.execute('SELECT * FROM fill_canonical WHERE wallet=? AND tx_hash=? AND token_id=? AND side=?', domain).fetchall()
    if prior is not None:
        if (prior['wallet'],prior['tx_hash'],prior['token_id'],prior['side'],prior['economics'])!=(*domain,value):
            state='AMBIGUOUS_CHAIN_EVIDENCE_CONFLICT'
        elif key:state='DUPLICATE_EXACT_CHAIN'
        elif any(raw.get(k) for k in ('id','trade_id','tradeId')):state='DUPLICATE_SOURCE_ID'
        else:state='AMBIGUOUS_UNKEYED_REPEAT'
    else:
        opposite = [row for row in aliases if row['first_source'] != source]
        if opposite:
            matches = [row for row in opposite if value is not None and row['economics'] == value]
            # Chain-to-chain distinct indexes NEVER collapse, even if economic values match.
            matches = [row for row in matches if not (key and row['strong_identity'])]
            matches = list({row['trade_key']:row for row in matches}.values())
            if len(matches) == 1 and ((key and unique and not matches[0]['strong_identity']) or
                                     (not key and matches[0]['strong_identity'] and matches[0]['receipt_unique'])):
                prior = matches[0]
                state = 'DUPLICATE_RECEIPT_EXACT_ECONOMICS'
                # Persist the strong alias without replacing the first source's raw row.
                if key:
                    con.execute('INSERT OR IGNORE INTO fill_canonical VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                        (key,prior['trade_key'],*domain,value,1,1,source,now))
                canonical = prior['canonical_id']
            elif not (key and all(row['strong_identity'] for row in opposite)):
                state = 'AMBIGUOUS_CROSS_SOURCE_IDENTITY'
    evidence = json.dumps({'trade':trade,'match_method':state},sort_keys=True,default=str)
    con.execute('INSERT INTO fill_identity_audit(wallet,source,source_id,state,observed_at,evidence_json) VALUES(?,?,?,?,?,?)',
        (wallet,source,source_id,state,now,evidence))
    con.execute('INSERT OR IGNORE INTO fill_source_observations VALUES(?,?,?,?,?,?,?)',
        (wallet,source,source_id,canonical if not state.startswith('AMBIGUOUS') else None,state,now,evidence))
    if state.startswith('AMBIGUOUS'):
        trade['_canonical_state'] = state
        return False
    if prior is not None:
        trade['trade_key'] = prior['trade_key']
        trade['_canonical_state'] = state
        return True  # existing INSERT OR IGNORE/raw source evidence suppresses execution
    con.execute('INSERT INTO fill_canonical VALUES(?,?,?,?,?,?,?,?,?,?,?)',
        (canonical,source_id,*domain,value,int(key is not None),int(unique),source,now))
    trade['_canonical_state'] = state
    return True
