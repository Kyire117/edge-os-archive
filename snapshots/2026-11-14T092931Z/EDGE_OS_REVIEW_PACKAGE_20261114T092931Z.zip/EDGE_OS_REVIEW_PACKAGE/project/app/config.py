from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from edge_runtime import active_database


def _f(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _i(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _b(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    polygon_wss_url: str = field(default=os.getenv("POLYGON_WSS_URL", ""),repr=False)
    polygon_fast_enabled: bool = _b("POLYGON_FAST_ENABLED", False)
    polygon_confirmation_depth: int = _i("POLYGON_CONFIRMATION_DEPTH", 1)
    polygon_backfill_blocks: int = _i("POLYGON_BACKFILL_BLOCKS", 128)
    polygon_exchange_contracts: str = os.getenv("POLYGON_EXCHANGE_CONTRACTS", "0xE111180000d2663C0091e4f400237545B87B996B,0xe2222d279d744050d28e00520010520000310F59")
    research_enabled: bool = _b("RESEARCH_ENABLED", True)
    database_path: str = os.getenv("DATABASE_PATH", str(active_database()))
    poll_interval_seconds: int = _i("POLL_INTERVAL_SECONDS", 2)
    monitor_max_concurrency: int = _i("MONITOR_MAX_CONCURRENCY", 8)
    realtime_request_timeout_seconds: float = _f("REALTIME_REQUEST_TIMEOUT_SECONDS", 8.0)
    realtime_trade_limit: int = _i("REALTIME_TRADE_LIMIT", 25)
    realtime_page_size: int = _i("REALTIME_PAGE_SIZE", 25)
    realtime_pages_per_slice: int = _i("REALTIME_PAGES_PER_SLICE", 3)
    realtime_process_limit_per_slice: int = _i("REALTIME_PROCESS_LIMIT_PER_SLICE", 75)
    paper_refresh_seconds: int = _i("PAPER_REFRESH_SECONDS", 15)
    paper_refresh_concurrency: int = _i("PAPER_REFRESH_CONCURRENCY", 6)
    paper_trade_usd: float = _f("PAPER_TRADE_USD", 100.0)
    max_paper_trade_usd: float = _f("MAX_PAPER_TRADE_USD", 250.0)
    min_copy_edge: float = _f("MIN_COPY_EDGE", 0.02)
    watch_edge: float = _f("WATCH_EDGE", 0.00)
    safety_margin: float = _f("SAFETY_MARGIN", 0.01)
    max_adverse_move: float = _f("MAX_ADVERSE_MOVE", 0.06)
    max_spread: float = _f("MAX_SPREAD", 0.08)
    min_trader_skill: float = _f("MIN_TRADER_SKILL", 55.0)
    min_closed_markets: int = _i("MIN_CLOSED_MARKETS", 8)
    max_history_trades: int = _i("MAX_HISTORY_TRADES", 2000)
    max_positions: int = _i("MAX_POSITIONS", 2000)
    request_timeout_seconds: float = _f("REQUEST_TIMEOUT_SECONDS", 60.0)
    decay_max_concurrency: int = _i("DECAY_MAX_CONCURRENCY", 6)
    # Slow-alpha signals can remain actionable several minutes after the
    # leader fill, so keep them eligible through the longest core window.
    stale_signal_seconds: int = _i("STALE_SIGNAL_SECONDS", 900)
    auto_pause_enabled: bool = _b("AUTO_PAUSE_ENABLED", True)
    auto_pause_min_samples: int = _i("AUTO_PAUSE_MIN_SAMPLES", 5)
    max_follow_delay_seconds: float = _f("MAX_FOLLOW_DELAY_SECONDS", 60.0)
    max_local_scan_seconds: float = _f("MAX_LOCAL_SCAN_SECONDS", 10.0)
    discovery_enabled: bool = _b("DISCOVERY_ENABLED", True)
    discovery_interval_seconds: int = _i("DISCOVERY_INTERVAL_SECONDS", 21600)
    discovery_start_delay_seconds: int = _i("DISCOVERY_START_DELAY_SECONDS", 10)
    discovery_board_limit: int = _i("DISCOVERY_BOARD_LIMIT", 30)
    discovery_analyze_per_cycle: int = _i("DISCOVERY_ANALYZE_PER_CYCLE", 3)
    discovery_max_tracked: int = _i("DISCOVERY_MAX_TRACKED", 20)
    discovery_min_skill: float = _f("DISCOVERY_MIN_SKILL", 65.0)
    discovery_max_top1_concentration: float = _f("DISCOVERY_MAX_TOP1_CONCENTRATION", 0.65)
    # Candidate research budget. These are soft reservations: unused slots
    # may be borrowed so discovery never stalls on an empty pool.
    discovery_slow_share: float = _f("DISCOVERY_SLOW_SHARE", 0.70)
    discovery_fast_share: float = _f("DISCOVERY_FAST_SHARE", 0.20)
    discovery_explore_share: float = _f("DISCOVERY_EXPLORE_SHARE", 0.10)
    alpha_min_forward_markets: int = _i("ALPHA_MIN_FORWARD_MARKETS", 5)
    alpha_min_settled_markets: int = _i("ALPHA_MIN_SETTLED_MARKETS", 3)
    slow_alpha_horizon_seconds: int = _i("SLOW_ALPHA_HORIZON_SECONDS", 120)
    slow_alpha_confirmation_horizon_seconds: int = _i("SLOW_ALPHA_CONFIRMATION_HORIZON_SECONDS", 300)
    slow_alpha_min_fillability: float = _f("SLOW_ALPHA_MIN_FILLABILITY", 0.80)
    slow_alpha_min_net_edge: float = _f("SLOW_ALPHA_MIN_NET_EDGE", 0.02)
    slow_alpha_min_profitable_rate: float = _f("SLOW_ALPHA_MIN_PROFITABLE_RATE", 0.55)
    signal_settlement_refresh_seconds: int = _i("SIGNAL_SETTLEMENT_REFRESH_SECONDS", 900)
    signal_settlement_batch_tokens: int = _i("SIGNAL_SETTLEMENT_BATCH_TOKENS", 100)

    data_api: str = "https://data-api.polymarket.com"
    clob_api: str = "https://clob.polymarket.com"
    gamma_api: str = "https://gamma-api.polymarket.com"

    def ensure_dirs(self) -> None:
        Path(self.database_path).parent.mkdir(parents=True, exist_ok=True)


settings = Settings()
