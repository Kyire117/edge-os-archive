from __future__ import annotations

import math
import re
from collections import defaultdict
from typing import Any


CATEGORY_KEYWORDS: dict[str, tuple[str, ...]] = {
    "Crypto": ("bitcoin", "btc", "ethereum", "eth", "solana", "sol", "crypto", "xrp", "doge", "token"),
    "Politics": ("election", "president", "senate", "congress", "democrat", "republican", "trump", "vance", "newsom", "governor", "primary", "poll"),
    "Geopolitics": ("iran", "israel", "gaza", "ukraine", "russia", "china", "taiwan", "war", "ceasefire", "nato", "strait", "geopolit"),
    "Macro": ("fed", "fomc", "interest rate", "inflation", "cpi", "gdp", "recession", "unemployment", "jobs report", "economy", "treasury"),
    "Sports": ("nba", "nfl", "mlb", "nhl", "ufc", "soccer", "football", "basketball", "baseball", "tennis", "championship", "match", "game"),
    "Tech": ("openai", "apple", "google", "meta", "microsoft", "nvidia", "ai ", "artificial intelligence", "launch", "iphone", "spacex"),
    "Culture": ("movie", "album", "oscar", "grammy", "box office", "celebrity", "music", "netflix", "spotify", "youtube"),
    "Weather": ("weather", "temperature", "hurricane", "storm", "rain", "snow", "heat", "degrees"),
}

FEE_RATE_BY_CATEGORY = {
    "Crypto": 0.07,
    "Sports": 0.05,
    "Macro": 0.05,
    "Culture": 0.05,
    "Weather": 0.05,
    "Tech": 0.04,
    "Politics": 0.04,
    "Geopolitics": 0.0,
    "Other": 0.05,
}


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return default
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def category_for(text: str | None, explicit: str | None = None) -> str:
    if explicit:
        e = explicit.strip().lower()
        mapping = {
            "crypto": "Crypto", "politics": "Politics", "geopolitics": "Geopolitics",
            "sports": "Sports", "tech": "Tech", "technology": "Tech", "culture": "Culture",
            "weather": "Weather", "finance": "Macro", "economics": "Macro", "economy": "Macro",
            "macro": "Macro",
        }
        if e in mapping:
            return mapping[e]
    t = f" {text or ''} ".lower()
    for category, words in CATEGORY_KEYWORDS.items():
        if any(w in t for w in words):
            return category
    return "Other"


def _position_values(p: dict[str, Any]) -> tuple[float, float, float, float]:
    cost = safe_float(p.get("total_cost_usdc", p.get("entry_cost_usdc", p.get("initialValue", 0))))
    realized = safe_float(p.get("realized_pnl", p.get("cashPnl", 0)))
    total_pnl = safe_float(p.get("total_pnl", realized + safe_float(p.get("unrealized_pnl", 0))))
    avg_price = safe_float(p.get("avg_price", p.get("avgPrice", 0)))
    return cost, realized, total_pnl, avg_price


def _title(p: dict[str, Any]) -> str:
    return str(p.get("title") or p.get("name") or p.get("question") or "Unknown market")


def _drawdown_from_points(points: list[dict[str, Any]]) -> float:
    if not points:
        return 0.0
    vals = []
    for pt in points:
        v = pt.get("economic_pnl")
        if v is None:
            v = pt.get("realized_pnl")
        if v is None:
            v = pt.get("trade_pnl")
        if v is not None:
            vals.append(safe_float(v))
    if not vals:
        return 0.0
    peak = vals[0]
    max_dd = 0.0
    for v in vals:
        peak = max(peak, v)
        max_dd = max(max_dd, peak - v)
    return max_dd


def _band(value: float, bands: list[tuple[float, float, str]]) -> str:
    for lo, hi, name in bands:
        if lo <= value < hi:
            return name
    return bands[-1][2]


def wallet_card_data(wallet: dict[str, Any], paper: dict[str, Any] | None = None) -> dict[str, Any]:
    """Presentation metrics with explicit denominators and provenance."""
    stats = wallet.get("stats") or {}
    analytics = wallet.get("analytics") or {}
    settled = max(0, int(stats.get("profitable_position_denominator") or stats.get("closed_market_count") or 0))
    wins = max(0, min(settled, int(stats.get("wins") or 0)))
    categories = []
    for row in analytics.get("category_breakdown") or wallet.get("category_stats") or []:
        count = max(0, int(row.get("market_count") or 0))
        positive = max(0, min(count, int(row.get("profitable_count") or 0)))
        categories.append({"category": str(row.get("category") or "Other"), "settled_positions": count,
                           "profitable_positions": positive, "profitable_rate": positive / count if count else None,
                           "historical_pnl": safe_float(row.get("pnl"))})
    observed = analytics.get("frequent_categories") or [
        {"category": row["category"], "observed_positions": row["settled_positions"],
         "settled_positions": row["settled_positions"]} for row in categories]
    observed = sorted(observed, key=lambda row: (-int(row.get("observed_positions") or 0), str(row.get("category") or "")))
    top = observed[0] if observed else None
    price_bands = sorted((analytics.get("entry_price_breakdown") or []), key=lambda row: -(row.get("count") or 0))
    price = price_bands[0] if price_bands and price_bands[0].get("count") else None
    sentences = [
        f"观察到的持仓主要集中在{top['category']}，共 {top['observed_positions']} 个持仓。" if top else "目前没有足够的持仓资料判断常交易分类。",
        f"已结算持仓中有 {wins}/{settled} 个盈利，盈利占比 {wins / settled:.1%}。" if settled else "目前没有可计算盈利占比的已结算持仓样本。",
        f"已结算样本最常见的入场价格区间为 {price['band']}，共 {price['count']} 个持仓。" if price else "目前没有足够的入场价格资料判断下单习惯。",
    ]
    return {
        "identity": wallet.get("public_profile"),
        "frequent_categories": observed,
        "categories": categories,
        "profitable_settled_positions": wins,
        "settled_position_sample": settled,
        "profitable_position_rate": wins / settled if settled else None,
        "leader_historical_realized_pnl": stats.get("realized_pnl") if stats else None,
        "leader_historical_unrealized_pnl": stats.get("open_total_pnl") if stats else None,
        "leader_historical_total_pnl": stats.get("overall_pnl") if stats else None,
        "leader_pnl_source": stats.get("pnl_source") or "LEGACY_WALLET_ANALYSIS",
        "leader_pnl_window": stats.get("pnl_window") or "analysis_snapshot_unknown_coverage",
        "position_source": "DATA_API_FETCHED_POSITIONS",
        "position_window": "sample_through_analysis",
        "analyzed_at_utc": stats.get("analyzed_at_utc"),
        "copyability": analytics.get("copyability") or {},
        "paper": paper or {},
        "style_sentences": sentences,
    }


def analyze_wallet(
    address: str,
    closed_positions: list[dict[str, Any]],
    open_positions: list[dict[str, Any]],
    profile_stats: dict[str, Any] | None = None,
    volume_stats: dict[str, Any] | None = None,
    pnl_points: list[dict[str, Any]] | None = None,
) -> tuple[dict[str, Any], dict[str, Any], str]:
    profile_stats = profile_stats or {}
    volume_stats = volume_stats or {}
    pnl_points = pnl_points or []
    all_positions = closed_positions + open_positions

    closed_rows = []
    for p in closed_positions:
        cost, realized, total_pnl, avg_price = _position_values(p)
        title = _title(p)
        category = category_for(title, p.get("category"))
        closed_rows.append({"cost": cost, "pnl": realized if realized or not total_pnl else total_pnl, "avg_price": avg_price, "title": title, "category": category})

    total_cost = sum(max(0.0, x["cost"]) for x in closed_rows)
    realized_pnl = sum(x["pnl"] for x in closed_rows)
    profile_pnl = profile_stats.get("all_time_pnl") or {}
    official_realized = profile_pnl.get("realized_pnl")
    official_trade_pnl = profile_pnl.get("trade_pnl")
    if official_realized is not None:
        realized_pnl = safe_float(official_realized)
    elif official_trade_pnl is not None:
        realized_pnl = safe_float(official_trade_pnl)

    open_total_pnl = sum(_position_values(p)[2] for p in open_positions)
    overall_pnl = realized_pnl + open_total_pnl
    roi = (realized_pnl / total_cost) if total_cost > 0 else 0.0
    wins = sum(1 for x in closed_rows if x["pnl"] > 0)
    losses = sum(1 for x in closed_rows if x["pnl"] < 0)
    win_rate = wins / len(closed_rows) if closed_rows else 0.0

    positive = sorted((x["pnl"] for x in closed_rows if x["pnl"] > 0), reverse=True)
    positive_total = sum(positive)
    def concentration(n: int) -> float:
        return sum(positive[:n]) / positive_total if positive_total > 0 else 0.0

    max_drawdown = _drawdown_from_points(pnl_points)
    if not max_drawdown and closed_rows:
        running = 0.0
        peak = 0.0
        for x in closed_rows:
            running += x["pnl"]
            peak = max(peak, running)
            max_drawdown = max(max_drawdown, peak - running)

    cat = defaultdict(lambda: {"market_count": 0, "profitable_count": 0, "pnl": 0.0, "cost": 0.0})
    for x in closed_rows:
        c = cat[x["category"]]
        c["market_count"] += 1
        c["profitable_count"] += int(x["pnl"] > 0)
        c["pnl"] += x["pnl"]
        c["cost"] += max(x["cost"], 0.0)
    category_breakdown = []
    for name, v in cat.items():
        category_breakdown.append({
            "category": name,
            "market_count": v["market_count"],
            "profitable_count": v["profitable_count"],
            "pnl": round(v["pnl"], 4),
            "cost": round(v["cost"], 4),
            "roi": round(v["pnl"] / v["cost"], 6) if v["cost"] else 0.0,
            "win_rate": round(v["profitable_count"] / v["market_count"], 6) if v["market_count"] else 0.0,
            "avg_position": round(v["cost"] / v["market_count"], 4) if v["market_count"] else 0.0,
        })
    category_breakdown.sort(key=lambda x: x["pnl"], reverse=True)
    # Frequency is observed position activity, including open positions.  A
    # profitable category is not necessarily a frequently traded category.
    activity_counts = defaultdict(int)
    for position in all_positions:
        activity_counts[category_for(_title(position), position.get("category"))] += 1
    frequent_categories = [
        {"category": category, "observed_positions": count,
         "settled_positions": cat[category]["market_count"]}
        for category, count in sorted(activity_counts.items(), key=lambda item: (-item[1], item[0]))
    ]

    price_bands = [(0, .1, "0.01–0.10"), (.1, .3, "0.10–0.30"), (.3, .6, "0.30–0.60"), (.6, .9, "0.60–0.90"), (.9, 1.01, "0.90–0.99")]
    size_bands = [(0, 500, "<$500"), (500, 2000, "$500–2k"), (2000, 10000, "$2k–10k"), (10000, 1e99, ">$10k")]

    def grouped(bands, key):
        g = defaultdict(lambda: {"count": 0, "wins": 0, "pnl": 0.0, "cost": 0.0})
        for x in closed_rows:
            b = _band(x[key], bands)
            g[b]["count"] += 1
            g[b]["wins"] += int(x["pnl"] > 0)
            g[b]["pnl"] += x["pnl"]
            g[b]["cost"] += x["cost"]
        result = []
        for _, _, name in bands:
            v = g[name]
            result.append({
                "band": name, "count": v["count"], "win_rate": (v["wins"] / v["count"] if v["count"] else 0.0),
                "roi": (v["pnl"] / v["cost"] if v["cost"] else 0.0), "pnl": v["pnl"], "cost": v["cost"]
            })
        return result

    entry_price = grouped(price_bands, "avg_price")
    position_size = grouped(size_bands, "cost")

    market_count = int(profile_stats.get("trades") or len(all_positions))
    volume_usdc = safe_float(volume_stats.get("volume_usdc", profile_pnl.get("volume_usdc", 0)))
    trade_count = int(volume_stats.get("trade_count") or profile_pnl.get("trade_count") or 0)

    # Interpretable 0-100 research score, deliberately conservative.
    sample_score = min(25.0, 25.0 * len(closed_rows) / 40.0)
    profitability_score = max(0.0, min(25.0, 12.5 + math.tanh(roi * 3.0) * 12.5))
    consistency_score = max(0.0, min(20.0, win_rate * 20.0))
    concentration_penalty = max(0.0, concentration(1) - 0.35) * 30.0
    dd_ratio = max_drawdown / max(abs(realized_pnl), 1.0)
    drawdown_score = max(0.0, 20.0 * (1.0 - min(dd_ratio, 1.0)))
    breadth_score = min(10.0, len(category_breakdown) * 2.0)
    trader_skill = max(0.0, min(100.0, sample_score + profitability_score + consistency_score + drawdown_score + breadth_score - concentration_penalty))

    stats = {
        "address": address.lower(),
        "market_count": market_count,
        "closed_market_count": len(closed_rows),
        "open_market_count": len(open_positions),
        "trade_count": trade_count,
        "volume_usdc": round(volume_usdc, 4),
        "realized_pnl": round(realized_pnl, 4),
        "open_total_pnl": round(open_total_pnl, 4),
        "overall_pnl": round(overall_pnl, 4),
        "roi": round(roi, 6),
        "win_rate": round(win_rate, 6),
        "wins": wins,
        "losses": losses,
        "profitable_position_denominator": len(closed_rows),
        "pnl_source": "DATA_API_USER_STATS" if official_realized is not None else ("DATA_API_USER_PNL" if official_trade_pnl is not None else "CLOSED_POSITION_SAMPLE"),
        "pnl_window": "all_time_reported" if official_realized is not None or official_trade_pnl is not None else "fetched_closed_positions",
        "max_drawdown": round(max_drawdown, 4),
        "biggest_win": safe_float(profile_stats.get("biggest_win")),
        "join_date": profile_stats.get("join_date"),
    }
    analytics = {
        "trader_skill": round(trader_skill, 2),
        "profit_concentration": {"top1": round(concentration(1), 6), "top3": round(concentration(3), 6), "top10": round(concentration(10), 6)},
        "category_breakdown": category_breakdown,
        "frequent_categories": frequent_categories,
        "entry_price_breakdown": entry_price,
        "position_size_breakdown": position_size,
        "best_category": category_breakdown[0]["category"] if category_breakdown else None,
        "copyability": {"status": "COLLECTING", "score": None, "note": "实时信号积累后计算"},
    }

    from .config import settings
    qualified = (
        trader_skill >= settings.min_trader_skill
        and len(closed_rows) >= settings.min_closed_markets
        and concentration(1) <= 0.70
    )
    # Historical skill only earns a place in the forward observation pool.
    # Fast/Slow Alpha qualification requires delayed executable-price replay.
    status = "COLLECTING" if qualified else "OBSERVING"
    return stats, analytics, status


def category_expected_alpha(category_stat: dict[str, Any] | None, wallet_analytics: dict[str, Any]) -> float:
    """Conservative proxy used only for paper signal gating, not a forecast."""
    if category_stat and category_stat.get("market_count", 0) >= 3:
        roi = safe_float(category_stat.get("roi"))
        sample = min(1.0, category_stat.get("market_count", 0) / 20.0)
        return max(-0.10, min(0.12, roi * 0.20 * sample))
    skill = safe_float(wallet_analytics.get("trader_skill")) / 100.0
    return max(0.0, (skill - 0.55) * 0.04)


def fee_rate_for_category(category: str) -> float:
    return FEE_RATE_BY_CATEGORY.get(category, FEE_RATE_BY_CATEGORY["Other"])


def fee_usdc(shares: float, price: float, fee_rate: float) -> float:
    if shares <= 0 or price <= 0 or fee_rate <= 0:
        return 0.0
    return round(shares * fee_rate * price * (1.0 - price), 5)
