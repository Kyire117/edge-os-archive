"""Isolated, deterministic paper execution primitives.

This module is deliberately not wired into the legacy paper trader or the
Forward Copy experiments. All times are timezone-aware UTC and all money and
quantity arithmetic uses Decimal.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_UP
from typing import Any, Iterable, Literal

ENGINE_VERSION = "strict-paper-engine-v2"
ENGINE_VERSION_V3 = "strict-paper-engine-v3"
ENGINE_VERSION_V4 = "strict-paper-engine-v4"
QTY_QUANTUM = Decimal("0.000001")
MONEY_QUANTUM = Decimal("0.000001")


def executable_level(price: Decimal, quantity: Decimal, minimum: Decimal) -> bool:
    """A rounded level must satisfy both quantity and monetary precision."""
    return quantity >= minimum and (price * quantity).quantize(MONEY_QUANTUM, rounding=ROUND_DOWN) > 0


def _decimal(value: Any, name: str) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(f"INVALID_{name.upper()}") from None
    if not result.is_finite():
        raise ValueError(f"INVALID_{name.upper()}")
    return result


def _utc(value: datetime, name: str) -> datetime:
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(f"INVALID_{name.upper()}_TIMESTAMP")
    return value.astimezone(timezone.utc)


@dataclass(frozen=True)
class MarketIdentity:
    condition_id: str
    token_id: str
    outcome: str

    def __post_init__(self) -> None:
        if not all(isinstance(x, str) and x.strip() for x in (self.condition_id, self.token_id, self.outcome)):
            raise ValueError("INVALID_MARKET_IDENTITY")

    def key(self) -> str:
        return f"{self.condition_id}|{self.token_id}|{self.outcome}"


@dataclass(frozen=True)
class BookLevel:
    price: Decimal
    quantity: Decimal

    def __post_init__(self) -> None:
        p, q = _decimal(self.price, "price"), _decimal(self.quantity, "quantity")
        if p <= 0 or p >= 1 or q <= 0:
            raise ValueError("INVALID_BOOK_LEVEL")
        object.__setattr__(self, "price", p)
        object.__setattr__(self, "quantity", q)


@dataclass(frozen=True)
class BookSnapshot:
    snapshot_id: str
    request_id: str
    identity: MarketIdentity
    source: str
    source_timestamp: datetime
    request_timestamp: datetime
    received_timestamp: datetime
    bids: tuple[BookLevel, ...]
    asks: tuple[BookLevel, ...]
    observation_evidence_json: str | None = None

    def __post_init__(self) -> None:
        if not self.snapshot_id or not self.request_id or not self.source:
            raise ValueError("MISSING_BOOK_SOURCE_ID")
        for attr in ("source_timestamp", "request_timestamp", "received_timestamp"):
            object.__setattr__(self, attr, _utc(getattr(self, attr), attr))
        bids, asks = tuple(self.bids), tuple(self.asks)
        if any(not isinstance(x, BookLevel) for x in bids + asks):
            raise ValueError("INVALID_BOOK_LEVEL")
        # Sort explicitly. Input order is not trusted as best-price order.
        bids = tuple(sorted(bids, key=lambda level: level.price, reverse=True))
        asks = tuple(sorted(asks, key=lambda level: level.price))
        if bids and asks and bids[0].price >= asks[0].price:
            raise ValueError("CROSSED_BOOK")
        object.__setattr__(self, "bids", bids)
        object.__setattr__(self, "asks", asks)

    @classmethod
    def from_raw(cls, *, snapshot_id: str, request_id: str, identity: MarketIdentity,
                 source: str, source_timestamp: datetime, request_timestamp: datetime,
                 received_timestamp: datetime, bids: Iterable[dict[str, Any]],
                 asks: Iterable[dict[str, Any]], observation_evidence: dict[str, Any] | None = None) -> "BookSnapshot":
        def levels(rows: Iterable[dict[str, Any]]) -> tuple[BookLevel, ...]:
            try:
                return tuple(BookLevel(_decimal(row["price"], "price"), _decimal(row.get("size", row.get("quantity")), "quantity")) for row in rows)
            except (KeyError, AttributeError, TypeError):
                raise ValueError("MALFORMED_BOOK") from None
        return cls(snapshot_id, request_id, identity, source, source_timestamp,
                   request_timestamp, received_timestamp, levels(bids), levels(asks),
                   json.dumps(observation_evidence, sort_keys=True, default=str) if observation_evidence is not None else None)

    def to_evidence(self, *, observed_at: datetime | None = None,
                    previous: "BookSnapshot | None" = None) -> dict[str, Any]:
        evidence = {
            "snapshot_id": self.snapshot_id, "request_id": self.request_id,
            "identity": {"condition_id": self.identity.condition_id, "token_id": self.identity.token_id, "outcome": self.identity.outcome},
            "source": self.source, "source_timestamp": self.source_timestamp.isoformat(),
            "request_timestamp": self.request_timestamp.isoformat(), "received_timestamp": self.received_timestamp.isoformat(),
            "bids": [[str(x.price), str(x.quantity)] for x in self.bids],
            "asks": [[str(x.price), str(x.quantity)] for x in self.asks],
        }
        if self.observation_evidence_json is not None or observed_at is not None:
            transport = json.loads(self.observation_evidence_json) if self.observation_evidence_json else {}
            prev = json.loads(previous.observation_evidence_json) if previous and previous.observation_evidence_json else {}
            evidence.update({**transport, **evidence,
                "source_timestamp_role": "UPSTREAM_BOOK_STATE_PROVENANCE",
                "received_timestamp_role": "EDGE_LOCAL_OBSERVATION_TIME",
                "source_minus_request_ms": (self.source_timestamp-self.request_timestamp).total_seconds()*1000,
                "source_minus_received_ms": (self.source_timestamp-self.received_timestamp).total_seconds()*1000,
                "response_age_at_decision_ms": (observed_at-self.received_timestamp).total_seconds()*1000 if observed_at else None,
                "source_equal_previous": self.source_timestamp==previous.source_timestamp if previous else None,
                "hash_equal_previous": transport.get("upstream_hash")==prev.get("upstream_hash") if transport.get("upstream_hash") is not None and prev.get("upstream_hash") is not None else None,
                "bid_level_count": len(self.bids), "ask_level_count": len(self.asks),
                "best_bid": str(self.bids[0].price) if self.bids else None,
                "best_ask": str(self.asks[0].price) if self.asks else None})
        return evidence


@dataclass(frozen=True)
class EngineRules:
    rule_version: str = "strict-paper-rules-v2"
    execution_latency_ms: int = 500
    max_book_age_ms: int = 3000
    max_adverse_move: Decimal = Decimal("0.03")
    max_visible_depth_fraction: Decimal = Decimal("0.10")
    allow_partial_fills: bool = False
    near_certainty_threshold: Decimal = Decimal("0.98")
    min_quantity: Decimal = QTY_QUANTUM

    def __post_init__(self) -> None:
        if not self.rule_version or self.execution_latency_ms < 0 or self.max_book_age_ms < 0:
            raise ValueError("INVALID_ENGINE_RULES")
        for name in ("max_adverse_move", "max_visible_depth_fraction", "near_certainty_threshold", "min_quantity"):
            val = _decimal(getattr(self, name), name)
            object.__setattr__(self, name, val)
        if self.max_adverse_move < 0 or not (0 < self.max_visible_depth_fraction <= 1):
            raise ValueError("INVALID_ENGINE_RULES")
        if not (Decimal("0.5") < self.near_certainty_threshold < 1) or self.min_quantity <= 0:
            raise ValueError("INVALID_ENGINE_RULES")

    def to_evidence(self) -> dict[str, Any]:
        return {"rule_version": self.rule_version, "execution_latency_ms": self.execution_latency_ms,
            "max_book_age_ms": self.max_book_age_ms, "max_adverse_move": str(self.max_adverse_move),
            "max_visible_depth_fraction": str(self.max_visible_depth_fraction),
            "allow_partial_fills": self.allow_partial_fills,
            "near_certainty_threshold": str(self.near_certainty_threshold),
            "min_quantity": str(self.min_quantity), "quantity_precision": str(QTY_QUANTUM),
            "money_precision": str(MONEY_QUANTUM), "fee_rounding": "ROUND_UP_PER_LEVEL",
            "cost_rounding": "ROUND_DOWN_PER_LEVEL",
            "buy_budget_definition": "GROSS_NOTIONAL_EXCLUDING_FEES"}


@dataclass(frozen=True)
class WalletFollowEngineRules(EngineRules):
    """Forward-only v3 policy; legacy price gates become observations."""
    rule_version: str = "strict-paper-rules-v3-wallet-follow-v2.0"
    allow_partial_fills: bool = True
    min_net_roi_if_win: Decimal = Decimal("0.05")

    def __post_init__(self) -> None:
        super().__post_init__()
        floor = _decimal(self.min_net_roi_if_win, "min_net_roi_if_win")
        if floor < 0:
            raise ValueError("INVALID_MIN_NET_ROI_IF_WIN")
        object.__setattr__(self, "min_net_roi_if_win", floor)

    def to_evidence(self) -> dict[str, Any]:
        return {**super().to_evidence(), "execution_policy": "WALLET_FOLLOW_V2",
                "min_net_roi_if_win": str(self.min_net_roi_if_win),
                "adverse_price_gate": "OBSERVE_ONLY", "near_certainty_gate": "DISABLED"}


@dataclass(frozen=True)
class LocalObservationEngineRules(WalletFollowEngineRules):
    """V4 execution revision; V2 product strategy and V3 rule semantics stay frozen."""
    rule_version: str = "strict-paper-rules-v4-wallet-follow-v2.0"

    def __post_init__(self) -> None:
        super().__post_init__()
        if not self.rule_version.startswith("strict-paper-rules-v4-"):
            raise ValueError("INVALID_TIMESTAMP_MODEL_RULE_VERSION")

    def to_evidence(self) -> dict[str, Any]:
        return {**super().to_evidence(),
                "timestamp_model": "LOCAL_CAUSAL_OBSERVATION_V1",
                "quote_causality_basis": "LOCAL_REQUEST_AFTER_EDGE_DETECTION",
                "book_freshness_basis": "LOCAL_RESPONSE_RECEIVED_AT",
                "upstream_timestamp_role": "PROVENANCE_ONLY",
                "execution_newness_basis": "DISTINCT_REQUEST_AFTER_FROZEN_LATENCY"}


@dataclass(frozen=True)
class OrderIntent:
    signal_id: str
    idempotency_key: str
    identity: MarketIdentity
    side: Literal["BUY", "SELL"]
    amount: Decimal  # BUY: gross trade notional excluding fees; SELL: requested shares.
    allow_partial: bool = False
    leader_trade_timestamp: datetime | None = None
    edge_detected_timestamp: datetime | None = None

    def __post_init__(self) -> None:
        if not self.signal_id or not self.idempotency_key or self.side not in ("BUY", "SELL"):
            raise ValueError("INVALID_ORDER_INTENT")
        amount = _decimal(self.amount, "amount").quantize(
            MONEY_QUANTUM if self.side == "BUY" else QTY_QUANTUM, rounding=ROUND_DOWN)
        if amount <= 0:
            raise ValueError("INVALID_ORDER_AMOUNT")
        object.__setattr__(self, "amount", amount)
        for name in ("leader_trade_timestamp", "edge_detected_timestamp"):
            val = getattr(self, name)
            if val is not None:
                object.__setattr__(self, name, _utc(val, name))


@dataclass(frozen=True)
class MarketState:
    identity: MarketIdentity
    closed: bool = False
    resolved: bool = False
    token_probability: Decimal | None = None
    state_source: str = ""
    observed_at: datetime | None = None
    accepting_orders: bool | None = None
    minimum_order_size: Decimal | None = None
    minimum_order_source: str = ""
    source_timestamp: datetime | None = None
    request_timestamp: datetime | None = None
    received_timestamp: datetime | None = None
    fee_rate: Decimal | None = None
    fee_source: str = ""
    fee_request_timestamp: datetime | None = None
    fee_received_timestamp: datetime | None = None

    def __post_init__(self) -> None:
        for name in ("observed_at", "source_timestamp", "request_timestamp", "received_timestamp",
                     "fee_request_timestamp", "fee_received_timestamp"):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(self, name, _utc(value, name))


@dataclass(frozen=True)
class ExecutionDecision:
    status: Literal["FILLED", "PARTIAL", "REJECTED"]
    reason: str
    engine_version: str
    rule_version: str
    signal_id: str
    idempotency_key: str
    identity: MarketIdentity
    side: str
    target_quantity: Decimal
    filled_quantity: Decimal
    unfilled_quantity: Decimal
    vwap: Decimal | None
    total_cost: Decimal
    total_fee: Decimal
    raw_visible_executable_amount: Decimal
    strict_allowed_executable_amount: Decimal
    fee_rate: Decimal
    fee_source: str
    quote: BookSnapshot
    execution: BookSnapshot | None
    market_state: MarketState
    rule_config: tuple[tuple[str, Any], ...]
    fills: tuple[tuple[Decimal, Decimal], ...]  # (price, quantity)
    observed_at: datetime
    execution_latency_ms: int
    requested_notional: Decimal = Decimal("0")
    filled_notional: Decimal = Decimal("0")
    unfilled_notional: Decimal = Decimal("0")
    min_net_roi_if_win: Decimal | None = None
    projected_net_profit_if_win: Decimal | None = None
    projected_net_roi_if_win: Decimal | None = None
    roi_limited_depth: Decimal = Decimal("0")
    liquidity_limited_depth: Decimal = Decimal("0")

    def to_evidence(self, intent: OrderIntent) -> dict[str, Any]:
        evidence = {
            "engine_version": self.engine_version, "rule_version": self.rule_version,
            "rule_config": dict(self.rule_config),
            "signal_id": self.signal_id, "idempotency_key": self.idempotency_key,
            "identity": {"condition_id": self.identity.condition_id, "token_id": self.identity.token_id, "outcome": self.identity.outcome},
            "side": self.side, "target_quantity": str(self.target_quantity),
            "intent_amount": str(intent.amount),
            "buy_budget_definition": "GROSS_NOTIONAL_EXCLUDING_FEES" if self.side == "BUY" else None,
            "requested_notional": str(self.requested_notional),
            "filled_notional": str(self.filled_notional),
            "unfilled_notional": str(self.unfilled_notional),
            "leader_trade_timestamp": intent.leader_trade_timestamp.isoformat() if intent.leader_trade_timestamp else None,
            "edge_detected_timestamp": intent.edge_detected_timestamp.isoformat() if intent.edge_detected_timestamp else None,
            "allow_partial_requested": intent.allow_partial,
            "quote": self.quote.to_evidence(observed_at=self.observed_at) if self.engine_version == ENGINE_VERSION_V4 else self.quote.to_evidence(),
            "execution": (self.execution.to_evidence(observed_at=self.observed_at, previous=self.quote) if self.engine_version == ENGINE_VERSION_V4 else self.execution.to_evidence()) if self.execution else None,
            "market_state": {"closed": self.market_state.closed, "resolved": self.market_state.resolved,
                "accepting_orders": self.market_state.accepting_orders,
                "minimum_order_size": str(self.market_state.minimum_order_size) if self.market_state.minimum_order_size is not None else None,
                "minimum_order_source": self.market_state.minimum_order_source,
                "token_probability": str(self.market_state.token_probability) if self.market_state.token_probability is not None else None,
                "source": self.market_state.state_source,
                "observed_at": self.market_state.observed_at.isoformat() if self.market_state.observed_at else None,
                "source_timestamp": self.market_state.source_timestamp.isoformat() if self.market_state.source_timestamp else None,
                "request_timestamp": self.market_state.request_timestamp.isoformat() if self.market_state.request_timestamp else None,
                "received_timestamp": self.market_state.received_timestamp.isoformat() if self.market_state.received_timestamp else None,
                "fee_rate": str(self.market_state.fee_rate) if self.market_state.fee_rate is not None else None,
                "fee_source": self.market_state.fee_source,
                "fee_request_timestamp": self.market_state.fee_request_timestamp.isoformat() if self.market_state.fee_request_timestamp else None,
                "fee_received_timestamp": self.market_state.fee_received_timestamp.isoformat() if self.market_state.fee_received_timestamp else None},
            "observed_at": self.observed_at.isoformat(), "status": self.status, "reason": self.reason,
            "filled_quantity": str(self.filled_quantity), "unfilled_quantity": str(self.unfilled_quantity),
            "vwap": str(self.vwap) if self.vwap is not None else None, "total_cost": str(self.total_cost),
            "total_fee": str(self.total_fee), "fee_rate": str(self.fee_rate), "fee_source": self.fee_source,
            "raw_visible_executable_amount": str(self.raw_visible_executable_amount),
            "strict_allowed_executable_amount": str(self.strict_allowed_executable_amount),
            "fills": [[str(p), str(q)] for p, q in self.fills],
            "execution_latency_ms": self.execution_latency_ms,
        }
        if self.engine_version in {ENGINE_VERSION_V3, ENGINE_VERSION_V4}:
            evidence.update({"min_net_roi_if_win": str(self.min_net_roi_if_win),
                "projected_net_profit_if_win": str(self.projected_net_profit_if_win) if self.projected_net_profit_if_win is not None else None,
                "projected_net_roi_if_win": str(self.projected_net_roi_if_win) if self.projected_net_roi_if_win is not None else None,
                "roi_limited_depth": str(self.roi_limited_depth),
                "liquidity_limited_depth": str(self.liquidity_limited_depth)})
        return evidence


def execute_order(intent: OrderIntent, market: MarketState, quote: BookSnapshot,
                  execution: BookSnapshot | None, rules: EngineRules = EngineRules(), *,
                  fee_rate: Decimal = Decimal("0"), fee_source: str = "explicit-zero",
                  observed_at: datetime | None = None) -> ExecutionDecision:
    """Evaluate a signal against a quote and a distinct later execution book."""
    try:
        fee = _decimal(fee_rate, "fee_rate")
        fee_valid = True
    except ValueError:
        fee, fee_valid = Decimal("0"), False
    now = _utc(observed_at or datetime.now(timezone.utc), "observed_at")
    fills: list[tuple[Decimal, Decimal]] = []
    total_cost = total_fee = filled_qty = Decimal("0")
    raw_amount = strict_amount = Decimal("0")
    reason = ""
    v3 = isinstance(rules, WalletFollowEngineRules)
    local_model = isinstance(rules, LocalObservationEngineRules)
    engine_version = ENGINE_VERSION_V4 if local_model else ENGINE_VERSION_V3 if v3 else ENGINE_VERSION
    roi_limited_depth = Decimal("0")
    projected_profit = projected_roi = None

    def reject(code: str) -> ExecutionDecision:
        target = Decimal("0") if intent.side == "BUY" else intent.amount
        return ExecutionDecision("REJECTED", code, engine_version, rules.rule_version, intent.signal_id,
            intent.idempotency_key, intent.identity, intent.side, target, Decimal("0"), target,
            None, Decimal("0"), Decimal("0"), raw_amount, strict_amount, fee, fee_source,
            quote, execution, market, tuple(sorted(rules.to_evidence().items())), tuple(), now, rules.execution_latency_ms,
            intent.amount if intent.side == "BUY" else Decimal("0"), Decimal("0"),
            intent.amount if intent.side == "BUY" else Decimal("0"),
            rules.min_net_roi_if_win if v3 else None, projected_profit, projected_roi,
            roi_limited_depth)

    if not fee_valid or fee < 0 or fee > 1 or not fee_source or (v3 and fee_source.strip().lower() in {"unknown", "unverified", "missing"}):
        return reject("INVALID_FEE_EVIDENCE")
    if market.identity != intent.identity or quote.identity != intent.identity or (execution and execution.identity != intent.identity):
        return reject("MARKET_IDENTITY_MISMATCH")
    if market.resolved or market.closed:
        return reject("MARKET_CLOSED_OR_RESOLVED")
    if v3 and market.accepting_orders is not True:
        return reject("MARKET_NOT_ACCEPTING_ORDERS")
    if v3:
        try:
            venue_minimum = _decimal(market.minimum_order_size, "minimum_order_size")
        except ValueError:
            return reject("INVALID_MINIMUM_ORDER_EVIDENCE")
        if venue_minimum < 0 or not market.minimum_order_source.strip():
            return reject("INVALID_MINIMUM_ORDER_EVIDENCE")
    if not market.state_source or market.observed_at is None:
        return reject("INVALID_MARKET_STATE")
    try:
        state_time = _utc(market.observed_at, "market_state")
    except ValueError:
        return reject("INVALID_MARKET_STATE")
    if state_time > now or (now-state_time).total_seconds()*1000 > rules.max_book_age_ms:
        return reject("STALE_MARKET_STATE")
    if intent.edge_detected_timestamp is not None and quote.request_timestamp < intent.edge_detected_timestamp:
        return reject("QUOTE_PREDATES_SIGNAL")
    if not local_model and intent.edge_detected_timestamp is not None and quote.source_timestamp < intent.edge_detected_timestamp:
        return reject("QUOTE_PREDATES_SIGNAL")
    if market.token_probability is not None:
        try:
            probability = _decimal(market.token_probability, "probability")
        except ValueError:
            return reject("INVALID_MARKET_STATE")
        if probability < 0 or probability > 1:
            return reject("INVALID_MARKET_STATE")
        if not v3 and (probability >= rules.near_certainty_threshold or probability <= (1 - rules.near_certainty_threshold)):
            return reject("NEAR_CERTAINTY_LOCKOUT")
    if local_model and (quote.request_timestamp > quote.received_timestamp or quote.received_timestamp > now):
        return reject("INVALID_QUOTE_LOCAL_TIMESTAMPS")
    if not local_model and (quote.source_timestamp > quote.received_timestamp or quote.request_timestamp > quote.received_timestamp):
        return reject("INVALID_QUOTE_TIMESTAMP")
    if not local_model and (quote.received_timestamp - quote.source_timestamp).total_seconds() * 1000 > rules.max_book_age_ms:
        return reject("STALE_QUOTE")
    if quote.received_timestamp > now:
        return reject("FUTURE_QUOTE_TIMESTAMP")
    if execution is None:
        return reject("MISSING_EXECUTION_BOOK")
    if execution.snapshot_id == quote.snapshot_id or execution.request_id == quote.request_id:
        return reject("REUSED_QUOTE_SNAPSHOT")
    if execution.request_timestamp < quote.received_timestamp or (execution.request_timestamp - quote.received_timestamp).total_seconds() * 1000 < rules.execution_latency_ms:
        return reject("EXECUTION_BEFORE_FROZEN_LATENCY")
    if not local_model and execution.source_timestamp <= quote.source_timestamp:
        return reject("EXECUTION_BOOK_NOT_NEWER")
    if local_model and (execution.request_timestamp > execution.received_timestamp or execution.received_timestamp > now):
        return reject("INVALID_EXECUTION_LOCAL_TIMESTAMPS")
    if not local_model and (execution.source_timestamp > execution.received_timestamp or execution.request_timestamp > execution.received_timestamp):
        return reject("INVALID_EXECUTION_TIMESTAMP")
    if execution.received_timestamp > now:
        return reject("FUTURE_EXECUTION_TIMESTAMP")
    if not local_model and (execution.received_timestamp - execution.source_timestamp).total_seconds() * 1000 > rules.max_book_age_ms:
        return reject("STALE_EXECUTION_BOOK")
    if v3 and (now - execution.received_timestamp).total_seconds() * 1000 > rules.max_book_age_ms:
        return reject("STALE_EXECUTION_BOOK")
    if local_model and (now - quote.received_timestamp).total_seconds() * 1000 > rules.max_book_age_ms:
        return reject("STALE_QUOTE")
    quote_side = quote.asks if intent.side == "BUY" else quote.bids
    levels = execution.asks if intent.side == "BUY" else execution.bids
    quote_best = quote_side[0].price if quote_side else None
    exec_best = levels[0].price if levels else None
    if quote_best is None or exec_best is None:
        return reject("EMPTY_EXECUTION_BOOK")
    effective_probability = _decimal(market.token_probability,"probability") if market.token_probability is not None else exec_best
    if effective_probability < 0 or effective_probability > 1:
        return reject("INVALID_MARKET_STATE")
    if not v3 and (effective_probability >= rules.near_certainty_threshold or effective_probability <= (1-rules.near_certainty_threshold)
            or exec_best >= rules.near_certainty_threshold or exec_best <= (1-rules.near_certainty_threshold)):
        return reject("NEAR_CERTAINTY_LOCKOUT")
    adverse = (exec_best - quote_best) if intent.side == "BUY" else (quote_best - exec_best)
    if not v3 and adverse > rules.max_adverse_move:
        return reject("ADVERSE_PRICE_MOVEMENT")

    # Measure all visible levels before applying the frozen depth fraction.
    raw_amount = sum((lv.price * lv.quantity for lv in levels), Decimal("0"))
    strict_amount = sum((lv.price * lv.quantity * rules.max_visible_depth_fraction for lv in levels), Decimal("0"))
    remaining_budget = intent.amount if intent.side == "BUY" else None
    remaining_qty = intent.amount if intent.side == "SELL" else Decimal("0")
    for index, level in enumerate(levels):
        capacity = (level.quantity * rules.max_visible_depth_fraction).quantize(QTY_QUANTUM, rounding=ROUND_DOWN)
        if not executable_level(level.price, capacity, rules.min_quantity):
            continue  # The entire allowed level is microscopic, independently of budget.
        if intent.side == "BUY":
            assert remaining_budget is not None
            use_qty = min(capacity, (remaining_budget / level.price).quantize(QTY_QUANTUM, rounding=ROUND_DOWN))
        else:
            use_qty = min(capacity, remaining_qty)
        use_qty = use_qty.quantize(QTY_QUANTUM, rounding=ROUND_DOWN)
        if not executable_level(level.price, use_qty, rules.min_quantity):
            if intent.side == "BUY":
                break  # Budget dust may never be spent at a dearer rounded price.
            continue
        cost = (level.price * use_qty).quantize(MONEY_QUANTUM, rounding=ROUND_DOWN)
        if cost <= 0:
            continue
        level_fee = (use_qty * fee * level.price * (Decimal("1") - level.price)).quantize(MONEY_QUANTUM, rounding=ROUND_UP)
        if v3 and intent.side == "BUY":
            candidate_cost, candidate_fee = total_cost + cost, total_fee + level_fee
            candidate_qty = filled_qty + use_qty
            candidate_capital = candidate_cost + candidate_fee
            candidate_roi = (candidate_qty - candidate_capital) / candidate_capital
            if candidate_roi < rules.min_net_roi_if_win:
                if not fills:
                    projected_profit = (candidate_qty - candidate_capital).quantize(MONEY_QUANTUM, rounding=ROUND_DOWN)
                    projected_roi = candidate_roi.quantize(Decimal("0.00000001"), rounding=ROUND_DOWN)
                roi_limited_depth = sum((lv.price * (lv.quantity * rules.max_visible_depth_fraction).quantize(QTY_QUANTUM, rounding=ROUND_DOWN)
                    for lv in levels[index:]), Decimal("0"))
                break
        fills.append((level.price, use_qty))
        filled_qty += use_qty
        total_cost += cost
        total_fee += level_fee
        if intent.side == "BUY":
            remaining_budget -= cost
            if remaining_budget <= 0:
                break
        else:
            remaining_qty -= use_qty
            if remaining_qty <= 0:
                break
    total_cost = total_cost.quantize(MONEY_QUANTUM, rounding=ROUND_DOWN)
    total_fee = total_fee.quantize(MONEY_QUANTUM, rounding=ROUND_UP)
    if intent.side == "BUY":
        unfilled = Decimal("0")  # A BUY has no quote-derived share target.
        unfilled_notional = max(Decimal("0"), intent.amount-total_cost).quantize(MONEY_QUANTUM)
    else:
        unfilled = max(Decimal("0"), (remaining_qty or Decimal("0"))).quantize(QTY_QUANTUM, rounding=ROUND_DOWN)
        unfilled_notional = Decimal("0")
    vwap = (total_cost / filled_qty).quantize(MONEY_QUANTUM, rounding=ROUND_DOWN) if filled_qty else None
    if filled_qty == 0:
        if v3 and roi_limited_depth:
            return reject("NET_ROI_BELOW_FLOOR")
        return reject("INSUFFICIENT_EXECUTABLE_DEPTH")
    if v3 and filled_qty < venue_minimum:
        return reject("BELOW_MINIMUM_ORDER")
    if v3 and intent.side == "BUY":
        capital = total_cost + total_fee
        projected_profit = (filled_qty - capital).quantize(MONEY_QUANTUM, rounding=ROUND_DOWN)
        exact_roi = (filled_qty - capital) / capital
        projected_roi = exact_roi.quantize(Decimal("0.00000001"), rounding=ROUND_DOWN)
        if exact_roi < rules.min_net_roi_if_win:
            return reject("NET_ROI_BELOW_FLOOR")
    is_partial = unfilled_notional > MONEY_QUANTUM if intent.side == "BUY" else unfilled > 0
    if is_partial and not (rules.allow_partial_fills and intent.allow_partial):
        return reject("PARTIAL_FILL_NOT_ALLOWED")
    return ExecutionDecision("PARTIAL" if is_partial else "FILLED", "PARTIAL_ROI_FLOOR" if is_partial and roi_limited_depth else "PARTIAL_VISIBLE_DEPTH" if is_partial else "EXECUTED",
        engine_version, rules.rule_version, intent.signal_id, intent.idempotency_key, intent.identity,
        intent.side, (Decimal("0") if intent.side == "BUY" else intent.amount),
        filled_qty, unfilled, vwap, total_cost, total_fee, raw_amount, strict_amount,
        fee, fee_source, quote, execution, market, tuple(sorted(rules.to_evidence().items())), tuple(fills), now, rules.execution_latency_ms,
        intent.amount if intent.side == "BUY" else Decimal("0"),
        total_cost if intent.side == "BUY" else Decimal("0"), unfilled_notional,
        rules.min_net_roi_if_win if v3 else None, projected_profit, projected_roi,
        roi_limited_depth, max(Decimal("0"), intent.amount - strict_amount) if v3 and intent.side == "BUY" else Decimal("0"))
