"""Opt-in, frozen risk overlay for a 100 USDC PAPER_ONLY trial.

Strategy selection and existing exit rules are unchanged. Every new BUY is
checked inside the ledger reservation transaction, including concurrent orders.
"""
from __future__ import annotations
import json,sqlite3
from datetime import datetime,timezone
from decimal import Decimal,ROUND_DOWN,ROUND_UP
from pathlib import Path

VERSION='paper-trial-risk-v2'
Q=Decimal('0.000001')
DEFAULTS={'version':VERSION,'initial_cash':'100.000000','max_order_debit':'1.000000',
 'max_market_exposure':'1.000000','max_event_exposure':'2.000000','max_open_exposure':'30.000000',
 'pause_net_loss':'20.000000','maximum_total_loss':'70.000000',
 'valuation_max_age_seconds':60,'live_orders':False}

def dec(x):
 v=Decimal(str(x))
 if not v.is_finite():raise ValueError('INVALID_RISK_AMOUNT')
 return v

def stamp(x):
 t=x if isinstance(x,datetime) else datetime.fromisoformat(x.replace('Z','+00:00'))
 if t.tzinfo is None:raise ValueError('INVALID_RISK_TIMESTAMP')
 return t.astimezone(timezone.utc)

def policy(con,account_id):
 if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='paper_trial_risk'").fetchone():return None
 rows=con.execute('SELECT * FROM paper_trial_risk').fetchall()
 for r in rows:
  r=dict(r)
  if account_id.startswith(r['account_prefix']):return r
 return None

def initialize(path,*,at,account_prefix='wallet-follow-v2.0:'):
 config=json.dumps(DEFAULTS,sort_keys=True,separators=(',',':'))
 with sqlite3.connect(path) as c:
  c.executescript('''
  CREATE TABLE IF NOT EXISTS paper_trial_risk(account_prefix TEXT PRIMARY KEY,config_json TEXT NOT NULL,created_at TEXT NOT NULL);
  CREATE TRIGGER IF NOT EXISTS paper_trial_risk_immutable_update BEFORE UPDATE ON paper_trial_risk BEGIN SELECT RAISE(ABORT,'FROZEN_RISK_POLICY'); END;
  CREATE TRIGGER IF NOT EXISTS paper_trial_risk_immutable_delete BEFORE DELETE ON paper_trial_risk BEGIN SELECT RAISE(ABORT,'FROZEN_RISK_POLICY'); END;
  CREATE TABLE IF NOT EXISTS paper_trial_risk_events(id INTEGER PRIMARY KEY,event_type TEXT NOT NULL,account_prefix TEXT NOT NULL,observed_at TEXT NOT NULL,evidence_json TEXT NOT NULL);
  CREATE TRIGGER IF NOT EXISTS paper_trial_events_no_update BEFORE UPDATE ON paper_trial_risk_events BEGIN SELECT RAISE(ABORT,'APPEND_ONLY_RISK_EVENT'); END;
  CREATE TRIGGER IF NOT EXISTS paper_trial_events_no_delete BEFORE DELETE ON paper_trial_risk_events BEGIN SELECT RAISE(ABORT,'APPEND_ONLY_RISK_EVENT'); END;
  CREATE TABLE IF NOT EXISTS paper_trial_valuations(condition_id TEXT NOT NULL,token_id TEXT NOT NULL,outcome TEXT NOT NULL,quantity TEXT NOT NULL,net_liquidation TEXT,observed_at TEXT NOT NULL,evidence_json TEXT NOT NULL,PRIMARY KEY(condition_id,token_id,outcome));
  CREATE TABLE IF NOT EXISTS paper_trial_equity(id INTEGER PRIMARY KEY,observed_at TEXT NOT NULL,net_pnl TEXT,realized_pnl TEXT NOT NULL,open_cost_basis TEXT NOT NULL,missing_valuations INTEGER NOT NULL,evidence_json TEXT NOT NULL);
  ''')
  pool=c.execute('SELECT fixed_initial_cash FROM strict_cash_pools WHERE account_prefix=?',(account_prefix,)).fetchone()
  if not pool or dec(pool[0])!=dec(DEFAULTS['initial_cash']):raise ValueError('RISK_REQUIRES_100_USDC_POOL')
  previous=c.execute('SELECT config_json FROM paper_trial_risk WHERE account_prefix=?',(account_prefix,)).fetchone()
  if previous and previous[0]!=config:raise ValueError('FROZEN_RISK_POLICY_CONFLICT')
  c.execute('INSERT OR IGNORE INTO paper_trial_risk VALUES(?,?,?)',(account_prefix,config,stamp(at).isoformat()))

def entry_notional(con,account_id,requested,fee_rate):
 p=policy(con,account_id)
 if not p:return dec(requested)
 cfg=json.loads(p['config_json'])
 # The engine's fee is bounded by notional * fee_rate. Reserve includes fees.
 return min(dec(requested),(dec(cfg['max_order_debit'])/(1+dec(fee_rate))).quantize(Q,rounding=ROUND_DOWN))

def snapshot(con,p,at):
 cfg=json.loads(p['config_json']);now=stamp(at);prefix=p['account_prefix']+'%'
 positions=[dict(r) for r in con.execute('SELECT * FROM strict_positions WHERE account_id LIKE ?',(prefix,))]
 realized=sum((dec(r['realized_pnl']) for r in positions),Decimal(0))
 basis=Decimal(0);groups={};events={};markets={}
 for r in positions:
  if dec(r['quantity'])<=0:continue
  b=dec(r['cost_basis']);basis+=b
  events[r['condition_id']]=events.get(r['condition_id'],Decimal(0))+b
  key=(r['condition_id'],r['token_id'],r['outcome'])
  markets[key]=markets.get(key,Decimal(0))+b
  groups[key]=groups.get(key,Decimal(0))+dec(r['quantity'])
 reserved=Decimal(0)
 for r in con.execute("SELECT condition_id,token_id,outcome,reserve_cash_remaining FROM strict_orders WHERE account_id LIKE ? AND side='BUY' AND status='OPEN'",(prefix,)):
  v=dec(r['reserve_cash_remaining']);reserved+=v
  events[r['condition_id']]=events.get(r['condition_id'],Decimal(0))+v
  key=(r['condition_id'],r['token_id'],r['outcome'])
  markets[key]=markets.get(key,Decimal(0))+v
 value=Decimal(0);missing=0
 for key,quantity in groups.items():
  mark=con.execute('SELECT * FROM paper_trial_valuations WHERE condition_id=? AND token_id=? AND outcome=?',key).fetchone()
  if (not mark or dec(mark['quantity'])!=quantity or mark['net_liquidation'] is None
      or not 0<=(now-stamp(mark['observed_at'])).total_seconds()<=cfg['valuation_max_age_seconds']):
   missing+=1
  else:value+=dec(mark['net_liquidation'])
 net=realized+value-basis if not missing else None
 paused=con.execute("SELECT event_type FROM paper_trial_risk_events WHERE account_prefix=? AND event_type IN ('PAUSED_NET_LOSS','STOPPED_TOTAL_LOSS') ORDER BY id DESC LIMIT 1",(p['account_prefix'],)).fetchone()
 return {'realized_pnl':realized,'open_cost_basis':basis,'reserved_cash':reserved,
  'net_pnl':net,'missing_valuations':missing,'market_exposure':markets,'event_exposure':events,
  'open_exposure':basis+reserved,'paused_reason':paused[0] if paused else None,
  'worst_case_net_loss':max(Decimal(0),basis+reserved-realized)}

def serial(value):
 if isinstance(value,Decimal):return str(value)
 raise TypeError(type(value).__name__)

def snapshot_evidence(s):
 out=dict(s)
 out['market_exposure']=[
  {'condition_id':key[0],'token_id':key[1],'outcome':key[2],'exposure':str(value)}
  for key,value in sorted(s['market_exposure'].items())]
 return out

def observe(con,account_id,at):
 p=policy(con,account_id)
 if not p:return
 cfg=json.loads(p['config_json']);s=snapshot(con,p,at)
 known=s['net_pnl']
 # Realized losses cannot be concealed by unavailable marks or assumed gains.
 observed_pnl=known if known is not None else s['realized_pnl']
 if observed_pnl<=-dec(cfg['maximum_total_loss']) and s['paused_reason']!='STOPPED_TOTAL_LOSS':
  reason='STOPPED_TOTAL_LOSS'
 elif observed_pnl<=-dec(cfg['pause_net_loss']) and s['paused_reason'] is None:
  reason='PAUSED_NET_LOSS'
 else:
  reason=None
 if reason:
  con.execute('INSERT INTO paper_trial_risk_events(event_type,account_prefix,observed_at,evidence_json) VALUES(?,?,?,?)',
   (reason,p['account_prefix'],stamp(at).isoformat(),json.dumps(snapshot_evidence(s),default=serial,sort_keys=True)))
 con.execute('INSERT INTO paper_trial_equity(observed_at,net_pnl,realized_pnl,open_cost_basis,missing_valuations,evidence_json) VALUES(?,?,?,?,?,?)',
  (stamp(at).isoformat(),str(known) if known is not None else None,str(s['realized_pnl']),str(s['open_cost_basis']),s['missing_valuations'],json.dumps(snapshot_evidence(s),default=serial,sort_keys=True)))

def check_buy(con,account_id,identity,reserve_cash,at):
 p=policy(con,account_id)
 if not p:return
 cfg=json.loads(p['config_json']);s=snapshot(con,p,at);debit=dec(reserve_cash)
 if s['paused_reason']:raise ValueError('TRIAL_RISK_'+s['paused_reason'])
 if (s['net_pnl'] if s['net_pnl'] is not None else s['realized_pnl'])<=-dec(cfg['pause_net_loss']):raise ValueError('TRIAL_RISK_PAUSED_NET_LOSS')
 if debit>dec(cfg['max_order_debit']):raise ValueError('TRIAL_RISK_ORDER_LIMIT')
 market_key=(identity.condition_id,identity.token_id,identity.outcome)
 # A currently running v1 experiment may still hold its immutable v1 config.
 # Preserve that experiment's frozen limits during the cutover; every v2
 # policy includes this key and enforces the cumulative market cap.
 market_limit=cfg.get('max_market_exposure')
 if market_limit is not None and s['market_exposure'].get(market_key,Decimal(0))+debit>dec(market_limit):raise ValueError('TRIAL_RISK_MARKET_LIMIT')
 if s['event_exposure'].get(identity.condition_id,Decimal(0))+debit>dec(cfg['max_event_exposure']):raise ValueError('TRIAL_RISK_EVENT_LIMIT')
 if s['open_exposure']+debit>dec(cfg['max_open_exposure']):raise ValueError('TRIAL_RISK_PORTFOLIO_LIMIT')
 if s['open_exposure']+debit-s['realized_pnl']>dec(cfg['maximum_total_loss']):raise ValueError('TRIAL_RISK_TOTAL_LOSS_BUDGET')
 if s['missing_valuations']:raise ValueError('TRIAL_RISK_VALUATION_UNAVAILABLE')

def record_book(path,account_id,book,*,fee_rate,minimum_order_size,observed_at):
 """Aggregate shared token exposure before walking bids; never reuse depth per wallet."""
 with sqlite3.connect(path,timeout=30,isolation_level=None) as c:
  c.row_factory=sqlite3.Row;c.execute('BEGIN IMMEDIATE')
  p=policy(c,account_id)
  if not p:return
  now=stamp(observed_at)
  if not book.request_timestamp<=book.received_timestamp<=now or (now-book.received_timestamp).total_seconds()>3:
   raise ValueError('STALE_RISK_BOOK')
  key=(book.identity.condition_id,book.identity.token_id,book.identity.outcome)
  quantity=sum((dec(r[0]) for r in c.execute('SELECT quantity FROM strict_positions WHERE account_id LIKE ? AND condition_id=? AND token_id=? AND outcome=?',(p['account_prefix']+'%',*key))),Decimal(0))
  remaining=quantity;value=Decimal(0);fills=[];rate=dec(fee_rate)
  if not 0<=rate<=1:raise ValueError('INVALID_RISK_FEE')
  # Same frozen 10% depth participation and fee model as the execution engine.
  levels={}
  for level in book.bids:levels[level.price]=levels.get(level.price,Decimal(0))+level.quantity
  for price,size in sorted(levels.items(),reverse=True):
   take=min(remaining,(size*Decimal('0.10')).quantize(Q,rounding=ROUND_DOWN))
   if take<=0:continue
   gross=(price*take).quantize(Q,rounding=ROUND_DOWN)
   fee=(take*rate*price*(1-price)).quantize(Q,rounding=ROUND_UP)
   value+=gross-fee;remaining-=take;fills.append([str(price),str(take),str(fee)])
   if remaining==0:break
  valid=quantity>=dec(minimum_order_size) and remaining==0 and quantity>0
  evidence={'book':book.to_evidence(observed_at=now),'fee_rate':str(rate),'minimum_order_size':str(minimum_order_size),
   'depth_fraction':'0.10','fills':fills,'unvalued_quantity':str(remaining),'complete':valid,'live_orders':False}
  c.execute('INSERT INTO paper_trial_valuations VALUES(?,?,?,?,?,?,?) ON CONFLICT(condition_id,token_id,outcome) DO UPDATE SET quantity=excluded.quantity,net_liquidation=excluded.net_liquidation,observed_at=excluded.observed_at,evidence_json=excluded.evidence_json',
   (*key,str(quantity),str(value) if valid else None,now.isoformat(),json.dumps(evidence,default=serial,sort_keys=True)))
  observe(c,account_id,now);c.commit()

def read_status(path,*,at=None):
 with sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True) as c:
  c.row_factory=sqlite3.Row;p=policy(c,'wallet-follow-v2.0:shared-cash')
  if not p:return {'enabled':False}
  return json.loads(json.dumps({'enabled':True,'config':json.loads(p['config_json']),**snapshot_evidence(snapshot(c,p,at or datetime.now(timezone.utc)))},default=serial))
