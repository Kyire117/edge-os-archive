from __future__ import annotations
import json
import time
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from .db import db
from .polymarket import pm, public_profile_view, verified_market_url
from .service import validate_wallet
from . import research as r
from .ai_research import AIResearch, ConfigIn
router=APIRouter(prefix='/api/research')
ai=AIResearch(db,pm)


def _journal_display(items: list[dict]) -> list[dict]:
    addresses = sorted({item.get('wallet') for item in items if item.get('wallet')})
    identities = {}
    if addresses:
        placeholders = ','.join('?' for _ in addresses)
        identities = {row['address']: row for row in r.rows(db,
            f'SELECT address,proxy_wallet,username,avatar_url,source,refreshed_at FROM wallet_public_profiles WHERE address IN ({placeholders})', addresses)}
    for item in items:
        item['leader_identity'] = public_profile_view(identities.get(item.get('wallet')), item.get('wallet') or '')
        item['market_url'] = verified_market_url(item.get('evidence'))
    return items

@router.get('/overview')
def overview():
    data=r.rows(db,'SELECT status,event_id,condition_id,token_id,cost,fee,pnl,settled_ts,marked_pnl FROM research_entries')
    return dict(baseline=r.BASELINE,metrics=r.metrics(data),counts={s:sum(x['status']==s for x in data) for s in ('OPEN','SETTLED','SKIP','PENDING')},
      versions=r.rows(db,'SELECT * FROM research_versions ORDER BY id DESC LIMIT 100'),
      exclusions=r.rows(db,'SELECT * FROM research_exclusions'),identities=r.rows(db,'SELECT * FROM research_identity'),
      reviews=r.rows(db,"SELECT subject,response_json,created_ts FROM research_ai_runs WHERE kind='WALLET' AND status='OK' ORDER BY id DESC LIMIT 100"),
      ai=ai.public_config(),last_error=ai.last_error)

@router.get('/experiment')
def experiment():
    return r.experiment_summary(db)

@router.get('/experiment/entries')
def experiment_entry_list(offset:int=Query(0,ge=0),limit:int=Query(50,ge=1,le=200),status:str='',wallet:str=''):
    result = r.experiment_entries(db,offset=offset,limit=limit,status=status or None,wallet=wallet or None)
    result['entries'] = _journal_display(result['entries'])
    return result

@router.get('/experiment/entries/{entry_id}')
def experiment_entry_detail(entry_id:int):
    rows = r.rows(db,'SELECT * FROM research_experiment_entries WHERE id=?',(entry_id,))
    if not rows: raise HTTPException(404,'无此实验记录')
    item = rows[0]
    item['evidence'] = json.loads(item.pop('entry_json'))
    return _journal_display([item])[0]

@router.post('/experiment/start')
def start_experiment():
    try:return r.start_experiment(db)
    except ValueError as e:raise HTTPException(409,str(e))

@router.get('/entries')
def entries(offset:int=Query(0,ge=0),limit:int=Query(50,ge=1,le=200),status:str='',wallet:str=''):
    where='WHERE 1=1';args=[]
    if status:where+=' AND status=?';args.append(status)
    if wallet:where+=' AND wallet=?';args.append(wallet.lower())
    total=r.rows(db,'SELECT COUNT(*) n FROM research_entries '+where,args)[0]['n']
    data=r.rows(db,'SELECT id FROM research_entries '+where+' ORDER BY id DESC LIMIT ? OFFSET ?',[*args,limit,offset])
    return {'total':total,'entries':_journal_display([r.entry(db,x['id']) for x in data])}

@router.get('/entries/{entry_id}')
def detail(entry_id:int):
    item=r.entry(db,entry_id)
    if item is None:raise HTTPException(404,'无此记录')
    return _journal_display([item])[0]

@router.get('/wallets/{wallet}')
def wallet_evidence(wallet:str):
    try:wallet=validate_wallet(wallet)
    except ValueError as e:raise HTTPException(400,str(e))
    context=r.evidence(db,wallet)
    context['ai_reviews']=r.rows(db,"SELECT * FROM research_ai_runs WHERE kind='WALLET' AND subject=? ORDER BY id DESC LIMIT 5",(wallet,))
    return context

@router.delete('/wallets/{wallet}')
def delete_wallet(wallet:str):
    try:r.exclude(db,validate_wallet(wallet))
    except ValueError as e:raise HTTPException(400,str(e))
    return {'ok':True}

@router.post('/wallets/{wallet}/restore')
def restore(wallet:str):
    try:r.exclude(db,validate_wallet(wallet),True)
    except ValueError as e:raise HTTPException(400,str(e))
    return {'ok':True}

@router.post('/wallets/{wallet}/review')
def review(wallet:str):
    try:wallet=validate_wallet(wallet)
    except ValueError as e:raise HTTPException(400,str(e))
    if r.excluded(db,wallet):raise HTTPException(409,'请先恢复该钱包')
    r.enqueue(db,'WALLET',wallet)
    return {'ok':True,'message':'已排入复盘；同一钱包每天最多自动调用一次'}

class IdentityIn(BaseModel):
    group_id:str=Field(max_length=100)
@router.post('/wallets/{wallet}/identity')
def identity(wallet:str,body:IdentityIn):
    try:wallet=validate_wallet(wallet)
    except ValueError as e:raise HTTPException(400,str(e))
    with db.conn() as c:
        if body.group_id.strip(): c.execute('INSERT OR REPLACE INTO research_identity VALUES(?,?)',(wallet,body.group_id.strip()))
        else:c.execute('DELETE FROM research_identity WHERE wallet=?',(wallet,))
    r.audit(db,'IDENTITY',dict(wallet=wallet,group=body.group_id));return {'ok':True}

@router.post('/versions/{version_id}/retire')
def retire(version_id:int):
    with db.conn() as c:c.execute("UPDATE research_versions SET state='RETIRED' WHERE id=?",(version_id,))
    r.audit(db,'RETIRE_VERSION',{'version_id':version_id});return {'ok':True}

@router.get('/ai/config')
def config():return ai.public_config()
@router.post('/ai/config')
def save(body:ConfigIn):return ai.save_config(body.model_dump())
@router.post('/ai/test')
async def test():
    try:return await ai.call('TEST','connection',{'message':'回复连接成功，说明你只负责有证据的研究。'})
    except ValueError as e:raise HTTPException(400,str(e))
@router.get('/ai/logs')
def logs():return r.rows(db,'SELECT * FROM research_ai_runs ORDER BY id DESC LIMIT 30')
@router.post('/ai/report')
def report():
    r.enqueue(db,'REPORT','manual-'+str(int(time.time()//86400)));return {'ok':True}

@router.get('/export')
def export():
    # A consistent SQLite read snapshot; config / API keys deliberately excluded.
    def generate():
        with db.conn() as c:
            c.execute('BEGIN')
            for table in ('research_entries','research_versions','research_exclusions','research_identity','research_ai_runs','research_jobs','research_audit','research_leader_outcomes','research_experiments','research_experiment_wallets','research_experiment_entries'):
                for row in c.execute('SELECT * FROM '+table):
                    yield r.dump({'table':table,'record':dict(row)})+'\n'
    return StreamingResponse(generate(),media_type='application/x-ndjson',headers={'Content-Disposition':'attachment; filename=edge-research.ndjson'})
