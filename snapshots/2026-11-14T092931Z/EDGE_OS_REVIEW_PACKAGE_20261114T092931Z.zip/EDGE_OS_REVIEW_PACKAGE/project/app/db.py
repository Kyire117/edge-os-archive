from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterable

from .config import settings
from .polymarket import public_profile_view


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Database:
    def __init__(self, path: str | None = None):
        self.path = path or settings.database_path
        self._write_lock = threading.Lock()

    @contextmanager
    def conn(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=5000")
        con.execute("PRAGMA foreign_keys=ON")
        try:
            yield con
            con.commit()
        finally:
            con.close()

    def init(self) -> None:
        settings.ensure_dirs()
        schema = """
        CREATE TABLE IF NOT EXISTS wallets (
            address TEXT PRIMARY KEY,
            status TEXT NOT NULL DEFAULT 'OBSERVING',
            tracked INTEGER NOT NULL DEFAULT 1,
            auto_managed INTEGER NOT NULL DEFAULT 0,
            discovery_source TEXT,
            alpha_class TEXT NOT NULL DEFAULT 'COLLECTING',
            alpha_target TEXT NOT NULL DEFAULT 'EXPLORE',
            classification_reason TEXT,
            classified_at TEXT,
            tracking_reason TEXT,
            paused_at TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_trade_ts INTEGER,
            stats_json TEXT NOT NULL DEFAULT '{}',
            analytics_json TEXT NOT NULL DEFAULT '{}',
            last_error TEXT
        );

        CREATE TABLE IF NOT EXISTS wallet_category_stats (
            address TEXT NOT NULL,
            category TEXT NOT NULL,
            market_count INTEGER NOT NULL DEFAULT 0,
            profitable_count INTEGER NOT NULL DEFAULT 0,
            pnl REAL NOT NULL DEFAULT 0,
            cost REAL NOT NULL DEFAULT 0,
            roi REAL NOT NULL DEFAULT 0,
            win_rate REAL NOT NULL DEFAULT 0,
            avg_position REAL NOT NULL DEFAULT 0,
            PRIMARY KEY (address, category),
            FOREIGN KEY(address) REFERENCES wallets(address) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS wallet_public_profiles (
            address TEXT PRIMARY KEY,
            proxy_wallet TEXT,
            username TEXT,
            avatar_url TEXT,
            profile_url TEXT,
            source TEXT NOT NULL,
            checked_at REAL NOT NULL,
            refreshed_at REAL,
            FOREIGN KEY(address) REFERENCES wallets(address) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS trades (
            trade_key TEXT PRIMARY KEY,
            wallet TEXT NOT NULL,
            token_id TEXT,
            condition_id TEXT,
            event_id TEXT,
            side TEXT,
            price REAL,
            size REAL,
            usd_value REAL,
            timestamp INTEGER,
            title TEXT,
            outcome TEXT,
            category TEXT,
            tx_hash TEXT,
            is_seed INTEGER NOT NULL DEFAULT 0,
            discovered_at TEXT NOT NULL,
            raw_json TEXT NOT NULL DEFAULT '{}',
            FOREIGN KEY(wallet) REFERENCES wallets(address) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_trades_wallet_ts ON trades(wallet, timestamp DESC);

        -- Realtime polling is a bounded, resumable ingestion lane. A checkpoint
        -- advances only after every cursor page and staged event in the range
        -- has been accounted for. Queue rows are transient staging, not fills.
        CREATE TABLE IF NOT EXISTS wallet_ingest_state (
            wallet TEXT PRIMARY KEY,
            checkpoint_timestamp INTEGER,
            checkpoint_trade_key TEXT,
            range_start INTEGER,
            next_cursor TEXT,
            cursor_history_json TEXT NOT NULL DEFAULT '[]',
            state TEXT NOT NULL DEFAULT 'IDLE'
                CHECK(state IN ('IDLE','FETCHING','DRAINING')),
            pages_requested INTEGER NOT NULL DEFAULT 0,
            rows_received INTEGER NOT NULL DEFAULT 0,
            range_max_timestamp INTEGER,
            last_attempt_at TEXT,
            last_success_at TEXT,
            failure_count INTEGER NOT NULL DEFAULT 0,
            next_retry_at REAL,
            last_error_category TEXT,
            last_error TEXT,
            FOREIGN KEY(wallet) REFERENCES wallets(address) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS wallet_ingest_queue (
            wallet TEXT NOT NULL,
            trade_key TEXT NOT NULL,
            trade_timestamp INTEGER NOT NULL,
            payload_json TEXT NOT NULL,
            source TEXT NOT NULL,
            state TEXT NOT NULL DEFAULT 'PENDING' CHECK(state IN ('PENDING','DONE')),
            staged_at TEXT NOT NULL,
            processed_at TEXT,
            outcome TEXT,
            PRIMARY KEY(wallet,trade_key),
            FOREIGN KEY(wallet) REFERENCES wallets(address) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_ingest_queue_pending
            ON wallet_ingest_queue(wallet,state,trade_timestamp,trade_key);
        CREATE TABLE IF NOT EXISTS wallet_ingest_events (
            trade_key TEXT PRIMARY KEY,
            wallet TEXT NOT NULL,
            first_source TEXT NOT NULL,
            claimed_at TEXT NOT NULL,
            completed_at TEXT,
            state TEXT NOT NULL CHECK(state IN ('CLAIMED','COMPLETE','FAILED')),
            outcome TEXT,
            error_type TEXT,
            error_detail TEXT,
            FOREIGN KEY(wallet) REFERENCES wallets(address) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS wallet_ingest_sources (
            trade_key TEXT NOT NULL,
            source TEXT NOT NULL,
            observed_at TEXT NOT NULL,
            first_source INTEGER NOT NULL DEFAULT 0,
            evidence_json TEXT NOT NULL DEFAULT '{}',
            PRIMARY KEY(trade_key,source),
            FOREIGN KEY(trade_key) REFERENCES trades(trade_key) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS wallet_ingest_attempts (
            attempt_id TEXT PRIMARY KEY,
            wallet TEXT NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT NOT NULL,
            outcome TEXT NOT NULL,
            error_category TEXT,
            pages_requested INTEGER NOT NULL DEFAULT 0,
            rows_received INTEGER NOT NULL DEFAULT 0,
            backlog_remaining INTEGER NOT NULL DEFAULT 0,
            cursor_present INTEGER NOT NULL DEFAULT 0,
            retry_count INTEGER NOT NULL DEFAULT 0,
            backoff_seconds REAL NOT NULL DEFAULT 0,
            elapsed_ms REAL NOT NULL DEFAULT 0,
            evidence_json TEXT NOT NULL DEFAULT '{}',
            FOREIGN KEY(wallet) REFERENCES wallets(address) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_ingest_attempts_wallet
            ON wallet_ingest_attempts(wallet,started_at DESC);

        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trade_key TEXT NOT NULL UNIQUE,
            wallet TEXT NOT NULL,
            token_id TEXT,
            market_title TEXT,
            outcome TEXT,
            category TEXT,
            leader_side TEXT,
            leader_price REAL,
            current_price REAL,
            leader_size REAL,
            leader_timestamp INTEGER,
            delay_ms INTEGER,
            scan_latency_ms INTEGER,
            expected_alpha REAL,
            delay_cost REAL,
            spread REAL,
            slippage REAL,
            fee_rate REAL,
            fee_cost REAL,
            safety_margin REAL,
            net_copy_edge REAL,
            paper_size_usd REAL,
            decision TEXT NOT NULL,
            skip_reason TEXT,
            is_initial_sync INTEGER NOT NULL DEFAULT 0,
            settlement_price REAL,
            settled_at TEXT,
            settlement_checked_at TEXT,
            created_at TEXT NOT NULL,
            raw_json TEXT NOT NULL DEFAULT '{}',
            FOREIGN KEY(wallet) REFERENCES wallets(address) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_signals_created ON signals(created_at DESC);

        CREATE TABLE IF NOT EXISTS signal_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER NOT NULL,
            wallet TEXT NOT NULL,
            token_id TEXT NOT NULL,
            horizon_seconds INTEGER NOT NULL,
            price REAL,
            adverse_move REAL,
            actual_delay_seconds REAL,
            filled INTEGER,
            cost_usd REAL,
            shares REAL,
            fees_usd REAL,
            slippage REAL,
            spread REAL,
            delayed_net_edge REAL,
            recorded_at TEXT NOT NULL,
            UNIQUE(signal_id, horizon_seconds),
            FOREIGN KEY(signal_id) REFERENCES signals(id)
        );
        CREATE INDEX IF NOT EXISTS idx_snapshots_wallet_horizon ON signal_snapshots(wallet, horizon_seconds);

        CREATE TABLE IF NOT EXISTS paper_trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id INTEGER NOT NULL,
            wallet TEXT NOT NULL,
            token_id TEXT,
            market_title TEXT,
            outcome TEXT,
            side TEXT,
            entry_price REAL,
            shares REAL,
            cost_usd REAL,
            fees_usd REAL,
            status TEXT NOT NULL DEFAULT 'OPEN',
            exit_price REAL,
            exit_value_usd REAL,
            pnl REAL,
            roi REAL,
            opened_at TEXT NOT NULL,
            closed_at TEXT,
            close_reason TEXT,
            mark_price REAL,
            current_value_usd REAL,
            unrealized_pnl REAL,
            unrealized_roi REAL,
            marked_at TEXT,
            mark_source TEXT,
            FOREIGN KEY(signal_id) REFERENCES signals(id)
        );
        CREATE INDEX IF NOT EXISTS idx_paper_status ON paper_trades(status, opened_at DESC);

        CREATE TABLE IF NOT EXISTS system_state (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS wallet_candidates (
            address TEXT PRIMARY KEY,
            source TEXT NOT NULL,
            best_rank INTEGER,
            leaderboard_pnl REAL,
            leaderboard_volume REAL,
            discovery_score REAL NOT NULL DEFAULT 0,
            appearances INTEGER NOT NULL DEFAULT 1,
            time_period TEXT,
            category TEXT,
            target_pool TEXT NOT NULL DEFAULT 'EXPLORE',
            slow_prior_score REAL NOT NULL DEFAULT 0,
            fast_prior_score REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'NEW',
            reject_reason TEXT,
            discovered_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            analyzed_at TEXT,
            raw_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS idx_candidates_score ON wallet_candidates(status, discovery_score DESC);
        """
        with self.conn() as con:
            # WAL is persistent for the database file. Re-applying this on
            # every high-frequency connection creates avoidable lock churn.
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA synchronous=NORMAL")
            con.executescript(schema)
            from .fill_identity import SCHEMA as fill_identity_schema
            con.executescript(fill_identity_schema)
            wallet_columns = {row["name"] for row in con.execute("PRAGMA table_info(wallets)").fetchall()}
            wallet_migrations = {
                "auto_managed": "INTEGER NOT NULL DEFAULT 0",
                "discovery_source": "TEXT",
                "alpha_class": "TEXT NOT NULL DEFAULT 'COLLECTING'",
                "alpha_target": "TEXT NOT NULL DEFAULT 'EXPLORE'",
                "classification_reason": "TEXT",
                "classified_at": "TEXT",
                "tracking_reason": "TEXT",
                "paused_at": "TEXT",
            }
            for name, sql_type in wallet_migrations.items():
                if name not in wallet_columns:
                    con.execute(f"ALTER TABLE wallets ADD COLUMN {name} {sql_type}")
            signal_columns = {row["name"] for row in con.execute("PRAGMA table_info(signals)").fetchall()}
            if "is_initial_sync" not in signal_columns:
                con.execute("ALTER TABLE signals ADD COLUMN is_initial_sync INTEGER NOT NULL DEFAULT 0")
            if "scan_latency_ms" not in signal_columns:
                con.execute("ALTER TABLE signals ADD COLUMN scan_latency_ms INTEGER")
            signal_migrations = {
                "leader_timestamp": "INTEGER",
                "settlement_price": "REAL",
                "settled_at": "TEXT",
                "settlement_checked_at": "TEXT",
            }
            for name, sql_type in signal_migrations.items():
                if name not in signal_columns:
                    con.execute(f"ALTER TABLE signals ADD COLUMN {name} {sql_type}")
            snapshot_columns = {row["name"] for row in con.execute("PRAGMA table_info(signal_snapshots)").fetchall()}
            snapshot_migrations = {
                "actual_delay_seconds": "REAL",
                "filled": "INTEGER",
                "cost_usd": "REAL",
                "shares": "REAL",
                "fees_usd": "REAL",
                "slippage": "REAL",
                "spread": "REAL",
                "delayed_net_edge": "REAL",
            }
            for name, sql_type in snapshot_migrations.items():
                if name not in snapshot_columns:
                    con.execute(f"ALTER TABLE signal_snapshots ADD COLUMN {name} {sql_type}")
            candidate_columns = {row["name"] for row in con.execute("PRAGMA table_info(wallet_candidates)").fetchall()}
            candidate_migrations = {
                "target_pool": "TEXT NOT NULL DEFAULT 'EXPLORE'",
                "slow_prior_score": "REAL NOT NULL DEFAULT 0",
                "fast_prior_score": "REAL NOT NULL DEFAULT 0",
            }
            for name, sql_type in candidate_migrations.items():
                if name not in candidate_columns:
                    con.execute(f"ALTER TABLE wallet_candidates ADD COLUMN {name} {sql_type}")
            paper_columns = {row["name"] for row in con.execute("PRAGMA table_info(paper_trades)").fetchall()}
            paper_migrations = {
                "mark_price": "REAL",
                "current_value_usd": "REAL",
                "unrealized_pnl": "REAL",
                "unrealized_roi": "REAL",
                "marked_at": "TEXT",
                "mark_source": "TEXT",
            }
            for name, sql_type in paper_migrations.items():
                if name not in paper_columns:
                    con.execute(f"ALTER TABLE paper_trades ADD COLUMN {name} {sql_type}")
        self.mark_legacy_initial_sync_signals()
        if not settings.research_enabled:
            self.reset_legacy_discovery_once()
        from .research import init
        init(self)

    def reset_legacy_discovery_once(self) -> dict[str, int]:
        """Remove the old leaderboard-qualified cohort once after this upgrade.

        Wallets with Paper history are retired and hidden so their accounting
        remains intact. Other auto-managed wallets and the old candidate pool
        are deleted. Manually analyzed wallets are left untouched.
        """
        key = "slow_alpha_reset_v1"
        with self._write_lock, self.conn() as con:
            if con.execute("SELECT 1 FROM system_state WHERE key=?", (key,)).fetchone():
                return {"deleted": 0, "retired": 0, "candidates": 0}
            rows = con.execute(
                "SELECT address FROM wallets WHERE auto_managed=1 OR discovery_source='POLYMARKET_LEADERBOARD'"
            ).fetchall()
            deleted = retired = 0
            for row in rows:
                address = row["address"]
                has_paper = con.execute(
                    "SELECT 1 FROM paper_trades WHERE wallet=? LIMIT 1", (address,)
                ).fetchone()
                if has_paper:
                    con.execute(
                        """
                        UPDATE wallets SET tracked=0,status='RETIRED_LEGACY',
                            tracking_reason='旧版排行榜 Qualified 已清理；仅保留 Paper 历史',updated_at=?
                        WHERE address=?
                        """,
                        (utc_now_iso(), address),
                    )
                    retired += 1
                else:
                    con.execute(
                        "DELETE FROM signal_snapshots WHERE signal_id IN (SELECT id FROM signals WHERE wallet=?)",
                        (address,),
                    )
                    con.execute("DELETE FROM wallets WHERE address=?", (address,))
                    deleted += 1
            candidate_count = int(con.execute("SELECT COUNT(*) c FROM wallet_candidates").fetchone()["c"])
            con.execute("DELETE FROM wallet_candidates")
            con.execute("INSERT INTO system_state(key,value) VALUES(?,?)", (key, utc_now_iso()))
            return {"deleted": deleted, "retired": retired, "candidates": candidate_count}

    def mark_legacy_initial_sync_signals(self) -> int:
        """Hide the exact 100-row race fingerprint created by older builds.

        Rows are retained and can be recovered by setting is_initial_sync=0.
        The narrow rule avoids reclassifying genuine LOW_TRADER_CONFIDENCE
        signals from wallets that were deliberately observed before qualifying.
        """
        with self._write_lock, self.conn() as con:
            cur = con.execute(
                """
                UPDATE signals AS s
                SET is_initial_sync=1
                WHERE is_initial_sync=0
                  AND skip_reason='LOW_TRADER_CONFIDENCE'
                  AND NOT EXISTS (SELECT 1 FROM paper_trades p WHERE p.signal_id=s.id)
                  AND NOT EXISTS (SELECT 1 FROM signal_snapshots ss WHERE ss.signal_id=s.id)
                  AND 100=(SELECT COUNT(*) FROM signals all_s WHERE all_s.wallet=s.wallet)
                  AND 100=(
                      SELECT COUNT(*) FROM signals low_s
                      WHERE low_s.wallet=s.wallet
                        AND low_s.skip_reason='LOW_TRADER_CONFIDENCE'
                  )
                """
            )
            return int(cur.rowcount or 0)

    def upsert_wallet(self, address: str, tracked: bool = True) -> None:
        now = utc_now_iso()
        with self._write_lock, self.conn() as con:
            con.execute(
                """
                INSERT INTO wallets(address, tracked, created_at, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(address) DO UPDATE SET tracked=excluded.tracked, updated_at=excluded.updated_at
                """,
                (address.lower(), int(tracked), now, now),
            )

    def set_wallet_analysis(self, address: str, stats: dict[str, Any], analytics: dict[str, Any], status: str) -> None:
        with self._write_lock, self.conn() as con:
            con.execute(
                "UPDATE wallets SET stats_json=?, analytics_json=?, status=?, updated_at=?, last_error=NULL WHERE address=?",
                (json.dumps(stats), json.dumps(analytics), status, utc_now_iso(), address.lower()),
            )
            con.execute("DELETE FROM wallet_category_stats WHERE address=?", (address.lower(),))
            for row in analytics.get("category_breakdown", []):
                con.execute(
                    """
                    INSERT INTO wallet_category_stats(address, category, market_count, profitable_count, pnl, cost, roi, win_rate, avg_position)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        address.lower(), row["category"], row["market_count"], row["profitable_count"], row["pnl"],
                        row["cost"], row["roi"], row["win_rate"], row["avg_position"]
                    ),
                )

    def set_wallet_error(self, address: str, error: str) -> None:
        with self._write_lock, self.conn() as con:
            con.execute("UPDATE wallets SET last_error=?, updated_at=? WHERE address=?", (error[:1000], utc_now_iso(), address.lower()))

    def clear_wallet_monitor_error(self, address: str) -> None:
        """Clear only stale errors owned by the wallet monitor."""
        with self._write_lock, self.conn() as con:
            con.execute("UPDATE wallets SET last_error=NULL, updated_at=? WHERE address=? AND last_error LIKE 'monitor:%'",
                        (utc_now_iso(), address.lower()))

    def save_public_profile(self, address: str, profile: dict[str, Any], checked_at: float) -> None:
        with self._write_lock, self.conn() as con:
            previous = con.execute("SELECT * FROM wallet_public_profiles WHERE address=?", (address.lower(),)).fetchone()
            if profile.get("source") != "GAMMA_PUBLIC_PROFILE" and previous and previous["proxy_wallet"]:
                profile = {**dict(previous), "source": "STALE_GAMMA_PUBLIC_PROFILE"}
            con.execute("""INSERT INTO wallet_public_profiles
                (address,proxy_wallet,username,avatar_url,profile_url,source,checked_at,refreshed_at)
                VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(address) DO UPDATE SET
                proxy_wallet=excluded.proxy_wallet,username=excluded.username,
                avatar_url=excluded.avatar_url,profile_url=excluded.profile_url,
                source=excluded.source,checked_at=excluded.checked_at,
                refreshed_at=COALESCE(excluded.refreshed_at,wallet_public_profiles.refreshed_at)""",
                (address.lower(), profile.get("proxy_wallet"), profile.get("username"),
                 profile.get("avatar_url"), profile.get("profile_url"), profile.get("source", "UNAVAILABLE"),
                 checked_at, checked_at if profile.get("source") == "GAMMA_PUBLIC_PROFILE" else None))

    def public_profile_refresh_candidates(self, now: float, limit: int = 5) -> list[str]:
        with self.conn() as con:
            return [row["address"] for row in con.execute("""SELECT w.address FROM wallets w
                LEFT JOIN wallet_public_profiles p ON p.address=w.address
                WHERE w.status!='RETIRED_LEGACY' AND
                  (p.address IS NULL OR p.checked_at < ? - CASE
                   WHEN p.source='GAMMA_PUBLIC_PROFILE' THEN 86400 ELSE 21600 END)
                ORDER BY COALESCE(p.checked_at,0),w.address LIMIT ?""", (now, limit))]

    def set_wallet_tracked(self, address: str, tracked: bool) -> None:
        from .research import excluded
        if tracked and excluded(self, address.lower()):
            raise ValueError("该钱包已被手动排除，请先恢复候选")
        with self._write_lock, self.conn() as con:
            if tracked:
                con.execute(
                    """
                    UPDATE wallets
                    SET tracked=1,
                        status=CASE WHEN status='PAUSED_DELAY' THEN alpha_class ELSE status END,
                        tracking_reason=NULL, paused_at=NULL, updated_at=?
                    WHERE address=?
                    """,
                    (utc_now_iso(), address.lower()),
                )
            else:
                con.execute(
                    "UPDATE wallets SET tracked=0, updated_at=? WHERE address=?",
                    (utc_now_iso(), address.lower()),
                )

    def set_wallet_origin(self, address: str, source: str, auto_managed: bool = True) -> None:
        with self._write_lock, self.conn() as con:
            con.execute(
                "UPDATE wallets SET discovery_source=?, auto_managed=?, updated_at=? WHERE address=?",
                (source, int(auto_managed), utc_now_iso(), address.lower()),
            )

    def set_wallet_alpha_target(self, address: str, target: str) -> None:
        target = target.upper()
        if target not in {"SLOW", "FAST", "EXPLORE", "MANUAL"}:
            target = "EXPLORE"
        with self._write_lock, self.conn() as con:
            con.execute(
                "UPDATE wallets SET alpha_target=?,updated_at=? WHERE address=?",
                (target, utc_now_iso(), address.lower()),
            )

    def pause_wallet_for_delay(self, address: str, reason: str) -> None:
        with self._write_lock, self.conn() as con:
            con.execute(
                """
                UPDATE wallets
                SET tracked=0, status='PAUSED_DELAY', tracking_reason=?, paused_at=?, updated_at=?
                WHERE address=?
                """,
                (reason[:500], utc_now_iso(), utc_now_iso(), address.lower()),
            )

    def get_wallet(self, address: str) -> dict[str, Any] | None:
        with self.conn() as con:
            row = con.execute("SELECT * FROM wallets WHERE address=?", (address.lower(),)).fetchone()
            if not row:
                return None
            out = dict(row)
            out["tracked"] = bool(out["tracked"])
            out["stats"] = json.loads(out.pop("stats_json") or "{}")
            out["analytics"] = json.loads(out.pop("analytics_json") or "{}")
            out["category_stats"] = [dict(x) for x in con.execute("SELECT * FROM wallet_category_stats WHERE address=? ORDER BY pnl DESC", (address.lower(),)).fetchall()]
            profile = con.execute("SELECT * FROM wallet_public_profiles WHERE address=?", (address.lower(),)).fetchone()
            out["public_profile"] = public_profile_view(dict(profile), address) if profile else None
            return out

    def list_wallets(self) -> list[dict[str, Any]]:
        with self.conn() as con:
            rows = con.execute("SELECT * FROM wallets WHERE status!='RETIRED_LEGACY' ORDER BY updated_at DESC").fetchall()
            profiles = {x["address"]: dict(x) for x in con.execute("SELECT * FROM wallet_public_profiles").fetchall()}
        result = []
        for row in rows:
            item = dict(row)
            item["tracked"] = bool(item["tracked"])
            item["stats"] = json.loads(item.pop("stats_json") or "{}")
            item["analytics"] = json.loads(item.pop("analytics_json") or "{}")
            item["public_profile"] = public_profile_view(profiles.get(item["address"]), item["address"])
            result.append(item)
        return result

    def tracked_wallets(self) -> list[dict[str, Any]]:
        result = []
        for wallet in self.list_wallets():
            if not wallet["tracked"]:
                continue
            detailed = self.get_wallet(wallet["address"])
            if detailed is not None:
                result.append(detailed)
        return result

    def wallet_paper_totals(self) -> dict[str, dict[str, Any]]:
        """Never combine the frozen experiment, older research, and legacy paper."""
        with self.conn() as con:
            latest = con.execute("SELECT id FROM research_experiments ORDER BY started_at DESC LIMIT 1").fetchone()
            experiment = con.execute("""SELECT wallet,
                SUM(CASE WHEN status='SETTLED' THEN COALESCE(pnl,0) ELSE 0 END) realized_pnl,
                SUM(CASE WHEN status='OPEN' THEN COALESCE(unrealized_pnl,0) ELSE 0 END) unrealized_pnl,
                SUM(CASE WHEN status='OPEN' THEN 1 ELSE 0 END) open_count
                FROM research_experiment_entries WHERE experiment_id=? GROUP BY wallet""",
                (latest["id"] if latest else "",)).fetchall()
            prior_experiments = con.execute("""SELECT wallet,
                SUM(CASE WHEN status='SETTLED' THEN COALESCE(pnl,0) ELSE 0 END) realized_pnl,
                SUM(CASE WHEN status='OPEN' THEN COALESCE(unrealized_pnl,0) ELSE 0 END) unrealized_pnl
                FROM research_experiment_entries WHERE experiment_id!=? GROUP BY wallet""",
                (latest["id"] if latest else "",)).fetchall()
            research = con.execute("""SELECT wallet,
                SUM(CASE WHEN status='SETTLED' THEN COALESCE(pnl,0) ELSE 0 END) realized_pnl,
                SUM(CASE WHEN status='OPEN' THEN COALESCE(marked_pnl,0) ELSE 0 END) unrealized_pnl
                FROM research_entries GROUP BY wallet""").fetchall()
            legacy = con.execute("""SELECT wallet,
                SUM(CASE WHEN status!='OPEN' THEN COALESCE(pnl,0) ELSE 0 END) realized_pnl,
                SUM(CASE WHEN status='OPEN' THEN COALESCE(unrealized_pnl,0) ELSE 0 END) unrealized_pnl
                FROM paper_trades GROUP BY wallet""").fetchall()
        result: dict[str, dict[str, Any]] = {}
        for key, rows in (("experiment", experiment), ("prior_experiments", prior_experiments),
                          ("older_research", research), ("legacy_paper", legacy)):
            for row in rows:
                result.setdefault(row["wallet"], {})[key] = dict(row)
        return result

    def replace_seed_trades(self, wallet: str, trades: Iterable[dict[str, Any]]) -> int:
        count = 0
        with self._write_lock, self.conn() as con:
            for t in trades:
                cur = con.execute(
                    """
                    INSERT OR IGNORE INTO trades(trade_key,wallet,token_id,condition_id,event_id,side,price,size,usd_value,timestamp,title,outcome,category,tx_hash,is_seed,discovered_at,raw_json)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        t["trade_key"], wallet.lower(), t.get("token_id"), t.get("condition_id"), t.get("event_id"), t.get("side"),
                        t.get("price"), t.get("size"), t.get("usd_value"), t.get("timestamp"), t.get("title"), t.get("outcome"),
                        t.get("category"), t.get("tx_hash"), 1, utc_now_iso(), json.dumps(t.get("raw", {}))
                    ),
                )
                count += cur.rowcount
            max_ts = con.execute("SELECT MAX(timestamp) AS m FROM trades WHERE wallet=?", (wallet.lower(),)).fetchone()["m"]
            if max_ts:
                con.execute("UPDATE wallets SET last_trade_ts=? WHERE address=?", (int(max_ts), wallet.lower()))
        return count

    def insert_trade_if_new(self, wallet: str, t: dict[str, Any], *, source: str = "DIRECT",
                            advance_checkpoint: bool = True) -> bool:
        """First-source-wins raw event gate shared by poll and fast ingestion.

        Duplicate sources are retained as reconciliation evidence but never
        routed to the strategy a second time.
        """
        wallet = wallet.lower()
        trade_key = str(t["trade_key"])
        source = str(source or "UNKNOWN")[:40]
        now = utc_now_iso()
        raw = dict(t.get("raw", {})) if isinstance(t.get("raw"), dict) else {}
        raw.setdefault("_edge_ingest", {"first_source": source, "observed_at": now})
        with self._write_lock, self.conn() as con:
            # Canonical aliases and raw trade ownership are one SQLite transaction.
            con.execute("BEGIN IMMEDIATE")
            from .fill_identity import claim_identity
            if not claim_identity(con, wallet, t, source, now):
                return False
            trade_key = str(t["trade_key"])
            cur = con.execute(
                """
                INSERT OR IGNORE INTO trades(trade_key,wallet,token_id,condition_id,event_id,side,price,size,usd_value,timestamp,title,outcome,category,tx_hash,is_seed,discovered_at,raw_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    trade_key, wallet, t.get("token_id"), t.get("condition_id"), t.get("event_id"), t.get("side"),
                    t.get("price"), t.get("size"), t.get("usd_value"), t.get("timestamp"), t.get("title"), t.get("outcome"),
                    t.get("category"), t.get("tx_hash"), 0, now, json.dumps(raw, sort_keys=True, default=str)
                ),
            )
            if cur.rowcount:
                con.execute("INSERT INTO wallet_ingest_events(trade_key,wallet,first_source,claimed_at,state) VALUES(?,?,?,?,'CLAIMED')",
                            (trade_key,wallet,source,now))
                con.execute("INSERT INTO wallet_ingest_sources(trade_key,source,observed_at,first_source,evidence_json) VALUES(?,?,?,1,?)",
                            (trade_key,source,now,json.dumps({"timestamp":t.get("timestamp"),"tx_hash":t.get("tx_hash")},sort_keys=True)))
                if advance_checkpoint and t.get("timestamp"):
                    con.execute("UPDATE wallets SET last_trade_ts=MAX(COALESCE(last_trade_ts,0),?) WHERE address=?", (int(t["timestamp"]), wallet))
                return True
            con.execute("INSERT OR IGNORE INTO wallet_ingest_sources(trade_key,source,observed_at,first_source,evidence_json) VALUES(?,?,?,0,?)",
                        (trade_key,source,now,json.dumps({"timestamp":t.get("timestamp"),"tx_hash":t.get("tx_hash"),"duplicate":True},sort_keys=True)))
            return False

    def complete_ingest_event(self, trade_key: str, *, outcome: str | None = None,
                              error_type: str | None = None, error_detail: str | None = None) -> None:
        state = "FAILED" if error_type else "COMPLETE"
        with self._write_lock, self.conn() as con:
            con.execute("UPDATE wallet_ingest_events SET completed_at=?,state=?,outcome=?,error_type=?,error_detail=? WHERE trade_key=? AND state='CLAIMED'",
                        (utc_now_iso(),state,str(outcome or "")[:80] or None,str(error_type or "")[:100] or None,
                         str(error_detail or "")[:500] or None,trade_key))

    def ingest_poll_state(self, wallet: str) -> dict[str, Any] | None:
        with self.conn() as con:
            row = con.execute("SELECT * FROM wallet_ingest_state WHERE wallet=?", (wallet.lower(),)).fetchone()
        return dict(row) if row else None

    def begin_ingest_range(self, wallet: str, *, baseline_timestamp: int, now: str) -> dict[str, Any]:
        wallet = wallet.lower()
        with self._write_lock, self.conn() as con:
            con.execute("INSERT OR IGNORE INTO wallet_ingest_state(wallet,checkpoint_timestamp,state) VALUES(?,?,'IDLE')",
                        (wallet,int(baseline_timestamp)))
            row = con.execute("SELECT * FROM wallet_ingest_state WHERE wallet=?",(wallet,)).fetchone()
            if row["state"] == "IDLE":
                checkpoint = row["checkpoint_timestamp"]
                start = max(1, int(checkpoint if checkpoint is not None else baseline_timestamp)-5)
                con.execute("UPDATE wallet_ingest_state SET range_start=?,next_cursor=NULL,cursor_history_json='[]',state='FETCHING',pages_requested=0,rows_received=0,range_max_timestamp=NULL,last_attempt_at=?,last_error_category=NULL,last_error=NULL,next_retry_at=NULL WHERE wallet=?",
                            (start,now,wallet))
                row = con.execute("SELECT * FROM wallet_ingest_state WHERE wallet=?",(wallet,)).fetchone()
            return dict(row)

    def stage_ingest_page(self, wallet: str, trades: list[dict[str, Any]], *,
                          current_cursor: str | None, next_cursor: str | None,
                          has_more: bool, now: str) -> None:
        wallet=wallet.lower()
        with self._write_lock, self.conn() as con:
            row=con.execute("SELECT state,range_max_timestamp,pages_requested,rows_received,cursor_history_json FROM wallet_ingest_state WHERE wallet=?",(wallet,)).fetchone()
            if not row or row["state"]!="FETCHING":
                raise ValueError("INGEST_RANGE_NOT_FETCHING")
            history=json.loads(row["cursor_history_json"] or "[]")
            if has_more and (not next_cursor or next_cursor==current_cursor or next_cursor in history):
                raise ValueError("REALTIME_CURSOR_LOOP")
            max_ts=row["range_max_timestamp"]
            for trade in trades:
                trade_key=str(trade.get("trade_key") or "")
                timestamp=trade.get("timestamp")
                if not trade_key or isinstance(timestamp,bool) or not isinstance(timestamp,(int,float)) or int(timestamp)<=0:
                    raise ValueError("INVALID_REALTIME_TRADE_ROW")
                payload=json.dumps(trade,sort_keys=True,separators=(",",":"),default=str)
                con.execute("INSERT OR IGNORE INTO wallet_ingest_queue(wallet,trade_key,trade_timestamp,payload_json,source,state,staged_at) VALUES(?,?,?,?,?,'PENDING',?)",
                            (wallet,trade_key,int(timestamp),payload,"DATA_API_POLL",now))
                max_ts=max(int(max_ts or timestamp),int(timestamp))
            if has_more and next_cursor not in history:
                history.append(next_cursor)
            history=history[-200:]
            con.execute("UPDATE wallet_ingest_state SET next_cursor=?,cursor_history_json=?,state=?,pages_requested=pages_requested+1,rows_received=rows_received+?,range_max_timestamp=?,last_attempt_at=? WHERE wallet=?",
                        (next_cursor,json.dumps(history,separators=(",",":")),"FETCHING" if has_more else "DRAINING",len(trades),max_ts,now,wallet))

    def ingest_cursor_seen(self, wallet: str, cursor: str) -> bool:
        state=self.ingest_poll_state(wallet)
        if not state:
            return False
        try:
            return cursor in json.loads(state.get("cursor_history_json") or "[]")
        except (TypeError,json.JSONDecodeError):
            return True

    def remember_ingest_cursor(self, wallet: str, cursor: str, *, now: str) -> None:
        wallet=wallet.lower()
        with self._write_lock, self.conn() as con:
            row=con.execute("SELECT cursor_history_json FROM wallet_ingest_state WHERE wallet=?",(wallet,)).fetchone()
            history=json.loads(row[0] or "[]") if row else []
            if cursor not in history:
                history.append(cursor)
            # Keep the cursor chain bounded; a 3-page slice will revisit the
            # range cursor only after an explicit failure, which is recorded.
            history=history[-200:]
            con.execute("UPDATE wallet_ingest_state SET cursor_history_json=?,last_attempt_at=? WHERE wallet=?",
                        (json.dumps(history,separators=(",",":")),now,wallet))

    def pending_ingest_trades(self, wallet: str, limit: int) -> list[dict[str, Any]]:
        with self.conn() as con:
            rows=con.execute("SELECT trade_key,payload_json FROM wallet_ingest_queue WHERE wallet=? AND state='PENDING' ORDER BY trade_timestamp,trade_key LIMIT ?",
                              (wallet.lower(),max(1,int(limit)))).fetchall()
        return [{"trade_key":row["trade_key"],"trade":json.loads(row["payload_json"])} for row in rows]

    def finish_ingest_queue_item(self, wallet: str, trade_key: str, *, outcome: str) -> None:
        with self._write_lock, self.conn() as con:
            con.execute("UPDATE wallet_ingest_queue SET state='DONE',processed_at=?,outcome=? WHERE wallet=? AND trade_key=? AND state='PENDING'",
                        (utc_now_iso(),outcome[:80],wallet.lower(),trade_key))

    def finalize_ingest_range(self, wallet: str, *, now: str) -> bool:
        wallet=wallet.lower()
        with self._write_lock, self.conn() as con:
            state=con.execute("SELECT * FROM wallet_ingest_state WHERE wallet=?",(wallet,)).fetchone()
            pending=con.execute("SELECT 1 FROM wallet_ingest_queue WHERE wallet=? AND state='PENDING' LIMIT 1",(wallet,)).fetchone()
            if not state or state["state"]!="DRAINING" or pending:
                return False
            max_ts=state["range_max_timestamp"]
            max_key=None
            if max_ts is not None:
                row=con.execute("SELECT MAX(trade_key) FROM wallet_ingest_queue WHERE wallet=? AND trade_timestamp=?",
                                (wallet,int(max_ts))).fetchone()
                max_key=row[0]
            if max_ts is not None:
                con.execute("UPDATE wallets SET last_trade_ts=MAX(COALESCE(last_trade_ts,0),?) WHERE address=?",(int(max_ts),wallet))
            con.execute("UPDATE wallet_ingest_state SET checkpoint_timestamp=MAX(COALESCE(checkpoint_timestamp,0),COALESCE(?,0)),checkpoint_trade_key=CASE WHEN ? IS NOT NULL THEN ? ELSE checkpoint_trade_key END,state='IDLE',range_start=NULL,next_cursor=NULL,cursor_history_json='[]',pages_requested=0,rows_received=0,range_max_timestamp=NULL,last_success_at=?,failure_count=0,next_retry_at=NULL,last_error_category=NULL,last_error=NULL WHERE wallet=?",
                        (max_ts,max_ts,max_key,now,wallet))
            con.execute("DELETE FROM wallet_ingest_queue WHERE wallet=? AND state='DONE'",(wallet,))
            return True

    def fail_ingest_range(self, wallet: str, *, category: str, detail: str,
                          failure_count: int, retry_at: float, now: str) -> None:
        with self._write_lock, self.conn() as con:
            con.execute("UPDATE wallet_ingest_state SET failure_count=?,next_retry_at=?,last_error_category=?,last_error=?,last_attempt_at=? WHERE wallet=?",
                        (failure_count,retry_at,category,detail[:1000],now,wallet.lower()))

    def record_ingest_attempt(self, *, attempt_id: str, wallet: str, started_at: str,
                              finished_at: str, outcome: str, error_category: str | None,
                              pages_requested: int, rows_received: int, backlog_remaining: int,
                              cursor_present: bool, retry_count: int, backoff_seconds: float,
                              elapsed_ms: float, evidence: dict[str, Any]) -> None:
        with self._write_lock,self.conn() as con:
            con.execute("INSERT INTO wallet_ingest_attempts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (attempt_id,wallet.lower(),started_at,finished_at,outcome,error_category,pages_requested,
                 rows_received,backlog_remaining,int(cursor_present),retry_count,backoff_seconds,elapsed_ms,
                 json.dumps(evidence,sort_keys=True,separators=(",",":"),default=str)))
            con.execute("DELETE FROM wallet_ingest_attempts WHERE wallet=? AND attempt_id NOT IN (SELECT attempt_id FROM wallet_ingest_attempts WHERE wallet=? ORDER BY started_at DESC LIMIT 50)",
                        (wallet.lower(),wallet.lower()))

    def existing_trade_keys(self, trade_keys: Iterable[str]) -> set[str]:
        keys = list(dict.fromkeys(str(key) for key in trade_keys if key))
        if not keys:
            return set()
        existing: set[str] = set()
        with self.conn() as con:
            for offset in range(0, len(keys), 900):
                batch = keys[offset:offset + 900]
                placeholders = ",".join("?" for _ in batch)
                rows = con.execute(
                    f"SELECT trade_key FROM trades WHERE trade_key IN ({placeholders})",
                    batch,
                ).fetchall()
                existing.update(str(row["trade_key"]) for row in rows)
        return existing

    def wallet_delay_health(self, address: str, limit: int = 20) -> dict[str, Any]:
        with self.conn() as con:
            rows = con.execute(
                """
                SELECT delay_ms, scan_latency_ms, created_at
                FROM signals
                WHERE wallet=? AND is_initial_sync=0 AND delay_ms IS NOT NULL
                ORDER BY id DESC LIMIT ?
                """,
                (address.lower(), max(1, limit)),
            ).fetchall()
        delays = sorted(float(row["delay_ms"] or 0) for row in rows)
        scans = sorted(float(row["scan_latency_ms"] or 0) for row in rows if row["scan_latency_ms"] is not None)

        def percentile(values: list[float], q: float) -> float | None:
            if not values:
                return None
            index = min(len(values) - 1, max(0, round((len(values) - 1) * q)))
            return values[index]

        return {
            "samples": len(delays),
            "median_delay_ms": percentile(delays, 0.5),
            "p75_delay_ms": percentile(delays, 0.75),
            "median_scan_latency_ms": percentile(scans, 0.5),
            "last_signal_at": rows[0]["created_at"] if rows else None,
        }

    def auto_pause_slow_wallets(self) -> list[dict[str, Any]]:
        if not settings.auto_pause_enabled:
            return []
        paused = []
        for wallet in self.tracked_wallets():
            health = self.wallet_delay_health(wallet["address"])
            if health["samples"] < settings.auto_pause_min_samples:
                continue
            median_delay = float(health["median_delay_ms"] or 0) / 1000
            median_scan = float(health["median_scan_latency_ms"] or 0) / 1000
            reason = None
            alpha_class = str(wallet.get("alpha_class") or "COLLECTING")
            if median_scan > settings.max_local_scan_seconds:
                reason = f"近 {health['samples']} 条 Signal 中位本地扫描 {median_scan:.1f}s，超过 {settings.max_local_scan_seconds:.0f}s"
            elif alpha_class == "NON_COPYABLE":
                reason = wallet.get("classification_reason") or "延迟回放显示 Net Edge 不可复制"
            elif alpha_class == "FAST_ALPHA" and median_delay > settings.max_follow_delay_seconds:
                reason = f"Fast Alpha 钱包中位延迟 {median_delay:.1f}s，超过 {settings.max_follow_delay_seconds:.0f}s"
            if reason:
                self.pause_wallet_for_delay(wallet["address"], reason)
                paused.append({"address": wallet["address"], "reason": reason, **health})
        return paused

    def upsert_candidate(self, candidate: dict[str, Any]) -> None:
        now = utc_now_iso()
        with self._write_lock, self.conn() as con:
            con.execute(
                """
                INSERT INTO wallet_candidates(
                    address,source,best_rank,leaderboard_pnl,leaderboard_volume,
                    discovery_score,appearances,time_period,category,target_pool,
                    slow_prior_score,fast_prior_score,status,
                    discovered_at,updated_at,raw_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'NEW',?,?,?)
                ON CONFLICT(address) DO UPDATE SET
                    best_rank=MIN(COALESCE(wallet_candidates.best_rank,excluded.best_rank),excluded.best_rank),
                    leaderboard_pnl=MAX(wallet_candidates.leaderboard_pnl,excluded.leaderboard_pnl),
                    leaderboard_volume=MAX(wallet_candidates.leaderboard_volume,excluded.leaderboard_volume),
                    discovery_score=MAX(wallet_candidates.discovery_score,excluded.discovery_score),
                    appearances=wallet_candidates.appearances+1,
                    time_period=excluded.time_period,
                    category=excluded.category,
                    target_pool=CASE
                        WHEN wallet_candidates.target_pool='SLOW' OR excluded.target_pool='SLOW' THEN 'SLOW'
                        WHEN wallet_candidates.target_pool='FAST' OR excluded.target_pool='FAST' THEN 'FAST'
                        ELSE 'EXPLORE' END,
                    slow_prior_score=MAX(wallet_candidates.slow_prior_score,excluded.slow_prior_score),
                    fast_prior_score=MAX(wallet_candidates.fast_prior_score,excluded.fast_prior_score),
                    updated_at=excluded.updated_at,
                    raw_json=excluded.raw_json
                """,
                (
                    candidate["address"].lower(), candidate.get("source", "POLYMARKET_LEADERBOARD"),
                    candidate.get("rank"), candidate.get("pnl"), candidate.get("volume"),
                    candidate.get("score", 0), candidate.get("appearances", 1),
                    candidate.get("time_period"), candidate.get("category"),
                    candidate.get("target_pool", "EXPLORE"), candidate.get("slow_prior_score", 0),
                    candidate.get("fast_prior_score", 0), now, now,
                    json.dumps(candidate.get("raw", {})),
                ),
            )
    def candidates(self, limit: int = 100, status: str | None = None) -> list[dict[str, Any]]:
        with self.conn() as con:
            if status:
                rows = con.execute(
                    "SELECT * FROM wallet_candidates WHERE status=? ORDER BY discovery_score DESC LIMIT ?",
                    (status, limit),
                ).fetchall()
            else:
                rows = con.execute(
                    "SELECT * FROM wallet_candidates ORDER BY discovery_score DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [dict(row) for row in rows]

    def candidates_for_pool(self, target_pool: str, limit: int = 1) -> list[dict[str, Any]]:
        with self.conn() as con:
            rows = con.execute(
                """
                SELECT * FROM wallet_candidates
                WHERE status='NEW' AND target_pool=?
                ORDER BY CASE WHEN ?='SLOW' THEN slow_prior_score
                              WHEN ?='FAST' THEN fast_prior_score
                              ELSE discovery_score END DESC,
                         discovery_score DESC
                LIMIT ?
                """,
                (target_pool, target_pool, target_pool, max(1, limit)),
            ).fetchall()
        return [dict(row) for row in rows]

    def candidate_pool_counts(self) -> dict[str, int]:
        with self.conn() as con:
            rows = con.execute(
                "SELECT target_pool,COUNT(*) c FROM wallet_candidates WHERE status='NEW' GROUP BY target_pool"
            ).fetchall()
        result = {"SLOW": 0, "FAST": 0, "EXPLORE": 0}
        result.update({str(row["target_pool"]): int(row["c"]) for row in rows})
        return result

    def set_candidate_status(self, address: str, status: str, reason: str | None = None) -> None:
        analyzed_at = utc_now_iso() if status in {"PROMOTED", "FORWARD_TEST", "REJECTED", "ERROR"} else None
        with self._write_lock, self.conn() as con:
            con.execute(
                """
                UPDATE wallet_candidates
                SET status=?, reject_reason=?, analyzed_at=COALESCE(?,analyzed_at), updated_at=?
                WHERE address=?
                """,
                (status, reason, analyzed_at, utc_now_iso(), address.lower()),
            )

    def insert_signal(self, s: dict[str, Any]) -> int:
        with self._write_lock, self.conn() as con:
            cur = con.execute(
                """
                INSERT INTO signals(trade_key,wallet,token_id,market_title,outcome,category,leader_side,leader_price,current_price,leader_size,leader_timestamp,delay_ms,scan_latency_ms,expected_alpha,delay_cost,spread,slippage,fee_rate,fee_cost,safety_margin,net_copy_edge,paper_size_usd,decision,skip_reason,created_at,raw_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    s["trade_key"], s["wallet"].lower(), s.get("token_id"), s.get("market_title"), s.get("outcome"), s.get("category"),
                    s.get("leader_side"), s.get("leader_price"), s.get("current_price"), s.get("leader_size"), s.get("leader_timestamp"), s.get("delay_ms"), s.get("scan_latency_ms"),
                    s.get("expected_alpha"), s.get("delay_cost"), s.get("spread"), s.get("slippage"), s.get("fee_rate"), s.get("fee_cost"),
                    s.get("safety_margin"), s.get("net_copy_edge"), s.get("paper_size_usd"), s["decision"], s.get("skip_reason"),
                    utc_now_iso(), json.dumps(s.get("raw", {}))
                ),
            )
            return int(cur.lastrowid)

    def insert_signal_snapshot(
        self,
        signal_id: int,
        wallet: str,
        token_id: str,
        horizon_seconds: int,
        price: float | None,
        adverse_move: float | None,
        *,
        actual_delay_seconds: float | None = None,
        filled: bool | None = None,
        cost_usd: float | None = None,
        shares: float | None = None,
        fees_usd: float | None = None,
        slippage: float | None = None,
        spread: float | None = None,
        delayed_net_edge: float | None = None,
    ) -> None:
        with self._write_lock, self.conn() as con:
            con.execute(
                """
                INSERT OR REPLACE INTO signal_snapshots(
                    signal_id,wallet,token_id,horizon_seconds,price,adverse_move,
                    actual_delay_seconds,filled,cost_usd,shares,fees_usd,slippage,spread,
                    delayed_net_edge,recorded_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    signal_id, wallet.lower(), token_id, horizon_seconds, price, adverse_move,
                    actual_delay_seconds, None if filled is None else int(filled), cost_usd, shares,
                    fees_usd, slippage, spread, delayed_net_edge, utc_now_iso(),
                ),
            )
        # Reclassify only at decision horizons; 60s/900s remain available for
        # the curve without repeatedly rescanning a wallet's full history.
        if horizon_seconds in {30, settings.slow_alpha_horizon_seconds, settings.slow_alpha_confirmation_horizon_seconds}:
            self.recompute_copyability(wallet)

    def signal_snapshots(self, signal_id: int | None = None, limit: int = 500) -> list[dict[str, Any]]:
        with self.conn() as con:
            if signal_id is not None:
                rows = con.execute("SELECT * FROM signal_snapshots WHERE signal_id=? ORDER BY horizon_seconds ASC", (signal_id,)).fetchall()
            else:
                rows = con.execute("SELECT * FROM signal_snapshots ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def alpha_decay(self) -> list[dict[str, Any]]:
        """Aggregate only real forward observations for the dashboard curve."""
        with self.conn() as con:
            rows = con.execute(
                """
                SELECT horizon_seconds,
                       COUNT(adverse_move) AS samples,
                       AVG(adverse_move) AS avg_adverse_move,
                       MAX(recorded_at) AS updated_at
                FROM signal_snapshots
                WHERE adverse_move IS NOT NULL AND actual_delay_seconds IS NOT NULL
                  AND horizon_seconds IN (30,60,120,300,900)
                GROUP BY horizon_seconds
                ORDER BY horizon_seconds ASC
                """
            ).fetchall()
            return [
                {
                    "h": int(r["horizon_seconds"]),
                    "v": round(float(r["avg_adverse_move"] or 0.0), 8),
                    "samples": int(r["samples"] or 0),
                    "updated_at": r["updated_at"],
                }
                for r in rows
            ]

    def signals_for_decay_recovery(self, max_age_seconds: int = 900) -> list[dict[str, Any]]:
        cutoff = int(datetime.now(timezone.utc).timestamp()) - max(1, max_age_seconds)
        with self.conn() as con:
            rows = con.execute(
                """
                SELECT * FROM signals
                WHERE is_initial_sync=0 AND token_id IS NOT NULL
                  AND leader_side IN ('BUY','SELL')
                  AND leader_timestamp>=?
                ORDER BY id ASC
                """,
                (cutoff,),
            ).fetchall()
        return [dict(row) for row in rows]

    def unsettled_signal_tokens(self, limit: int = 100) -> list[str]:
        with self.conn() as con:
            rows = con.execute(
                """
                SELECT s.token_id,MIN(s.created_at) oldest,MIN(s.settlement_checked_at) checked
                FROM signals s
                WHERE s.settlement_price IS NULL AND s.token_id IS NOT NULL
                  AND EXISTS (SELECT 1 FROM signal_snapshots ss WHERE ss.signal_id=s.id)
                GROUP BY s.token_id ORDER BY checked IS NOT NULL,checked ASC,oldest ASC LIMIT ?
                """,
                (max(1, limit),),
            ).fetchall()
        return [str(row["token_id"]) for row in rows]

    def settle_signal_token(self, token_id: str, settlement_price: float) -> int:
        with self._write_lock, self.conn() as con:
            wallets = [
                str(row["wallet"])
                for row in con.execute(
                    "SELECT DISTINCT wallet FROM signals WHERE token_id=? AND settlement_price IS NULL",
                    (token_id,),
                ).fetchall()
            ]
            cur = con.execute(
                "UPDATE signals SET settlement_price=?,settled_at=?,settlement_checked_at=? WHERE token_id=? AND settlement_price IS NULL",
                (settlement_price, utc_now_iso(), utc_now_iso(), token_id),
            )
            count = int(cur.rowcount or 0)
        for wallet in wallets:
            self.recompute_copyability(wallet)
        return count

    def mark_signal_token_checked(self, token_id: str) -> None:
        with self._write_lock, self.conn() as con:
            con.execute(
                "UPDATE signals SET settlement_checked_at=? WHERE token_id=? AND settlement_price IS NULL",
                (utc_now_iso(), token_id),
            )

    def wallet_alpha_profile(self, wallet: str) -> dict[str, Any]:
        """Aggregate forward replay by independent market, not trade count."""
        with self.conn() as con:
            rows = con.execute(
                """
                SELECT ss.*,s.settlement_price,s.expected_alpha,
                       COALESCE(NULLIF(t.condition_id,''),s.token_id) market_key
                FROM signal_snapshots ss
                JOIN signals s ON s.id=ss.signal_id
                LEFT JOIN trades t ON t.trade_key=s.trade_key
                WHERE ss.wallet=? AND s.leader_side='BUY' AND s.is_initial_sync=0
                  AND ss.actual_delay_seconds IS NOT NULL
                ORDER BY ss.horizon_seconds,market_key
                """,
                (wallet.lower(),),
            ).fetchall()
        grouped: dict[tuple[int, str], list[sqlite3.Row]] = {}
        for row in rows:
            grouped.setdefault((int(row["horizon_seconds"]), str(row["market_key"])), []).append(row)
        by_horizon: dict[int, list[dict[str, float | bool | None]]] = {}
        for (horizon, _), market_rows in grouped.items():
            def avg(name: str) -> float | None:
                values = [float(r[name]) for r in market_rows if r[name] is not None]
                return sum(values) / len(values) if values else None

            filled_values = [int(r["filled"]) for r in market_rows if r["filled"] is not None]
            rois = []
            for row in market_rows:
                if not row["filled"] or row["settlement_price"] is None:
                    continue
                cost = float(row["cost_usd"] or 0)
                shares = float(row["shares"] or 0)
                fees = float(row["fees_usd"] or 0)
                if cost > 0:
                    rois.append((float(row["settlement_price"]) * shares - cost - fees) / cost)
            by_horizon.setdefault(horizon, []).append({
                "filled": (sum(filled_values) / len(filled_values)) >= 0.5 if filled_values else False,
                "adverse": avg("adverse_move"),
                "net_edge": avg("delayed_net_edge"),
                "actual_delay": avg("actual_delay_seconds"),
                "settled_roi": sum(rois) / len(rois) if rois else None,
            })
        profile: dict[str, Any] = {}
        for horizon, markets in sorted(by_horizon.items()):
            def mean_present(name: str) -> float | None:
                values = [float(m[name]) for m in markets if m[name] is not None]
                return sum(values) / len(values) if values else None

            settled = [float(m["settled_roi"]) for m in markets if m["settled_roi"] is not None]
            profile[str(horizon)] = {
                "markets": len(markets),
                "fillability": round(sum(bool(m["filled"]) for m in markets) / len(markets), 6),
                "avg_adverse_move": round(mean_present("adverse") or 0.0, 8),
                "avg_delayed_net_edge": round(mean_present("net_edge") or 0.0, 8),
                "avg_actual_delay_seconds": round(mean_present("actual_delay") or 0.0, 3),
                "settled_markets": len(settled),
                "avg_settled_roi": round(sum(settled) / len(settled), 8) if settled else None,
                "profitable_rate": round(sum(roi > 0 for roi in settled) / len(settled), 6) if settled else None,
            }
        return profile

    def recompute_copyability(self, wallet: str) -> None:
        delay_profile = self.wallet_alpha_profile(wallet)
        with self._write_lock, self.conn() as con:
            row = con.execute(
                "SELECT analytics_json,status,auto_managed,tracked FROM wallets WHERE address=?",
                (wallet.lower(),),
            ).fetchone()
            if not row:
                return
            analytics = json.loads(row["analytics_json"] or "{}")
            signal_row = con.execute(
                "SELECT COUNT(*) n, AVG(delay_ms) avg_delay, AVG(scan_latency_ms) avg_scan_latency, AVG(CASE WHEN spread IS NOT NULL THEN spread END) avg_spread FROM signals WHERE wallet=? AND leader_side='BUY' AND is_initial_sync=0",
                (wallet.lower(),),
            ).fetchone()
            samples = int(signal_row["n"] or 0)
            avg_delay = float(signal_row["avg_delay"] or 0.0)
            avg_scan_latency = float(signal_row["avg_scan_latency"] or 0.0)
            avg_spread = float(signal_row["avg_spread"] or 0.0)
            primary = delay_profile.get(str(settings.slow_alpha_horizon_seconds), {})
            confirm = delay_profile.get(str(settings.slow_alpha_confirmation_horizon_seconds), {})
            fast = delay_profile.get("30", {})
            min_forward = settings.alpha_min_forward_markets
            primary_ready = int(primary.get("markets") or 0) >= min_forward
            fast_ready = int(fast.get("markets") or 0) >= min_forward
            slow_forward = (
                primary_ready
                and float(primary.get("fillability") or 0) >= settings.slow_alpha_min_fillability
                and float(primary.get("avg_delayed_net_edge") or 0) >= settings.slow_alpha_min_net_edge
            )
            if int(confirm.get("markets") or 0) >= min_forward:
                slow_forward = slow_forward and (
                    float(confirm.get("fillability") or 0) >= settings.slow_alpha_min_fillability
                    and float(confirm.get("avg_delayed_net_edge") or 0) >= 0
                )
            fast_forward = (
                fast_ready
                and float(fast.get("fillability") or 0) >= settings.slow_alpha_min_fillability
                and float(fast.get("avg_delayed_net_edge") or 0) >= settings.slow_alpha_min_net_edge
            )
            settled_ready = int(primary.get("settled_markets") or 0) >= settings.alpha_min_settled_markets
            settled_roi = primary.get("avg_settled_roi")
            profitable_rate = primary.get("profitable_rate")
            alpha_class = "COLLECTING"
            reason = f"等待 {settings.slow_alpha_horizon_seconds}s forward markets {int(primary.get('markets') or 0)}/{min_forward}"
            if slow_forward:
                if settled_ready:
                    if float(settled_roi or 0) > 0 and float(profitable_rate or 0) >= settings.slow_alpha_min_profitable_rate:
                        alpha_class = "SLOW_ALPHA"
                        reason = f"{settings.slow_alpha_horizon_seconds}s 后 ROI {float(settled_roi):.1%}，盈利市场 {float(profitable_rate):.0%}"
                    else:
                        alpha_class = "NON_COPYABLE"
                        reason = f"延迟后结算 ROI {float(settled_roi or 0):.1%}，盈利市场 {float(profitable_rate or 0):.0%}"
                else:
                    alpha_class = "SLOW_CANDIDATE"
                    reason = f"{settings.slow_alpha_horizon_seconds}s 后仍有净优势；等待结算 {int(primary.get('settled_markets') or 0)}/{settings.alpha_min_settled_markets}"
            elif fast_forward:
                alpha_class = "FAST_ALPHA"
                reason = "30s 仍可复制，但 120s 优势不足"
            elif primary_ready:
                alpha_class = "NON_COPYABLE"
                reason = f"{settings.slow_alpha_horizon_seconds}s 后净优势或可成交率不足"

            score = None
            if primary_ready:
                fill_score = float(primary.get("fillability") or 0) * 30
                edge_score = max(0.0, min(30.0, float(primary.get("avg_delayed_net_edge") or 0) * 600))
                adverse_score = max(0.0, 20.0 - float(primary.get("avg_adverse_move") or 0) * 400)
                settlement_score = 0.0
                if settled_roi is not None:
                    settlement_score = max(0.0, min(20.0, 10 + float(settled_roi) * 50))
                score = max(0.0, min(100.0, fill_score + edge_score + adverse_score + settlement_score))
            half_life = None
            for h in (30, 60, 120, 300, 900):
                if float(delay_profile.get(str(h), {}).get("avg_adverse_move", 0.0)) >= 0.03:
                    half_life = h
                    break
            analytics["copyability"] = {
                "status": "MEASURED" if primary_ready else "COLLECTING",
                "score": round(score, 2) if score is not None else None,
                "samples": samples,
                "avg_detection_delay_ms": round(avg_delay, 1),
                "avg_scan_latency_ms": round(avg_scan_latency, 1),
                "avg_spread": round(avg_spread, 6),
                "alpha_class": alpha_class,
                "classification_reason": reason,
                "delay_profile": delay_profile,
                "alpha_decay": {
                    h: {"samples": v["markets"], "avg_adverse_move": v["avg_adverse_move"]}
                    for h, v in delay_profile.items()
                },
                "edge_decay_3c_seconds": half_life,
            }
            next_status = alpha_class
            tracked = int(row["tracked"])
            tracking_reason = None
            if alpha_class == "NON_COPYABLE" and int(row["auto_managed"] or 0):
                tracked = 0
                tracking_reason = reason
            con.execute(
                """
                UPDATE wallets SET analytics_json=?,status=?,alpha_class=?,classification_reason=?,
                    classified_at=?,tracked=?,tracking_reason=COALESCE(?,tracking_reason),updated_at=?
                WHERE address=?
                """,
                (
                    json.dumps(analytics), next_status, alpha_class, reason, utc_now_iso(),
                    tracked, tracking_reason, utc_now_iso(), wallet.lower(),
                ),
            )
            candidate_status = "FORWARD_TEST" if alpha_class == "COLLECTING" else alpha_class
            con.execute(
                """
                UPDATE wallet_candidates SET status=?,reject_reason=?,updated_at=?,
                    analyzed_at=COALESCE(analyzed_at,?)
                WHERE address=? AND status NOT IN ('REJECTED','ERROR')
                """,
                (candidate_status, reason, utc_now_iso(), utc_now_iso(), wallet.lower()),
            )

    def create_paper_trade(self, p: dict[str, Any]) -> int:
        with self._write_lock, self.conn() as con:
            cur = con.execute(
                """
                INSERT INTO paper_trades(signal_id,wallet,token_id,market_title,outcome,side,entry_price,shares,cost_usd,fees_usd,status,opened_at,mark_price,current_value_usd,unrealized_pnl,unrealized_roi,marked_at,mark_source)
                VALUES(?,?,?,?,?,?,?,?,?,?, 'OPEN', ?,?,?,?,?,?,?)
                """,
                (
                    p["signal_id"], p["wallet"].lower(), p.get("token_id"), p.get("market_title"), p.get("outcome"), p.get("side"),
                    p.get("entry_price"), p.get("shares"), p.get("cost_usd"), p.get("fees_usd"), utc_now_iso(),
                    p.get("entry_price"), p.get("cost_usd"), -float(p.get("fees_usd") or 0),
                    (-float(p.get("fees_usd") or 0) / float(p.get("cost_usd") or 1)), utc_now_iso(), "ENTRY"
                ),
            )
            return int(cur.lastrowid)

    def open_paper_for(self, wallet: str, token_id: str) -> list[dict[str, Any]]:
        with self.conn() as con:
            return [dict(r) for r in con.execute(
                "SELECT * FROM paper_trades WHERE wallet=? AND token_id=? AND status='OPEN' ORDER BY opened_at ASC",
                (wallet.lower(), token_id),
            ).fetchall()]

    def open_paper_trades(self, limit: int = 1000) -> list[dict[str, Any]]:
        with self.conn() as con:
            return [dict(r) for r in con.execute(
                "SELECT * FROM paper_trades WHERE status='OPEN' ORDER BY opened_at ASC LIMIT ?",
                (limit,),
            ).fetchall()]

    def mark_paper_trade(self, trade_id: int, mark_price: float, source: str) -> None:
        with self._write_lock, self.conn() as con:
            row = con.execute(
                "SELECT shares,cost_usd,fees_usd FROM paper_trades WHERE id=? AND status='OPEN'",
                (trade_id,),
            ).fetchone()
            if not row:
                return
            current_value = float(row["shares"] or 0) * mark_price
            pnl = current_value - float(row["cost_usd"] or 0) - float(row["fees_usd"] or 0)
            roi = pnl / float(row["cost_usd"]) if row["cost_usd"] else 0.0
            con.execute(
                """
                UPDATE paper_trades
                SET mark_price=?, current_value_usd=?, unrealized_pnl=?, unrealized_roi=?, marked_at=?, mark_source=?
                WHERE id=? AND status='OPEN'
                """,
                (mark_price, current_value, pnl, roi, utc_now_iso(), source, trade_id),
            )

    def close_paper_trade(self, trade_id: int, exit_price: float, exit_value: float, pnl: float, roi: float, reason: str) -> None:
        with self._write_lock, self.conn() as con:
            con.execute(
                """
                UPDATE paper_trades
                SET status='CLOSED', exit_price=?, exit_value_usd=?, pnl=?, roi=?, closed_at=?, close_reason=?,
                    mark_price=?, current_value_usd=?, unrealized_pnl=NULL, unrealized_roi=NULL, marked_at=?, mark_source=?
                WHERE id=?
                """,
                (exit_price, exit_value, pnl, roi, utc_now_iso(), reason, exit_price, exit_value, utc_now_iso(), reason, trade_id),
            )

    def recent_signals(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.conn() as con:
            return [dict(r) for r in con.execute(
                "SELECT * FROM signals WHERE is_initial_sync=0 ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()]

    def paper_trades(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.conn() as con:
            return [dict(r) for r in con.execute("SELECT * FROM paper_trades ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

    def dashboard(self) -> dict[str, Any]:
        with self.conn() as con:
            wallets = con.execute("SELECT COUNT(*) c FROM wallets WHERE tracked=1").fetchone()["c"]
            qualified = con.execute("SELECT COUNT(*) c FROM wallets WHERE alpha_class IN ('SLOW_ALPHA','FAST_ALPHA') AND status!='RETIRED_LEGACY'").fetchone()["c"]
            slow_alpha = con.execute("SELECT COUNT(*) c FROM wallets WHERE alpha_class='SLOW_ALPHA' AND status!='RETIRED_LEGACY'").fetchone()["c"]
            slow_candidates = con.execute("SELECT COUNT(*) c FROM wallets WHERE alpha_class='SLOW_CANDIDATE' AND status!='RETIRED_LEGACY'").fetchone()["c"]
            fast_alpha = con.execute("SELECT COUNT(*) c FROM wallets WHERE alpha_class='FAST_ALPHA' AND status!='RETIRED_LEGACY'").fetchone()["c"]
            collecting = con.execute("SELECT COUNT(*) c FROM wallets WHERE alpha_class='COLLECTING' AND status!='RETIRED_LEGACY'").fetchone()["c"]
            signals_today = con.execute("SELECT COUNT(*) c FROM signals WHERE is_initial_sync=0 AND date(created_at)=date('now')").fetchone()["c"]
            copy_today = con.execute("SELECT COUNT(*) c FROM signals WHERE is_initial_sync=0 AND date(created_at)=date('now') AND decision='COPY'").fetchone()["c"]
            watch_today = con.execute("SELECT COUNT(*) c FROM signals WHERE is_initial_sync=0 AND date(created_at)=date('now') AND decision='WATCH'").fetchone()["c"]
            skip_today = con.execute("SELECT COUNT(*) c FROM signals WHERE is_initial_sync=0 AND date(created_at)=date('now') AND decision='SKIP'").fetchone()["c"]
            open_paper = con.execute("SELECT COUNT(*) c FROM paper_trades WHERE status='OPEN'").fetchone()["c"]
            closed = con.execute("SELECT COUNT(*) c, COALESCE(SUM(pnl),0) pnl, COALESCE(AVG(roi),0) avg_roi FROM paper_trades WHERE status='CLOSED'").fetchone()
            open_marks = con.execute("SELECT COALESCE(SUM(unrealized_pnl),0) pnl FROM paper_trades WHERE status='OPEN'").fetchone()
            candidates = con.execute("SELECT COUNT(*) c FROM wallet_candidates").fetchone()["c"]
            promoted = con.execute("SELECT COUNT(*) c FROM wallet_candidates WHERE status IN ('PROMOTED','FORWARD_TEST','SLOW_CANDIDATE','SLOW_ALPHA','FAST_ALPHA','NON_COPYABLE')").fetchone()["c"]
            paused_delay = con.execute("SELECT COUNT(*) c FROM wallets WHERE status='PAUSED_DELAY'").fetchone()["c"]
            equity_rows = con.execute(
                "SELECT COALESCE(pnl,0) pnl FROM paper_trades WHERE status='CLOSED' ORDER BY closed_at ASC, id ASC"
            ).fetchall()
            equity = [0.0]
            for row in equity_rows:
                equity.append(round(equity[-1] + float(row["pnl"] or 0), 4))
            total_pnl = float(closed["pnl"] or 0) + float(open_marks["pnl"] or 0)
            if not equity_rows or abs(equity[-1] - total_pnl) > 1e-9:
                equity.append(round(total_pnl, 4))
            return {
                "tracked_wallets": wallets,
                "qualified_traders": qualified,
                "slow_alpha_wallets": slow_alpha,
                "slow_alpha_candidates": slow_candidates,
                "fast_alpha_wallets": fast_alpha,
                "collecting_wallets": collecting,
                "signals_today": signals_today,
                "copy_today": copy_today,
                "watch_today": watch_today,
                "skip_today": skip_today,
                "open_paper": open_paper,
                "closed_paper": closed["c"],
                "realized_paper_pnl": closed["pnl"],
                "unrealized_paper_pnl": open_marks["pnl"],
                "paper_pnl": total_pnl,
                "paper_equity": equity,
                "avg_paper_roi": closed["avg_roi"],
                "discovery_candidates": candidates,
                "discovery_promoted": promoted,
                "paused_delay_wallets": paused_delay,
                "live_enabled": False,
            }


db = Database()
