from __future__ import annotations

import re
import time
from datetime import datetime, timezone
from typing import Any

from .analytics import analyze_wallet, category_expected_alpha
from .config import settings
from .db import db
from .db import utc_now_iso
from .paper import simulate_buy, simulate_sell, top_of_book
from .polymarket import PolymarketError, pm

WALLET_RE = re.compile(r"^0x[a-fA-F0-9]{40}$")


def validate_wallet(address: str) -> str:
    a = address.strip().lower()
    if not WALLET_RE.match(a):
        raise ValueError("请输入有效的 EVM 钱包地址（0x + 40 位十六进制字符）")
    return a


async def refresh_public_profile(address: str) -> None:
    """Best effort identity refresh; unavailable identity never blocks research."""
    if not hasattr(db, "save_public_profile"):
        return
    try:
        profile = await pm.public_profile(address)
    except Exception:
        profile = {"source": "UNAVAILABLE"}
    db.save_public_profile(address, profile, time.time())


async def refresh_due_public_profiles(addresses: list[str]) -> None:
    import asyncio
    await asyncio.gather(*(refresh_public_profile(address) for address in addresses))


async def analyze_and_store(address: str, tracked: bool | None = None) -> dict[str, Any]:
    address = validate_wallet(address)
    if settings.research_enabled:
        from .research import excluded
        if excluded(db, address):
            raise ValueError("该钱包已手动排除，请先恢复")
    existing = db.get_wallet(address)
    restore_tracking = bool(existing["tracked"]) if tracked is None and existing else (True if tracked is None else tracked)
    # Initial analysis can take longer than the monitor interval for active
    # wallets. Keep the wallet out of the realtime monitor until its historical
    # trades have been seeded, otherwise the monitor turns the latest 100
    # historical trades into fake realtime Signals.
    db.upsert_wallet(address, tracked=False)
    if tracked is None:
        db.set_wallet_alpha_target(address, "MANUAL")
    try:
        profile, volume, pnl, closed, opened, trades, warnings = await _gather_wallet(address)
        stats, analytics, status = analyze_wallet(address, closed, opened, profile, volume, pnl)
        stats["analyzed_at_utc"] = utc_now_iso()
        stats["analysis_partial"] = bool(warnings)
        analytics["data_warnings"] = warnings
        db.set_wallet_analysis(address, stats, analytics, status)
        await refresh_public_profile(address)
        db.replace_seed_trades(address, trades)
        if settings.research_enabled:
            if any(w.startswith("trades:") for w in warnings):
                raise PolymarketError("历史成交读取失败，未开启跟踪；请重新分析")
            with db.conn() as con:
                con.execute("UPDATE wallets SET last_trade_ts=MAX(COALESCE(last_trade_ts,0),?) WHERE address=?", (int(time.time()),address))
            from .research import enqueue
            enqueue(db, "WALLET", address)
        else:
            db.recompute_copyability(address)
        db.set_wallet_tracked(address, restore_tracking)
        return db.get_wallet(address) or {}
    except Exception as e:
        db.set_wallet_error(address, str(e))
        if existing and not settings.research_enabled:
            db.set_wallet_tracked(address, restore_tracking)
        raise


async def _gather_wallet(address: str):
    import asyncio
    results = await asyncio.gather(
        pm.user_stats(address),
        pm.user_volume(address),
        pm.user_pnl(address),
        pm.positions(address, "CLOSED"),
        pm.positions(address, "OPEN"),
        pm.trades(address, start=1, limit_total=settings.max_history_trades),
        return_exceptions=True,
    )
    source_names = ["profile", "volume", "pnl", "closed", "opened", "trades"]
    cleaned = []
    warnings: list[str] = []
    successes = 0
    for name, r in zip(source_names, results):
        if isinstance(r, Exception):
            warnings.append(f"{name}: {r}")
            cleaned.append({} if name == "volume" else [])
        else:
            successes += 1
            cleaned.append(r)
    # Wallet analysis should degrade gracefully when one large endpoint times
    # out.  It is only a hard failure when no Polymarket source was readable.
    if not successes:
        detail = "; ".join(warnings[:3]) or "all data sources failed"
        raise PolymarketError(detail)
    return (*cleaned, warnings)


def _category_stat(wallet: dict[str, Any], category: str) -> dict[str, Any] | None:
    for row in wallet.get("category_stats", []):
        if row.get("category") == category:
            return row
    return None


async def process_new_trade(
    wallet: dict[str, Any],
    trade: dict[str, Any],
    scan_started_at: float | None = None,
    *,
    source: str = "FAST_PATH",
    advance_checkpoint: bool = True,
) -> dict[str, Any] | None:
    detected_at = time.time()
    trade = dict(trade)
    raw = dict(trade.get("raw") or {}) if isinstance(trade.get("raw"), dict) else {}
    raw.setdefault("_edge_ingest", {"source": source, "observed_at": datetime.fromtimestamp(detected_at, timezone.utc).isoformat()})
    trade["raw"] = raw
    try:
        inserted = db.insert_trade_if_new(wallet["address"], trade, source=source,
                                          advance_checkpoint=advance_checkpoint)
    except TypeError as exc:
        # Small test doubles and downstream adapters may still implement the
        # original two-argument API. Never hide a TypeError raised internally.
        if "unexpected keyword" not in str(exc):
            raise
        inserted = db.insert_trade_if_new(wallet["address"], trade)
    if not inserted:
        return None
    try:
        result = await _process_new_trade_claimed(wallet, trade, scan_started_at, detected_at)
    except Exception as exc:
        if hasattr(db, "complete_ingest_event"):
            db.complete_ingest_event(str(trade.get("trade_key") or ""),
                                     error_type=type(exc).__name__, error_detail=str(exc))
        raise
    if hasattr(db, "complete_ingest_event"):
        db.complete_ingest_event(str(trade.get("trade_key") or ""),
                                 outcome=(result or {}).get("decision") if isinstance(result, dict) else "NO_SIGNAL")
    if raw.get("_chain_fill") and isinstance(result,dict):
        result={**result,"_fast_path_processing_started_at":raw.get("strategy_started_at")}
    return result


async def ingest_fast_path_trade(wallet: dict[str, Any], trade: dict[str, Any],
                                 detected_at: float | None = None) -> dict[str, Any] | None:
    """Live producer gateway; shares atomic canonical ownership with polling."""
    return await process_new_trade(wallet, trade, source="FAST_PATH", advance_checkpoint=False)


async def _process_new_trade_claimed(
    wallet: dict[str, Any],
    trade: dict[str, Any],
    scan_started_at: float | None,
    detected_at: float,
) -> dict[str, Any] | None:

    # Production V2 is opt-in and only routed after its explicit activation.
    # Raw ingestion above remains the single deduplication gate. This branch
    # deliberately returns before either legacy research admission path.
    from .wallet_follow_runtime import V2ActivationState, v2_activation_state, WalletFollowRuntime
    if hasattr(db,"path"):
        activation=v2_activation_state(db.path)
        if activation is V2ActivationState.READ_ERROR:
            # Unknown activation state is fail-closed: keep the raw trade, but
            # never route the same signal into legacy research/paper capture.
            import logging
            logger=logging.getLogger("edge.wallet_follow_v2")
            try:
                from .wallet_follow_v2 import WalletFollowV2
                WalletFollowV2(db.path).record_runtime_failure(
                    signal_id=str(trade.get("trade_key") or "unknown"),
                    wallet=wallet["address"],condition_id=trade.get("condition_id"),
                    reason="V2_ACTIVATION_STATE_READ_ERROR",
                    occurred_at=datetime.fromtimestamp(detected_at,timezone.utc),
                    evidence={"phase":"LIVE_ROUTING","state":"READ_ERROR",
                              "trade_key":str(trade.get("trade_key") or "")})
            except Exception:
                logger.exception("Could not persist V2 state-read routing failure")
            return {"wallet_follow_v2":True,"decision":"V2_ROUTING_STATE_ERROR",
                    "reason":"V2_ACTIVATION_STATE_READ_ERROR"}
    else:
        activation=None
    if (trade.get("raw") or {}).get("_chain_fill") and activation is not V2ActivationState.ACTIVE:
        return {"wallet_follow_v2":True,"decision":"FAST_PATH_V2_INACTIVE"}
    if activation is V2ActivationState.ACTIVE:
        if str(trade.get("side") or "").upper() != "BUY":
            return {"wallet_follow_v2": True, "decision": "V2_NON_BUY_IGNORED"}
        try:
            observed_at = datetime.fromtimestamp(detected_at, timezone.utc)
            if (trade.get("raw") or {}).get("_chain_fill"):
                trade["raw"]["strategy_started_at"]=datetime.now(timezone.utc).isoformat()
            result = await WalletFollowRuntime(db.path, pm).process_trade(
                wallet["address"], trade, detected_at=observed_at)
            return {"wallet_follow_v2": True, **(result or {"decision":"V2_NO_ENTRY"})}
        except Exception as exc:
            # The raw trade remains persisted; do not turn a runtime failure
            # into a historical retry against a future order book.
            import logging
            logging.getLogger("edge.wallet_follow_v2").exception("V2 signal adapter failed for %s", trade.get("trade_key"))
            try:
                from .wallet_follow_v2 import WalletFollowV2
                WalletFollowV2(db.path).record_runtime_failure(signal_id=str(trade.get("trade_key") or "unknown"),
                    wallet=wallet["address"],condition_id=trade.get("condition_id"),reason="RUNTIME_ADAPTER_FAILURE",
                    occurred_at=datetime.fromtimestamp(detected_at,timezone.utc),
                    evidence={"phase":"LIVE_ROUTING","error_type":type(exc).__name__})
            except Exception:
                logging.getLogger("edge.wallet_follow_v2").exception("Could not persist isolated V2 routing failure")
            return {"wallet_follow_v2":True,"decision":"V2_RUNTIME_FAILURE","error_type":type(exc).__name__}
    if activation is V2ActivationState.LOCKED:
        # A completed/retired V2 version still owns the runtime. Never revive
        # legacy V0.x admission after production V2 has once been activated.
        return {"wallet_follow_v2":True,"decision":"V2_RUNTIME_LOCKED"}

    # The isolated 14-day baseline only consumes trades observed by this live
    # path. Startup/history recovery never calls this function to make fills.
    from .research import capture_experiment, experiment_active
    if hasattr(db, "conn") and experiment_active(db):
        await capture_experiment(db, pm, wallet, trade, detected_at)

    if settings.research_enabled:
        from .research import capture
        return await capture(db, pm, wallet, trade)

    trade_ts = float(trade.get("timestamp") or detected_at)
    delay_ms = max(0, round((detected_at - trade_ts) * 1000))
    scan_latency_ms = (
        max(0, round((detected_at - scan_started_at) * 1000))
        if scan_started_at is not None
        else None
    )
    token_id = trade.get("token_id") or ""
    side = (trade.get("side") or "").upper()
    category = trade.get("category") or "Other"
    leader_price = float(trade.get("price") or 0.0)
    expected_alpha = category_expected_alpha(_category_stat(wallet, category), wallet.get("analytics", {}))

    signal: dict[str, Any] = {
        "trade_key": trade["trade_key"],
        "wallet": wallet["address"],
        "token_id": token_id,
        "market_title": trade.get("title"),
        "outcome": trade.get("outcome"),
        "category": category,
        "leader_side": side,
        "leader_price": leader_price,
        "leader_size": trade.get("size"),
        "leader_timestamp": int(trade_ts),
        "delay_ms": delay_ms,
        "scan_latency_ms": scan_latency_ms,
        "expected_alpha": expected_alpha,
        "safety_margin": settings.safety_margin,
        "paper_size_usd": min(settings.paper_trade_usd, settings.max_paper_trade_usd),
        "raw": {"trade": trade.get("raw", {})},
    }

    if delay_ms > settings.stale_signal_seconds * 1000:
        signal.update({
            "current_price": None,
            "delay_cost": 0,
            "spread": None,
            "slippage": None,
            "fee_rate": 0,
            "fee_cost": 0,
            "net_copy_edge": -1,
            "decision": "SKIP",
            "skip_reason": "STALE_SIGNAL",
        })
        signal["id"] = db.insert_signal(signal)
        return signal

    skill = float(wallet.get("analytics", {}).get("trader_skill") or 0)
    if skill < settings.min_trader_skill:
        signal.update({"current_price": None, "delay_cost": 0, "spread": None, "slippage": None, "fee_rate": 0, "fee_cost": 0, "net_copy_edge": -1, "decision": "SKIP", "skip_reason": "LOW_TRADER_CONFIDENCE"})
        signal["id"] = db.insert_signal(signal)
        return signal
    if not token_id:
        signal.update({"current_price": None, "delay_cost": 0, "spread": None, "slippage": None, "fee_rate": 0, "fee_cost": 0, "net_copy_edge": -1, "decision": "SKIP", "skip_reason": "MISSING_TOKEN_ID"})
        signal["id"] = db.insert_signal(signal)
        return signal

    try:
        book = await pm.orderbook(token_id)
    except Exception as e:
        # A delisted/closed token must not abort the rest of a wallet scan.
        signal.update({
            "current_price": None,
            "delay_cost": 0,
            "spread": None,
            "slippage": None,
            "fee_rate": 0,
            "fee_cost": 0,
            "net_copy_edge": -1,
            "decision": "SKIP",
            "skip_reason": "MARKET_DATA_UNAVAILABLE",
        })
        signal["raw"]["market_data_error"] = str(e)[:300]
        signal["id"] = db.insert_signal(signal)
        return signal
    best_bid, best_ask, spread = top_of_book(book)
    fee_rate = await pm.market_fee_rate(trade.get("condition_id"), category)
    signal["spread"] = spread
    signal["fee_rate"] = fee_rate

    if spread is None:
        signal.update({"current_price": best_ask or best_bid, "delay_cost": 0, "slippage": None, "fee_cost": 0, "net_copy_edge": -1, "decision": "SKIP", "skip_reason": "LOW_LIQUIDITY"})
        signal["id"] = db.insert_signal(signal)
        return signal
    if spread > settings.max_spread:
        signal.update({"current_price": best_ask if side == "BUY" else best_bid, "delay_cost": 0, "slippage": 0, "fee_cost": 0, "net_copy_edge": -spread, "decision": "SKIP", "skip_reason": "HIGH_SPREAD"})
        signal["id"] = db.insert_signal(signal)
        return signal

    if side == "SELL":
        opens = db.open_paper_for(wallet["address"], token_id)
        if not opens:
            signal.update({"current_price": best_bid, "delay_cost": max(0.0, leader_price - (best_bid or leader_price)), "slippage": 0, "fee_cost": 0, "net_copy_edge": 0, "decision": "SKIP", "skip_reason": "NO_PAPER_POSITION"})
            signal["id"] = db.insert_signal(signal)
            return signal
        total_shares = sum(float(p["shares"] or 0) for p in opens)
        sim = simulate_sell(book, total_shares, fee_rate)
        current_price = float(sim["avg_price"] or best_bid or 0)
        adverse = max(0.0, leader_price - current_price)
        signal.update({"current_price": current_price, "delay_cost": adverse, "slippage": float(sim["slippage"] or 0), "fee_cost": float(sim["fee"] or 0), "net_copy_edge": 0.0, "decision": "COPY" if sim["filled"] else "SKIP", "skip_reason": None if sim["filled"] else "LOW_LIQUIDITY"})
        signal_id = db.insert_signal(signal)
        signal["id"] = signal_id
        if sim["filled"]:
            # Pro-rata close all open paper positions at one simulated price.
            for p in opens:
                shares = float(p["shares"] or 0)
                gross = shares * current_price
                fee = float(sim["fee"] or 0) * (shares / total_shares if total_shares else 0)
                exit_value = gross - fee
                pnl = exit_value - float(p["cost_usd"] or 0) - float(p["fees_usd"] or 0)
                roi = pnl / float(p["cost_usd"]) if p["cost_usd"] else 0
                db.close_paper_trade(int(p["id"]), current_price, exit_value, pnl, roi, "MIRROR_EXIT")
        return signal

    if side != "BUY":
        signal.update({"current_price": best_ask or best_bid, "delay_cost": 0, "slippage": 0, "fee_cost": 0, "net_copy_edge": -1, "decision": "SKIP", "skip_reason": "UNSUPPORTED_SIDE"})
        signal["id"] = db.insert_signal(signal)
        return signal

    sim = simulate_buy(book, signal["paper_size_usd"], fee_rate)
    current_price = float(sim["avg_price"] or best_ask or 0)
    adverse = max(0.0, current_price - leader_price)
    slippage = max(0.0, float(sim["slippage"] or 0.0))
    fee_cost = float(sim["fee"] or 0.0)
    fee_edge = fee_cost / max(float(sim["cost"] or 0.0), 1e-9)
    spread_cost = max(0.0, spread / 2.0)
    net_edge = expected_alpha - adverse - spread_cost - slippage - fee_edge - settings.safety_margin

    decision = "SKIP"
    reason = None
    alpha_class = str(wallet.get("alpha_class") or "COLLECTING")
    if not sim["filled"]:
        reason = "LOW_LIQUIDITY"
    elif adverse > settings.max_adverse_move:
        reason = "EDGE_DECAYED"
    elif alpha_class == "NON_COPYABLE":
        reason = "DELAY_NOT_COPYABLE"
    elif alpha_class == "FAST_ALPHA" and delay_ms > settings.max_follow_delay_seconds * 1000:
        reason = "FAST_ALPHA_TOO_LATE"
    elif alpha_class in {"COLLECTING", "SLOW_CANDIDATE"}:
        if net_edge >= settings.watch_edge:
            decision = "WATCH"
            reason = "ALPHA_REPLAY_COLLECTING"
        else:
            reason = "NEGATIVE_NET_EDGE"
    elif net_edge >= settings.min_copy_edge:
        decision = "COPY"
    elif net_edge >= settings.watch_edge:
        decision = "WATCH"
        reason = "EDGE_TOO_THIN"
    else:
        reason = "NEGATIVE_NET_EDGE"

    signal.update({
        "current_price": current_price,
        "delay_cost": adverse,
        "slippage": slippage,
        "fee_cost": fee_cost,
        "net_copy_edge": net_edge,
        "decision": decision,
        "skip_reason": reason,
    })
    signal_id = db.insert_signal(signal)
    signal["id"] = signal_id
    if decision == "COPY":
        db.create_paper_trade({
            "signal_id": signal_id,
            "wallet": wallet["address"],
            "token_id": token_id,
            "market_title": trade.get("title"),
            "outcome": trade.get("outcome"),
            "side": "BUY",
            "entry_price": current_price,
            "shares": float(sim["shares"] or 0),
            "cost_usd": float(sim["cost"] or 0),
            "fees_usd": fee_cost,
        })
    return signal
