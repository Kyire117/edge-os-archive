from __future__ import annotations

from typing import Any

from .analytics import fee_usdc


def top_of_book(book: dict[str, Any]) -> tuple[float | None, float | None, float | None]:
    bids = book.get("bids") or []
    asks = book.get("asks") or []
    best_bid = float(bids[0]["price"]) if bids else None
    best_ask = float(asks[0]["price"]) if asks else None
    spread = (best_ask - best_bid) if best_bid is not None and best_ask is not None else None
    return best_bid, best_ask, spread


def simulate_buy(book: dict[str, Any], budget_usd: float, fee_rate: float) -> dict[str, float | bool | None]:
    asks = book.get("asks") or []
    remaining = max(0.0, budget_usd)
    cost = 0.0
    fee = 0.0
    shares = 0.0
    best = float(asks[0]["price"]) if asks else None
    for level in asks:
        p = float(level["price"])
        s = float(level["size"])
        max_cost = p * s
        use_cost = min(remaining, max_cost)
        if p <= 0:
            continue
        use_shares = use_cost / p
        cost += use_cost
        shares += use_shares
        fee += fee_usdc(use_shares, p, fee_rate)
        remaining -= use_cost
        if remaining <= 1e-8:
            break
    filled = budget_usd <= 0 or remaining / max(budget_usd, 1e-9) <= 0.01
    avg = cost / shares if shares else None
    slippage = (avg - best) if (avg is not None and best is not None) else None
    return {"filled": filled, "shares": shares, "cost": cost, "avg_price": avg, "fee": fee, "slippage": slippage, "unfilled_usd": remaining}


def simulate_sell(book: dict[str, Any], shares_to_sell: float, fee_rate: float) -> dict[str, float | bool | None]:
    bids = book.get("bids") or []
    remaining = max(0.0, shares_to_sell)
    proceeds = 0.0
    fee = 0.0
    sold = 0.0
    best = float(bids[0]["price"]) if bids else None
    for level in bids:
        p = float(level["price"])
        s = float(level["size"])
        use = min(remaining, s)
        proceeds += use * p
        sold += use
        fee += fee_usdc(use, p, fee_rate)
        remaining -= use
        if remaining <= 1e-8:
            break
    filled = shares_to_sell <= 0 or remaining / max(shares_to_sell, 1e-9) <= 0.01
    avg = proceeds / sold if sold else None
    slippage = (best - avg) if (avg is not None and best is not None) else None
    return {"filled": filled, "shares": sold, "proceeds": proceeds, "avg_price": avg, "fee": fee, "slippage": slippage, "unfilled_shares": remaining}
