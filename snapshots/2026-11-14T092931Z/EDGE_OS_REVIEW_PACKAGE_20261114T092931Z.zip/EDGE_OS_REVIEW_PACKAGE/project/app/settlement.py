from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any

from .config import settings
from .db import db
from .paper import top_of_book
from .polymarket import pm

log = logging.getLogger("edge.settlement")


async def refresh_open_paper_positions(database=db, client=pm) -> dict[str, Any]:
    """Mark open paper positions and close them after official resolution."""
    positions = database.open_paper_trades()
    result: dict[str, Any] = {
        "paper_checked": len(positions),
        "paper_marked": 0,
        "paper_settled": 0,
        "paper_errors": [],
    }
    if not positions:
        return result

    by_token: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for position in positions:
        token_id = str(position.get("token_id") or "")
        if token_id:
            by_token[token_id].append(position)
        else:
            result["paper_errors"].append(f"paper #{position['id']}: missing token id")

    semaphore = asyncio.Semaphore(max(1, settings.paper_refresh_concurrency))

    async def refresh_token(token_id: str, token_positions: list[dict[str, Any]]) -> dict[str, Any]:
        local = {"marked": 0, "settled": 0, "errors": []}
        async with semaphore:
            try:
                state = await asyncio.wait_for(
                    client.market_state(token_id),
                    timeout=settings.realtime_request_timeout_seconds,
                )
                settlement_price = state.get("settlement_price")
                if state.get("resolved") and settlement_price is not None:
                    price = float(settlement_price)
                    for position in token_positions:
                        shares = float(position.get("shares") or 0)
                        cost = float(position.get("cost_usd") or 0)
                        entry_fee = float(position.get("fees_usd") or 0)
                        exit_value = shares * price
                        pnl = exit_value - cost - entry_fee
                        roi = pnl / cost if cost else 0.0
                        database.close_paper_trade(
                            int(position["id"]), price, exit_value, pnl, roi, "MARKET_SETTLED"
                        )
                        local["settled"] += 1
                    return local

                mark_price = state.get("current_price")
                source = "GAMMA_PRICE"
                try:
                    book = await client.orderbook(token_id)
                    best_bid, _, _ = top_of_book(book)
                    if best_bid is not None:
                        mark_price = best_bid
                        source = "ORDER_BOOK_BID"
                except Exception:
                    # Closed, thin or temporarily unavailable books are common.
                    # Gamma's token price is still useful for an unrealized mark.
                    pass

                if mark_price is not None:
                    price = max(0.0, min(1.0, float(mark_price)))
                    for position in token_positions:
                        database.mark_paper_trade(int(position["id"]), price, source)
                        local["marked"] += 1
            except Exception as exc:
                local["errors"].append(f"{token_id}: {exc}")
                log.warning("paper refresh failed for %s: %s", token_id, exc)
        return local

    batches = await asyncio.gather(
        *(refresh_token(token_id, rows) for token_id, rows in by_token.items())
    )
    for batch in batches:
        result["paper_marked"] += batch["marked"]
        result["paper_settled"] += batch["settled"]
        result["paper_errors"].extend(batch["errors"])
    result["paper_errors"] = result["paper_errors"][:10]
    return result


async def refresh_signal_settlements(database=db, client=pm) -> dict[str, Any]:
    """Resolve forward replay samples even when no Paper trade was opened."""
    tokens = database.unsettled_signal_tokens(settings.signal_settlement_batch_tokens)
    result: dict[str, Any] = {"tokens_checked": len(tokens), "signals_settled": 0, "errors": []}
    if not tokens:
        return result
    semaphore = asyncio.Semaphore(max(1, settings.paper_refresh_concurrency))

    async def refresh(token_id: str) -> tuple[int, str | None]:
        async with semaphore:
            try:
                state = await client.market_state(token_id)
                price = state.get("settlement_price")
                if state.get("resolved") and price is not None:
                    return database.settle_signal_token(token_id, float(price)), None
                database.mark_signal_token_checked(token_id)
                return 0, None
            except Exception as exc:
                database.mark_signal_token_checked(token_id)
                return 0, f"{token_id}: {exc}"

    rows = await asyncio.gather(*(refresh(token) for token in tokens))
    for settled, error in rows:
        result["signals_settled"] += settled
        if error:
            result["errors"].append(error)
    result["errors"] = result["errors"][:10]
    return result
