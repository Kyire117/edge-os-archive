# GitHub 参考项目审阅记录

本任务前段读取了 GitHub 账号 **Kyire117** 当时公开的全部 **25 个标星仓库**清单；列表首个 100 条页面返回 25 条，无下一页。逐项检查仓库说明及相关文件，选取与需求直接相关的设计。恢复阶段沿用这份审阅记录。

这里的“审阅”不是逐行审计所有源码、安装运行全部项目或下载全部数据。并非所有星标都与 Edge OS 有关；无 README 的资源仓库只检查元数据。下表明确保留采用与不采用的原因。本实现没有复制第三方项目源码，也没有声称把这些项目全部作为依赖接入。

| 仓库 | 审阅与取舍 |
|---|---|
| [pselamy/polymarket-insider-tracker](https://github.com/pselamy/polymarket-insider-tracker) | 借鉴可追溯评分/配置版本、研究审计思路；本版采用记录与规则版本。资金实体关联尚未实现，仅支持人工关联分组。 |
| [warproxxx/poly_data](https://github.com/warproxxx/poly_data) | 借鉴原始成交与市场/代币映射、时间戳记录。未引入 HyperSync/RPC 数据栈；当前仍是公开 API 轮询。注意该项目 GPL-3.0，本版未复制其源码。 |
| [Jon-Becker/prediction-market-analysis](https://github.com/Jon-Becker/prediction-market-analysis) | 阅读 README 和 `docs/SCHEMAS.md`，参考市场/事件/交易标识与研究数据边界。未下载约 36GB 数据集，不冒充历史订单簿回放。 |
| [Polymarket/polymarket-cli](https://github.com/Polymarket/polymarket-cli) | 参考公开数据与执行分层。本版不引入 CLI 私钥、签名或真实下单。 |
| [steveseguinnin/polymarket-arbitrage-reverse-bot](https://github.com/steveseguinnin/polymarket-arbitrage-reverse-bot) | 双腿短周期套利与钱包条件跟单研究目标不同；不接入。 |
| [AveYofox/polymarket-forecasting-bot](https://github.com/AveYofox/polymarket-forecasting-bot) | 阅读 README，参考固定实验预算、已处理成交去重、模拟/实盘分离。当前 $25 基线与仅模拟边界按本项目需要实现。 |
| [FrondEnt/PolymarketBTC15mAssistant](https://github.com/FrondEnt/PolymarketBTC15mAssistant) | BTC 15 分钟方向特化，与当前跨领域钱包研究不一致；不强行加入。 |
| [OpenByteInc/QuantDinger](https://github.com/OpenByteInc/QuantDinger) | 阅读 README 与 `docs/agent/README.md`，参考研究/执行隔离、模型接口和审计；未移植整个平台。 |
| [msitarzewski/agency-agents](https://github.com/msitarzewski/agency-agents) | 借鉴研究、批判和复盘职责分工；当前一个模型接口承担不同任务，不引入多代理框架。 |
| [Johnshall/Shadowrocket-ADBlock-Rules-Forever](https://github.com/Johnshall/Shadowrocket-ADBlock-Rules-Forever) | 网络规则，与策略无直接关系；不接入。 |
| [google/langextract](https://github.com/google/langextract) | 借鉴结构化输出与证据定位；使用本项目 Pydantic schema/档案 ID 校验，未额外安装 SDK。 |
| [YouMind-OpenLab/nano-banana-pro-prompts-recommend-skill](https://github.com/YouMind-OpenLab/nano-banana-pro-prompts-recommend-skill) | 图像提示词用途，无关本版核心目标。 |
| [666ghj/BettaFish](https://github.com/666ghj/BettaFish) | 借鉴证据、反例和研究报告结构；当前没有新闻检索模块，不声称已接入该项目的舆情能力。 |
| [linshenkx/prompt-optimizer](https://github.com/linshenkx/prompt-optimizer) | 参考提示词版本与评估意识；保留系统提示版本、上下文和结果，不让 AI 自行重写核心权限。 |
| [KnowNo/books-2](https://github.com/KnowNo/books-2) | 资源库；未获得 README，仅核对仓库元信息。无本版可复用模块。 |
| [xming521/WeClone](https://github.com/xming521/WeClone) | 训练/个性化方向，本版通过检索档案复盘，不做模型微调；不接入。 |
| [elder-plinius/L1B3RT4S](https://github.com/elder-plinius/L1B3RT4S) | 越狱提示词与可靠策略研究无关，不使用。 |
| [jeecgboot/JeecgBoot](https://github.com/jeecgboot/JeecgBoot) | 重型企业应用框架；当前 FastAPI/SQLite MVP 不需要迁移。 |
| [free-nodes/v2rayfree](https://github.com/free-nodes/v2rayfree) | 网络资源与研究功能无关，不接入。 |
| [NSA/ghidra](https://github.com/NSA/ghidra) | 逆向分析工具，不适用。 |
| [vastsa/FileCodeBox](https://github.com/vastsa/FileCodeBox) | 文件分享服务，本机档案导出即可满足本版需求；不新增服务。 |
| [xfangfang/wiliwili](https://github.com/xfangfang/wiliwili) | 视频客户端，不适用。 |
| [Ice-Hazymoon/MikuTools](https://github.com/Ice-Hazymoon/MikuTools) | 工具集合，没有本版必要依赖。 |
| [didi/LogicFlow](https://github.com/didi/LogicFlow) | 可用于未来规则可视化编辑；本版优先清楚展示条件，暂不加图形编排器。 |
| [immersive-translate/immersive-translate](https://github.com/immersive-translate/immersive-translate) | 发布/翻译项目，非本版策略模块，不接入。 |

## 用户指定的 Polymarket/agents

阅读了 [Polymarket/agents](https://github.com/Polymarket/agents) README 及 `agents/application/executor.py`、`agents/application/prompts.py`。借鉴“数据 → 研究 → 明确决策”的结构；本版用小型兼容 API 接口与结构化 JSON 校验实现。

该仓库已归档，所用旧模型/依赖和私钥下单路径不直接移植。当前版本保持无交易签名、无真钱下单，不把归档示例当成已适配当前 API 的成品。

## 当前 API 核对

- [Polymarket 市场列表](https://docs.polymarket.com/api-reference/markets/list-markets)：`closed` 默认为 false；修复为未关闭查询无结果时查询 `closed=true`，并严格匹配 token。
- [Polymarket 费用规则](https://docs.polymarket.com/trading/fees)：按实际成交价层计算费用，未知费用不使用静态类别费率代替。
- [CLOB 市场费用参数](https://docs.polymarket.com/api-reference/markets/get-clob-market-info)：读取费用来源，未支持的指数曲线跳过并记录。
- [DeepSeek JSON 输出](https://api-docs.deepseek.com/guides/json_mode/)：JSON 响应及结构校验；检查输出截断。
- [Qwen OpenAI 兼容接口](https://www.alibabacloud.com/help/en/model-studio/compatibility-of-openai-with-dashscope)：区分大陆/国际地址，支持页面填写模型名与 API Key。

用得上的设计已经体现为小型可检验模块。未来接入任何完整第三方代码前，仍需独立检查许可证、维护状态、依赖和测试结果。
