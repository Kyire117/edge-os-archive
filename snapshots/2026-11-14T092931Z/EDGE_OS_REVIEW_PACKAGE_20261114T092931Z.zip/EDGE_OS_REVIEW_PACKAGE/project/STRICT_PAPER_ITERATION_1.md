# Strict paper execution and ledger — iteration 1

This is an isolated, opt-in prototype. It is not connected to the running
Forward Copy V0.1/V0.4 experiment, the legacy `paper_trades` table, app startup,
settlement worker, or dashboard. No existing signal is replayed.

## Components

- `app/strict_paper.py` validates an exact condition/token/outcome identity,
  then evaluates a separate quote snapshot and later execution snapshot. BUY
  walks asks; SELL walks bids. Both books are sorted explicitly, checked for
  crossed/invalid levels, source timestamps and age. Execution requires a new
  request and snapshot, a newer source timestamp, and the configured latency.
  The quote's source timestamp must also be at or after signal detection; a
  request made after detection cannot legitimize a pre-signal book snapshot.
- `app/strict_ledger.py` is an opt-in SQLite account that creates only
  `strict_*` tables, including a frozen rule-version registry. It records
  accepted and rejected decisions, cash reservations, orders, fills, positions,
  realized/unrealized P&L, observed best-bid marks, cash flows, settlement
  observations and audit events. It does not call the
  existing `Database.init()` migration path.
- `tests/test_strict_paper_iteration1.py` uses temporary SQLite files and
  deterministic UTC fixtures. It also places a legacy paper row in the test
  database and confirms initialization and fills leave it unchanged.

## Frozen defaults and accounting

The default immutable `EngineRules` values are:

| Rule | Default |
| --- | ---: |
| Engine version | `strict-paper-engine-v1` |
| Rule version | `strict-paper-rules-v1` |
| Execution latency | 500 ms |
| Maximum source-book age | 3,000 ms |
| Maximum adverse move | 0.03 probability points |
| Maximum visible depth participation | 10% per level |
| Partial fills | disabled unless engine rule and order both allow them |
| Near-certainty lockout | 0.98 / 0.02 |
| Quantity / money precision | 6 decimal places |

The supplied quote best price converts BUY notional into a share target. A BUY
cannot spend more than its notional. Execution depth is capped per level by
the configured participation fraction. Costs are rounded down per level and
fees are rounded up per level with the existing fee expression
`quantity × fee_rate × price × (1 - price)`. The fee schedule and source are
inputs and are preserved in the decision evidence; zero fees require an
explicit zero-fee source label. Rule configuration is stored once per rule
version in `strict_rule_versions`; attempting to reuse the version with a
different configuration fails closed.

BUY orders reserve cash before any fill. SELL orders reserve held shares.
  Each fill transaction validates the recorded quote/execution evidence against
  the fill levels, visible depth, frozen latency/rule configuration, identity,
  fee calculation and target quantity. It then updates fill, position, cash,
  order reservation and the audit chain atomically. Duplicate event IDs with
  different payloads fail; replaying the same partial execution evidence under
  a different caller-generated fill ID is also idempotently ignored. Fill
  levels must follow best executable price order. Decision, fill, cash and settlement journal rows
reject direct updates/deletes.
Formal settlement requires an authoritative source and explicit payout per
share. Market end time, market closure, pending data, void states or API errors
do not create a payout. Open positions survive temporary refresh failures.

## Explicit activation and migration

The only schema operation is an explicit call to
`StrictPaperLedger.initialize(test_or_future_database_path)`. It runs
`CREATE TABLE/INDEX/TRIGGER IF NOT EXISTS` for new `strict_*` objects and does
not alter old tables or records. The tests ran this operation only against
temporary databases. Production `data/edge_mvp.db` was never opened by a
write-capable code path during this iteration.

The local audit hash chain detects accidental/out-of-band edits, missing rows,
and sequence changes. It is not cryptographic proof that a local database
cannot be forged by someone who controls that database.

## Known limits before any integration

- No upstream client adapter currently builds `BookSnapshot` from Polymarket;
  callers must supply source-backed identity, timestamps, levels and fee
  evidence.
- `MarketState` must be supplied by an adapter. This prototype does not fetch
  resolution state or infer settlement from an expected end time.
- BUY intent is expressed as a maximum notional and converted to a target
  quantity at the quote best ask. A worse later execution price can leave a
  partially filled share target; the default rejects that candidate unless
  partial fills are explicitly enabled by both frozen rules and intent.
- The ledger is not wired into app startup/API/UI and creates no account unless
  an explicit caller initializes a chosen database and creates one.
- External reference tests were not run from PaperTrench. Only the reviewed
  correctness intentions were implemented as Python fixtures; its prediction
  submit refusal is not treated as a completed fill system.
