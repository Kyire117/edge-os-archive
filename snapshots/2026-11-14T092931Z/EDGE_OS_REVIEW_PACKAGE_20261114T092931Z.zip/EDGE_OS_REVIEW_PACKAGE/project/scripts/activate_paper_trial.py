"""Atomically select a fully prepared, verified PAPER_ONLY experiment."""
import argparse,json,os,sqlite3,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.archive_paper_run import sha,require_stopped
from edge_runtime import MANIFEST,active_run
from app.paper_trial_risk import DEFAULTS

def activate(out):
 require_stopped();out=Path(out).resolve()
 archive=json.loads((out/'archive.json').read_text(encoding='utf8'))
 prepared=json.loads((out/'prepared_experiment.json').read_text(encoding='utf8'))
 if active_run()!=archive['old_run']:raise RuntimeError('ACTIVE_EXPERIMENT_CHANGED')
 snapshot=Path(archive['backup'])
 if archive.get('integrity_check')!='ok' or sha(snapshot)!=archive.get('backup_sha256'):raise RuntimeError('ARCHIVE_CHANGED')
 if prepared.get('run_id')==archive['old_run'].get('run_id'):raise RuntimeError('RUN_ID_NOT_UNIQUE')
 if prepared.get('live_orders') is not False or prepared.get('risk_policy')!=DEFAULTS:raise RuntimeError('PAPER_POLICY_MISMATCH')
 if prepared.get('fixed_initial_cash')!='100.000000':raise RuntimeError('INITIAL_CASH_MISMATCH')
 database=(ROOT/prepared['database']).resolve()
 if database.parent!=(ROOT/'data').resolve() or not database.name.startswith('edge_forward_') or database==Path(archive['source']).resolve():
  raise RuntimeError('INVALID_NEW_EXPERIMENT_DATABASE')
 with sqlite3.connect(database.as_uri()+'?mode=ro',uri=True) as c:
  c.row_factory=sqlite3.Row
  if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('NEW_DATABASE_INTEGRITY_FAILED')
  if c.execute('PRAGMA foreign_key_check').fetchone():raise RuntimeError('NEW_DATABASE_FOREIGN_KEY_FAILED')
  risk=json.loads(c.execute('SELECT config_json FROM paper_trial_risk').fetchone()[0])
  if risk!=DEFAULTS:raise RuntimeError('RISK_POLICY_MISMATCH')
  for table in ('wallet_v2_episodes','strict_orders','strict_fills','strict_positions','strict_settlements',
                'strict_decisions','paper_trial_risk_events','paper_trial_equity'):
   if c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]!=0:raise RuntimeError('NEW_DATABASE_NOT_EMPTY_'+table.upper())
  pool=c.execute('SELECT cash_account_id,fixed_initial_cash FROM strict_cash_pools').fetchone()
  if not pool or pool['fixed_initial_cash']!='100.000000':raise RuntimeError('INITIAL_POOL_MISMATCH')
  cash=c.execute('SELECT available_cash,reserved_cash FROM strict_accounts WHERE account_id=?',(pool['cash_account_id'],)).fetchone()
  if not cash or cash['available_cash']!='100.000000' or cash['reserved_cash']!='0.000000':raise RuntimeError('INITIAL_CASH_STATE_MISMATCH')
  version=c.execute("SELECT state,activated_at,evidence_cutoff FROM wallet_v2_versions WHERE strategy_version='wallet-follow-v2.0'").fetchone()
  if not version or version['state']!='FORWARD_TEST' or version['activated_at']!=prepared['activated_at'] or version['evidence_cutoff']!=prepared['evidence_cutoff']:
   raise RuntimeError('FORWARD_ACTIVATION_MISMATCH')
 current=json.loads(MANIFEST.read_text(encoding='utf8'))
 active={**prepared,'archives':archive['old_run'].get('archives',[])+[{
  'run_id':archive['old_run']['run_id'],'label':'Archived previous paper experiment',
  'database':archive['old_run']['database'],'verified_snapshot':str(snapshot.relative_to(ROOT)),
  'snapshot_sha256':archive['backup_sha256'],'archived_at':archive['created_at'],
  **{k:archive['summary'][k] for k in ('wallet_v2_episodes','strict_orders','strict_fills','strict_positions','strict_settlements',
   'strict_decisions','realized_pnl','open_cost_basis','open_positions','available_cash','reserved_cash','risk_config')},
  'preserved_read_only':True}],
  'activated_locally_at':datetime.now(timezone.utc).isoformat(),'live_orders':False}
 temp=MANIFEST.with_name(MANIFEST.name+'.tmp')
 (out/'active_experiment_before.json').write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding='utf8')
 temp.write_text(json.dumps(active,ensure_ascii=False,indent=2),encoding='utf8')
 os.replace(temp,MANIFEST)
 try:
  if active_run()['run_id']!=active['run_id']:raise RuntimeError('ACTIVE_EXPERIMENT_VERIFY_FAILED')
 except Exception:
  rollback=MANIFEST.with_name(MANIFEST.name+'.rollback.tmp')
  rollback.write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding='utf8');os.replace(rollback,MANIFEST)
  raise
 (out/'active_experiment_after.json').write_text(json.dumps(active,ensure_ascii=False,indent=2),encoding='utf8')
 receipt={'phase':'activated_paper_only','activated_at':active['activated_locally_at'],'run_id':active['run_id'],
  'database':str(database),'risk_policy':DEFAULTS,'live_orders':False,'old_archive_sha256':archive['backup_sha256'],
  'initial_cash':'100.000000','available_cash':'100.000000','reserved_cash':'0.000000','open_cost_basis':'0',
  'realized_pnl':'0','strict_orders':0,'strict_fills':0,'open_positions':0,'risk_events':0}
 (out/'activation_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
 print(json.dumps(receipt,ensure_ascii=False),flush=True)
 return receipt

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('out');args=parser.parse_args();activate(args.out)
