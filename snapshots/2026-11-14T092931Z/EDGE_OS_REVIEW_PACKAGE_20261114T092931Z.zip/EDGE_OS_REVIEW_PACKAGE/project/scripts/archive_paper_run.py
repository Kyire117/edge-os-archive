"""Create a verified archive without changing the active experiment."""
import hashlib,json,socket,sqlite3,sys
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from edge_runtime import active_database,active_run

def sha(path):
 d=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(4*1024*1024),b''):d.update(chunk)
 return d.hexdigest()

def require_stopped():
 with socket.socket() as s:
  s.settimeout(2)
  if s.connect_ex(('127.0.0.1',8000))==0:raise RuntimeError('APPLICATION_MUST_BE_STOPPED')

def archive():
 require_stopped();run=active_run();source=active_database()
 stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 out=ROOT/'execution_output'/('paper_trial_100_'+stamp);out.mkdir(parents=True,exist_ok=False)
 backup=ROOT/'data/backups'/(source.stem+'.archived-'+stamp+'.db');backup.parent.mkdir(parents=True,exist_ok=True)
 (out/'active_experiment_before.json').write_text(json.dumps(run,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({'phase':'archive_started','out':str(out)}),flush=True)
 files=[p for p in (source,Path(str(source)+'-wal')) if p.exists()]
 before={p.name:{'size':p.stat().st_size,'sha256':sha(p)} for p in files}
 with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True,timeout=30) as src:
  src.execute('PRAGMA query_only=ON');src.execute('BEGIN')
  assert src.execute('PRAGMA quick_check').fetchone()[0]=='ok'
  with sqlite3.connect(backup) as dst:
   src.backup(dst)
   assert dst.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  src.rollback()
 require_stopped()
 after={p.name:{'size':p.stat().st_size,'sha256':sha(p)} for p in files}
 if before!=after:raise RuntimeError('SOURCE_CHANGED_DURING_ARCHIVE')
 with sqlite3.connect(backup.as_uri()+'?mode=ro',uri=True) as con:
  con.row_factory=sqlite3.Row
  required=('wallet_v2_episodes','strict_orders','strict_fills','strict_positions','strict_settlements',
   'strict_decisions','paper_trial_risk_events')
  counts={t:con.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in required}
  positions=[dict(x) for x in con.execute('SELECT account_id,condition_id,token_id,outcome,quantity,cost_basis,realized_pnl FROM strict_positions')]
  open_positions=[p for p in positions if Decimal(p['quantity'])>0]
  pool=con.execute('SELECT * FROM strict_cash_pools ORDER BY activated_at DESC LIMIT 1').fetchone()
  cash=dict(con.execute('SELECT * FROM strict_accounts WHERE account_id=?',(pool['cash_account_id'],)).fetchone()) if pool else None
  risk=con.execute('SELECT config_json FROM paper_trial_risk ORDER BY created_at DESC LIMIT 1').fetchone()
  rejection_counts={r['reason'] or 'UNKNOWN':r['count'] for r in con.execute("SELECT reason,COUNT(*) AS count FROM strict_decisions WHERE status='REJECTED' GROUP BY reason ORDER BY reason")}
  summary={**counts,'strategy_version':run.get('strategy_version'),'started_at':run.get('started_at'),
   'database_path':str(source),'initial_cash':pool['fixed_initial_cash'] if pool else None,
   'available_cash':cash['available_cash'] if cash else None,'reserved_cash':cash['reserved_cash'] if cash else None,
   'realized_pnl':str(sum((Decimal(p['realized_pnl']) for p in positions),Decimal(0))),
   'open_cost_basis':str(sum((Decimal(p['cost_basis']) for p in positions if Decimal(p['quantity'])>0),Decimal(0))),
   'open_positions':len(open_positions),'open_position_details':open_positions,
   'rejection_reason_counts':rejection_counts,
   'risk_config':json.loads(risk['config_json']) if risk else None,
   'semantics':'Frozen historical snapshot; unsettled positions are not assumed closed.'}
 manifest={'created_at':datetime.now(timezone.utc).isoformat(),'old_run':run,'source':str(source),'source_files':before,
  'source_unchanged':True,'backup':str(backup),'backup_size':backup.stat().st_size,'backup_sha256':sha(backup),
  'database_sha256':sha(backup),'integrity_check':'ok','summary':summary,'activation_performed':False,'live_orders':False}
 (out/'archive.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({'phase':'archive_verified','out':str(out),'backup':str(backup),'summary':summary}),flush=True)
if __name__=='__main__':archive()
