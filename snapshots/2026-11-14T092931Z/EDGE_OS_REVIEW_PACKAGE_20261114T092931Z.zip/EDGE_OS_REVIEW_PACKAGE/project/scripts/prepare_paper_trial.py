"""Prepare a fresh 100 USDC experiment from a verified archive; never delete history."""
import argparse,json,sqlite3,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.archive_paper_run import sha,require_stopped
from edge_runtime import MANIFEST,active_run
from app.db import Database
from app import research
from app.wallet_follow_v2 import WalletFollowV2,StrategyConfig
from app.shared_pool import activate_pool
from app.exit_v1 import ensure_exit_v1_active
from app.paper_trial_risk import initialize as initialize_risk,DEFAULTS,read_status

def prepare(out):
 require_stopped();out=Path(out).resolve();record=json.loads((out/'archive.json').read_text(encoding='utf8'))
 old=active_run()
 if old!=record['old_run']:raise RuntimeError('ACTIVE_EXPERIMENT_CHANGED')
 archive=Path(record['backup'])
 if record['integrity_check']!='ok' or sha(archive)!=record['backup_sha256']:raise RuntimeError('ARCHIVE_CHANGED')
 at=datetime.now(timezone.utc);stamp=at.strftime('%Y%m%dT%H%M%SZ');run_id='FORWARD-'+stamp
 if run_id==old['run_id']:raise RuntimeError('RUN_ID_NOT_UNIQUE')
 destination=ROOT/'data'/('edge_forward_'+stamp+'.db')
 if destination.exists():raise RuntimeError('DESTINATION_EXISTS')
 with sqlite3.connect(archive.as_uri()+'?mode=ro',uri=True) as c:
  c.row_factory=sqlite3.Row
  version=dict(c.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version='wallet-follow-v2.0'").fetchone())
  exit_config=c.execute("SELECT config_json FROM wallet_v2_exit_rules WHERE state='ACTIVE'").fetchone()[0]
 config=StrategyConfig.from_evidence(json.loads(version['config_json']))
 if config.evidence()!=old['frozen_config']:raise RuntimeError('SOURCE_STRATEGY_CONFIG_MISMATCH')
 db=Database(str(destination));db.init();research.init(db)
 # Preserve wallet discovery/research inputs, not historical paper performance.
 tables=['wallets','wallet_category_stats','wallet_public_profiles','trades','wallet_candidates','research_identity','research_exclusions','research_ai_runs']
 with sqlite3.connect(destination,uri=True) as c:
  c.execute('PRAGMA foreign_keys=ON');c.execute('ATTACH DATABASE ? AS archive',(archive.as_uri()+'?mode=ro',))
  for table in tables:
   columns={r[1] for r in c.execute('PRAGMA archive.table_info("'+table+'")')}
   target=[r[1] for r in c.execute('PRAGMA main.table_info("'+table+'")') if r[1] in columns]
   if not target:continue
   names=','.join('"'+x+'"' for x in target)
   c.execute('INSERT INTO main."'+table+'" ('+names+') SELECT '+names+' FROM archive."'+table+'"')
  c.execute('UPDATE wallets SET last_trade_ts=?,last_error=NULL',(int(at.timestamp()),))
  c.execute('UPDATE trades SET is_seed=1')
  c.execute("UPDATE system_state SET value=? WHERE key='research_started_at'",(at.isoformat(),))
  tracked=[r[0] for r in c.execute('SELECT address FROM wallets WHERE tracked=1 ORDER BY address')]
 if not tracked:raise RuntimeError('NO_TRACKED_WALLETS')
 WalletFollowV2.initialize(destination);engine=WalletFollowV2(destination)
 engine.create_version(config,created_at=at,evidence_cutoff=at);engine.activate(at=at)
 # Exactly one capital credit. Shared-pool books created subsequently receive zero.
 engine.ledger(tracked[0]).create_account('100',created_at=at.isoformat())
 activate_pool(destination,initial_cash='100',at=at)
 ensure_exit_v1_active(destination,activated_at=at)
 initialize_risk(destination,at=at)
 with sqlite3.connect(destination,uri=True) as c:
  assert json.loads(c.execute("SELECT config_json FROM wallet_v2_exit_rules WHERE state='ACTIVE'").fetchone()[0])==json.loads(exit_config)
  c.execute("INSERT INTO wallet_v2_audit(action,occurred_at,evidence_json) VALUES('CLEAN_FORWARD_RESTART',?,?)",(at.isoformat(),json.dumps({'run_id':run_id,'source_replay':False,'archive_run':old['run_id'],'archive_sha256':record['backup_sha256'],'risk_overlay':DEFAULTS},sort_keys=True)))
  assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
  assert not c.execute('PRAGMA foreign_key_check').fetchone()
  for t in ['wallet_v2_episodes','strict_orders','strict_fills','strict_positions','strict_settlements',
            'strict_decisions','paper_trial_risk_events','paper_trial_equity']:
   assert c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0]==0
  assert c.execute('SELECT COUNT(*) FROM strict_cash_ledger WHERE entry_type="INITIAL_CASH"').fetchone()[0]==1
  pool=c.execute('SELECT cash_account_id,fixed_initial_cash FROM strict_cash_pools').fetchone()
  assert pool and pool[1]=='100.000000'
  cash=c.execute('SELECT available_cash,reserved_cash FROM strict_accounts WHERE account_id=?',(pool[0],)).fetchone()
  assert cash and cash[0]=='100.000000' and cash[1]=='0.000000'
 assert engine.ledger(tracked[0]).reconcile()['ok']
 initial_status=read_status(destination,at=at)
 assert initial_status['enabled'] and initial_status['config']==DEFAULTS
 assert initial_status['realized_pnl']=='0' and initial_status['open_cost_basis']=='0'
 assert initial_status['reserved_cash']=='0' and initial_status['open_exposure']=='0'
 assert initial_status['market_exposure']==[] and initial_status['event_exposure']=={}
 initial_status['financial_state']={'initial_cash':'100.000000','available_cash':cash[0],
  'ledger_reserved_cash':cash[1],'strict_orders':0,'strict_fills':0,'open_positions':0,
  'strict_settlements':0,'risk_events':0,'realized_pnl':'0','open_cost_basis':'0'}
 archive_entry={'run_id':old['run_id'],'label':'Archived previous paper experiment','database':old['database'],
  'verified_snapshot':str(archive.relative_to(ROOT)),'snapshot_sha256':record['backup_sha256'],
  'episodes':record['summary']['wallet_v2_episodes'],'fills':record['summary']['strict_fills'],
  'realized_pnl':record['summary']['realized_pnl'],'open_positions':record['summary']['open_positions'],
  'archived_at':at.isoformat(),'preserved_read_only':True}
 manifest={'run_id':run_id,'label':'100 USDC paper trial — 1U sizing','started_at':at.isoformat(),'activated_at':at.isoformat(),
  'evidence_cutoff':at.isoformat(),'database':str(destination.relative_to(ROOT)),
  'strategy_version':old['strategy_version'],'live_orders':False,'archives':old.get('archives',[])+[archive_entry],
  'initial_episodes':0,'initial_fills':0,'frozen_config':config.evidence(),'funding_model':'SHARED_FIXED',
  'fixed_initial_cash':'100.000000','funding_version':'shared-cash-pool-v1','risk_policy':DEFAULTS,
  'evaluation':{'trigger':'例行报告','scheduled_reports':False,'primary_metric':'COMPOSITE_NET_RETURN_TREND',
   'minimum_win_rate_gate':False,'evidence_sufficiency_gate':False,'observation_weeks':2,
   'conclusions':['继续模拟','需要优化','满足小额实盘试验条件','暂无法判断']}}
 (out/'prepared_experiment.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
 (out/'initial_risk.json').write_text(json.dumps(initial_status,indent=2),encoding='utf8')
 print(json.dumps({'phase':'prepared_not_active','run_id':run_id,'database':str(destination),'tracked_wallets':len(tracked),'initial_cash':'100','fills':0}),flush=True)
 return manifest

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('out');args=parser.parse_args();prepare(args.out)
