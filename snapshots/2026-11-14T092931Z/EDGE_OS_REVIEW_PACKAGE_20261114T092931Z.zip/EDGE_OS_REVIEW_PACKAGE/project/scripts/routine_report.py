"""On-demand read-only evidence for the Chinese 'routine report' workflow.

Prints current evidence; the operator assesses the return curve and final
readiness using ROUTINE_REPORT.md. Never schedules reports or enables trading.
"""
import json,sqlite3,sys,urllib.request
from datetime import datetime,timezone,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from edge_runtime import active_run,active_database
from app.shared_pool import capital_metrics
from app.paper_trial_risk import policy,snapshot,serial
from app.strict_ledger import StrictPaperLedger

def collect():
 now=datetime.now(timezone.utc);run=active_run();path=active_database()
 with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=30) as c:
  c.row_factory=sqlite3.Row;c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
  p=policy(c,'wallet-follow-v2.0:shared-cash')
  risk=snapshot(c,p,now) if p else None
  version=dict(c.execute("SELECT * FROM wallet_v2_versions WHERE strategy_version='wallet-follow-v2.0'").fetchone())
  capital=capital_metrics(c,'wallet-follow-v2.0',now=now)
  counts={t:c.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in ['strict_orders','strict_fills','wallet_v2_episodes','strict_settlements']}
  reasons=dict(c.execute('SELECT rejection_reason,COUNT(*) FROM wallet_v2_episodes WHERE paper_status="REJECTED" GROUP BY rejection_reason'))
  accounts=[r[0] for r in c.execute('SELECT account_id FROM strict_accounts ORDER BY account_id')]
  curve=[dict(r) for r in c.execute('SELECT observed_at,net_pnl,realized_pnl,open_cost_basis,missing_valuations FROM paper_trial_equity ORDER BY id')] if p else []
  events=[dict(r) for r in c.execute('SELECT condition_id,token_id,outcome,quantity,cost_basis,realized_pnl FROM strict_positions ORDER BY condition_id')]
  payload={'assessed_at_utc':now.isoformat(),'experiment':run,'version':version,'capital':capital,
   'risk':risk,'counts':counts,'rejection_reasons':reasons,'equity_observations':curve,'position_attribution':events,
   'days_since_start':(now-datetime.fromisoformat(run.get('observation_started_at') or run['started_at'])).total_seconds()/86400,
   'workflow':'ROUTINE_REPORT.md','live_orders':False,'snapshot_scope':'single read transaction; health/audit probes separately timestamped'}
  if risk:
   payload['total_net_return']=risk['net_pnl']/100 if risk['net_pnl'] is not None else None
 # Ledger audit chains are append-only and separately captured after the financial snapshot.
 payload['audit_checks']={a:StrictPaperLedger(path,a).verify_audit_chain() for a in accounts}
 payload['audit_checked_at_utc']=datetime.now(timezone.utc).isoformat()
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  with opener.open('http://127.0.0.1:8000/api/health',timeout=15) as r:payload['runtime_health']=json.load(r)
 except Exception as e:payload['runtime_health']={'available':False,'error_type':type(e).__name__}
 return payload
if __name__=='__main__':print(json.dumps(collect(),ensure_ascii=True,indent=2,default=serial))
