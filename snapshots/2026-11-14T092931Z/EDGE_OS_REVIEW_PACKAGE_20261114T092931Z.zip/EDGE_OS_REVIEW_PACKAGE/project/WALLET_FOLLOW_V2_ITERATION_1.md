# Wallet Follow V2, Iteration 1

This iteration adds an **opt-in simulation**. The running V0.x service, its database, wallet cohort, historical decisions and dashboard do not import or invoke `app/wallet_follow_v2.py`. A future, separately reviewed activation must wire this path to live observation.

## Frozen strategy

`wallet-follow-v2.0` starts as `CANDIDATE`, can move to `FORWARD_TEST`, then `COMPLETED` or `RETIRED`. The database trigger prevents editing its version ID, parent, creation time, evidence cutoff or configuration. Activation cannot precede the cutoff. Only newly detected signals from `LIVE_OBSERVATION` at or after activation are admitted. Old signals are never replayed into V2.

Defaults: $25 gross BUY notional **excluding** entry fees; 5% minimum projected net ROI if the outcome wins; $1,000 virtual cash per wallet in this isolated simulation; 20 formally resolved episodes before a wallet is marked eligible for human review. The frozen config also includes 500 ms quote-to-execution latency, 3,000 ms book-age limit, full visible depth participation, one-shot partial fills, hold to formal resolution, and `live_orders=false`.

## V3 decision path

`strict-paper-engine-v3` walks observed asks in price order against a separate fresh execution snapshot. At each level it computes:

```text
invested_capital = gross_notional + entry_fee
net_profit_if_win = filled_quantity - invested_capital
net_roi_if_win = net_profit_if_win / invested_capital
```

The first level that would take aggregate ROI below the frozen floor is not consumed. Earlier valid levels become a terminal `PARTIALLY_FILLED` order; the unused reservation is released in the same ledger fill transaction. The engine rejects an unaffordable first level with `NET_ROI_BELOW_FLOOR`. No future settlement fee is guessed.

Market/token/outcome mismatch, closed or resolved market, orders not accepted, missing or stale execution evidence, invalid fee evidence, insufficient visible depth and insufficient cash still block fills. Legacy V0.x price movement, near-certainty, signal-delay, spread, end-time-semantic and time-to-end gates are absent from this V2 admission path. They remain historical records or analytics. V3 decision evidence preserves quote and execution books, timestamps, fee source and calculation, requested/filled/unfilled notional, consumed depth, projected ROI and frozen rule version.

## Directional research

`wallet_v2_versions`, `wallet_v2_episodes` and `wallet_v2_events` live only in the selected simulation database. A wallet and condition ID produce one first directional episode. Same-side later buys are `ADD_ON`; opposite-side buys are `REVERSAL`. Neither creates a second first-signal paper order or another directional win. A no-fill episode remains pending until an explicit authoritative formal result arrives. Market end time alone cannot settle it. Per-wallet results separate resolved directional accuracy from paper fills, realized paper P&L and pending outcomes. No automatic wallet promotion or deletion occurs.

Each wallet has its own isolated strict-paper account. The strategy and paper account are initialized only through explicit calls with a chosen database path. `execute_first` refuses to use a newer book after a persisted decision is found during recovery. If a decision was saved but its fill was not committed, it reports `RECOVERY_REQUIRED`; an operator must inspect the saved evidence instead of creating a retrospective fill.

## Current limits

This is an isolated Python API and schema, not a production scanner or dashboard feature. The first observed direction is the core sample even if a later reversal is correct. A void result does not invent a cash payout; it needs a later accounting policy before financial closure. The leader-to-EDGE price difference is available, while a fully comparable leader net ROI requires verified leader fees and execution evidence. Strategy review eligibility is a count threshold only; it never changes tracking automatically.
