"""Public local run selection shared by the server and one-click launcher."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
MANIFEST=ROOT/'data/active_experiment.json'

def active_run():
    if not MANIFEST.is_file():
        return {'run_id':'legacy-v2','label':'历史 V2 实验','database':'data/edge_mvp.db','started_at':None}
    data=json.loads(MANIFEST.read_text(encoding='utf-8'))
    path=(ROOT/data['database']).resolve()
    if path.parent!=(ROOT/'data').resolve() or not path.name.startswith('edge_forward_') or path.suffix!='.db':
        raise ValueError('INVALID_ACTIVE_EXPERIMENT_DATABASE')
    if data.get('live_orders') is not False:raise ValueError('LIVE_ORDERS_NOT_ALLOWED')
    return data

def active_database():return (ROOT/active_run()['database']).resolve()

def public_run(database_path=None):
    run=active_run()
    if database_path is not None and Path(database_path).resolve()!=active_database():
        return {'run_id':'UNBOUND','label':'运行库与选定实验不匹配','started_at':None,'live_orders':False,'archives':[]}
    return {key:run.get(key) for key in ('run_id','label','started_at','strategy_version','live_orders','archives','funding_model','fixed_initial_cash','funding_version')}
