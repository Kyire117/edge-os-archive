# Wallet Follow V2 — Iteration 2 review fixes

This opt-in implementation remains separate from the running Forward Copy V0.x service and production database. It has not been activated for live monitoring.

## Venue minimum order size

The V3 paper engine requires an observed, finite, non-negative venue minimum order size and its source. The Polymarket market normalization exposes `minimum_order_size` from `orderMinSize` and labels its source `Gamma.market.orderMinSize`. A caller must pass both fields into `MarketState` from the same observed market state; missing or malformed evidence fails closed as `INVALID_MINIMUM_ORDER_EVIDENCE`. After walking the actual execution asks and applying the ROI floor, a final quantity below that minimum is rejected as `BELOW_MINIMUM_ORDER`, with no financial fill. The directional episode remains in the research corpus. Legacy V2 engine decisions do not use this new gate.

## Forward evidence timeline

`evidence_cutoff <= created_at <= activated_at`. The cutoff is the latest historical evidence allowed to inform the frozen candidate. Observation admission still starts at `activated_at`; older signals cannot become forward observations. `activated_at` is immutable once set. A child version may name a completed parent, but does not import the parent's historical episodes as its own forward sample.

## Remaining decision before production activation

The first V2 experiment must freeze its depth participation, per-trade notional, and ROI threshold. The present config defaults to 100% visible-depth participation, $25 gross notional, and 5% minimum net ROI. These are opt-in defaults, not an activated production experiment.
